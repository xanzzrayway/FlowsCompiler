package com.example.veil

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var backend: GoBackend
    private lateinit var status: TextView
    private lateinit var msg: TextView
    private lateinit var power: Button
    private lateinit var input: EditText

    private var up = false
    private var busy = false

    // The tunnel handle WireGuard needs. The name is just a label.
    private val tunnel = object : Tunnel {
        override fun getName(): String = "veil"
        override fun onStateChange(newState: Tunnel.State) {
            runOnUiThread { up = newState == Tunnel.State.UP; render() }
        }
    }

    // Android shows its own "Connection request" dialog the first time.
    private val consent = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) startTunnel()
        else say("VPN permission was denied.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        backend = GoBackend(applicationContext)
        status = findViewById(R.id.status)
        msg = findViewById(R.id.msg)
        power = findViewById(R.id.power)
        input = findViewById(R.id.config)

        // Saved in the app's private storage only (not backed up, see manifest).
        val prefs = getSharedPreferences("veil", Context.MODE_PRIVATE)
        input.setText(prefs.getString("cfg", ""))

        power.setOnClickListener {
            if (busy) return@setOnClickListener
            if (up) {
                change(Tunnel.State.DOWN, null)
            } else {
                val text = input.text.toString().trim()
                if (text.isEmpty()) {
                    say("Paste your WireGuard config first.")
                    return@setOnClickListener
                }
                prefs.edit().putString("cfg", text).apply()
                val intent = VpnService.prepare(this)
                if (intent != null) consent.launch(intent) else startTunnel()
            }
        }
        render()
    }

    private fun startTunnel() {
        val config = try {
            Config.parse(input.text.toString().trim().byteInputStream())
        } catch (e: Exception) {
            say("Config problem: ${e.message}")
            return
        }
        change(Tunnel.State.UP, config)
    }

    // setState blocks while the tunnel starts, so it runs off the main thread.
    private fun change(target: Tunnel.State, config: Config?) {
        busy = true
        say("")
        render()
        thread {
            try {
                val result = backend.setState(tunnel, target, config)
                runOnUiThread { up = result == Tunnel.State.UP }
            } catch (e: Exception) {
                runOnUiThread { say("Could not change the connection: ${e.message}") }
            }
            runOnUiThread { busy = false; render() }
        }
    }

    private fun say(text: String) { msg.text = text }

    private fun render() {
        when {
            busy -> { status.text = "Working…"; power.text = "Please wait"; power.isEnabled = false }
            up -> {
                status.text = "Protected"
                status.setTextColor(Color.parseColor("#D9891A"))
                power.text = "Disconnect"; power.isEnabled = true
            }
            else -> {
                status.text = "Not protected"
                status.setTextColor(power.currentTextColor)
                power.text = "Connect"; power.isEnabled = true
            }
        }
    }
}
