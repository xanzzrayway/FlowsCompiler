# XOTA SYSTEM — Paket Backend + APK

## Isi Paket
- `index.html` — Frontend (sudah terhubung ke backend)
- `config.js` — Pengaturan URL backend
- `backend/server.js` — Backend API (Node.js, TANPA npm install)
- `backend/package.json`

## CARA KERJA
1. OWNER login (default: `FALLX` / `FALLX12`)
2. OWNER buat akun di menu **CREATE AKUN** → tersimpan di SERVER
3. SIAPA PUN bisa login dengan akun itu dari HP mana pun / APK mana pun
4. OWNER bisa ON/OFF fitur BUG WA untuk SEMUA user sekaligus
5. REQUEST user masuk ke OWNER secara real-time via server

---

## LANGKAH 1 — JALANKAN BACKEND

### Opsi A: Gratis di Render.com (paling mudah, tanpa kartu)
1. Buat akun di https://render.com
2. New → **Web Service** → connect repo/upload folder `backend`
3. Build Command: *(kosongkan)*
4. Start Command: `node server.js`
5. Deploy → salin URL yang muncul, contoh: `https://xota-api.onrender.com`

### Opsi B: VPS / Komputer sendiri
```bash
cd backend
node server.js
```
Backend jalan di `http://IP-KAMU:3000` (buka port 3000 di firewall).

### Opsi C: Termux (HP Android)
```bash
pkg install nodejs
cd backend
node server.js
```
(untuk tes lokal saja; untuk publik tetap butuh hosting)

## LANGKAH 2 — SET BACKEND_URL
Edit `config.js`:
```js
const BACKEND_URL = "https://xota-api.onrender.com";   // ganti punya kamu
```

## LANGKAH 3 — TES
- Buka `https://xota-api.onrender.com/api/health` di browser → muncul JSON `{"ok":true,...}`
- Login OWNER → CREATE AKUN → coba login akun baru di HP lain ✅

---

## LANGKAH 4 — BUAT APK (Capacitor)

### Persyaratan: install dulu
- **Node.js** dari https://nodejs.org
- **Android Studio** dari https://developer.android.com/studio
- **Java JDK 17**

### Perintah (di folder `xota-apk`)
```bash
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android
mkdir www
copy index.html wwwcopy config.js wwwnpx cap init "XOTA" com.xota.app --web-dir=www
npx cap add android
npx cap sync
npx cap open android
```
Di Android Studio: **Build → Build APK(s)** → APK jadi di
`android/app/build/outputs/apk/debug/app-debug.apk`

### Alternatif tanpa Android Studio (Web2APK)
Kalau tidak mau install Android Studio, bisa pakai layanan WebView APK online
(Website 2 APK, AppsGeyser, dll) — masukkan URL frontend yang sudah di-host,
atau file HTML. Tapi Capacitor tetap yang terbaik (offline support + cache login).

### Catatan penting APK
- APK wajib punya **internet** (backend di-hosting online)
- Di `config.js`, `BACKEND_URL` harus **https** (bukan http) supaya tidak diblokir Android
- Login terakhir tersimpan cache — user tetap bisa buka APK walau sinyal putus sebentar

---

## KEAMANAN (WAJIB DIBACA)
1. **GANTI password OWNER** setelah login pertama: edit `backend/data.json`,
   ubah `"password": "FALLX12"` → password baru, restart server.
2. Jangan pernah upload `data.json` ke publik.
3. Backend ini sederhana (tanpa database). Untuk produksi besar,
   migrasi ke MongoDB/PostgreSQL disarankan.

## TROUBLESHOOTING
| Masalah | Solusi |
|---|---|
| Login "Tidak bisa terhubung ke server" | Cek `BACKEND_URL` di config.js & pastikan backend jalan |
| "Akun EXPIRED" | Akun lewat masa berlaku, owner buatkan lagi |
| Request tidak masuk | Pastikan user & owner sama-sama pakai backend URL yang sama |
