// ============================================================
//  KONFIGURASI BACKEND XOTA
//  Ganti dengan URL backend kamu setelah deploy (lihat README_APK.md)
//  Contoh hasil deploy gratis di Render:
//      const BACKEND_URL = "https://xota-api.onrender.com";
// ============================================================
const BACKEND_URL = "http://localhost:3000";
