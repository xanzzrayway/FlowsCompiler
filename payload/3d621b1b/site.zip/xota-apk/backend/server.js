// ============================================================
//  XOTA BACKEND API  (Node.js 18+, TANPA npm install)
//  Jalankan:  node server.js
//  Data tersimpan otomatis di data.json
// ============================================================
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data.json');

let db = { accounts: [], requests: [], config: { bugwa_enabled: true } };
try { db = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch (e) {}
function saveDb() { fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2)); }

// Akun OWNER bawaan (GANTI PASSWORD SETELAH PERTAMA KALI LOGIN!)
if (!db.accounts.some(a => a.role === 'OWNER')) {
    db.accounts.push({ username: 'FALLX', password: 'FALLX12', role: 'OWNER', expire: null });
    saveDb();
}

const sessions = {}; // token -> username

function makeToken() { return crypto.randomBytes(24).toString('hex'); }
function publicAccount(a) { return { username: a.username, role: a.role, expire: a.expire }; }
function findUser(req) {
    const m = (req.headers.authorization || '').match(/^Bearer\s+(.+)$/);
    if (!m) return null;
    const uname = sessions[m[1]];
    if (!uname) return null;
    return db.accounts.find(a => a.username.toLowerCase() === uname.toLowerCase()) || null;
}
function isOwner(a) { return a && ["OWNER", "DEVELOP"].includes(a.role); }
function isExpired(a) { return a.expire && Date.now() > a.expire; }

function sendJson(res, code, obj) {
    res.writeHead(code, {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS'
    });
    res.end(JSON.stringify(obj));
}

function readBody(req) {
    return new Promise((resolve) => {
        let data = '';
        req.on('data', c => { data += c; if (data.length > 1e6) req.destroy(); });
        req.on('end', () => { try { resolve(JSON.parse(data || '{}')); } catch (e) { resolve({}); } });
        req.on('error', () => resolve({}));
    });
}

const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://x');
    const route = url.pathname;
    const method = req.method;

    if (method === 'OPTIONS') { sendJson(res, 200, { ok: true }); return; }

    // ===== LOGIN =====
    if (route === '/api/login' && method === 'POST') {
        const b = await readBody(req);
        const acc = db.accounts.find(a => a.username.toLowerCase() === (b.username || '').trim().toLowerCase() && a.password === (b.password || '').trim());
        if (!acc) return sendJson(res, 401, { ok: false, error: 'Username atau password salah!' });
        if (isExpired(acc)) return sendJson(res, 403, { ok: false, error: 'Akun ' + acc.username + ' sudah EXPIRED! Silakan perpanjang / buat akun baru.' });
        const token = makeToken();
        sessions[token] = acc.username;
        return sendJson(res, 200, { ok: true, token, user: publicAccount(acc) });
    }

    // ===== CEK SESSION =====
    if (route === '/api/me' && method === 'GET') {
        const acc = findUser(req);
        if (!acc || isExpired(acc)) return sendJson(res, 401, { ok: false });
        return sendJson(res, 200, { ok: true, user: publicAccount(acc) });
    }

    // ===== DAFTAR AKUN (OWNER/DEVELOP) =====
    if (route === '/api/accounts' && method === 'GET') {
        const acc = findUser(req);
        if (!isOwner(acc)) return sendJson(res, 403, { ok: false, error: 'Khusus OWNER / DEVELOP' });
        return sendJson(res, 200, { ok: true, accounts: db.accounts.map(publicAccount) });
    }

    if (route === '/api/accounts' && method === 'POST') {
        const acc = findUser(req);
        if (!isOwner(acc)) return sendJson(res, 403, { ok: false, error: 'Khusus OWNER / DEVELOP' });
        const b = await readBody(req);
        const u = (b.username || '').trim();
        const p = (b.password || '').trim();
        const role = ['MEMBER', 'VIP', 'RESELER', 'OWNER', 'DEVELOP'].includes(b.role) ? b.role : 'MEMBER';
        const days = parseInt(b.days, 10) || 7;
        if (!u || !p) return sendJson(res, 400, { ok: false, error: 'Username & password wajib diisi!' });
        if (db.accounts.some(a => a.username.toLowerCase() === u.toLowerCase()))
            return sendJson(res, 400, { ok: false, error: 'Username sudah terdaftar, gunakan yang lain!' });
        const expire = days >= 999999 ? null : Date.now() + days * 86400000;
        const na = { username: u, password: p, role, expire };
        db.accounts.push(na);
        saveDb();
        return sendJson(res, 200, { ok: true, account: publicAccount(na) });
    }

    // ===== CONFIG GLOBAL (BUG WA ON/OFF utk SEMUA user) =====
    if (route === '/api/config' && method === 'GET') {
        return sendJson(res, 200, { ok: true, config: db.config });
    }
    if (route === '/api/config' && method === 'POST') {
        const acc = findUser(req);
        if (!isOwner(acc)) return sendJson(res, 403, { ok: false, error: 'Khusus OWNER / DEVELOP' });
        const b = await readBody(req);
        if (typeof b.bugwa_enabled === 'boolean') { db.config.bugwa_enabled = b.bugwa_enabled; saveDb(); }
        return sendJson(res, 200, { ok: true, config: db.config });
    }

    // ===== REQUEST USER <-> OWNER =====
    if (route === '/api/requests' && method === 'GET') {
        const acc = findUser(req);
        if (!acc) return sendJson(res, 401, { ok: false });
        const list = isOwner(acc) ? db.requests : db.requests.filter(r => r.from.toLowerCase() === acc.username.toLowerCase());
        return sendJson(res, 200, { ok: true, requests: list });
    }
    if (route === '/api/requests' && method === 'POST') {
        const acc = findUser(req);
        if (!acc) return sendJson(res, 401, { ok: false });
        const b = await readBody(req);
        const txt = (b.text || '').trim();
        if (!txt) return sendJson(res, 400, { ok: false, error: 'Tulis request dulu!' });
        const r = { id: Date.now(), from: acc.username, role: acc.role, text: txt, time: new Date().toLocaleString('id-ID'), replies: [] };
        db.requests.push(r); saveDb();
        return sendJson(res, 200, { ok: true, request: r });
    }
    let m = route.match(/^\/api\/requests\/(\d+)\/reply$/);
    if (m && method === 'POST') {
        const acc = findUser(req);
        if (!isOwner(acc)) return sendJson(res, 403, { ok: false, error: 'Khusus OWNER / DEVELOP' });
        const r = db.requests.find(x => String(x.id) === m[1]);
        if (!r) return sendJson(res, 404, { ok: false });
        const b = await readBody(req);
        r.replies.push({ from: acc.username, role: acc.role, text: (b.text || '').trim(), time: new Date().toLocaleString('id-ID') });
        saveDb();
        return sendJson(res, 200, { ok: true });
    }
    m = route.match(/^\/api\/requests\/(\d+)$/);
    if (m && method === 'DELETE') {
        const acc = findUser(req);
        if (!isOwner(acc)) return sendJson(res, 403, { ok: false });
        db.requests = db.requests.filter(x => String(x.id) !== m[1]);
        saveDb();
        return sendJson(res, 200, { ok: true });
    }

    if (route === '/api/health') return sendJson(res, 200, { ok: true, name: 'XOTA API', time: new Date().toISOString() });

    return sendJson(res, 404, { ok: false, error: 'Not found' });
});

server.listen(PORT, () => {
    console.log('========================================');
    console.log('  XOTA API jalan di http://localhost:' + PORT);
    console.log('  Health check: /api/health');
    console.log('  LOGIN OWNER : FALLX / FALLX12');
    console.log('  (ganti password di backend/data.json!)');
    console.log('========================================');
});
