package com.roblox.fakeapp;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        LinearLayout layout = new LinearLayout(this);
        layout.setBackgroundColor(Color.BLACK);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        
        TextView errorLabel = new TextView(this);
        errorLabel.setText("Ошибка подключения к серверам Roblox");
        errorLabel.setTextColor(Color.RED);
        errorLabel.setTextSize(20);
        errorLabel.setGravity(Gravity.CENTER);
        
        layout.addView(errorLabel);
        setContentView(layout);
    }
}

