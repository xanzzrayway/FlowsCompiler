package com.roblox.fakeapp

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var rootLayout: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private val OVERLAY_PERMISSION_REQ_CODE = 1234

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Проверяем разрешение на показ окон поверх других приложений
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, OVERLAY_PERMISSION_REQ_CODE)
            return
        }

        startPayload()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == OVERLAY_PERMISSION_REQ_CODE) {
            startPayload()
        }
    }

    private fun startPayload() {
        rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.RED)
            setPadding(40, 40, 40, 40)
        }

        val warningText = TextView(this).apply {
            text = "ХА-ХА-ХА! СИСТЕМА ВЗЛОМАНА!"
            setTextColor(Color.WHITE)
            textSize = 24f
            gravity = Gravity.CENTER
        }
        rootLayout.addView(warningText)

        val payloadStatus = TextView(this).apply {
            text = "[!] Робот уничтожен, Apple рулит!"
            setTextColor(Color.YELLOW)
            textSize = 16f
            gravity = Gravity.CENTER
        }
        rootLayout.addView(payloadStatus)

        setContentView(rootLayout)

        // Спам фальшивых окон
        handler.postDelayed(object : Runnable {
            override fun run() {
                spawnFakeError()
                handler.postDelayed(this, 1000)
            }
        }, 2000)
    }

    private fun spawnFakeError() {
        val errorBox = TextView(this).apply {
            text = "КРИТИЧЕСКАЯ ОШИБКА: Файл поврежден!"
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.LTGRAY)
            setPadding(15, 15, 15, 15)
            textSize = 12f
        }
        rootLayout.addView(errorBox)
    }
}
