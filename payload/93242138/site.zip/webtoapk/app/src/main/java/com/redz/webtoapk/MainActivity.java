package com.redz.webtoapk;

import android.app.AlertDialog;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText htmlEditor;
    private Button previewButton;
    private Button buildButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        htmlEditor = findViewById(R.id.htmlEditor);
        previewButton = findViewById(R.id.previewButton);
        buildButton = findViewById(R.id.buildButton);

        htmlEditor.setText(getStarterHtml());

        previewButton.setOnClickListener(view -> {
            showPreview(htmlEditor.getText().toString());
        });

        buildButton.setOnClickListener(view -> {
            generateProject(htmlEditor.getText().toString());
        });
    }

    private void showPreview(String html) {

        WebView webView = new WebView(this);

        WebSettings settings = webView.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);

        webView.setWebViewClient(new WebViewClient());

        webView.loadDataWithBaseURL(
                null,
                html,
                "text/html",
                "UTF-8",
                null
        );

        new AlertDialog.Builder(this)
                .setTitle("APK Preview")
                .setView(webView)
                .setPositiveButton("Tutup", null)
                .show();
    }

    private void generateProject(String html) {

        /*
         * Versi ini menghasilkan template HTML yang siap
         * dimasukkan ke project Android WebView.
         *
         * Kompilasi APK dilakukan oleh AIDE/Gradle.
         */

        String project = createAndroidTemplate(html);

        new AlertDialog.Builder(this)
                .setTitle("Project Generated")
                .setMessage(project)
                .setPositiveButton("OK", null)
                .show();

        Toast.makeText(
                this,
                "Template project berhasil dibuat",
                Toast.LENGTH_SHORT
        ).show();
    }

    private String createAndroidTemplate(String html) {

        return
                "WEB TO APK PROJECT\n\n" +
                "Generated successfully.\n\n" +
                "HTML length: " +
                html.length() +
                " characters\n\n" +
                "Target: Android WebView";
    }

    private String getStarterHtml() {

        return """
<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0">

<title>My APK</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    min-height: 100vh;

    display: flex;
    align-items: center;
    justify-content: center;

    font-family: Arial, sans-serif;

    background: #101827;
    color: white;
}

.card {
    width: 90%;
    max-width: 420px;

    padding: 30px;

    text-align: center;

    border-radius: 20px;

    background: #1d2939;

    box-shadow:
        0 20px 50px
        rgba(0, 0, 0, 0.4);
}

button {
    padding: 12px 20px;

    border: 0;
    border-radius: 10px;

    background: #38bdf8;
    color: #082f49;

    font-weight: bold;
}

</style>

</head>

<body>

<div class="card">

    <h1>APK Gue</h1>

    <p id="text">
        Dibuat dengan HTML + CSS + JavaScript.
    </p>

    <button onclick="ubahText()">
        Klik
    </button>

</div>

<script>

function ubahText() {

    document.getElementById("text").textContent =
        "ABSOLUTE KODE — JavaScript jalan!";

}

</script>

</body>

</html>
""";
    }
}