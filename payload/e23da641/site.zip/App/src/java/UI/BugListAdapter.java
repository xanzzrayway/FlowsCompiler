package com.droid.bug.UI;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.droid.bug.MainActivity;
import com.droid.bug.R;
import com.google.android.material.switchmaterial.SwitchMaterial;
import java.util.List;

public class BugListAdapter extends RecyclerView.Adapter<BugListAdapter.ViewHolder> {

    private final List<MainActivity.BugItem> list;

    public BugListAdapter(List<MainActivity.BugItem> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_bug, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        MainActivity.BugItem item = list.get(position);
        h.tvName.setText(item.name);
        h.tvDesc.setText(item.desc);
        h.switchBug.setChecked(item.enabled);
        h.switchBug.setOnCheckedChangeListener((btn, checked) -> item.enabled = checked);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvDesc;
        SwitchMaterial switchBug;

        ViewHolder(View v) {
            super(v);
            tvName = v.findViewById(R.id.tvBugName);
            tvDesc = v.findViewById(R.id.tvBugDesc);
            switchBug = v.findViewById(R.id.switchBug);
        }
    }
}