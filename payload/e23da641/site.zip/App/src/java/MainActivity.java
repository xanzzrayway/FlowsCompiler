package com.droid.bug;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.droid.bug.UI.BugListAdapter;
import com.droid.bug.utils.FontHelper;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvBugs;
    private BugListAdapter adapter;
    private MaterialButton btnTarget, btnLaunch;
    private String targetNumber = "";
    private List<BugItem> bugList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FontHelper.applyFonts(this);

        rvBugs = findViewById(R.id.rvBugs);
        btnTarget = findViewById(R.id.btnTarget);
        btnLaunch = findViewById(R.id.btnLaunch);

        setupBugs();
        setupRecycler();
        setupButtons();
    }

    private void setupBugs() {
        bugList.add(new BugItem("Crash Force", "Force close WhatsApp target", true));
        bugList.add(new BugItem("Freeze Chat", "Freeze chat permanently", true));
        bugList.add(new BugItem("Blank Message", "Kirim pesan kosong tak terbaca", false));
        bugList.add(new BugItem("Media Crash", "Crash saat buka media", true));
        bugList.add(new BugItem("Status Bug", "Rusak status viewer", false));
        bugList.add(new BugItem("Group Destroyer", "Crash group + member", true));
        bugList.add(new BugItem("Contact Spam", "Spam contact invisible", false));
        bugList.add(new BugItem("Typing Loop", "Infinite typing indicator", false));
        bugList.add(new BugItem("Last Seen Freeze", "Freeze last seen", false));
        bugList.add(new BugItem("Full Wipe", "Combo all payload", true));
    }

    private void setupRecycler() {
        adapter = new BugListAdapter(bugList);
        rvBugs.setLayoutManager(new LinearLayoutManager(this));
        rvBugs.setAdapter(adapter);
    }

    private void setupButtons() {
        btnTarget.setOnClickListener(v -> showTargetDialog());
        btnLaunch.setOnClickListener(v -> launchBugs());
    }

    private void showTargetDialog() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this, R.style.Theme_Droid);
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setHint("628xxxxxxxxxx");
        input.setTextColor(getColor(R.color.text_primary));
        input.setHintTextColor(getColor(R.color.text_secondary));
        input.setBackgroundColor(getColor(R.color.bg_card));
        input.setPadding(40, 30, 40, 30);

        builder.setTitle("Set Target Number")
                .setView(input)
                .setPositiveButton("SAVE", (d, w) -> {
                    targetNumber = input.getText().toString().trim();
                    if (!targetNumber.isEmpty()) {
                        Toast.makeText(this, "Target: " + targetNumber, Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("CANCEL", null)
                .show();
    }

    private void launchBugs() {
        if (targetNumber.isEmpty()) {
            Toast.makeText(this, "Set target dulu", Toast.LENGTH_SHORT).show();
            return;
        }

        List<String> active = new ArrayList<>();
        for (BugItem item : bugList) {
            if (item.enabled) active.add(item.name);
        }

        if (active.isEmpty()) {
            Toast.makeText(this, "Pilih minimal 1 bug", Toast.LENGTH_SHORT).show();
            return;
        }

        BugEngine engine = new BugEngine(this);
        engine.execute(targetNumber, active);
    }

    public static class BugItem {
        public String name;
        public String desc;
        public boolean enabled;

        public BugItem(String name, String desc, boolean enabled) {
            this.name = name;
            this.desc = desc;
            this.enabled = enabled;
        }
    }
}