package com.droid.bug.utils;

import android.app.Activity;
import android.graphics.Typeface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class FontHelper {

    public static void applyFonts(Activity activity) {
        Typeface bold = Typeface.createFromAsset(activity.getAssets(), "font/poppins_bold.ttf");
        Typeface medium = Typeface.createFromAsset(activity.getAssets(), "font/poppins_medium.ttf");
        applyToView(activity.findViewById(android.R.id.content), bold, medium);
    }

    private static void applyToView(View view, Typeface bold, Typeface medium) {
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                applyToView(group.getChildAt(i), bold, medium);
            }
        } else if (view instanceof TextView) {
            TextView tv = (TextView) view;
            if (tv.getTypeface() != null && tv.getTypeface().isBold()) {
                tv.setTypeface(bold);
            } else {
                tv.setTypeface(medium);
            }
        }
    }
}