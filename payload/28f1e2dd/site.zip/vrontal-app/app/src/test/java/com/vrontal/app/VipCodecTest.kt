package com.vrontal.app

import com.vrontal.app.ui.features.encryption.CodecResult
import com.vrontal.app.ui.features.encryption.VipCodec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class VipCodecTest {

    private fun ok(r: CodecResult): String = (r as CodecResult.Ok).value

    @Test fun binary_A() = assertEquals("01000001", ok(VipCodec.textToBinary("A")))

    @Test fun binary_roundTrip_unicode() {
        val text = "Halo Dunia! Ünï 你好 🙂"
        assertEquals(text, ok(VipCodec.binaryToText(ok(VipCodec.textToBinary(text)))))
    }

    @Test fun binary_acceptsNoSpaces() =
        assertEquals("Hi", ok(VipCodec.binaryToText("0100100001101001")))

    @Test fun binary_rejectsBadLength() =
        assertTrue(VipCodec.binaryToText("0100") is CodecResult.Error)

    @Test fun binary_rejectsNonBinary() =
        assertTrue(VipCodec.binaryToText("0102") is CodecResult.Error)

    @Test fun binary_rejectsInvalidUtf8() =
        assertTrue(VipCodec.binaryToText("11111111") is CodecResult.Error)

    @Test fun morse_sos() = assertEquals("... --- ...", ok(VipCodec.textToMorse("sos")))

    @Test fun morse_words() =
        assertEquals(".... .. / -.. .. ...- .", ok(VipCodec.textToMorse("hi dive")))

    @Test fun morse_roundTrip() {
        val text = "SAYA BELAJAR 123, OK?"
        assertEquals(text, ok(VipCodec.morseToText(ok(VipCodec.textToMorse(text)))))
    }

    @Test fun morse_decodeAltSymbols() =
        assertEquals("SOS", ok(VipCodec.morseToText("··· −−− ···")))

    @Test fun morse_unsupportedChar() =
        assertTrue(VipCodec.textToMorse("halo ~") is CodecResult.Error)

    @Test fun morse_unknownCode() =
        assertTrue(VipCodec.morseToText(".-.-.-.-.-") is CodecResult.Error)

    @Test fun empty_isOk() {
        assertEquals("", ok(VipCodec.textToBinary("")))
        assertEquals("", ok(VipCodec.textToMorse("")))
        assertEquals("", ok(VipCodec.morseToText("")))
        assertEquals("", ok(VipCodec.binaryToText("")))
    }
}
