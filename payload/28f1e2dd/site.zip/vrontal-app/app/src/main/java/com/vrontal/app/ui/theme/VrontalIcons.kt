package com.vrontal.app.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Ikon custom gaya garis (stroke), gantinya material-icons-extended.
 * Alasan: extended membawa ribuan ikon (beberapa MB) padahal cuma ~10 yang dipakai —
 * bertentangan dengan target ringan di HP spek rendah. Ini cuma 10 vector kecil,
 * dan sekaligus jadi identitas visual sendiri, bukan ikon generik.
 *
 * Semua digambar di kanvas 24x24 dengan gaya stroke (bukan fill), stroke width 2.
 */
private fun strokeIcon(name: String, block: androidx.compose.ui.graphics.vector.PathBuilder.() -> Unit): ImageVector =
    ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).path(
        fill = null,
        stroke = SolidColor(Color.Black), // warna sebenarnya diberikan lewat tint saat Icon() dipakai
        strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
        pathFillType = PathFillType.NonZero,
        pathBuilder = block,
    ).build()

object VrontalIcons {

    val ArrowBack: ImageVector = strokeIcon("ArrowBack") {
        moveTo(19f, 12f); lineTo(5f, 12f)
        moveTo(11f, 6f); lineTo(5f, 12f); lineTo(11f, 18f)
    }

    val Menu: ImageVector = strokeIcon("Menu") {
        moveTo(4f, 7f); lineTo(20f, 7f)
        moveTo(4f, 12f); lineTo(20f, 12f)
        moveTo(4f, 17f); lineTo(20f, 17f)
    }

    val ChevronDown: ImageVector = strokeIcon("ChevronDown") {
        moveTo(6f, 9f); lineTo(12f, 15f); lineTo(18f, 9f)
    }

    val Eye: ImageVector = strokeIcon("Eye") {
        moveTo(2f, 12f)
        curveTo(2f, 12f, 6f, 5f, 12f, 5f)
        curveTo(18f, 5f, 22f, 12f, 22f, 12f)
        curveTo(22f, 12f, 18f, 19f, 12f, 19f)
        curveTo(6f, 19f, 2f, 12f, 2f, 12f)
        close()
        moveTo(12f, 15f)
        curveTo(13.6569f, 15f, 15f, 13.6569f, 15f, 12f)
        curveTo(15f, 10.3431f, 13.6569f, 9f, 12f, 9f)
        curveTo(10.3431f, 9f, 9f, 10.3431f, 9f, 12f)
        curveTo(9f, 13.6569f, 10.3431f, 15f, 12f, 15f)
        close()
    }

    val EyeOff: ImageVector = strokeIcon("EyeOff") {
        moveTo(2f, 12f)
        curveTo(2f, 12f, 6f, 5f, 12f, 5f)
        curveTo(18f, 5f, 22f, 12f, 22f, 12f)
        curveTo(22f, 12f, 18f, 19f, 12f, 19f)
        curveTo(6f, 19f, 2f, 12f, 2f, 12f)
        close()
        moveTo(9.5f, 9.5f)
        curveTo(8.87f, 10.13f, 8.5f, 11f, 8.5f, 12f)
        curveTo(8.5f, 13.933f, 10.067f, 15.5f, 12f, 15.5f)
        curveTo(13f, 15.5f, 13.87f, 15.13f, 14.5f, 14.5f)
        moveTo(3f, 3f); lineTo(21f, 21f)
    }

    val Lock: ImageVector = strokeIcon("Lock") {
        moveTo(6f, 11f); lineTo(18f, 11f); lineTo(18f, 21f); lineTo(6f, 21f); close()
        moveTo(8f, 11f); lineTo(8f, 7f)
        curveTo(8f, 4.7909f, 9.7909f, 3f, 12f, 3f)
        curveTo(14.2091f, 3f, 16f, 4.7909f, 16f, 7f)
        lineTo(16f, 11f)
    }

    val Calendar: ImageVector = strokeIcon("Calendar") {
        moveTo(4f, 5f); lineTo(20f, 5f); lineTo(20f, 21f); lineTo(4f, 21f); close()
        moveTo(4f, 10f); lineTo(20f, 10f)
        moveTo(8f, 3f); lineTo(8f, 7f)
        moveTo(16f, 3f); lineTo(16f, 7f)
        moveTo(8.5f, 15f); lineTo(11f, 17.5f); lineTo(16f, 12.5f)
    }

    val Info: ImageVector = strokeIcon("Info") {
        moveTo(12f, 21f)
        curveTo(16.9706f, 21f, 21f, 16.9706f, 21f, 12f)
        curveTo(21f, 7.0294f, 16.9706f, 3f, 12f, 3f)
        curveTo(7.0294f, 3f, 3f, 7.0294f, 3f, 12f)
        curveTo(3f, 16.9706f, 7.0294f, 21f, 12f, 21f)
        close()
        moveTo(12f, 11f); lineTo(12f, 16f)
        moveTo(12f, 7.5f); lineTo(12f, 7.6f)
    }

    val Globe: ImageVector = strokeIcon("Globe") {
        moveTo(12f, 21f)
        curveTo(16.9706f, 21f, 21f, 16.9706f, 21f, 12f)
        curveTo(21f, 7.0294f, 16.9706f, 3f, 12f, 3f)
        curveTo(7.0294f, 3f, 3f, 7.0294f, 3f, 12f)
        curveTo(3f, 16.9706f, 7.0294f, 21f, 12f, 21f)
        close()
        moveTo(3f, 12f); lineTo(21f, 12f)
        moveTo(12f, 3f)
        curveTo(14.5f, 5.7f, 15.8f, 8.8f, 15.8f, 12f)
        curveTo(15.8f, 15.2f, 14.5f, 18.3f, 12f, 21f)
        curveTo(9.5f, 18.3f, 8.2f, 15.2f, 8.2f, 12f)
        curveTo(8.2f, 8.8f, 9.5f, 5.7f, 12f, 3f)
        close()
    }

    val Bot: ImageVector = strokeIcon("Bot") {
        moveTo(7f, 9f); lineTo(17f, 9f); lineTo(17f, 19f); lineTo(7f, 19f); close()
        moveTo(12f, 9f); lineTo(12f, 5f)
        moveTo(9.5f, 5f); lineTo(14.5f, 5f)
        moveTo(10.2f, 13f); lineTo(10.2f, 14.2f)
        moveTo(13.8f, 13f); lineTo(13.8f, 14.2f)
        moveTo(4f, 12f); lineTo(7f, 12f)
        moveTo(17f, 12f); lineTo(20f, 12f)
        moveTo(9.5f, 16.5f); lineTo(14.5f, 16.5f)
    }

    val Box: ImageVector = strokeIcon("Box") {
        moveTo(12f, 3f); lineTo(20f, 7.5f); lineTo(20f, 16.5f); lineTo(12f, 21f); lineTo(4f, 16.5f); lineTo(4f, 7.5f); close()
        moveTo(4f, 7.5f); lineTo(12f, 12f); lineTo(20f, 7.5f)
        moveTo(12f, 12f); lineTo(12f, 21f)
    }
}
