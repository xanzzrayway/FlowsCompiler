package com.vrontal.app.ui.features.credit

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.vrontal.app.ui.components.FeatureScaffold
import com.vrontal.app.ui.components.glass
import com.vrontal.app.ui.theme.VrontalCyan
import com.vrontal.app.ui.theme.VrontalGold
import com.vrontal.app.ui.theme.VrontalTextMuted
import com.vrontal.app.ui.theme.VrontalTextPrimary

private sealed interface CreditEntry {
    data class Person(val name: String, val role: String) : CreditEntry
    data class Heading(val text: String) : CreditEntry
    data class Community(val name: String) : CreditEntry
    data class Stat(val label: String, val value: String) : CreditEntry
    data class Footer(val text: String) : CreditEntry
}

private val entries: List<CreditEntry> = listOf(
    CreditEntry.Person("DTM", "ADMIN"),
    CreditEntry.Person("FAIS", "OWNER"),
    CreditEntry.Person("ZIO", "TEAM"),
    CreditEntry.Person("OZI", "TEAM"),
    CreditEntry.Heading("DAN KOMUNITAS SUPPORT"),
    CreditEntry.Community("XVIPFUROM"),
    CreditEntry.Community("GEMERcreaking"),
    CreditEntry.Community("aDi™Om"),
    CreditEntry.Community("Anti∆Masak"),
    CreditEntry.Community("iKal™Cup"),
    CreditEntry.Stat("WA GRUP", "395 ANGGOTA ✓"),
    CreditEntry.Stat("SALURAN", "1402 ANGGOTA ✓"),
    CreditEntry.Footer("MADE COPY 2026 ISPIRASION"),
    CreditEntry.Footer("TEAM Gabungan komunitas"),
)

@Composable
fun CreditScreen(onBack: () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }

    FeatureScaffold(title = "Credit", onBack = onBack) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            entries.forEachIndexed { index, entry ->
                // Muncul berurutan satu per satu: geser naik + memudar masuk, jeda 130 ms per baris.
                AnimatedVisibility(
                    visible = visible,
                    enter = fadeIn(tween(600, delayMillis = index * 130)) +
                        slideInVertically(tween(600, delayMillis = index * 130)) { it / 2 },
                ) {
                    when (entry) {
                        is CreditEntry.Person -> Row(
                            Modifier.fillMaxWidth().glass().padding(horizontal = 20.dp, vertical = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(entry.name, style = MaterialTheme.typography.titleLarge, color = VrontalTextPrimary)
                            Text(entry.role, style = MaterialTheme.typography.labelMedium, color = VrontalGold)
                        }
                        is CreditEntry.Heading -> Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
                            Text(
                                entry.text,
                                style = MaterialTheme.typography.titleMedium,
                                color = VrontalCyan,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                        is CreditEntry.Community -> Text(
                            entry.name,
                            style = MaterialTheme.typography.titleMedium,
                            color = VrontalTextPrimary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().glass().padding(vertical = 14.dp),
                        )
                        is CreditEntry.Stat -> Row(
                            Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(entry.label, style = MaterialTheme.typography.labelMedium, color = VrontalTextMuted)
                            Text(entry.value, style = MaterialTheme.typography.labelMedium, color = VrontalGold)
                        }
                        is CreditEntry.Footer -> Text(
                            entry.text,
                            style = MaterialTheme.typography.labelMedium,
                            color = VrontalTextMuted,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}
