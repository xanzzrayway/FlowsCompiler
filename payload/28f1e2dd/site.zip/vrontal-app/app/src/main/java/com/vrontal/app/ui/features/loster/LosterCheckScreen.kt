package com.vrontal.app.ui.features.loster

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vrontal.app.data.loster.AttendanceStatus
import com.vrontal.app.ui.components.FeatureScaffold
import com.vrontal.app.ui.components.SegmentRow
import com.vrontal.app.ui.components.glass
import com.vrontal.app.ui.theme.VrontalCyan
import com.vrontal.app.ui.theme.VrontalDanger
import com.vrontal.app.ui.theme.VrontalGlassBorder
import com.vrontal.app.ui.theme.VrontalGold
import com.vrontal.app.ui.theme.VrontalTextMuted
import com.vrontal.app.ui.theme.VrontalTextPrimary

private val monthShort = listOf(
    "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des",
)

/**
 * Layar "Check Alpha" / "Check Hadir" dari menu titik tiga Loster Legal.
 * [mode] = "alpha" atau "hadir". Isinya sama persis, cuma status yang dihitung yang beda —
 * sesuai catatan alur aslinya: "fitur 2 itu sebalik ya" (kebalikan dari fitur 1).
 */
@Composable
fun LosterCheckScreen(mode: String, onBack: () -> Unit) {
    val vm: LosterViewModel = viewModel()
    val targetStatus = if (mode == "hadir") AttendanceStatus.HADIR else AttendanceStatus.ALPHA
    val title = if (mode == "hadir") "Check Hadir" else "Check Alpha"
    val accent = if (mode == "hadir") VrontalCyan else VrontalDanger

    var viewMode by remember { mutableIntStateOf(0) } // 0 = Bulan, 1 = Tahun

    val monthRecords by vm.monthRecords.collectAsState()
    val yearCounts by vm.yearMonthCounts.collectAsState()
    val year by vm.selectedYear.collectAsState()
    val month by vm.selectedMonth.collectAsState()

    FeatureScaffold(title = title, onBack = onBack) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            SegmentRow(options = listOf("Bulan", "Tahun"), selectedIndex = viewMode, onSelect = { viewMode = it })
            Spacer(Modifier.height(14.dp))

            if (viewMode == 0) {
                // --- Per hari: total untuk bulan yang sedang dipilih ---
                Row(
                    Modifier.fillMaxWidth().glass().padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    OutlinedButton(onClick = {
                        if (month == 1) { vm.setYear(year - 1); vm.setMonth(12) } else vm.setMonth(month - 1)
                    }) { Text("‹", color = VrontalGold) }
                    Text("${monthNamesFull[month - 1]} $year", style = MaterialTheme.typography.titleMedium, color = VrontalTextPrimary)
                    OutlinedButton(onClick = {
                        if (month == 12) { vm.setYear(year + 1); vm.setMonth(1) } else vm.setMonth(month + 1)
                    }) { Text("›", color = VrontalGold) }
                }
                Spacer(Modifier.height(14.dp))
                val total = monthRecords.count { it.status == targetStatus }
                Column(
                    Modifier.fillMaxWidth().glass().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("$total", style = MaterialTheme.typography.displaySmall, color = accent)
                    Text(
                        "Total ${title.substringAfter(" ")} bulan ${monthNamesFull[month - 1]}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = VrontalTextMuted,
                    )
                }
            } else {
                // --- Per bulan: rekap semua bulan di tahun yang dipilih, total di kanan ---
                Row(
                    Modifier.fillMaxWidth().glass().padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    OutlinedButton(onClick = { vm.setYear(year - 1) }) { Text("‹", color = VrontalGold) }
                    Text("Tahun $year", style = MaterialTheme.typography.titleMedium, color = VrontalTextPrimary)
                    OutlinedButton(onClick = { vm.setYear(year + 1) }) { Text("›", color = VrontalGold) }
                }
                Spacer(Modifier.height(14.dp))
                Column(Modifier.fillMaxWidth().glass()) {
                    yearCounts.forEachIndexed { i, mc ->
                        if (i > 0) HorizontalDivider(color = VrontalGlassBorder)
                        val value = if (mode == "hadir") mc.hadir else mc.alpha
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(monthShort[mc.month - 1], color = VrontalTextPrimary)
                            Text("$value", color = accent, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                    HorizontalDivider(color = VrontalGlassBorder)
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text("Total", color = VrontalTextMuted, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "${yearCounts.sumOf { if (mode == "hadir") it.hadir else it.alpha }}",
                            color = accent,
                            style = MaterialTheme.typography.titleMedium,
                        )
                    }
                }
            }
        }
    }
}

private val monthNamesFull = listOf(
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember",
)
