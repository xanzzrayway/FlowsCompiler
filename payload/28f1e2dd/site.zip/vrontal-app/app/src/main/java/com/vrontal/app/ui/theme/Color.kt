package com.vrontal.app.ui.theme

import androidx.compose.ui.graphics.Color

// Dasar gelap ala "digital" — bukan hitam pekat, supaya kaca (glass) di atasnya tetap kelihatan
val VrontalBackground = Color(0xFF0E1116)
val VrontalSurface = Color(0xFF171C24)
val VrontalSurfaceGlass = Color(0xFF1E2530)

// Aksen "klasik" — emas, dipakai untuk aksi utama & branding
val VrontalGold = Color(0xFFD4AF37)
val VrontalGoldSoft = Color(0x33D4AF37)

// Aksen "gamer/digital" — cyan, dipakai untuk status & elemen interaktif sekunder
val VrontalCyan = Color(0xFF00E5D8)
val VrontalCyanSoft = Color(0x2200E5D8)

val VrontalTextPrimary = Color(0xFFEDEFF2)
val VrontalTextMuted = Color(0xFF9AA3B2)
val VrontalDanger = Color(0xFFFF6B6B)
val VrontalGlassBorder = Color(0x1FFFFFFF)
