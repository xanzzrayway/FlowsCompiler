package com.vrontal.app.data.ingat

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.room.withTransaction
import com.vrontal.app.data.VrontalDatabase
import java.io.File
import java.io.IOException
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.withContext

/** Pesan di sini aman langsung ditampilkan ke user. */
class IngatException(message: String) : Exception(message)

private data class MediaInfo(val path: String, val type: String, val thumb: String?)

class IngatRepository(context: Context) {
    private val appContext = context.applicationContext
    private val db = VrontalDatabase.get(context)
    private val dao = db.ingatDao()
    private val mediaDir get() = File(appContext.filesDir, "ingat_media").apply { mkdirs() }

    fun observeItems(): Flow<List<IngatItemView>> =
        combine(dao.observeItems(), dao.observeEntries()) { items, entries ->
            val byItem = entries.groupBy { it.itemId }
            items.map { IngatItemView(it, byItem[it.id].orEmpty()) }
        }

    fun observeAlarms(): Flow<List<IngatAlarm>> = dao.observeAlarms()

    // ---------- Barang ----------

    suspend fun addItem(name: String, place: String, media: Uri?) {
        val info = media?.let { withContext(Dispatchers.IO) { copyMedia(it) } }
        try {
            db.withTransaction {
                val id = dao.insertItem(IngatItem(name = name))
                dao.insertEntry(entryOf(id, place, info))
            }
        } catch (e: Exception) {
            info?.let { deleteFile(it.path); deleteFile(it.thumb) }
            throw e
        }
    }

    suspend fun addEntry(itemId: Long, place: String, media: Uri?) {
        val info = media?.let { withContext(Dispatchers.IO) { copyMedia(it) } }
        try {
            dao.insertEntry(entryOf(itemId, place, info))
        } catch (e: Exception) {
            info?.let { deleteFile(it.path); deleteFile(it.thumb) }
            throw e
        }
    }

    /** Selesai / hapus: barang, seluruh riwayat, dan file foto/videonya hilang permanen. */
    suspend fun finishItem(itemId: Long) {
        val entries = dao.entriesOf(itemId)
        db.withTransaction {
            dao.deleteEntriesOf(itemId)
            dao.deleteItem(itemId)
        }
        withContext(Dispatchers.IO) {
            entries.forEach { deleteFile(it.mediaPath); deleteFile(it.thumbPath) }
        }
    }

    private fun entryOf(itemId: Long, place: String, info: MediaInfo?) = IngatEntry(
        itemId = itemId, place = place,
        mediaPath = info?.path, mediaType = info?.type, thumbPath = info?.thumb,
    )

    private fun deleteFile(path: String?) {
        if (path != null) runCatching { File(path).delete() }
    }

    private fun copyMedia(source: Uri): MediaInfo {
        val mime = appContext.contentResolver.getType(source).orEmpty()
        val isVideo = mime.startsWith("video/")
        if (!isVideo && !mime.startsWith("image/")) throw IngatException("Hanya foto atau video yang bisa dilampirkan.")
        val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: if (isVideo) "mp4" else "jpg"
        val max = if (isVideo) 100L * 1024 * 1024 else 20L * 1024 * 1024
        val dest = File(mediaDir, "${System.currentTimeMillis()}_${UUID.randomUUID()}.$ext")

        val input = try {
            appContext.contentResolver.openInputStream(source)
        } catch (e: Exception) {
            null
        } ?: throw IngatException("File tidak bisa dibuka.")
        try {
            var total = 0L
            input.use { ins ->
                dest.outputStream().use { out ->
                    val buf = ByteArray(16 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > max) {
                            throw IngatException(
                                if (isVideo) "Video terlalu besar (maks 100 MB)." else "Foto terlalu besar (maks 20 MB)."
                            )
                        }
                        out.write(buf, 0, n)
                    }
                }
            }
        } catch (e: IngatException) {
            dest.delete(); throw e
        } catch (e: IOException) {
            dest.delete(); throw IngatException("Gagal menyalin file: ${e.message ?: "penyimpanan penuh?"}")
        }

        val thumb = if (isVideo) makeVideoThumb(dest) else null
        return MediaInfo(dest.absolutePath, if (isVideo) MEDIA_VIDEO else MEDIA_IMAGE, thumb)
    }

    /** Cuplikan bingkai pertama video; gagal = tanpa cuplikan, bukan error. */
    private fun makeVideoThumb(video: File): String? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(video.absolutePath)
            val frame = retriever.getFrameAtTime(0) ?: return null
            val out = File(video.parentFile, video.nameWithoutExtension + "_thumb.jpg")
            out.outputStream().use { frame.compress(Bitmap.CompressFormat.JPEG, 80, it) }
            out.absolutePath
        } catch (e: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    // ---------- Alarm ----------

    suspend fun addAlarm(title: String, hour: Int, minute: Int, repeatDaily: Boolean) {
        val alarm = IngatAlarm(title = title, hour = hour, minute = minute, repeatDaily = repeatDaily)
        val id = dao.insertAlarm(alarm)
        IngatScheduler.schedule(appContext, alarm.copy(id = id))
    }

    suspend fun setAlarmEnabled(alarm: IngatAlarm, enabled: Boolean) {
        val updated = alarm.copy(enabled = enabled)
        dao.updateAlarm(updated)
        if (enabled) IngatScheduler.schedule(appContext, updated) else IngatScheduler.cancel(appContext, alarm.id)
    }

    suspend fun deleteAlarm(alarm: IngatAlarm) {
        IngatScheduler.cancel(appContext, alarm.id)
        dao.deleteAlarm(alarm.id)
    }
}
