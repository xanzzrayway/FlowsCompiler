package com.vrontal.app.ui.features.xipvox

import android.app.Application
import android.webkit.WebView
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import java.util.concurrent.atomic.AtomicLong

/**
 * Satu tab XipVOx. [webView] dibuat sekali (lazy, di XipVoxScreen) dan dipegang di sini supaya
 * riwayat/scroll tab tidak hilang saat pindah-pindah tab — WebView-nya sendiri yang tetap hidup,
 * cuma dipindah-pasang ke container yang terlihat.
 */
class XipTab(startUrl: String) {
    val id: Long = nextId.getAndIncrement()
    val url = mutableStateOf(startUrl)
    val title = mutableStateOf(startUrl)
    val loading = mutableStateOf(true)
    val progress = mutableIntStateOf(0)
    val canGoBack = mutableStateOf(false)
    var webView: WebView? = null

    companion object {
        private val nextId = AtomicLong(1)
    }
}

class XipVoxViewModel(app: Application) : AndroidViewModel(app) {
    val tabs = androidx.compose.runtime.mutableStateListOf<XipTab>()
    val activeTabId = mutableStateOf<Long?>(null)

    init {
        if (tabs.isEmpty()) newTab(DEFAULT_URL)
    }

    fun activeTab(): XipTab? = tabs.find { it.id == activeTabId.value }

    fun newTab(url: String = DEFAULT_URL) {
        val tab = XipTab(normalizeUrl(url))
        tabs.firstOrNull { it.id == activeTabId.value }?.webView?.onPause()
        tabs.add(tab)
        activeTabId.value = tab.id
    }

    fun closeTab(id: Long) {
        val idx = tabs.indexOfFirst { it.id == id }
        if (idx == -1) return
        tabs[idx].webView?.destroy()
        tabs.removeAt(idx)
        if (tabs.isEmpty()) {
            newTab(DEFAULT_URL)
        } else if (activeTabId.value == id) {
            activeTabId.value = tabs[(idx - 1).coerceAtLeast(0)].id
            tabs.firstOrNull { it.id == activeTabId.value }?.webView?.onResume() // tab ini tadi dijeda
        }
    }

    fun selectTab(id: Long) {
        if (id == activeTabId.value) return
        // Tahap 7 [ai]: tab yang tidak tampil dijeda (JS timer/media berhenti), tab baru dilanjutkan.
        tabs.firstOrNull { it.id == activeTabId.value }?.webView?.onPause()
        tabs.firstOrNull { it.id == id }?.webView?.onResume()
        activeTabId.value = id
    }

    /** Dipanggil saat layar masuk background: hentikan JS timer & media di semua tab supaya tidak boros baterai. */
    fun pauseWebViews() {
        tabs.forEach { it.webView?.onPause() }
        tabs.firstNotNullOfOrNull { it.webView }?.pauseTimers()
    }

    /** Dipanggil saat layar kembali tampil: lanjutkan hanya tab aktif. */
    fun resumeWebViews() {
        tabs.firstNotNullOfOrNull { it.webView }?.resumeTimers()
        tabs.firstOrNull { it.id == activeTabId.value }?.webView?.onResume()
    }

    override fun onCleared() {
        tabs.forEach { it.webView?.destroy() }
        super.onCleared()
    }

    companion object {
        const val DEFAULT_URL = "https://www.google.com"

        /** Tambahkan https:// kalau user cuma tempel "contoh.com" tanpa skema. */
        fun normalizeUrl(input: String): String {
            val trimmed = input.trim()
            if (trimmed.isEmpty()) return DEFAULT_URL
            val hasScheme = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://").containsMatchIn(trimmed)
            return if (hasScheme) trimmed else "https://$trimmed"
        }
    }
}
