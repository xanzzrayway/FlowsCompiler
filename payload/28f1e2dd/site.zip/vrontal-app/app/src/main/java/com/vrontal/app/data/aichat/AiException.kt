package com.vrontal.app.data.aichat

class AiException(message: String) : Exception(message)
