package com.vrontal.app.data.aichat

import org.json.JSONArray
import org.json.JSONObject

/**
 * Resolver jalan sederhana ke dalam JSON, format "choices.0.message.content" —
 * angka berarti indeks array, selain itu berarti key object.
 */
object JsonPath {
    fun resolve(root: Any?, path: String): String? {
        if (path.isBlank()) return null
        var current: Any? = root
        for (segment in path.split('.')) {
            current = when (current) {
                is JSONObject -> if (current.has(segment)) current.get(segment) else return null
                is JSONArray -> {
                    val idx = segment.toIntOrNull() ?: return null
                    if (idx in 0 until current.length()) current.get(idx) else return null
                }
                else -> return null
            }
        }
        return when (current) {
            null -> null
            is String -> current
            JSONObject.NULL -> null
            else -> current.toString()
        }
    }
}
