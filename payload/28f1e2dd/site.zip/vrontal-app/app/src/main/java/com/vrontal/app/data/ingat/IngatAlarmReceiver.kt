package com.vrontal.app.data.ingat

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.vrontal.app.MainActivity
import com.vrontal.app.VrontalApp
import com.vrontal.app.data.VrontalDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Dipanggil AlarmManager saat alarm Ingat berbunyi. Alarm harian dijadwal ulang; alarm sekali dihapus otomatis. */
class IngatAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(IngatScheduler.EXTRA_ID, -1L)
        if (id < 0) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = VrontalDatabase.get(context).ingatDao()
                val alarm = dao.getAlarm(id) ?: return@launch
                if (!alarm.enabled) return@launch
                notify(context, alarm)
                if (alarm.repeatDaily) IngatScheduler.schedule(context, alarm, justFired = true)
                else dao.deleteAlarm(alarm.id) // alarm sekali: selesai = hilang otomatis
            } finally {
                pending.finish()
            }
        }
    }

    private fun notify(context: Context, alarm: IngatAlarm) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ActivityCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
        ) return

        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notif = NotificationCompat.Builder(context, VrontalApp.CHANNEL_INGAT)
            .setContentTitle(alarm.title)
            .setContentText("Pengingat Ingat • %02d:%02d".format(alarm.hour, alarm.minute))
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL) // untuk Android < 8; di 8+ suara diatur channel
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIF_BASE + (alarm.id % 100000).toInt(), notif)
    }

    private companion object {
        const val NOTIF_BASE = 2000
    }
}
