package com.vrontal.app.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.vrontal.app.data.AuthRepository
import com.vrontal.app.ui.auth.LoginScreen
import com.vrontal.app.ui.features.aichat.AiChatScreen
import com.vrontal.app.ui.features.aichat.AiProfileFormScreen
import com.vrontal.app.ui.features.credit.CreditScreen
import com.vrontal.app.ui.features.encryption.EncryptionScreen
import com.vrontal.app.ui.features.ingat.IngatScreen
import com.vrontal.app.ui.features.loster.LosterCheckScreen
import com.vrontal.app.ui.features.loster.LosterScreen
import com.vrontal.app.ui.features.xipvox.XipVoxScreen
import com.vrontal.app.ui.menu.MenuScreen

@Composable
fun VrontalNav(auth: AuthRepository) {
    val nav = rememberNavController()
    val start = remember { if (auth.shouldAutoLogin()) "menu" else "login" }

    NavHost(
        navController = nav,
        startDestination = start,
        enterTransition = { slideInHorizontally(tween(350)) { it / 4 } + fadeIn(tween(350)) },
        exitTransition = { fadeOut(tween(250)) },
        popEnterTransition = { fadeIn(tween(300)) },
        popExitTransition = { slideOutHorizontally(tween(300)) { it / 4 } + fadeOut(tween(300)) },
    ) {
        composable("login") {
            LoginScreen(auth) {
                nav.navigate("menu") { popUpTo("login") { inclusive = true } }
            }
        }
        composable("menu") {
            MenuScreen(
                displayName = auth.displayName(),
                onNavigate = { route -> nav.navigate(route) },
                onSignOut = {
                    auth.signOut()
                    nav.navigate("login") { popUpTo("menu") { inclusive = true } }
                },
            )
        }
        composable("encryption") { EncryptionScreen { nav.popBackStack() } }
        composable("loster") {
            LosterScreen(
                onBack = { nav.popBackStack() },
                onOpenCheck = { mode -> nav.navigate("loster/check/$mode") },
            )
        }
        composable("loster/check/{mode}") { backStackEntry ->
            val mode = backStackEntry.arguments?.getString("mode") ?: "alpha"
            LosterCheckScreen(mode = mode, onBack = { nav.popBackStack() })
        }
        composable("credit") { CreditScreen { nav.popBackStack() } }
        composable("xipvox") { XipVoxScreen { nav.popBackStack() } }
        composable("ingat") { IngatScreen { nav.popBackStack() } }
        composable("aichat") {
            AiChatScreen(
                onBack = { nav.popBackStack() },
                onAddProfile = { nav.navigate("aichat/new-profile") },
            )
        }
        composable("aichat/new-profile") {
            AiProfileFormScreen(
                onBack = { nav.popBackStack() },
                onSaved = { nav.popBackStack() },
            )
        }
    }
}
