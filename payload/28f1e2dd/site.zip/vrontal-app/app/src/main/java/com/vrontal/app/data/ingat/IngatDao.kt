package com.vrontal.app.data.ingat

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface IngatDao {
    @Insert suspend fun insertItem(item: IngatItem): Long
    @Insert suspend fun insertEntry(entry: IngatEntry): Long

    @Query("SELECT * FROM ingat_item ORDER BY createdAt DESC")
    fun observeItems(): Flow<List<IngatItem>>
    @Query("SELECT * FROM ingat_entry ORDER BY createdAt DESC, id DESC")
    fun observeEntries(): Flow<List<IngatEntry>>
    @Query("SELECT * FROM ingat_entry WHERE itemId = :itemId")
    suspend fun entriesOf(itemId: Long): List<IngatEntry>
    @Query("DELETE FROM ingat_entry WHERE itemId = :itemId")
    suspend fun deleteEntriesOf(itemId: Long)
    @Query("DELETE FROM ingat_item WHERE id = :itemId")
    suspend fun deleteItem(itemId: Long)

    @Insert suspend fun insertAlarm(alarm: IngatAlarm): Long
    @Update suspend fun updateAlarm(alarm: IngatAlarm)
    @Query("SELECT * FROM ingat_alarm ORDER BY hour ASC, minute ASC")
    fun observeAlarms(): Flow<List<IngatAlarm>>
    @Query("SELECT * FROM ingat_alarm WHERE id = :id LIMIT 1")
    suspend fun getAlarm(id: Long): IngatAlarm?
    @Query("SELECT * FROM ingat_alarm WHERE enabled = 1")
    suspend fun enabledAlarms(): List<IngatAlarm>
    @Query("DELETE FROM ingat_alarm WHERE id = :id")
    suspend fun deleteAlarm(id: Long)
}
