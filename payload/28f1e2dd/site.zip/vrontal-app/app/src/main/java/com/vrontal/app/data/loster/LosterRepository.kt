package com.vrontal.app.data.loster

import android.content.Context
import com.vrontal.app.data.VrontalDatabase
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.flow.Flow

/**
 * Batas waktu: kalau sampai jam ini belum absen, hari itu otomatis Alpha.
 * Satu tempat saja supaya UI (pengecekan saat dibuka) dan alarm (pengecekan latar belakang)
 * selalu memakai batas yang sama persis.
 */
val ALPHA_CUTOFF: LocalTime = LocalTime.of(11, 0)

class LosterRepository(context: Context) {
    private val dao = VrontalDatabase.get(context).attendanceDao()
    private val prefs = context.applicationContext.getSharedPreferences("vrontal_loster", Context.MODE_PRIVATE)
    private val dateFmt = DateTimeFormatter.ISO_LOCAL_DATE

    private fun startDate(): LocalDate {
        val saved = prefs.getString(KEY_START, null)
        if (saved != null) return LocalDate.parse(saved, dateFmt)
        val today = LocalDate.now()
        prefs.edit().putString(KEY_START, today.format(dateFmt)).apply()
        return today
    }

    suspend fun markHadirToday(): AttendanceRecord? {
        val today = LocalDate.now()
        val key = today.format(dateFmt)
        val existing = dao.getByDate(key)
        if (existing != null) return existing // sudah tercatat (Hadir atau sudah kadung Alpha), tidak ditimpa
        val now = LocalTime.now()
        val record = AttendanceRecord(key, AttendanceStatus.HADIR, now.format(DateTimeFormatter.ofPattern("HH:mm")))
        dao.upsert(record)
        return record
    }

    /**
     * Isi Alpha untuk semua tanggal yang terlewat tanpa catatan, dari tanggal mulai sampai kemarin,
     * dan untuk hari ini juga kalau sudah lewat [ALPHA_CUTOFF]. Dipanggil saat layar dibuka
     * (jaga-jaga kalau alarm tidak sempat jalan) maupun dari alarm 11 pagi itu sendiri.
     * @return true kalau hari ini BARU SAJA ditandai Alpha pada pemanggilan ini (dipakai untuk notifikasi/efek UI).
     */
    suspend fun backfillAlpha(): Boolean {
        val today = LocalDate.now()
        var d = startDate()
        while (d.isBefore(today)) {
            val key = d.format(dateFmt)
            if (dao.getByDate(key) == null) dao.upsert(AttendanceRecord(key, AttendanceStatus.ALPHA))
            d = d.plusDays(1)
        }
        val todayKey = today.format(dateFmt)
        val markedNow = if (dao.getByDate(todayKey) == null && LocalTime.now() >= ALPHA_CUTOFF) {
            dao.upsert(AttendanceRecord(todayKey, AttendanceStatus.ALPHA))
            true
        } else false
        return markedNow
    }

    suspend fun todayRecord(): AttendanceRecord? = dao.getByDate(LocalDate.now().format(dateFmt))

    fun observeMonth(year: Int, month: Int): Flow<List<AttendanceRecord>> =
        dao.observeByMonth("%04d-%02d".format(year, month))

    fun observeYear(year: Int): Flow<List<AttendanceRecord>> =
        dao.observeByYear("%04d".format(year))

    private companion object {
        const val KEY_START = "start_date"
    }
}
