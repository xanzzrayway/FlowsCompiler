package com.vrontal.app.data.aichat

import android.content.Context
import android.net.Uri
import android.util.Base64
import java.util.concurrent.TimeUnit
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONException
import org.json.JSONObject
import org.json.JSONTokener

/**
 * Pemanggil API yang bebas bentuknya — endpoint, header, dan body sepenuhnya ditentukan user
 * lewat AiProfile. Timeout 10 menit sesuai alur: "jika lewat 10 menit maka error".
 */
/** Dilempar saat user menekan Stop. Bukan error — hanya menandai pengiriman dihentikan. */
class AiCancelledException : Exception("Dihentikan oleh pengguna.")

class AiClient(context: Context) {
    @Volatile private var cancelled = false
    @Volatile private var activeCall: okhttp3.Call? = null

    /** Panggil di awal tiap pengiriman, sebelum pekerjaan berat apa pun dimulai. */
    fun reset() { cancelled = false; activeCall = null }

    /** Hentikan pengiriman/stream yang sedang berjalan (aman dipanggil kapan saja). */
    fun cancel() { cancelled = true; activeCall?.cancel() }

    private val appContext = context.applicationContext
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.MINUTES)
        .writeTimeout(10, TimeUnit.MINUTES)
        .callTimeout(10, TimeUnit.MINUTES)
        .build()

    /** @return teks balasan AI. Melempar [AiException] dengan pesan yang bisa langsung ditampilkan ke user. */
    fun send(
        endpoint: String,
        headers: List<Pair<String, String>>,
        bodyTemplate: String,
        responsePath: String,
        streamPath: String,
        message: String,
        history: List<Pair<String, String>>,
        imageUri: Uri?,
        onDelta: (String) -> Unit,
    ): String {
        val imageBase64 = imageUri?.let { encodeImage(it) } ?: ""
        // Riwayat: array JSON [{"role":"user"|"assistant","content":"..."}], sudah termasuk pesan terbaru.
        val historyJson = org.json.JSONArray().apply {
            history.forEach { (role, content) -> put(JSONObject().put("role", role).put("content", content)) }
        }.toString()
        // Satu kali lewat: isi pesan user yang kebetulan memuat "{{...}}" tidak ikut disubstitusi ulang.
        val body = PLACEHOLDER.replace(bodyTemplate) { m ->
            when (m.groupValues[1]) {
                "PESAN" -> jsonEscape(message)
                "GAMBAR_BASE64" -> imageBase64
                else -> historyJson
            }
        }

        // Pastikan hasil substitusi masih JSON yang valid sebelum dikirim — kalau tidak,
        // user langsung dikasih tahu templatenya yang salah, bukan error HTTP yang membingungkan.
        try {
            JSONTokener(body).nextValue()
        } catch (e: JSONException) {
            throw AiException("Template body bukan JSON yang valid setelah {{PESAN}} diisi. Cek lagi tanda kutip/koma-nya.")
        }

        val reqBuilder = Request.Builder().url(endpoint)
        var hasContentType = false
        for ((key, value) in headers) {
            if (key.isBlank()) continue
            if (key.equals("Content-Type", ignoreCase = true)) hasContentType = true
            reqBuilder.addHeader(key, value)
        }
        val mediaType = if (hasContentType) null else "application/json".toMediaType()
        reqBuilder.post(body.toRequestBody(mediaType))

        if (cancelled) throw AiCancelledException()
        val call = client.newCall(reqBuilder.build())
        activeCall = call
        val response = try {
            call.execute()
        } catch (e: java.net.SocketTimeoutException) {
            if (call.isCanceled()) throw AiCancelledException()
            throw AiException("Tidak ada respons sampai 10 menit — dianggap gagal.")
        } catch (e: java.io.IOException) {
            if (call.isCanceled()) throw AiCancelledException()
            throw AiException("Tidak bisa menghubungi endpoint: ${e.message ?: "periksa URL dan koneksi internet"}")
        }

        response.use { res ->
            if (!res.isSuccessful) {
                val raw = res.body?.string().orEmpty()
                throw AiException("Server membalas error ${res.code}: ${raw.take(300).ifBlank { res.message }}")
            }
            // Streaming aktif kalau user mengisi jalur potongan balasan di profil AI.
            if (streamPath.isNotBlank()) return readStream(res, streamPath, responsePath, onDelta)

            val raw = res.body?.string().orEmpty()
            val parsed = try {
                JSONTokener(raw).nextValue()
            } catch (e: JSONException) {
                throw AiException("Respons bukan JSON yang bisa dibaca.")
            }
            val text = JsonPath.resolve(parsed, responsePath)
            if (text.isNullOrBlank()) {
                throw AiException("Tidak menemukan hasil di jalur \"$responsePath\" — salah input jalurnya, atau respons API-nya beda bentuk.")
            }
            return text
        }
    }

    /**
     * Baca respons SSE ("data: {json}" per baris). Tiap potongan diambil lewat [streamPath] lalu
     * ditambahkan ke teks utuh dan dilaporkan lewat [onDelta]. Kalau server ternyata mengabaikan
     * mode stream dan membalas JSON biasa, dipakai [responsePath] sebagai cadangan.
     */
    private fun readStream(res: okhttp3.Response, streamPath: String, responsePath: String, onDelta: (String) -> Unit): String {
        val source = res.body?.source() ?: throw AiException("Respons kosong dari server.")
        val acc = StringBuilder()
        val rawLines = StringBuilder()
        var sawData = false
        try {
            while (true) {
                val line = source.readUtf8Line() ?: break
                if (!line.startsWith("data:")) {
                    if (!sawData && rawLines.length < 1_000_000) rawLines.append(line).append('\n')
                    continue
                }
                sawData = true
                val payload = line.removePrefix("data:").trim()
                if (payload == "[DONE]") break
                if (payload.isEmpty()) continue
                val delta = try {
                    JsonPath.resolve(JSONTokener(payload).nextValue(), streamPath)
                } catch (e: JSONException) {
                    null
                }
                if (!delta.isNullOrEmpty()) {
                    acc.append(delta)
                    onDelta(acc.toString())
                }
            }
        } catch (e: java.net.SocketTimeoutException) {
            if (res.call().isCanceled()) throw AiCancelledException()
            throw AiException("Streaming terputus: tidak ada data sampai 10 menit.")
        } catch (e: java.io.IOException) {
            if (res.call().isCanceled()) throw AiCancelledException()
            throw AiException("Koneksi streaming terputus: ${e.message ?: "periksa koneksi internet"}")
        }

        if (!sawData) {
            val parsed = try {
                JSONTokener(rawLines.toString()).nextValue()
            } catch (e: JSONException) {
                throw AiException("Respons bukan streaming (SSE) maupun JSON yang bisa dibaca.")
            }
            val text = JsonPath.resolve(parsed, responsePath)
            if (text.isNullOrBlank()) throw AiException("Server tidak mengirim stream, dan jalur \"$responsePath\" juga tidak menemukan hasil.")
            return text
        }
        if (acc.isBlank()) throw AiException("Stream selesai tapi tidak ada teks di jalur \"$streamPath\" — cek jalur potongan balasannya.")
        return acc.toString()
    }

    private companion object {
        val PLACEHOLDER = Regex("""\{\{(PESAN|GAMBAR_BASE64|RIWAYAT)\}\}""")
    }

    private fun jsonEscape(text: String): String = JSONObject.quote(text).let { it.substring(1, it.length - 1) }

    private fun encodeImage(uri: Uri): String {
        val bytes = appContext.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return ""
        // Batas 8 MB: gambar lebih besar dari ini bikin HP spek rendah kehabisan memori setelah di-Base64.
        if (bytes.size > 8 * 1024 * 1024) throw AiException("Gambar terlalu besar (maks 8 MB). Pilih gambar yang lebih kecil.")
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }
}
