package com.vrontal.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class VrontalApp : Application() {
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_LOSTER,
                "Loster Legal",
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = "Pemberitahuan status absen/alpha harian"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)

            val alarmSound = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM)
            val ingat = NotificationChannel(CHANNEL_INGAT, "Ingat (alarm)", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Alarm pengingat: bangun, cek absen, cek gaji, dll."
                setSound(
                    alarmSound,
                    android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build(),
                )
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 300, 500)
            }
            nm.createNotificationChannel(ingat)
        }
    }

    companion object {
        const val CHANNEL_LOSTER = "loster_channel"
        const val CHANNEL_INGAT = "ingat_channel"
    }
}
