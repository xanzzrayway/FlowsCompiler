package com.vrontal.app.data

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Profil lokal (Nama + Password). Semua tersimpan di perangkat, tidak pernah ke server.
 * Password TIDAK pernah disimpan; yang disimpan hanya hash PBKDF2 + salt acak, dan keduanya
 * dienkripsi lewat SecureStore (AndroidKeyStore) sebelum masuk SharedPreferences biasa.
 */
class AuthRepository(context: Context) {

    private val appContext = context.applicationContext
    private val prefs: SharedPreferences by lazy {
        appContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    }

    fun hasProfile(): Boolean = prefs.contains(K_HASH)
    fun displayName(): String = decryptOrEmpty(prefs.getString(K_NAME, null))
    fun shouldAutoLogin(): Boolean = hasProfile() && prefs.getBoolean(K_REMEMBER, false)
    fun keepDataFlag(): Boolean = prefs.getBoolean(K_KEEP, true)

    suspend fun register(name: String, password: String, remember: Boolean, keepData: Boolean) {
        withContext(Dispatchers.Default) {
            val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            val algo = pickAlgo()
            val hash = derive(password, salt, algo)
            prefs.edit()
                .putString(K_NAME, SecureStore.encrypt(name.trim()))
                .putString(K_SALT, SecureStore.encrypt(b64(salt)))
                .putString(K_HASH, SecureStore.encrypt(b64(hash)))
                .putString(K_ALGO, algo)
                .putBoolean(K_REMEMBER, remember)
                .putBoolean(K_KEEP, keepData)
                .apply()
        }
    }

    suspend fun verify(name: String, password: String, remember: Boolean, keepData: Boolean): Boolean =
        withContext(Dispatchers.Default) {
            val storedSalt = prefs.getString(K_SALT, null)
            val storedHash = prefs.getString(K_HASH, null)
            if (storedSalt == null || storedHash == null) return@withContext false

            val salt = Base64.decode(SecureStore.decrypt(storedSalt), Base64.NO_WRAP)
            val expected = Base64.decode(SecureStore.decrypt(storedHash), Base64.NO_WRAP)
            val algo = prefs.getString(K_ALGO, null) ?: pickAlgo()
            // Hash selalu dihitung dulu, baru nama dibandingkan, supaya waktu proses tidak membocorkan info.
            val actual = derive(password, salt, algo)
            val nameOk = decryptOrEmpty(prefs.getString(K_NAME, null)).equals(name.trim(), ignoreCase = true)
            val ok = MessageDigest.isEqual(expected, actual) && nameOk
            if (ok) {
                prefs.edit().putBoolean(K_REMEMBER, remember).putBoolean(K_KEEP, keepData).apply()
            }
            ok
        }

    /**
     * Keluar dari akun. Kalau "Simpan data di perangkat ini" TIDAK dicentang, ini juga
     * menghapus seluruh profil (bukan cuma status ingat-saya) — lihat laporan bug #1:
     * sebelumnya checkbox ini tersimpan tapi tidak pernah benar-benar dipakai.
     */
    fun signOut() {
        if (!keepDataFlag()) {
            resetProfile()
        } else {
            prefs.edit().putBoolean(K_REMEMBER, false).apply()
        }
    }

    fun resetProfile() {
        prefs.edit().clear().apply()
        SecureStore.deleteKey()
    }

    private fun decryptOrEmpty(stored: String?): String =
        if (stored == null) "" else try { SecureStore.decrypt(stored) } catch (e: Exception) { "" }

    // PBKDF2WithHmacSHA256 baru andal tersedia mulai API 26; di bawah itu (minSdk kita 24) pakai SHA1.
    private fun pickAlgo(): String =
        if (Build.VERSION.SDK_INT >= 26) "PBKDF2WithHmacSHA256" else "PBKDF2WithHmacSHA1"

    private fun derive(password: String, salt: ByteArray, algo: String): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 256)
        return SecretKeyFactory.getInstance(algo).generateSecret(spec).encoded
    }

    private fun b64(bytes: ByteArray): String = Base64.encodeToString(bytes, Base64.NO_WRAP)

    private companion object {
        const val FILE = "vrontal_prefs"
        const val K_NAME = "name"
        const val K_SALT = "salt"
        const val K_HASH = "hash"
        const val K_ALGO = "algo"
        const val K_REMEMBER = "remember"
        const val K_KEEP = "keep_data"
        const val ITERATIONS = 100_000
    }
}
