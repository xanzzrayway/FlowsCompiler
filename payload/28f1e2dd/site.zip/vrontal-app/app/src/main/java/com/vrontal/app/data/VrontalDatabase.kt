package com.vrontal.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.vrontal.app.data.aichat.AiChatDao
import com.vrontal.app.data.aichat.AiProfile
import com.vrontal.app.data.aichat.ChatMessage
import com.vrontal.app.data.aichat.ChatRole
import com.vrontal.app.data.ingat.IngatAlarm
import com.vrontal.app.data.ingat.IngatDao
import com.vrontal.app.data.ingat.IngatEntry
import com.vrontal.app.data.ingat.IngatItem
import com.vrontal.app.data.loster.AttendanceDao
import com.vrontal.app.data.loster.AttendanceRecord
import com.vrontal.app.data.loster.AttendanceStatus

/** v1 -> v2: tambah tabel Chat AI tanpa menyentuh data absen/alpha yang sudah ada. */
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `ai_profile` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `endpoint` TEXT NOT NULL, `headersJsonEncrypted` TEXT NOT NULL, `bodyTemplateEncrypted` TEXT NOT NULL, `responsePath` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS `chat_message` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `profileId` INTEGER NOT NULL, `role` TEXT NOT NULL, `text` TEXT NOT NULL, `colorHex` TEXT, `imageUri` TEXT, `timestamp` INTEGER NOT NULL)")
    }
}

/** v2 -> v3: kolom jalur streaming di profil AI (kosong = tanpa streaming). */
val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE `ai_profile` ADD COLUMN `streamPath` TEXT NOT NULL DEFAULT ''")
    }
}

/** v3 -> v4: tabel fitur Ingat (barang, riwayat lokasi, alarm). */
val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `ingat_item` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS `ingat_entry` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `itemId` INTEGER NOT NULL, `place` TEXT NOT NULL, `mediaPath` TEXT, `mediaType` TEXT, `thumbPath` TEXT, `createdAt` INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS `ingat_alarm` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT NOT NULL, `hour` INTEGER NOT NULL, `minute` INTEGER NOT NULL, `repeatDaily` INTEGER NOT NULL, `enabled` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL)")
    }
}

class Converters {
    @TypeConverter fun fromStatus(status: AttendanceStatus): String = status.name
    @TypeConverter fun toStatus(value: String): AttendanceStatus = AttendanceStatus.valueOf(value)

    @TypeConverter fun fromRole(role: ChatRole): String = role.name
    @TypeConverter fun toRole(value: String): ChatRole = ChatRole.valueOf(value)
}

@Database(
    entities = [AttendanceRecord::class, AiProfile::class, ChatMessage::class, IngatItem::class, IngatEntry::class, IngatAlarm::class],
    version = 4,
    exportSchema = false,
)
@TypeConverters(Converters::class)
abstract class VrontalDatabase : RoomDatabase() {
    abstract fun attendanceDao(): AttendanceDao
    abstract fun aiChatDao(): AiChatDao
    abstract fun ingatDao(): IngatDao

    companion object {
        @Volatile private var instance: VrontalDatabase? = null

        fun get(context: Context): VrontalDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    VrontalDatabase::class.java,
                    "vrontal.db",
                )
                    // Migrasi manual: data lama tidak lagi terhapus saat skema naik versi.
                    // Tiap kenaikan versi berikutnya wajib menambah Migration baru di sini.
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                    .build().also { instance = it }
            }
    }
}
