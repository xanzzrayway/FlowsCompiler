package com.vrontal.app.ui.features.aichat

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vrontal.app.data.aichat.AiChatRepository
import com.vrontal.app.data.aichat.AiProfile
import com.vrontal.app.data.aichat.ProfileInput
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AiChatViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = AiChatRepository(app)

    val profiles: StateFlow<List<AiProfile>> =
        repo.observeProfiles().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeProfileId = MutableStateFlow<Long?>(null)
    val sending = MutableStateFlow(false)

    val messages = activeProfileId.flatMapLatest { id ->
        if (id == null) kotlinx.coroutines.flow.flowOf(emptyList()) else repo.observeMessages(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectProfile(id: Long) { activeProfileId.value = id }

    fun saveProfile(input: ProfileInput, onSaved: (Long) -> Unit) {
        viewModelScope.launch {
            val id = repo.saveProfile(input)
            onSaved(id)
        }
    }

    fun deleteProfile(profile: AiProfile) {
        viewModelScope.launch {
            repo.deleteProfile(profile)
            if (activeProfileId.value == profile.id) activeProfileId.value = null
        }
    }

    fun send(text: String, colorHex: String?, imageUri: Uri?) {
        val profile = profiles.value.find { it.id == activeProfileId.value } ?: return
        if (text.isBlank() && imageUri == null) return
        if (sending.value) return // cegah kirim ganda
        viewModelScope.launch {
            sending.value = true
            try {
                repo.sendMessage(profile, text, colorHex, imageUri)
            } finally {
                sending.value = false
            }
        }
    }

    fun stop() = repo.stop()

    fun clearChat() {
        val id = activeProfileId.value ?: return
        viewModelScope.launch { repo.clearMessages(id) }
    }
}
