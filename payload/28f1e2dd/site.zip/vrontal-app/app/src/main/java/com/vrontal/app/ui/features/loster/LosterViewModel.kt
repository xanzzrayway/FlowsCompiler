package com.vrontal.app.ui.features.loster

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vrontal.app.data.loster.AlarmScheduler
import com.vrontal.app.data.loster.AttendanceRecord
import com.vrontal.app.data.loster.AttendanceStatus
import com.vrontal.app.data.loster.LosterRepository
import java.time.LocalDate
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class MonthCount(val month: Int, val hadir: Int, val alpha: Int)

class LosterViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = LosterRepository(app)
    private val today = LocalDate.now()

    val selectedYear = MutableStateFlow(today.year)
    val selectedMonth = MutableStateFlow(today.monthValue) // 1..12

    val todayRecord = MutableStateFlow<AttendanceRecord?>(null)

    val monthRecords: StateFlow<List<AttendanceRecord>> =
        combine(selectedYear, selectedMonth) { y, m -> y to m }
            .flatMapLatest { (y, m) -> repo.observeMonth(y, m) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Hitungan Hadir/Alpha per bulan (1..12) untuk tahun yang sedang dipilih — dasar tampilan "Tahun". */
    val yearMonthCounts: StateFlow<List<MonthCount>> =
        selectedYear.flatMapLatest { y -> repo.observeYear(y) }
            .map { records ->
                val byMonth = records.groupBy { it.date.substring(5, 7).toInt() }
                (1..12).map { m ->
                    val list = byMonth[m].orEmpty()
                    MonthCount(
                        month = m,
                        hadir = list.count { it.status == AttendanceStatus.HADIR },
                        alpha = list.count { it.status == AttendanceStatus.ALPHA },
                    )
                }
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), (1..12).map { MonthCount(it, 0, 0) })

    init {
        refresh()
        AlarmScheduler.scheduleNext(app)
    }

    fun refresh() {
        viewModelScope.launch {
            repo.backfillAlpha()
            todayRecord.value = repo.todayRecord()
        }
    }

    fun onAbsenClick() {
        viewModelScope.launch { todayRecord.value = repo.markHadirToday() }
    }

    fun setMonth(month: Int) { selectedMonth.value = month }
    fun setYear(year: Int) { selectedYear.value = year }
}
