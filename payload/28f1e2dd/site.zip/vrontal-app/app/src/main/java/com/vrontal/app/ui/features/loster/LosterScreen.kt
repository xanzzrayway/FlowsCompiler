package com.vrontal.app.ui.features.loster

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vrontal.app.data.loster.AttendanceStatus
import com.vrontal.app.ui.components.glass
import com.vrontal.app.ui.theme.VrontalBackground
import com.vrontal.app.ui.theme.VrontalCyan
import com.vrontal.app.ui.theme.VrontalDanger
import com.vrontal.app.ui.theme.VrontalGold
import com.vrontal.app.ui.theme.VrontalGoldSoft
import com.vrontal.app.ui.theme.VrontalIcons
import com.vrontal.app.ui.theme.VrontalTextMuted
import com.vrontal.app.ui.theme.VrontalTextPrimary

private val monthNames = listOf(
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember",
)

@Composable
fun LosterScreen(onBack: () -> Unit, onOpenCheck: (mode: String) -> Unit) {
    val context = LocalContext.current
    val vm: LosterViewModel = viewModel()

    val todayRecord by vm.todayRecord.collectAsState()
    val monthRecords by vm.monthRecords.collectAsState()
    val year by vm.selectedYear.collectAsState()
    val month by vm.selectedMonth.collectAsState()

    var menuOpen by remember { mutableStateOf(false) }

    // Notifikasi (Android 13+) diminta di sini, tepat saat fitur yang butuh benar-benar dipakai.
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    // Balik ke layar ini (mis. dari Settings) -> cek ulang, jaga-jaga kalau lewat jam 11 sambil app di background.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) vm.refresh() }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    val hadirCount = monthRecords.count { it.status == AttendanceStatus.HADIR }
    val alphaCount = monthRecords.count { it.status == AttendanceStatus.ALPHA }

    Box(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth()) {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) {
                    androidx.compose.material3.Icon(VrontalIcons.ArrowBack, contentDescription = "Kembali", tint = VrontalTextPrimary)
                }
                Text("Loster Legal", style = MaterialTheme.typography.titleLarge, color = VrontalTextPrimary, modifier = Modifier.weight(1f))
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Text("⋮", style = MaterialTheme.typography.titleLarge, color = VrontalTextPrimary)
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(text = { Text("Check Alpha") }, onClick = { menuOpen = false; onOpenCheck("alpha") })
                        DropdownMenuItem(text = { Text("Check Hadir") }, onClick = { menuOpen = false; onOpenCheck("hadir") })
                    }
                }
            }

            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
                // --- Dashboard status hari ini ---
                Column(
                    Modifier.fillMaxWidth().glass().padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    val status = todayRecord?.status
                    val (label, color) = when (status) {
                        AttendanceStatus.HADIR -> "Hadir hari ini · ${todayRecord?.time}" to VrontalCyan
                        AttendanceStatus.ALPHA -> "Alpha hari ini" to VrontalDanger
                        null -> "Belum absen hari ini" to VrontalTextMuted
                    }
                    Box(
                        Modifier.size(88.dp).clip(CircleShape).background(
                            when (status) {
                                AttendanceStatus.HADIR -> VrontalCyan.copy(alpha = 0.15f)
                                AttendanceStatus.ALPHA -> VrontalDanger.copy(alpha = 0.15f)
                                null -> VrontalGoldSoft
                            }
                        ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            when (status) { AttendanceStatus.HADIR -> "✓"; AttendanceStatus.ALPHA -> "✕"; null -> "?" },
                            style = MaterialTheme.typography.displaySmall,
                            color = color,
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(label, style = MaterialTheme.typography.titleMedium, color = VrontalTextPrimary)
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = { vm.onAbsenClick() },
                        enabled = status == null,
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = VrontalGold,
                            contentColor = VrontalBackground,
                            disabledContainerColor = VrontalGold.copy(alpha = 0.35f),
                            disabledContentColor = VrontalTextMuted,
                        ),
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                    ) {
                        Text(
                            when (status) {
                                AttendanceStatus.HADIR -> "Sudah absen"
                                AttendanceStatus.ALPHA -> "Alpha — absen ditutup"
                                null -> "Absen sekarang"
                            },
                            style = MaterialTheme.typography.labelLarge,
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))

                // --- Navigasi bulan ---
                Row(
                    Modifier.fillMaxWidth().glass().padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    OutlinedButton(onClick = {
                        if (month == 1) { vm.setYear(year - 1); vm.setMonth(12) } else vm.setMonth(month - 1)
                    }) { Text("‹", color = VrontalGold) }
                    Text("${monthNames[month - 1]} $year", style = MaterialTheme.typography.titleMedium, color = VrontalTextPrimary)
                    OutlinedButton(onClick = {
                        if (month == 12) { vm.setYear(year + 1); vm.setMonth(1) } else vm.setMonth(month + 1)
                    }) { Text("›", color = VrontalGold) }
                }

                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatChip("Hadir", hadirCount, VrontalCyan, Modifier.weight(1f))
                    StatChip("Alpha", alphaCount, VrontalDanger, Modifier.weight(1f))
                }

                Spacer(Modifier.height(10.dp))
                if (monthRecords.isEmpty()) {
                    Text(
                        "Belum ada catatan di bulan ini.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = VrontalTextMuted,
                        modifier = Modifier.padding(12.dp),
                    )
                } else {
                    Column(Modifier.fillMaxWidth().glass()) {
                        monthRecords.sortedByDescending { it.date }.forEachIndexed { i, r ->
                            if (i > 0) androidx.compose.material3.HorizontalDivider(color = com.vrontal.app.ui.theme.VrontalGlassBorder)
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text(r.date.substring(8, 10) + " " + monthNames[month - 1].take(3), color = VrontalTextPrimary)
                                Text(
                                    if (r.status == AttendanceStatus.HADIR) "Hadir ${r.time}" else "Alpha",
                                    color = if (r.status == AttendanceStatus.HADIR) VrontalCyan else VrontalDanger,
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                ExactAlarmCard()
                Spacer(Modifier.height(12.dp))
                BatteryExemptionCard()
            }
        }
    }
}

@Composable
private fun StatChip(label: String, value: Int, color: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
    Column(
        modifier.glass().padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("$value", style = MaterialTheme.typography.headlineMedium, color = color)
        Text(label, style = MaterialTheme.typography.labelMedium, color = VrontalTextMuted)
    }
}

/** Ajakan matikan optimasi baterai untuk app ini, supaya alarm jam 11 lebih andal — bukan wajib, cuma disarankan. */
@Composable
private fun BatteryExemptionCard() {
    val context = LocalContext.current
    var ignoring by remember {
        mutableStateOf(
            (context.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager)
                .isIgnoringBatteryOptimizations(context.packageName)
        )
    }
    if (ignoring) return
    Column(Modifier.fillMaxWidth().glass().padding(16.dp)) {
        Text("Pengecekan jam 11 lebih andal", style = MaterialTheme.typography.titleMedium, color = VrontalTextPrimary)
        Spacer(Modifier.height(6.dp))
        Text(
            "Sebagian HP mematikan alarm aplikasi di latar belakang untuk hemat baterai. " +
                "Matikan optimasi baterai khusus Vrontal supaya pengecekan Alpha tetap tepat waktu.",
            style = MaterialTheme.typography.bodyMedium,
            color = VrontalTextMuted,
        )
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = android.net.Uri.parse("package:${context.packageName}")
            }
            context.startActivity(intent)
        }) { Text("Matikan optimasi baterai", color = VrontalGold) }
    }
}

/** Ajakan izinkan alarm presisi (Android 12+) — tanpa ini, pengecekan jam 11 bisa meleset beberapa menit. */
@Composable
private fun ExactAlarmCard() {
    val context = LocalContext.current
    if (Build.VERSION.SDK_INT < 31) return
    var allowed by remember {
        mutableStateOf((context.getSystemService(android.content.Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms())
    }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                allowed = (context.getSystemService(android.content.Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }
    if (allowed) return

    Column(Modifier.fillMaxWidth().glass().padding(16.dp)) {
        Text("Izinkan alarm presisi", style = MaterialTheme.typography.titleMedium, color = VrontalTextPrimary)
        Spacer(Modifier.height(6.dp))
        Text(
            "Supaya pengecekan Alpha jam 11 pagi tepat waktu, bukan meleset beberapa menit kemudian.",
            style = MaterialTheme.typography.bodyMedium,
            color = VrontalTextMuted,
        )
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = {
            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                data = android.net.Uri.parse("package:${context.packageName}")
            }
            context.startActivity(intent)
        }) { Text("Izinkan di Pengaturan", color = VrontalGold) }
    }
}
