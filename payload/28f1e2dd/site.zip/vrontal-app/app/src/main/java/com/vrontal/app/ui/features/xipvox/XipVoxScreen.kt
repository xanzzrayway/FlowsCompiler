package com.vrontal.app.ui.features.xipvox

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vrontal.app.ui.components.LiveBackground
import com.vrontal.app.ui.components.glass
import com.vrontal.app.ui.theme.VrontalCyan
import com.vrontal.app.ui.theme.VrontalGlassBorder
import com.vrontal.app.ui.theme.VrontalGold
import com.vrontal.app.ui.theme.VrontalGoldSoft
import com.vrontal.app.ui.theme.VrontalIcons
import com.vrontal.app.ui.theme.VrontalTextMuted
import com.vrontal.app.ui.theme.VrontalTextPrimary

/**
 * Mini-browser dalam aplikasi: tempel URL, tampil rapi, beberapa tab sekaligus.
 * Tiap tab punya WebView sendiri yang tetap hidup saat pindah tab (lihat XipTab.webView) —
 * yang berganti cuma WebView mana yang ditempel ke container yang terlihat.
 */
@Composable
fun XipVoxScreen(onBack: () -> Unit) {
    val vm: XipVoxViewModel = viewModel()
    val activeTab = vm.activeTab()

    // Tahap 7 [ai]: jeda semua WebView saat layar masuk background, lanjutkan saat kembali.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> vm.pauseWebViews()
                Lifecycle.Event.ON_RESUME -> vm.resumeWebViews()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Box(Modifier.fillMaxSize()) {
        LiveBackground()
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp),
        ) {
            // --- Top bar ---
            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(VrontalIcons.ArrowBack, contentDescription = "Kembali", tint = VrontalTextPrimary)
                }
                Text("XipVOx", style = MaterialTheme.typography.titleLarge, color = VrontalTextPrimary, modifier = Modifier.weight(1f))
                IconButton(onClick = { vm.newTab() }) {
                    Text("+", style = MaterialTheme.typography.headlineMedium, color = VrontalGold)
                }
            }

            // --- Tab strip ---
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 4.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                items(vm.tabs, key = { it.id }) { tab ->
                    val selected = tab.id == vm.activeTabId.value
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (selected) VrontalGoldSoft else androidx.compose.ui.graphics.Color.Transparent)
                            .border(1.dp, if (selected) VrontalGold else VrontalGlassBorder, RoundedCornerShape(12.dp))
                            .clickable { vm.selectTab(tab.id) }
                            .padding(start = 12.dp, end = 6.dp, top = 8.dp, bottom = 8.dp)
                            .width(140.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            tab.title.value,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (selected) VrontalGold else VrontalTextMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        IconButton(onClick = { vm.closeTab(tab.id) }, modifier = Modifier.size(20.dp)) {
                            Text("×", color = VrontalTextMuted, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }

            if (activeTab == null) return@Column

            // --- URL bar + navigasi ---
            var urlField by remember(activeTab.id) { mutableStateOf(activeTab.url.value) }
            // Sinkron kolom URL kalau user navigasi lewat tautan di dalam halaman — tapi cuma saat
            // alamatnya benar-benar berubah, bukan tiap recomposition (supaya tidak menimpa ketikan user).
            androidx.compose.runtime.LaunchedEffect(activeTab.id, activeTab.url.value) {
                urlField = activeTab.url.value
            }

            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(
                    onClick = { activeTab.webView?.goBack() },
                    enabled = activeTab.canGoBack.value,
                ) {
                    Icon(VrontalIcons.ArrowBack, contentDescription = "Mundur",
                        tint = if (activeTab.canGoBack.value) VrontalTextPrimary else VrontalTextMuted)
                }
                OutlinedTextField(
                    value = urlField,
                    onValueChange = { urlField = it },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    textStyle = MaterialTheme.typography.bodyMedium,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = {
                        activeTab.webView?.loadUrl(XipVoxViewModel.normalizeUrl(urlField))
                    }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = VrontalTextPrimary,
                        unfocusedTextColor = VrontalTextPrimary,
                        focusedBorderColor = VrontalGold,
                        unfocusedBorderColor = VrontalGlassBorder,
                        cursorColor = VrontalGold,
                    ),
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = { activeTab.webView?.reload() }) {
                    Text("↻", style = MaterialTheme.typography.titleLarge, color = VrontalCyan)
                }
            }

            if (activeTab.loading.value) {
                LinearProgressIndicator(
                    progress = { activeTab.progress.intValue / 100f },
                    color = VrontalGold,
                    trackColor = VrontalGlassBorder,
                    modifier = Modifier.fillMaxWidth().height(2.dp),
                )
            }

            // --- Konten web ---
            Box(
                Modifier.fillMaxWidth().weight(1f).padding(top = 8.dp, bottom = 12.dp)
                    .clip(RoundedCornerShape(16.dp)).glass(),
            ) {
                XipVoxWebViewHost(tab = activeTab)
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun XipVoxWebViewHost(tab: XipTab) {
    val context = LocalContext.current
    AndroidView(
        factory = { FrameLayout(it) },
        update = { container ->
            val webView = tab.webView ?: WebView(context).apply {
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.loadWithOverviewMode = true
                settings.useWideViewPort = true
                // Tidak ada addJavascriptInterface() di mana pun — sengaja, supaya halaman luar
                // tidak pernah punya jalan masuk ke kode/data aplikasi.
                webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                        tab.loading.value = true
                        tab.canGoBack.value = view.canGoBack()
                    }
                    override fun onPageFinished(view: WebView, url: String?) {
                        tab.loading.value = false
                        tab.canGoBack.value = view.canGoBack()
                        if (url != null) tab.url.value = url
                    }
                }
                webChromeClient = object : WebChromeClient() {
                    override fun onProgressChanged(view: WebView, newProgress: Int) {
                        tab.progress.intValue = newProgress
                    }
                    override fun onReceivedTitle(view: WebView, title: String?) {
                        tab.title.value = if (title.isNullOrBlank()) tab.url.value else title
                    }
                }
                loadUrl(tab.url.value)
            }.also { tab.webView = it }

            (webView.parent as? ViewGroup)?.let { if (it !== container) it.removeView(webView) }
            if (container.childCount == 0 || container.getChildAt(0) !== webView) {
                container.removeAllViews()
                container.addView(webView)
            }
        },
        modifier = Modifier.fillMaxSize(),
    )
}
