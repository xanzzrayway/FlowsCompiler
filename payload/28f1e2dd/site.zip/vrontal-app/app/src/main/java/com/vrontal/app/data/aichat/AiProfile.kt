package com.vrontal.app.data.aichat

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Satu "AI" yang user daftarkan sendiri — bebas API apa saja, bukan terkunci ke satu provider.
 * [headersJsonEncrypted] dan [bodyTemplate] dienkripsi (lihat SecureStore) karena biasanya memuat
 * API key/token di dalamnya (mis. header "Authorization: Bearer ..." atau key tertulis di body).
 *
 * [bodyTemplate]: JSON bebas bikinan user, isi placeholder:
 *   {{PESAN}}          -> diganti teks pesan user (sudah di-escape aman buat JSON)
 *   {{GAMBAR_BASE64}}  -> diganti base64 gambar terlampir (string kosong kalau tidak ada gambar)
 * [responsePath]: jalan menuju teks balasan di JSON respons, format "choices.0.message.content".
 */
@Entity(tableName = "ai_profile")
data class AiProfile(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val endpoint: String,
    val headersJsonEncrypted: String,
    val bodyTemplateEncrypted: String,
    val responsePath: String,
    // Jalur potongan balasan untuk mode streaming (SSE), mis. "choices.0.delta.content". Kosong = tanpa streaming.
    @ColumnInfo(defaultValue = "''") val streamPath: String = "",
    val createdAt: Long = System.currentTimeMillis(),
)
