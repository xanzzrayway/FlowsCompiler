package com.vrontal.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val VrontalColorScheme = darkColorScheme(
    primary = VrontalGold,
    onPrimary = VrontalBackground,
    secondary = VrontalCyan,
    onSecondary = VrontalBackground,
    background = VrontalBackground,
    onBackground = VrontalTextPrimary,
    surface = VrontalSurface,
    onSurface = VrontalTextPrimary,
    surfaceVariant = VrontalSurfaceGlass,
    onSurfaceVariant = VrontalTextMuted,
    error = VrontalDanger,
    outline = VrontalGlassBorder,
)

@Composable
fun VrontalTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = VrontalColorScheme,
        typography = VrontalTypography,
        content = content,
    )
}
