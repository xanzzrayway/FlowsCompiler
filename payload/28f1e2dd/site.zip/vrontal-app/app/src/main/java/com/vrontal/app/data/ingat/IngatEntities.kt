package com.vrontal.app.data.ingat

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Satu barang yang dicatat. Lokasinya disimpan sebagai riwayat di [IngatEntry]. */
@Entity(tableName = "ingat_item")
data class IngatItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
)

/** Satu catatan lokasi barang (teks + foto/video opsional). Entri terbaru = lokasi saat ini. */
@Entity(tableName = "ingat_entry")
data class IngatEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemId: Long,
    val place: String,
    val mediaPath: String? = null, // file di penyimpanan internal app
    val mediaType: String? = null, // MEDIA_IMAGE / MEDIA_VIDEO
    val thumbPath: String? = null, // cuplikan untuk video
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "ingat_alarm")
data class IngatAlarm(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val hour: Int,
    val minute: Int,
    val repeatDaily: Boolean,
    val enabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
)

const val MEDIA_IMAGE = "IMAGE"
const val MEDIA_VIDEO = "VIDEO"

data class IngatItemView(val item: IngatItem, val entries: List<IngatEntry>) {
    val latest: IngatEntry? get() = entries.firstOrNull()
}
