package com.vrontal.app.data.loster

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.vrontal.app.data.VrontalDatabase
import com.vrontal.app.data.ingat.IngatScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Alarm tidak bertahan setelah HP dimatikan/restart — jadwalkan ulang alarm Loster dan semua alarm Ingat di sini. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AlarmScheduler.scheduleNext(context)
                IngatScheduler.rescheduleAll(context, VrontalDatabase.get(context).ingatDao().enabledAlarms())
            } finally {
                pending.finish()
            }
        }
    }
}
