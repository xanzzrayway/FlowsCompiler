package com.vrontal.app.ui.features.ingat

import android.Manifest
import android.net.Uri
import android.os.Build
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimeInput
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.rememberAsyncImagePainter
import com.vrontal.app.data.ingat.IngatAlarm
import com.vrontal.app.data.ingat.IngatEntry
import com.vrontal.app.data.ingat.IngatItemView
import com.vrontal.app.data.ingat.MEDIA_VIDEO
import com.vrontal.app.ui.components.FeatureScaffold
import com.vrontal.app.ui.components.SegmentRow
import com.vrontal.app.ui.components.glass
import com.vrontal.app.ui.theme.VrontalBackground
import com.vrontal.app.ui.theme.VrontalCyan
import com.vrontal.app.ui.theme.VrontalDanger
import com.vrontal.app.ui.theme.VrontalGlassBorder
import com.vrontal.app.ui.theme.VrontalGold
import com.vrontal.app.ui.theme.VrontalTextMuted
import com.vrontal.app.ui.theme.VrontalTextPrimary
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val dateFmt = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID"))

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = VrontalTextPrimary,
    unfocusedTextColor = VrontalTextPrimary,
    focusedBorderColor = VrontalGold,
    unfocusedBorderColor = VrontalGlassBorder,
    focusedLabelColor = VrontalGold,
    unfocusedLabelColor = VrontalTextMuted,
    cursorColor = VrontalGold,
)

@Composable
fun IngatScreen(onBack: () -> Unit) {
    val vm: IngatViewModel = viewModel()
    val items by vm.items.collectAsState()
    val alarms by vm.alarms.collectAsState()
    val query by vm.query.collectAsState()
    val message by vm.message.collectAsState()

    var tab by remember { mutableStateOf(0) }
    var addItem by remember { mutableStateOf(false) }
    var updateFor by remember { mutableStateOf<IngatItemView?>(null) }
    var finishFor by remember { mutableStateOf<IngatItemView?>(null) }
    var mediaFor by remember { mutableStateOf<IngatEntry?>(null) }
    var addAlarm by remember { mutableStateOf(false) }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    FeatureScaffold(title = "Ingat", onBack = onBack) {
        Column(Modifier.fillMaxSize()) {
            SegmentRow(listOf("Barang", "Alarm"), tab) { tab = it }
            Spacer(Modifier.height(12.dp))
            message?.let {
                Text(
                    it, color = VrontalDanger, style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.fillMaxWidth().clickable { vm.dismissMessage() }.padding(bottom = 8.dp),
                )
            }
            if (tab == 0) {
                ItemsTab(
                    modifier = Modifier.weight(1f),
                    items = items, query = query, onQuery = { vm.query.value = it },
                    onAdd = { addItem = true },
                    onUpdate = { updateFor = it }, onFinish = { finishFor = it }, onMedia = { mediaFor = it },
                )
            } else {
                AlarmsTab(
                    modifier = Modifier.weight(1f),
                    alarms = alarms, onAdd = { addAlarm = true },
                    onToggle = { a, on -> vm.setAlarmEnabled(a, on) }, onDelete = { vm.deleteAlarm(it) },
                )
            }
        }
    }

    if (addItem) {
        ItemFormDialog(
            title = "Catat barang", askName = true, onDismiss = { addItem = false },
            onSave = { name, place, media -> vm.addItem(name, place, media); addItem = false },
        )
    }
    updateFor?.let { view ->
        ItemFormDialog(
            title = "Update lokasi: ${view.item.name}", askName = false, onDismiss = { updateFor = null },
            onSave = { _, place, media -> vm.addEntry(view.item.id, place, media); updateFor = null },
        )
    }
    finishFor?.let { view ->
        AlertDialog(
            onDismissRequest = { finishFor = null },
            containerColor = VrontalBackground,
            title = { Text("Selesai dengan \"${view.item.name}\"?", color = VrontalTextPrimary) },
            text = {
                Text(
                    "Barang ini beserta seluruh riwayat lokasi, foto, dan videonya akan dihapus permanen dan tidak bisa dikembalikan.",
                    color = VrontalTextMuted,
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.finishItem(view.item.id); finishFor = null }) { Text("Selesai & hapus", color = VrontalDanger) }
            },
            dismissButton = { TextButton(onClick = { finishFor = null }) { Text("Batal", color = VrontalTextMuted) } },
        )
    }
    mediaFor?.let { MediaViewerDialog(it) { mediaFor = null } }
    if (addAlarm) {
        AddAlarmDialog(
            onDismiss = { addAlarm = false },
            onSave = { title, h, m, repeat -> vm.addAlarm(title, h, m, repeat); addAlarm = false },
        )
    }
}

// ---------------------------------------------------------------- Barang

@Composable
private fun ItemsTab(
    modifier: Modifier,
    items: List<IngatItemView>,
    query: String,
    onQuery: (String) -> Unit,
    onAdd: () -> Unit,
    onUpdate: (IngatItemView) -> Unit,
    onFinish: (IngatItemView) -> Unit,
    onMedia: (IngatEntry) -> Unit,
) {
    Column(modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query, onValueChange = onQuery,
                label = { Text("Cari barang / lokasi") },
                singleLine = true, colors = fieldColors(), shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f),
            )
            Button(
                onClick = onAdd, shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = VrontalGold, contentColor = VrontalBackground),
            ) { Text("+ Barang") }
        }
        Spacer(Modifier.height(12.dp))
        if (items.isEmpty()) {
            Text(
                if (query.isBlank()) "Belum ada barang. Tekan \"+ Barang\" untuk mencatat di mana kamu menaruhnya." else "Tidak ada yang cocok.",
                color = VrontalTextMuted, style = MaterialTheme.typography.bodyMedium,
            )
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(items, key = { it.item.id }) { view ->
                ItemCard(view, onUpdate = { onUpdate(view) }, onFinish = { onFinish(view) }, onMedia = onMedia)
            }
        }
    }
}

@Composable
private fun ItemCard(view: IngatItemView, onUpdate: () -> Unit, onFinish: () -> Unit, onMedia: (IngatEntry) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val latest = view.latest
    Column(Modifier.fillMaxWidth().glass().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            latest?.let { MediaThumb(it, 72.dp) { onMedia(it) } }
            Column(Modifier.weight(1f)) {
                Text(view.item.name, style = MaterialTheme.typography.titleMedium, color = VrontalGold)
                Text("Terakhir di: ${latest?.place ?: "-"}", style = MaterialTheme.typography.bodyMedium, color = VrontalTextPrimary)
                latest?.let { Text(dateFmt.format(Date(it.createdAt)), style = MaterialTheme.typography.labelMedium, color = VrontalTextMuted) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onUpdate) { Text("Update lokasi", color = VrontalCyan) }
            TextButton(onClick = { expanded = !expanded }) { Text("Riwayat (${view.entries.size})", color = VrontalTextMuted) }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onFinish) { Text("Selesai", color = VrontalDanger) }
        }
        if (expanded) {
            view.entries.forEach { e ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    MediaThumb(e, 40.dp) { onMedia(e) }
                    Column {
                        Text(e.place, style = MaterialTheme.typography.bodyMedium, color = VrontalTextPrimary)
                        Text(dateFmt.format(Date(e.createdAt)), style = MaterialTheme.typography.labelMedium, color = VrontalTextMuted)
                    }
                }
            }
        }
    }
}

@Composable
private fun MediaThumb(entry: IngatEntry, size: Dp, onClick: () -> Unit) {
    if (entry.mediaPath == null) return
    val isVideo = entry.mediaType == MEDIA_VIDEO
    val preview = if (isVideo) entry.thumbPath else entry.mediaPath
    Box(
        Modifier.size(size).clip(RoundedCornerShape(12.dp)).background(VrontalGlassBorder).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (preview != null) {
            Image(
                painter = rememberAsyncImagePainter(File(preview)), contentDescription = null,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize(),
            )
        }
        if (isVideo) Text("▶", color = Color.White, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
private fun ItemFormDialog(title: String, askName: Boolean, onDismiss: () -> Unit, onSave: (String, String, Uri?) -> Unit) {
    var name by remember { mutableStateOf("") }
    var place by remember { mutableStateOf("") }
    var media by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) media = uri }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = VrontalBackground,
        title = { Text(title, color = VrontalTextPrimary) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (askName) {
                    OutlinedTextField(
                        value = name, onValueChange = { name = it }, label = { Text("Nama barang") },
                        singleLine = true, colors = fieldColors(), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth(),
                    )
                }
                OutlinedTextField(
                    value = place, onValueChange = { place = it }, label = { Text("Ditaruh di mana?") },
                    minLines = 2, colors = fieldColors(), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth(),
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                    }) { Text(if (media == null) "+ Foto / video" else "Ganti foto / video", color = VrontalCyan) }
                    if (media != null) TextButton(onClick = { media = null }) { Text("Lepas", color = VrontalDanger) }
                }
                if (media != null) Text("1 file terlampir", style = MaterialTheme.typography.labelMedium, color = VrontalTextMuted)
            }
        },
        confirmButton = {
            TextButton(
                enabled = place.isNotBlank() && (!askName || name.isNotBlank()),
                onClick = { onSave(name.trim(), place.trim(), media) },
            ) { Text("Simpan", color = VrontalGold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = VrontalTextMuted) } },
    )
}

@Composable
private fun MediaViewerDialog(entry: IngatEntry, onDismiss: () -> Unit) {
    val path = entry.mediaPath ?: return
    Dialog(onDismissRequest = onDismiss) {
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.Black)) {
            if (entry.mediaType == MEDIA_VIDEO) {
                AndroidView(
                    factory = { ctx ->
                        VideoView(ctx).apply {
                            setVideoPath(path)
                            val controller = MediaController(ctx)
                            controller.setAnchorView(this)
                            setMediaController(controller)
                            setOnPreparedListener { start() }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(320.dp),
                )
            } else {
                Image(
                    painter = rememberAsyncImagePainter(File(path)), contentDescription = null,
                    contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Alarm

@Composable
private fun AlarmsTab(
    modifier: Modifier,
    alarms: List<IngatAlarm>,
    onAdd: () -> Unit,
    onToggle: (IngatAlarm, Boolean) -> Unit,
    onDelete: (IngatAlarm) -> Unit,
) {
    Column(modifier) {
        Button(
            onClick = onAdd, shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = VrontalGold, contentColor = VrontalBackground),
        ) { Text("+ Alarm") }
        Spacer(Modifier.height(12.dp))
        if (alarms.isEmpty()) {
            Text(
                "Belum ada alarm. Contoh: bangun, cek aplikasi absen, cek gaji.",
                color = VrontalTextMuted, style = MaterialTheme.typography.bodyMedium,
            )
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(alarms, key = { it.id }) { alarm ->
                Row(
                    Modifier.fillMaxWidth().glass().padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "%02d:%02d".format(alarm.hour, alarm.minute),
                            style = MaterialTheme.typography.headlineMedium,
                            color = if (alarm.enabled) VrontalGold else VrontalTextMuted,
                        )
                        Text(alarm.title, style = MaterialTheme.typography.bodyMedium, color = VrontalTextPrimary)
                        Text(
                            if (alarm.repeatDaily) "Setiap hari" else "Sekali (hilang setelah berbunyi)",
                            style = MaterialTheme.typography.labelMedium, color = VrontalTextMuted,
                        )
                    }
                    Switch(checked = alarm.enabled, onCheckedChange = { onToggle(alarm, it) })
                    Spacer(Modifier.width(4.dp))
                    TextButton(onClick = { onDelete(alarm) }) { Text("×", color = VrontalDanger, style = MaterialTheme.typography.titleLarge) }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddAlarmDialog(onDismiss: () -> Unit, onSave: (String, Int, Int, Boolean) -> Unit) {
    var title by remember { mutableStateOf("") }
    var repeat by remember { mutableStateOf(true) }
    val time = rememberTimePickerState(initialHour = 7, initialMinute = 0, is24Hour = true)

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = VrontalBackground,
        title = { Text("Alarm baru", color = VrontalTextPrimary) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row {
                    listOf("Bangun", "Cek absen", "Cek gaji").forEach { s ->
                        TextButton(onClick = { title = s }) { Text(s, color = VrontalCyan) }
                    }
                }
                OutlinedTextField(
                    value = title, onValueChange = { title = it }, label = { Text("Nama alarm") },
                    singleLine = true, colors = fieldColors(), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth(),
                )
                TimeInput(state = time)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = repeat, onCheckedChange = { repeat = it })
                    Spacer(Modifier.width(8.dp))
                    Text(if (repeat) "Ulangi setiap hari" else "Sekali saja", color = VrontalTextPrimary)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank(),
                onClick = { onSave(title.trim(), time.hour, time.minute, repeat) },
            ) { Text("Simpan", color = VrontalGold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = VrontalTextMuted) } },
    )
}
