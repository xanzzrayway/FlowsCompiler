package com.vrontal.app.data.aichat

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ChatRole { USER, AI, ERROR }

@Entity(tableName = "chat_message")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: Long,
    val role: ChatRole,
    val text: String,
    val colorHex: String? = null, // warna RGB custom untuk teks pesan user, null = warna bawaan
    val imageUri: String? = null, // URI lokal gambar terlampir (dari Photo Picker), kalau ada
    val timestamp: Long = System.currentTimeMillis(),
)
