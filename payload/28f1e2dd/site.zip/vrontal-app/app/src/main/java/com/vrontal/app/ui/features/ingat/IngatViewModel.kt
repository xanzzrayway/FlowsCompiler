package com.vrontal.app.ui.features.ingat

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vrontal.app.data.ingat.IngatAlarm
import com.vrontal.app.data.ingat.IngatException
import com.vrontal.app.data.ingat.IngatItemView
import com.vrontal.app.data.ingat.IngatRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class IngatViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = IngatRepository(app)

    val query = MutableStateFlow("")
    val message = MutableStateFlow<String?>(null)

    /** Daftar barang, disaring pencarian (cocok dengan nama barang ATAU lokasi mana pun di riwayatnya). */
    val items: StateFlow<List<IngatItemView>> =
        combine(repo.observeItems(), query) { list, q ->
            val key = q.trim()
            if (key.isEmpty()) list
            else list.filter { v -> v.item.name.contains(key, true) || v.entries.any { it.place.contains(key, true) } }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val alarms: StateFlow<List<IngatAlarm>> =
        repo.observeAlarms().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private fun launchSafe(block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: IngatException) {
                message.value = e.message
            } catch (e: Exception) {
                message.value = "Gagal menyimpan: ${e.message ?: e::class.simpleName}"
            }
        }
    }

    fun addItem(name: String, place: String, media: Uri?) = launchSafe { repo.addItem(name, place, media) }
    fun addEntry(itemId: Long, place: String, media: Uri?) = launchSafe { repo.addEntry(itemId, place, media) }
    fun finishItem(itemId: Long) = launchSafe { repo.finishItem(itemId) }

    fun addAlarm(title: String, hour: Int, minute: Int, repeatDaily: Boolean) =
        launchSafe { repo.addAlarm(title, hour, minute, repeatDaily) }
    fun setAlarmEnabled(alarm: IngatAlarm, enabled: Boolean) = launchSafe { repo.setAlarmEnabled(alarm, enabled) }
    fun deleteAlarm(alarm: IngatAlarm) = launchSafe { repo.deleteAlarm(alarm) }

    fun dismissMessage() { message.value = null }
}
