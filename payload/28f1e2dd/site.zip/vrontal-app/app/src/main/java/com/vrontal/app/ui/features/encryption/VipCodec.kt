package com.vrontal.app.ui.features.encryption

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction

enum class CodecMode(val label: String) {
    BINER("Biner"),
    MORSE("Morse"),
}

sealed interface CodecResult {
    data class Ok(val value: String) : CodecResult
    data class Error(val message: String) : CodecResult
}

/**
 * Konversi teks <-> biner dan teks <-> Morse. Murni logika, tanpa Android/internet,
 * jadi bisa dites langsung lewat unit test.
 */
object VipCodec {

    fun convert(mode: CodecMode, textToCode: Boolean, input: String): CodecResult = when (mode) {
        CodecMode.BINER -> if (textToCode) textToBinary(input) else binaryToText(input)
        CodecMode.MORSE -> if (textToCode) textToMorse(input) else morseToText(input)
    }

    // ---------- Biner ----------

    /** Tiap byte UTF-8 jadi 8 bit, dipisah spasi. Emoji & huruf non-Latin ikut aman. */
    fun textToBinary(text: String): CodecResult {
        val bytes = text.toByteArray(Charsets.UTF_8)
        return CodecResult.Ok(
            bytes.joinToString(" ") { (it.toInt() and 0xFF).toString(2).padStart(8, '0') }
        )
    }

    fun binaryToText(binary: String): CodecResult {
        val clean = binary.filterNot { it.isWhitespace() }
        if (clean.isEmpty()) return CodecResult.Ok("")
        val bad = clean.firstOrNull { it != '0' && it != '1' }
        if (bad != null) return CodecResult.Error("Ada karakter selain 0 dan 1: '$bad'")
        if (clean.length % 8 != 0) {
            return CodecResult.Error("Jumlah bit harus kelipatan 8 (sekarang ${clean.length} bit)")
        }
        val bytes = ByteArray(clean.length / 8) { i ->
            clean.substring(i * 8, i * 8 + 8).toInt(2).toByte()
        }
        return try {
            val decoder = Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
            CodecResult.Ok(decoder.decode(ByteBuffer.wrap(bytes)).toString())
        } catch (e: CharacterCodingException) {
            CodecResult.Error("Biner ini bukan teks UTF-8 yang valid")
        }
    }

    // ---------- Morse ----------

    private val morseTable: Map<Char, String> = mapOf(
        'A' to ".-", 'B' to "-...", 'C' to "-.-.", 'D' to "-..", 'E' to ".",
        'F' to "..-.", 'G' to "--.", 'H' to "....", 'I' to "..", 'J' to ".---",
        'K' to "-.-", 'L' to ".-..", 'M' to "--", 'N' to "-.", 'O' to "---",
        'P' to ".--.", 'Q' to "--.-", 'R' to ".-.", 'S' to "...", 'T' to "-",
        'U' to "..-", 'V' to "...-", 'W' to ".--", 'X' to "-..-", 'Y' to "-.--",
        'Z' to "--..",
        '0' to "-----", '1' to ".----", '2' to "..---", '3' to "...--", '4' to "....-",
        '5' to ".....", '6' to "-....", '7' to "--...", '8' to "---..", '9' to "----.",
        '.' to ".-.-.-", ',' to "--..--", '?' to "..--..", '\'' to ".----.", '!' to "-.-.--",
        '/' to "-..-.", '(' to "-.--.", ')' to "-.--.-", '&' to ".-...", ':' to "---...",
        ';' to "-.-.-.", '=' to "-...-", '+' to ".-.-.", '-' to "-....-", '_' to "..--.-",
        '"' to ".-..-.", '$' to "...-..-", '@' to ".--.-.",
    )

    private val morseReverse: Map<String, Char> = morseTable.entries.associate { (k, v) -> v to k }

    /** Huruf dipisah spasi, kata dipisah " / ". Huruf kecil otomatis jadi besar. */
    fun textToMorse(text: String): CodecResult {
        val unsupported = linkedSetOf<Char>()
        val words = text.split(Regex("\\s+")).filter { it.isNotEmpty() }.map { word ->
            word.map { ch ->
                val code = morseTable[ch.uppercaseChar()]
                if (code == null) unsupported.add(ch)
                code
            }
        }
        if (unsupported.isNotEmpty()) {
            return CodecResult.Error(
                "Karakter ini belum didukung Morse: " + unsupported.joinToString(" ") { "'$it'" }
            )
        }
        return CodecResult.Ok(words.joinToString(" / ") { codes -> codes.joinToString(" ") })
    }

    /** Terima titik/strip biasa, plus variasi (· • − – _) dan pemisah kata "/" atau "|". */
    fun morseToText(morse: String): CodecResult {
        val normalized = morse
            .replace('·', '.').replace('•', '.')
            .replace('−', '-').replace('–', '-').replace('—', '-').replace('_', '-')
            .replace('|', '/')
        val unknown = mutableListOf<String>()
        val words = normalized.split('/').map { it.trim() }.filter { it.isNotEmpty() }.map { word ->
            word.split(Regex("\\s+")).filter { it.isNotEmpty() }.map { code ->
                val ch = morseReverse[code]
                if (ch == null) unknown.add(code)
                ch
            }
        }
        if (unknown.isNotEmpty()) {
            return CodecResult.Error("Kode Morse tidak dikenal: " + unknown.distinct().joinToString(" "))
        }
        return CodecResult.Ok(words.joinToString(" ") { chars -> chars.joinToString("") })
    }
}
