package com.vrontal.app.ui.menu

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.vrontal.app.ui.components.LiveBackground
import com.vrontal.app.ui.components.glass
import com.vrontal.app.ui.theme.VrontalCyan
import com.vrontal.app.ui.theme.VrontalGlassBorder
import com.vrontal.app.ui.theme.VrontalGold
import com.vrontal.app.ui.theme.VrontalIcons
import com.vrontal.app.ui.theme.VrontalTextMuted
import com.vrontal.app.ui.theme.VrontalTextPrimary

private data class MenuItem(val route: String, val title: String, val subtitle: String, val icon: ImageVector)

private val menuItems = listOf(
    MenuItem("encryption", "VipEnkripsi", "Biner & Morse, bisa dua arah", VrontalIcons.Lock),
    MenuItem("loster", "Loster Legal", "Absen harian & rekap alpha", VrontalIcons.Calendar),
    MenuItem("credit", "Credit", "Tim & komunitas", VrontalIcons.Info),
    MenuItem("xipvox", "XipVOx", "Buka web dalam tab", VrontalIcons.Globe),
    MenuItem("aichat", "Chat AI", "Pakai API key milikmu sendiri", VrontalIcons.Bot),
    MenuItem("ingat", "Ingat", "Catat barang & alarm pengingat", VrontalIcons.Box),
)

@Composable
fun MenuScreen(displayName: String, onNavigate: (String) -> Unit, onSignOut: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val chevron by animateFloatAsState(if (expanded) 180f else 0f, tween(300), label = "chevron")

    Box(Modifier.fillMaxSize()) {
        LiveBackground()
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(24.dp)
        ) {
            Spacer(Modifier.height(24.dp))
            Text("Vrontal", style = MaterialTheme.typography.displaySmall, color = VrontalGold)
            Spacer(Modifier.height(4.dp))
            Text("Halo, $displayName", style = MaterialTheme.typography.bodyLarge, color = VrontalTextMuted)
            Spacer(Modifier.height(28.dp))

            Row(
                Modifier
                    .fillMaxWidth()
                    .glass(RoundedCornerShape(18.dp))
                    .clickable { expanded = !expanded }
                    .padding(horizontal = 18.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(VrontalIcons.Menu, contentDescription = null, tint = VrontalGold)
                Spacer(Modifier.width(12.dp))
                Text(
                    "Menu",
                    style = MaterialTheme.typography.titleMedium,
                    color = VrontalTextPrimary,
                    modifier = Modifier.weight(1f),
                )
                Icon(
                    VrontalIcons.ChevronDown,
                    contentDescription = if (expanded) "Tutup menu" else "Buka menu",
                    tint = VrontalTextMuted,
                    modifier = Modifier.rotate(chevron),
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically(tween(350)) + fadeIn(tween(350)),
                exit = shrinkVertically(tween(300)) + fadeOut(tween(200)),
            ) {
                Column(Modifier.padding(top = 10.dp).fillMaxWidth().glass()) {
                    menuItems.forEachIndexed { index, item ->
                        if (index > 0) HorizontalDivider(color = VrontalGlassBorder)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { onNavigate(item.route) }
                                .padding(horizontal = 18.dp, vertical = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(item.icon, contentDescription = null, tint = VrontalCyan)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.title, style = MaterialTheme.typography.titleMedium, color = VrontalTextPrimary)
                                Text(item.subtitle, style = MaterialTheme.typography.bodyMedium, color = VrontalTextMuted)
                            }
                            Text("${index + 1}", style = MaterialTheme.typography.labelMedium, color = VrontalTextMuted)
                        }
                    }
                }
            }

            Spacer(Modifier.weight(1f))
            TextButton(onClick = onSignOut, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text("Keluar", color = VrontalTextMuted)
            }
        }
    }
}
