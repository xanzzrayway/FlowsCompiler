package com.vrontal.app.ui.features.aichat

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vrontal.app.data.aichat.ProfileInput
import com.vrontal.app.ui.components.FeatureScaffold
import com.vrontal.app.ui.components.glass
import com.vrontal.app.ui.theme.VrontalBackground
import com.vrontal.app.ui.theme.VrontalDanger
import com.vrontal.app.ui.theme.VrontalGlassBorder
import com.vrontal.app.ui.theme.VrontalGold
import com.vrontal.app.ui.theme.VrontalTextMuted
import com.vrontal.app.ui.theme.VrontalTextPrimary

@Composable
fun AiProfileFormScreen(onBack: () -> Unit, onSaved: (Long) -> Unit) {
    val vm: AiChatViewModel = viewModel()

    var name by remember { mutableStateOf("") }
    var endpoint by remember { mutableStateOf("") }
    var headers by remember { mutableStateOf(listOf("Authorization" to "Bearer ")) }
    var bodyTemplate by remember {
        mutableStateOf("{\"model\":\"\",\"messages\":[{\"role\":\"user\",\"content\":\"{{PESAN}}\"}]}")
    }
    var responsePath by remember { mutableStateOf("choices.0.message.content") }
    var streamPath by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = VrontalTextPrimary,
        unfocusedTextColor = VrontalTextPrimary,
        focusedBorderColor = VrontalGold,
        unfocusedBorderColor = VrontalGlassBorder,
        focusedLabelColor = VrontalGold,
        unfocusedLabelColor = VrontalTextMuted,
        cursorColor = VrontalGold,
    )

    FeatureScaffold(title = "Pasang AI baru", onBack = onBack) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("Nama AI (bebas, buat penanda saja)") },
                singleLine = true, colors = fieldColors, shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = endpoint, onValueChange = { endpoint = it },
                label = { Text("Endpoint URL") },
                singleLine = true, colors = fieldColors, shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            )

            Text("Header", style = MaterialTheme.typography.titleMedium, color = VrontalTextPrimary)
            headers.forEachIndexed { i, (k, v) ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = k, onValueChange = { nv -> headers = headers.toMutableList().also { it[i] = nv to v } },
                        label = { Text("Key") }, singleLine = true, colors = fieldColors,
                        shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = v, onValueChange = { nv -> headers = headers.toMutableList().also { it[i] = k to nv } },
                        label = { Text("Value") }, singleLine = true, colors = fieldColors,
                        shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1.4f),
                    )
                    IconButton(onClick = { headers = headers.toMutableList().also { it.removeAt(i) } }) {
                        Text("×", color = VrontalTextMuted, style = MaterialTheme.typography.titleLarge)
                    }
                }
            }
            Button(
                onClick = { headers = headers + ("" to "") },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = VrontalGlassBorder, contentColor = VrontalTextPrimary),
            ) { Text("+ Tambah header") }

            OutlinedTextField(
                value = bodyTemplate, onValueChange = { bodyTemplate = it },
                label = { Text("Template body (JSON)") },
                textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                minLines = 5, colors = fieldColors, shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "Pakai {{PESAN}} buat teks pesan user (AI tidak ingat pesan sebelumnya), atau {{RIWAYAT}} buat mengirim 20 pesan terakhir sebagai array JSON [{\"role\",\"content\"}] — mis. \"messages\":{{RIWAYAT}}. Boleh juga {{GAMBAR_BASE64}} kalau mau sisipkan gambar sebagai base64 (opsional, tergantung API-nya dukung atau tidak).",
                style = MaterialTheme.typography.labelMedium, color = VrontalTextMuted,
            )

            OutlinedTextField(
                value = responsePath, onValueChange = { responsePath = it },
                label = { Text("Jalur balasan di respons JSON") },
                singleLine = true, colors = fieldColors, shape = RoundedCornerShape(14.dp),
                textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "Contoh: choices.0.message.content — angka berarti urutan di dalam array.",
                style = MaterialTheme.typography.labelMedium, color = VrontalTextMuted,
            )

            OutlinedTextField(
                value = streamPath, onValueChange = { streamPath = it },
                label = { Text("Jalur potongan balasan (streaming, opsional)") },
                singleLine = true, colors = fieldColors, shape = RoundedCornerShape(14.dp),
                textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "Kosongkan kalau tidak mau streaming. Kalau diisi (mis. choices.0.delta.content), balasan muncul bertahap — template body juga harus meminta stream, mis. tambahkan \"stream\":true.",
                style = MaterialTheme.typography.labelMedium, color = VrontalTextMuted,
            )

            error?.let { Text(it, color = VrontalDanger, style = MaterialTheme.typography.bodyMedium) }

            Button(
                onClick = {
                    when {
                        name.isBlank() -> error = "Isi nama dulu"
                        endpoint.isBlank() -> error = "Isi endpoint dulu"
                        !(bodyTemplate.contains("{{PESAN}}") || bodyTemplate.contains("{{RIWAYAT}}")) -> error = "Template body wajib memuat {{PESAN}} atau {{RIWAYAT}}"
                        responsePath.isBlank() -> error = "Isi jalur balasan dulu"
                        else -> {
                            error = null
                            vm.saveProfile(
                                ProfileInput(name.trim(), endpoint.trim(), headers.filter { it.first.isNotBlank() }, bodyTemplate, responsePath.trim(), streamPath.trim()),
                                onSaved = onSaved,
                            )
                        }
                    }
                },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = VrontalGold, contentColor = VrontalBackground),
                modifier = Modifier.fillMaxWidth().height(50.dp),
            ) { Text("Simpan & pakai", style = MaterialTheme.typography.labelLarge) }
        }
    }
}
