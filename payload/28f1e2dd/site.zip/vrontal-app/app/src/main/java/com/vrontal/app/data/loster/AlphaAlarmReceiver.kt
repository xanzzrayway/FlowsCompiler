package com.vrontal.app.data.loster

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.vrontal.app.MainActivity
import com.vrontal.app.VrontalApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Dipanggil AlarmManager tepat jam 11 pagi. Cek status hari ini, tandai Alpha kalau belum absen. */
class AlphaAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repo = LosterRepository(context)
                val markedNow = repo.backfillAlpha()
                if (markedNow) notifyAlpha(context)
            } finally {
                // Jadwalkan lagi untuk besok, apa pun hasilnya.
                AlarmScheduler.scheduleNext(context)
                pending.finish()
            }
        }
    }

    private fun notifyAlpha(context: Context) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ActivityCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
        ) return

        val openIntent = Intent(context, MainActivity::class.java)
        val pi = android.app.PendingIntent.getActivity(
            context, 0, openIntent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE,
        )
        val notif = NotificationCompat.Builder(context, VrontalApp.CHANNEL_LOSTER)
            .setContentTitle("Alpha hari ini")
            .setContentText("Belum absen sampai jam 11 — tercatat Alpha di Loster Legal.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIF_ID, notif)
    }

    private companion object {
        const val NOTIF_ID = 1001
    }
}
