package com.vrontal.app.data.aichat

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AiChatDao {
    @Insert suspend fun insertProfile(profile: AiProfile): Long
    @Delete suspend fun deleteProfile(profile: AiProfile)
    @Query("SELECT * FROM ai_profile ORDER BY createdAt ASC")
    fun observeProfiles(): Flow<List<AiProfile>>
    @Query("SELECT * FROM ai_profile WHERE id = :id LIMIT 1")
    suspend fun getProfile(id: Long): AiProfile?

    @Insert suspend fun insertMessage(message: ChatMessage): Long
    @Query("SELECT * FROM chat_message WHERE profileId = :profileId ORDER BY timestamp ASC")
    fun observeMessages(profileId: Long): Flow<List<ChatMessage>>
    @Query("SELECT * FROM (SELECT * FROM chat_message WHERE profileId = :profileId AND role != 'ERROR' AND text != '' ORDER BY timestamp DESC, id DESC LIMIT :limit) ORDER BY timestamp ASC, id ASC")
    suspend fun recentMessages(profileId: Long, limit: Int): List<ChatMessage>
    @Query("UPDATE chat_message SET text = :text WHERE id = :id")
    suspend fun updateMessageText(id: Long, text: String)
    @Query("SELECT imageUri FROM chat_message WHERE profileId = :profileId AND imageUri IS NOT NULL")
    suspend fun imageUrisOf(profileId: Long): List<String>
    @Query("DELETE FROM chat_message WHERE profileId = :profileId")
    suspend fun clearMessages(profileId: Long)
}
