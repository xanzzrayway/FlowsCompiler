package com.vrontal.app.ui.features.aichat

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.rememberAsyncImagePainter
import com.vrontal.app.data.aichat.AiProfile
import com.vrontal.app.data.aichat.ChatMessage
import com.vrontal.app.data.aichat.ChatRole
import com.vrontal.app.ui.components.LiveBackground
import com.vrontal.app.ui.components.glass
import com.vrontal.app.ui.theme.VrontalBackground
import com.vrontal.app.ui.theme.VrontalCyan
import com.vrontal.app.ui.theme.VrontalDanger
import com.vrontal.app.ui.theme.VrontalGlassBorder
import com.vrontal.app.ui.theme.VrontalGold
import com.vrontal.app.ui.theme.VrontalGoldSoft
import com.vrontal.app.ui.theme.VrontalIcons
import com.vrontal.app.ui.theme.VrontalTextMuted
import com.vrontal.app.ui.theme.VrontalTextPrimary

private val palette = listOf(
    null, // default
    0xFFFFB020, 0xFF00E5D8, 0xFFFF6B6B, 0xFF7FD17F, 0xFF8CA8FF, 0xFFE08CFF, 0xFFFFFFFF,
)

@Composable
fun AiChatScreen(onBack: () -> Unit, onAddProfile: () -> Unit) {
    val vm: AiChatViewModel = viewModel()
    val profiles by vm.profiles.collectAsState()
    val activeId by vm.activeProfileId.collectAsState()
    val messages by vm.messages.collectAsState()
    val sending by vm.sending.collectAsState()

    LaunchedEffect(profiles) {
        if (vm.activeProfileId.value == null && profiles.isNotEmpty()) vm.selectProfile(profiles.first().id)
    }

    val activeProfile = profiles.find { it.id == activeId }
    var menuOpen by remember { mutableStateOf(false) }
    var profilePicker by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        LiveBackground()
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            // --- Top bar ---
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) { Icon(VrontalIcons.ArrowBack, contentDescription = "Kembali", tint = VrontalTextPrimary) }
                Box(Modifier.weight(1f)) {
                    Row(
                        Modifier.clickable { profilePicker = true }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            activeProfile?.name ?: "Pilih AI",
                            style = MaterialTheme.typography.titleLarge,
                            color = VrontalTextPrimary,
                        )
                        if (profiles.size > 1) Text(" ▾", color = VrontalTextMuted)
                    }
                    DropdownMenu(expanded = profilePicker, onDismissRequest = { profilePicker = false }) {
                        profiles.forEach { p ->
                            DropdownMenuItem(text = { Text(p.name) }, onClick = { vm.selectProfile(p.id); profilePicker = false })
                        }
                    }
                }
                IconButton(onClick = onAddProfile) { Text("+", style = MaterialTheme.typography.headlineMedium, color = VrontalGold) }
                Box {
                    IconButton(onClick = { menuOpen = true }) { Text("⋮", style = MaterialTheme.typography.titleLarge, color = VrontalTextPrimary) }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(text = { Text("Hapus riwayat chat") }, onClick = { menuOpen = false; vm.clearChat() })
                        if (activeProfile != null) {
                            DropdownMenuItem(
                                text = { Text("Hapus AI ini", color = VrontalDanger) },
                                onClick = { menuOpen = false; vm.deleteProfile(activeProfile) },
                            )
                        }
                    }
                }
            }

            if (profiles.isEmpty()) {
                EmptyState(onAddProfile)
                return@Column
            }

            // --- Daftar pesan ---
            val listState = rememberLazyListState()
            val showTyping = sending && messages.lastOrNull()?.role != com.vrontal.app.data.aichat.ChatRole.AI
            LaunchedEffect(messages.size, showTyping, messages.lastOrNull()?.text?.length) {
                val count = messages.size + if (showTyping) 1 else 0
                if (count > 0) listState.scrollToItem(count - 1)
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 8.dp),
            ) {
                items(messages, key = { it.id }) { msg -> MessageBubble(msg) }
                if (showTyping) item(key = "typing") { TypingBubble() }
            }

            // --- Input ---
            ChatInput(sending = sending, onStop = { vm.stop() }, onSend = { text, color, uri -> vm.send(text, color, uri) })
        }
    }
}


@Composable
private fun EmptyState(onAddProfile: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(VrontalIcons.Bot, contentDescription = null, tint = VrontalGold, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(14.dp))
        Text("Belum ada AI terpasang", style = MaterialTheme.typography.titleLarge, color = VrontalTextPrimary)
        Spacer(Modifier.height(8.dp))
        Text(
            "Pasang API key, URL, dan format punyamu sendiri — bebas AI apa saja.",
            style = MaterialTheme.typography.bodyMedium, color = VrontalTextMuted,
            modifier = Modifier.padding(horizontal = 24.dp),
        )
        Spacer(Modifier.height(18.dp))
        androidx.compose.material3.Button(
            onClick = onAddProfile,
            colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = VrontalGold, contentColor = VrontalBackground),
        ) { Text("Pasang AI") }
    }
}

@Composable
private fun MessageBubble(msg: ChatMessage) {
    when (msg.role) {
        ChatRole.USER -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Column(
                Modifier.fillMaxWidth(0.82f).clip(RoundedCornerShape(16.dp, 4.dp, 16.dp, 16.dp))
                    .background(VrontalGoldSoft).padding(12.dp),
                horizontalAlignment = Alignment.End,
            ) {
                msg.imageUri?.let {
                    Image(
                        painter = rememberAsyncImagePainter(Uri.parse(it)),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(12.dp)).padding(bottom = if (msg.text.isNotBlank()) 8.dp else 0.dp),
                    )
                }
                if (msg.text.isNotBlank()) {
                    Text(msg.text, color = msg.colorHex?.let { runCatching { Color(android.graphics.Color.parseColor(it)) }.getOrNull() } ?: VrontalTextPrimary)
                }
            }
        }
        ChatRole.AI -> Row(Modifier.fillMaxWidth(0.88f), verticalAlignment = Alignment.Top) {
            AiAvatar()
            Spacer(Modifier.width(8.dp))
            Column(
                Modifier.clip(RoundedCornerShape(4.dp, 16.dp, 16.dp, 16.dp)).glass().padding(12.dp),
            ) { Text(msg.text, color = VrontalTextPrimary) }
        }
        ChatRole.ERROR -> Row(Modifier.fillMaxWidth(0.88f), verticalAlignment = Alignment.Top) {
            Box(
                Modifier.size(28.dp).clip(CircleShape).background(VrontalDanger.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center,
            ) { Text("!", color = VrontalDanger) }
            Spacer(Modifier.width(8.dp))
            Column(
                Modifier.clip(RoundedCornerShape(4.dp, 16.dp, 16.dp, 16.dp))
                    .border(1.dp, VrontalDanger.copy(alpha = 0.4f), RoundedCornerShape(4.dp, 16.dp, 16.dp, 16.dp))
                    .padding(12.dp),
            ) { Text(msg.text, color = VrontalDanger) }
        }
    }
}

@Composable
private fun AiAvatar() {
    Box(Modifier.size(28.dp).clip(CircleShape).background(VrontalGoldSoft), contentAlignment = Alignment.Center) {
        Icon(VrontalIcons.Bot, contentDescription = null, tint = VrontalGold, modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun TypingBubble() {
    Row(Modifier.fillMaxWidth(0.5f), verticalAlignment = Alignment.CenterVertically) {
        AiAvatar()
        Spacer(Modifier.width(8.dp))
        Box(Modifier.clip(RoundedCornerShape(4.dp, 16.dp, 16.dp, 16.dp)).glass().padding(horizontal = 16.dp, vertical = 14.dp)) {
            Text("mengetik…", color = VrontalTextMuted, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun ChatInput(sending: Boolean, onStop: () -> Unit, onSend: (String, String?, Uri?) -> Unit) {
    var text by remember { mutableStateOf("") }
    var colorHex by remember { mutableStateOf<String?>(null) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var colorPicker by remember { mutableStateOf(false) }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> imageUri = uri }

    Column(Modifier.fillMaxWidth().imePadding().navigationBarsPadding().padding(12.dp)) {
        imageUri?.let { uri ->
            Row(Modifier.padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = rememberAsyncImagePainter(uri), contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)),
                )
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = { imageUri = null }) { Text("×", color = VrontalTextMuted) }
            }
        }

        if (colorPicker) {
            Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                palette.forEach { argb ->
                    val color = argb?.let { Color(it.toInt()) } ?: VrontalTextMuted
                    Box(
                        Modifier.size(26.dp).clip(CircleShape).background(color)
                            .border(2.dp, if ((argb?.let { "#%06X".format(0xFFFFFF and it.toInt()) }) == colorHex) VrontalGold else Color.Transparent, CircleShape)
                            .clickable {
                                colorHex = argb?.let { "#%06X".format(0xFFFFFF and it.toInt()) }
                                colorPicker = false
                            },
                    )
                }
            }
        }

        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            IconButton(onClick = { colorPicker = !colorPicker }) {
                Box(Modifier.size(20.dp).clip(CircleShape).background(colorHex?.let { Color(android.graphics.Color.parseColor(it)) } ?: VrontalGoldSoft))
            }
            IconButton(onClick = { pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                Text("🖼", style = MaterialTheme.typography.titleMedium)
            }
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                placeholder = { Text("Tulis pesan…", color = VrontalTextMuted) },
                textStyle = MaterialTheme.typography.bodyMedium.copy(
                    color = colorHex?.let { runCatching { Color(android.graphics.Color.parseColor(it)) }.getOrNull() } ?: VrontalTextPrimary,
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = VrontalGold, unfocusedBorderColor = VrontalGlassBorder, cursorColor = VrontalGold,
                ),
                shape = RoundedCornerShape(16.dp),
                maxLines = 4,
                modifier = Modifier.weight(1f),
            )
            IconButton(
                onClick = {
                    if (sending) {
                        onStop()
                    } else if (text.isNotBlank() || imageUri != null) {
                        onSend(text.trim(), colorHex, imageUri)
                        text = ""; imageUri = null
                    }
                },
            ) { Text(if (sending) "■" else "➤", color = if (sending) VrontalDanger else VrontalGold, style = MaterialTheme.typography.titleLarge) }
        }
    }
}
