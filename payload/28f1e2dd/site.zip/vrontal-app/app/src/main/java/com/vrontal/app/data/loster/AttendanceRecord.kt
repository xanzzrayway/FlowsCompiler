package com.vrontal.app.data.loster

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class AttendanceStatus { HADIR, ALPHA }

/** Satu baris = satu tanggal. [date] format ISO "yyyy-MM-dd" supaya query LIKE per bulan/tahun gampang. */
@Entity(tableName = "attendance")
data class AttendanceRecord(
    @PrimaryKey val date: String,
    val status: AttendanceStatus,
    val time: String? = null, // "HH:mm", hanya terisi kalau HADIR
)
