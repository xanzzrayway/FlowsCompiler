package com.vrontal.app.ui.auth

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.vrontal.app.data.AuthRepository
import com.vrontal.app.ui.components.LiveBackground
import com.vrontal.app.ui.components.glass
import com.vrontal.app.ui.theme.VrontalIcons
import com.vrontal.app.ui.theme.VrontalBackground
import com.vrontal.app.ui.theme.VrontalCyan
import com.vrontal.app.ui.theme.VrontalDanger
import com.vrontal.app.ui.theme.VrontalGlassBorder
import com.vrontal.app.ui.theme.VrontalGold
import com.vrontal.app.ui.theme.VrontalSurface
import com.vrontal.app.ui.theme.VrontalTextMuted
import com.vrontal.app.ui.theme.VrontalTextPrimary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(auth: AuthRepository, onLoggedIn: () -> Unit) {
    val scope = rememberCoroutineScope()

    var hasProfile by remember { mutableStateOf(auth.hasProfile()) }
    var name by remember { mutableStateOf(if (hasProfile) auth.displayName() else "") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var rememberMe by remember { mutableStateOf(true) }
    var keepData by remember { mutableStateOf(true) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var showReset by remember { mutableStateOf(false) }
    var visible by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { visible = true }

    fun submit() {
        if (loading) return
        val n = name.trim()
        if (n.isEmpty()) { error = "Isi nama dulu"; return }
        if (password.length < 6) { error = "Password minimal 6 karakter"; return }
        error = null
        loading = true
        scope.launch {
            val started = System.currentTimeMillis()
            val ok = if (hasProfile) {
                auth.verify(n, password, rememberMe, keepData)
            } else {
                auth.register(n, password, rememberMe, keepData)
                true
            }
            // Loading minimal 0,9 detik supaya animasinya terlihat halus, bukan berkedip.
            val elapsed = System.currentTimeMillis() - started
            if (elapsed < 900) delay(900 - elapsed)
            loading = false
            if (ok) onLoggedIn() else error = "Nama atau password salah"
        }
    }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = VrontalTextPrimary,
        unfocusedTextColor = VrontalTextPrimary,
        focusedBorderColor = VrontalGold,
        unfocusedBorderColor = VrontalGlassBorder,
        focusedLabelColor = VrontalGold,
        unfocusedLabelColor = VrontalTextMuted,
        cursorColor = VrontalGold,
    )

    Box(Modifier.fillMaxSize()) {
        LiveBackground()
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.Start,
        ) {
            AnimatedVisibility(
                visible = visible,
                enter = fadeIn(tween(600)) + slideInVertically(tween(600)) { -it / 3 },
            ) {
                Column {
                    Text("Vrontal", style = MaterialTheme.typography.displaySmall, color = VrontalGold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Multitasking jadi lebih enak.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = VrontalTextMuted,
                    )
                }
            }

            Spacer(Modifier.height(28.dp))

            AnimatedVisibility(
                visible = visible,
                enter = fadeIn(tween(600, delayMillis = 200)) + slideInVertically(tween(600, delayMillis = 200)) { it / 4 },
            ) {
                Column(
                    Modifier.fillMaxWidth().glass().padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Text(
                        if (hasProfile) "Masuk" else "Buat profil",
                        style = MaterialTheme.typography.headlineMedium,
                        color = VrontalTextPrimary,
                    )

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it; error = null },
                        label = { Text("Nama") },
                        singleLine = true,
                        enabled = !loading,
                        colors = fieldColors,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth(),
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it; error = null },
                        label = { Text("Password") },
                        singleLine = true,
                        enabled = !loading,
                        colors = fieldColors,
                        shape = RoundedCornerShape(14.dp),
                        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            IconButton(onClick = { showPassword = !showPassword }) {
                                Icon(
                                    if (showPassword) VrontalIcons.EyeOff else VrontalIcons.Eye,
                                    contentDescription = if (showPassword) "Sembunyikan password" else "Tampilkan password",
                                    tint = VrontalTextMuted,
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    )

                    CheckRow("Ingat saya", rememberMe, enabled = !loading) { rememberMe = it }
                    CheckRow("Simpan data di perangkat ini", keepData, enabled = !loading) { keepData = it }

                    AnimatedVisibility(visible = error != null) {
                        Text(error.orEmpty(), color = VrontalDanger, style = MaterialTheme.typography.bodyMedium)
                    }

                    Button(
                        onClick = { submit() },
                        enabled = !loading,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = VrontalGold,
                            contentColor = VrontalBackground,
                            disabledContainerColor = VrontalGold.copy(alpha = 0.75f),
                            disabledContentColor = VrontalBackground,
                        ),
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                    ) {
                        AnimatedContent(targetState = loading, label = "loginButton") { isLoading ->
                            if (isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    color = VrontalBackground,
                                    strokeWidth = 2.5.dp,
                                )
                            } else {
                                Text(
                                    if (hasProfile) "Masuk" else "Buat profil & masuk",
                                    style = MaterialTheme.typography.labelLarge,
                                )
                            }
                        }
                    }

                    if (hasProfile) {
                        TextButton(
                            onClick = { showReset = true },
                            enabled = !loading,
                            modifier = Modifier.align(Alignment.CenterHorizontally),
                        ) {
                            Text("Lupa password? Reset profil", color = VrontalCyan)
                        }
                    }
                }
            }
        }
    }

    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            containerColor = VrontalSurface,
            titleContentColor = VrontalTextPrimary,
            textContentColor = VrontalTextMuted,
            title = { Text("Reset profil?") },
            text = {
                Text(
                    "Nama & password lokal di perangkat ini akan dihapus, lalu kamu bisa membuat profil baru. " +
                        "Karena tidak ada server, password yang lupa memang tidak bisa dipulihkan."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    auth.resetProfile()
                    hasProfile = false
                    name = ""
                    password = ""
                    rememberMe = true
                    keepData = true
                    error = null
                    showReset = false
                }) { Text("Reset", color = VrontalDanger) }
            },
            dismissButton = {
                TextButton(onClick = { showReset = false }) { Text("Batal", color = VrontalTextPrimary) }
            },
        )
    }
}

@Composable
private fun CheckRow(label: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = enabled) { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onChange,
            enabled = enabled,
            colors = CheckboxDefaults.colors(
                checkedColor = VrontalGold,
                checkmarkColor = VrontalBackground,
                uncheckedColor = VrontalTextMuted,
            ),
        )
        Text(label, style = MaterialTheme.typography.bodyMedium, color = VrontalTextPrimary)
    }
}
