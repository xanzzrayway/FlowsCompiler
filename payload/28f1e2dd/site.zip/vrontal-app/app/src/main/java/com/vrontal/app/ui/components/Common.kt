package com.vrontal.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.vrontal.app.ui.theme.VrontalBackground
import com.vrontal.app.ui.theme.VrontalCyan
import com.vrontal.app.ui.theme.VrontalGlassBorder
import com.vrontal.app.ui.theme.VrontalGold
import com.vrontal.app.ui.theme.VrontalGoldSoft
import com.vrontal.app.ui.theme.VrontalIcons
import com.vrontal.app.ui.theme.VrontalTextMuted

/** Efek "kaca": lapisan putih transparan bergradasi + garis tepi tipis, di atas background hidup. */
fun Modifier.glass(shape: Shape = RoundedCornerShape(20.dp)): Modifier = this
    .clip(shape)
    .background(
        Brush.linearGradient(
            listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.04f))
        )
    )
    .border(1.dp, VrontalGlassBorder, shape)

/**
 * Background hidup: dua cahaya (emas & cyan) bergerak pelan.
 * Sengaja hanya gradient radial di Canvas (tanpa blur berat) supaya ringan di HP spek rendah.
 */
@Composable
fun LiveBackground(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "bg")
    val p by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse),
        label = "bgProgress",
    )
    Canvas(modifier = modifier.fillMaxSize().background(VrontalBackground)) {
        val w = size.width
        val h = size.height
        val c1 = Offset(w * (0.15f + 0.55f * p), h * (0.12f + 0.25f * p))
        val c2 = Offset(w * (0.85f - 0.55f * p), h * (0.85f - 0.25f * p))
        drawCircle(
            brush = Brush.radialGradient(listOf(VrontalGold.copy(alpha = 0.22f), Color.Transparent), center = c1, radius = w * 0.9f),
            radius = w * 0.9f,
            center = c1,
        )
        drawCircle(
            brush = Brush.radialGradient(listOf(VrontalCyan.copy(alpha = 0.18f), Color.Transparent), center = c2, radius = w * 0.9f),
            radius = w * 0.9f,
            center = c2,
        )
    }
}

/** Kerangka layar fitur: background hidup + tombol kembali + judul. */
@Composable
fun FeatureScaffold(title: String, onBack: () -> Unit, content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        LiveBackground()
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) {
                    Icon(VrontalIcons.ArrowBack, contentDescription = "Kembali", tint = MaterialTheme.colorScheme.onBackground)
                }
                Text(title, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
            }
            content()
        }
    }
}

/** Halaman sementara untuk fitur yang dibangun di tahap berikutnya. */
@Composable
fun FeaturePlaceholder(title: String, onBack: () -> Unit, plan: List<String>) {
    FeatureScaffold(title = title, onBack = onBack) {
        Column(
            Modifier.fillMaxWidth().glass().padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Segera hadir", style = MaterialTheme.typography.titleMedium, color = VrontalGold)
            plan.forEach { line ->
                Text("• $line", style = MaterialTheme.typography.bodyMedium, color = VrontalTextMuted)
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

/** Pemilih pilihan bergaya segmented control (dipakai VipEnkripsi & Check Alpha/Hadir). */
@Composable
fun SegmentRow(options: List<String>, selectedIndex: Int, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().glass(shape).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        options.forEachIndexed { index, label ->
            val selected = index == selectedIndex
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (selected) VrontalGoldSoft else Color.Transparent)
                    .border(1.dp, if (selected) VrontalGold else Color.Transparent, RoundedCornerShape(10.dp))
                    .clickable { onSelect(index) }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (selected) VrontalGold else VrontalTextMuted,
                    textAlign = TextAlign.Center,
                )
            }
        }
    }
}
