package com.vrontal.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.vrontal.app.data.AuthRepository
import com.vrontal.app.ui.navigation.VrontalNav
import com.vrontal.app.ui.theme.VrontalTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        val auth = AuthRepository(applicationContext)
        setContent {
            VrontalTheme {
                VrontalNav(auth)
            }
        }
    }
}
