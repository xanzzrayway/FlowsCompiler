package com.vrontal.app.ui.features.encryption

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.vrontal.app.ui.components.FeatureScaffold
import com.vrontal.app.ui.components.SegmentRow
import com.vrontal.app.ui.components.glass
import com.vrontal.app.ui.theme.VrontalBackground
import com.vrontal.app.ui.theme.VrontalCyan
import com.vrontal.app.ui.theme.VrontalDanger
import com.vrontal.app.ui.theme.VrontalGlassBorder
import com.vrontal.app.ui.theme.VrontalGold
import com.vrontal.app.ui.theme.VrontalGoldSoft
import com.vrontal.app.ui.theme.VrontalTextMuted
import com.vrontal.app.ui.theme.VrontalTextPrimary
import kotlinx.coroutines.delay

@Composable
fun EncryptionScreen(onBack: () -> Unit) {
    var mode by remember { mutableStateOf(CodecMode.BINER) }
    var textToCode by remember { mutableStateOf(true) }
    var input by remember { mutableStateOf("") }
    var copied by remember { mutableStateOf(false) }

    // Hasil dihitung langsung setiap input/mode/arah berubah, semuanya di perangkat.
    val result = remember(mode, textToCode, input) { VipCodec.convert(mode, textToCode, input) }
    val outputText = (result as? CodecResult.Ok)?.value.orEmpty()
    val clipboard = LocalClipboardManager.current

    LaunchedEffect(copied) {
        if (copied) {
            delay(1500)
            copied = false
        }
    }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = VrontalTextPrimary,
        unfocusedTextColor = VrontalTextPrimary,
        focusedBorderColor = VrontalGold,
        unfocusedBorderColor = VrontalGlassBorder,
        focusedLabelColor = VrontalGold,
        unfocusedLabelColor = VrontalTextMuted,
        cursorColor = VrontalGold,
    )

    val codeName = if (mode == CodecMode.BINER) "Biner" else "Morse"
    val inputLabel = if (textToCode) "Teks" else "Kode $codeName"
    val outputLabel = if (textToCode) "Kode $codeName" else "Teks"
    val hint = if (mode == CodecMode.BINER) {
        "Tiap karakter jadi 8 bit (UTF-8), dipisah spasi."
    } else {
        "Spasi memisahkan huruf, tanda / memisahkan kata. Hasil ke teks selalu huruf besar."
    }

    FeatureScaffold(title = "VipEnkripsi", onBack = onBack) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SegmentRow(
                options = CodecMode.values().map { it.label },
                selectedIndex = mode.ordinal,
                onSelect = { mode = CodecMode.values()[it] },
            )
            SegmentRow(
                options = listOf("Teks ke Kode", "Kode ke Teks"),
                selectedIndex = if (textToCode) 0 else 1,
                onSelect = { textToCode = (it == 0) },
            )

            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text(inputLabel) },
                minLines = 4,
                colors = fieldColors,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            )

            Column(
                Modifier.fillMaxWidth().glass().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(outputLabel, style = MaterialTheme.typography.labelMedium, color = VrontalCyan)
                when (result) {
                    is CodecResult.Error -> Text(
                        result.message,
                        style = MaterialTheme.typography.bodyMedium,
                        color = VrontalDanger,
                    )
                    is CodecResult.Ok -> SelectionContainer {
                        Text(
                            text = result.value.ifEmpty { "Hasil muncul di sini" },
                            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                            color = if (result.value.isEmpty()) VrontalTextMuted else VrontalTextPrimary,
                        )
                    }
                }
                Text(hint, style = MaterialTheme.typography.labelMedium, color = VrontalTextMuted)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = {
                        clipboard.setText(AnnotatedString(outputText))
                        copied = true
                    },
                    enabled = outputText.isNotEmpty(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = VrontalGold,
                        contentColor = VrontalBackground,
                    ),
                    modifier = Modifier.weight(1f),
                ) { Text(if (copied) "Tersalin" else "Salin") }

                OutlinedButton(
                    onClick = {
                        // Pakai hasil sebagai input baru dan balik arahnya: cara cepat mengecek bolak-balik.
                        input = outputText
                        textToCode = !textToCode
                    },
                    enabled = outputText.isNotEmpty(),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, VrontalGlassBorder),
                    modifier = Modifier.weight(1f),
                ) { Text("Balik", color = VrontalCyan) }

                OutlinedButton(
                    onClick = { input = "" },
                    enabled = input.isNotEmpty(),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, VrontalGlassBorder),
                    modifier = Modifier.weight(1f),
                ) { Text("Hapus", color = VrontalTextMuted) }
            }
        }
    }
}
