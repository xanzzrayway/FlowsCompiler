package com.vrontal.app.data.ingat

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.vrontal.app.MainActivity
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Penjadwal alarm Ingat. Pakai setAlarmClock: presisi, tembus mode hemat daya (Doze), dan TIDAK
 * butuh izin "alarm presisi" — cocok untuk alarm bangun/pengingat. Muncul ikon alarm di status bar.
 */
object IngatScheduler {
    const val EXTRA_ID = "ingat_alarm_id"

    private fun pendingIntent(context: Context, id: Long): PendingIntent {
        val intent = Intent(context, IngatAlarmReceiver::class.java)
            .setData(Uri.parse("vrontal://ingat/alarm/$id")) // data unik supaya tiap alarm punya PendingIntent sendiri
            .putExtra(EXTRA_ID, id)
        return PendingIntent.getBroadcast(
            context, (id % Int.MAX_VALUE).toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    /** @param justFired true saat dipanggil dari receiver setelah alarm berbunyi, supaya tidak menjadwal ulang ke menit yang sama. */
    fun schedule(context: Context, alarm: IngatAlarm, justFired: Boolean = false) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = LocalDateTime.now()
        val base = if (justFired) now.plusMinutes(1) else now
        var next = base.toLocalDate().atTime(alarm.hour, alarm.minute)
        if (!next.isAfter(base)) next = next.plusDays(1)
        val triggerAt = next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

        val show = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, show), pendingIntent(context, alarm.id))
    }

    fun cancel(context: Context, id: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(context, id))
    }

    fun rescheduleAll(context: Context, alarms: List<IngatAlarm>) = alarms.forEach { schedule(context, it) }
}
