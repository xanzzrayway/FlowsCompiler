package com.vrontal.app.data.loster

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AttendanceDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(record: AttendanceRecord)

    @Query("SELECT * FROM attendance WHERE date = :date LIMIT 1")
    suspend fun getByDate(date: String): AttendanceRecord?

    @Query("SELECT * FROM attendance ORDER BY date ASC")
    suspend fun getAllOnce(): List<AttendanceRecord>

    @Query("SELECT MIN(date) FROM attendance")
    suspend fun getEarliestDate(): String?

    @Query("SELECT * FROM attendance WHERE date LIKE :yearMonthPrefix || '%' ORDER BY date ASC")
    fun observeByMonth(yearMonthPrefix: String): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance WHERE date LIKE :yearPrefix || '%' ORDER BY date ASC")
    fun observeByYear(yearPrefix: String): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance WHERE date = :date LIMIT 1")
    fun observeByDateExact(date: String): Flow<AttendanceRecord?>
}
