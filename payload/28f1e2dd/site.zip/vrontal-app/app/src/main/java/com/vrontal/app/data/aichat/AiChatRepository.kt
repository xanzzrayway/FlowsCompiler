package com.vrontal.app.data.aichat

import android.content.Context
import android.net.Uri
import com.vrontal.app.data.SecureStore
import com.vrontal.app.data.VrontalDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class ProfileInput(
    val name: String,
    val endpoint: String,
    val headers: List<Pair<String, String>>,
    val bodyTemplate: String,
    val responsePath: String,
    val streamPath: String = "",
)

data class ProfileDetail(
    val profile: AiProfile,
    val headers: List<Pair<String, String>>,
    val bodyTemplate: String,
)

class AiChatRepository(context: Context) {
    private companion object { const val HISTORY_LIMIT = 20 }
    private val appContext = context.applicationContext
    private val dao = VrontalDatabase.get(context).aiChatDao()
    private val client = AiClient(context)

    fun observeProfiles(): Flow<List<AiProfile>> = dao.observeProfiles()
    fun observeMessages(profileId: Long): Flow<List<ChatMessage>> = dao.observeMessages(profileId)

    suspend fun saveProfile(input: ProfileInput): Long = withContext(Dispatchers.Default) {
        val headersJson = JSONArray().apply {
            input.headers.forEach { (k, v) -> put(JSONObject().put("k", k).put("v", v)) }
        }.toString()
        dao.insertProfile(
            AiProfile(
                name = input.name,
                endpoint = input.endpoint,
                headersJsonEncrypted = SecureStore.encrypt(headersJson),
                bodyTemplateEncrypted = SecureStore.encrypt(input.bodyTemplate),
                responsePath = input.responsePath,
                streamPath = input.streamPath,
            )
        )
    }

    suspend fun deleteProfile(profile: AiProfile) {
        clearMessages(profile.id) // hapus riwayat + file gambar, supaya tidak jadi data yatim
        dao.deleteProfile(profile)
    }

    suspend fun profileDetail(profile: AiProfile): ProfileDetail = withContext(Dispatchers.Default) {
        val headersJson = SecureStore.decrypt(profile.headersJsonEncrypted)
        val arr = JSONArray(headersJson)
        val headers = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            o.getString("k") to o.getString("v")
        }
        val body = SecureStore.decrypt(profile.bodyTemplateEncrypted)
        ProfileDetail(profile, headers, body)
    }

    /** Simpan pesan user (dengan warna/gambar kalau ada), panggil API, lalu simpan balasan atau error-nya. */
    /** Hentikan balasan yang sedang berjalan. */
    fun stop() = client.cancel()

    suspend fun sendMessage(profile: AiProfile, text: String, colorHex: String?, imageUri: Uri?) {
        client.reset()
        // Salin gambar ke penyimpanan internal app: izin Photo Picker bersifat sementara,
        // jadi tanpa salinan gambar di riwayat hilang setelah app ditutup.
        val localUri: Uri? = try {
            imageUri?.let { withContext(Dispatchers.IO) { copyImageToInternal(it) } }
        } catch (e: AiException) {
            dao.insertMessage(ChatMessage(profileId = profile.id, role = ChatRole.ERROR, text = e.message ?: "Gagal memproses gambar"))
            return
        } catch (e: java.io.IOException) {
            dao.insertMessage(ChatMessage(profileId = profile.id, role = ChatRole.ERROR, text = "Gagal membaca gambar: ${e.message ?: "file tidak bisa dibuka"}"))
            return
        }
        dao.insertMessage(
            ChatMessage(profileId = profile.id, role = ChatRole.USER, text = text, colorHex = colorHex, imageUri = localUri?.toString())
        )
        // Riwayat terakhir (maks 20 pesan, tanpa bubble error) — hanya dikirim kalau template memakai {{RIWAYAT}}.
        val history = dao.recentMessages(profile.id, HISTORY_LIMIT).map {
            (if (it.role == ChatRole.USER) "user" else "assistant") to it.text
        }
        var streamedId: Long? = null
        var partial = ""
        var lastWrite = 0L
        // Dipanggil dari thread IO tiap ada potongan balasan: bubble AI dibuat saat potongan pertama,
        // lalu diperbarui paling sering tiap 100 ms supaya database & layar tidak kewalahan.
        val onDelta: (String) -> Unit = { full ->
            partial = full
            val now = System.currentTimeMillis()
            runBlocking {
                val id = streamedId
                if (id == null) {
                    streamedId = dao.insertMessage(ChatMessage(profileId = profile.id, role = ChatRole.AI, text = full))
                    lastWrite = now
                } else if (now - lastWrite >= 100) {
                    dao.updateMessageText(id, full)
                    lastWrite = now
                }
            }
        }
        val reply = withContext(Dispatchers.IO) {
            try {
                // Dekripsi ikut di dalam try: kalau kunci Keystore hilang (mis. setelah reset profil),
                // user dapat bubble error, bukan app crash.
                val detail = profileDetail(profile)
                Result.success(
                    client.send(
                        detail.profile.endpoint, detail.headers, detail.bodyTemplate,
                        detail.profile.responsePath, detail.profile.streamPath, text, history, localUri, onDelta,
                    )
                )
            } catch (e: AiCancelledException) {
                Result.failure(AiException("Dihentikan oleh pengguna."))
            } catch (e: AiException) {
                Result.failure(e)
            } catch (e: java.security.GeneralSecurityException) {
                Result.failure(AiException("Data AI ini tidak bisa dibuka lagi (kunci enkripsi berubah). Hapus profil AI ini lalu buat ulang."))
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(AiException("Gagal tak terduga: ${e.message ?: e::class.simpleName}"))
            }
        }
        reply.fold(
            onSuccess = { full ->
                val id = streamedId
                if (id != null) dao.updateMessageText(id, full)
                else dao.insertMessage(ChatMessage(profileId = profile.id, role = ChatRole.AI, text = full))
            },
            onFailure = { err ->
                // Teks parsial yang sudah sempat tampil tetap disimpan, lalu error muncul di bawahnya.
                streamedId?.let { dao.updateMessageText(it, partial) }
                dao.insertMessage(ChatMessage(profileId = profile.id, role = ChatRole.ERROR, text = err.message ?: "Terjadi kesalahan"))
            },
        )
    }

    suspend fun clearMessages(profileId: Long) {
        withContext(Dispatchers.IO) { deleteImagesOf(profileId) }
        dao.clearMessages(profileId)
    }

    private val imageDir get() = java.io.File(appContext.filesDir, "chat_images").apply { mkdirs() }

    private fun copyImageToInternal(source: Uri): Uri {
        val dest = java.io.File(imageDir, "${System.currentTimeMillis()}_${java.util.UUID.randomUUID()}.img")
        val max = 8L * 1024 * 1024
        var total = 0L
        val input = appContext.contentResolver.openInputStream(source) ?: throw java.io.IOException("file tidak bisa dibuka")
        try {
            input.use { ins ->
                dest.outputStream().use { out ->
                    val buf = ByteArray(8192)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > max) throw AiException("Gambar terlalu besar (maks 8 MB). Pilih gambar yang lebih kecil.")
                        out.write(buf, 0, n)
                    }
                }
            }
        } catch (e: Exception) {
            dest.delete()
            throw e
        }
        return Uri.fromFile(dest)
    }

    private suspend fun deleteImagesOf(profileId: Long) {
        dao.imageUrisOf(profileId).forEach { u ->
            runCatching { Uri.parse(u).path?.let { java.io.File(it).takeIf { f -> f.parentFile == imageDir }?.delete() } }
        }
    }
}
