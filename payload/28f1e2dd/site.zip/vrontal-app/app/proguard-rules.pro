# Aturan tambahan proyek Vrontal.
# AndroidX/Compose/Navigation sudah menyertakan consumer-rules sendiri secara otomatis,
# jadi file ini sengaja dikosongkan sampai ada kebutuhan khusus (mis. library JSON/refleksi
# untuk Chat AI di tahap berikutnya).
