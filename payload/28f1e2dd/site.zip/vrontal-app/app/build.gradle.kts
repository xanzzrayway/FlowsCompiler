plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.vrontal.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vrontal.app"
        // minSdk 24 sengaja dipilih rendah biar tetap jalan di HP spek rendah ("kentang")
        minSdk = 24
        targetSdk = 35
        versionCode = 12
        versionName = "0.10.0-tahap7-ai"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        // java.time (dipakai LosterRepository) baru asli tersedia mulai API 26; minSdk kita 24,
        // jadi wajib di-desugar supaya tetap jalan di HP lama/spek rendah.
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")

    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")

    // Loster Legal: catatan absen/alpha (data tabular, butuh query per bulan/tahun -> Room lebih pas dari SharedPreferences)
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // Enkripsi lokal langsung pakai AndroidKeyStore (lihat SecureStore.kt) —
    // tidak pakai androidx.security:security-crypto karena sudah deprecated sejak 1.1.0-alpha07.
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // Chat AI: klien HTTP buat panggil API custom milik user. Photo Picker buat lampiran gambar
    // (tanpa perlu izin storage/media) sudah ikut tersedia lewat androidx.activity-compose di atas.
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("io.coil-kt:coil-compose:2.6.0") // tampilkan gambar lampiran chat dari content:// Uri

    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
