# Vrontal (Tahap 7 [ai] — 6 menu)

Aplikasi Android native (Kotlin + Jetpack Compose). Semua data tersimpan di perangkat, tanpa server.

## Cara build jadi APK
1. Install Android Studio (gratis) dari developer.android.com/studio
2. File > Open > pilih folder `vrontal-app` ini, tunggu Gradle Sync selesai (butuh internet sekali untuk unduh dependency)
3. Build > Build Bundle(s) / APK(s) > Build APK(s)
4. File APK ada di `app/build/outputs/apk/debug/app-debug.apk`

## Isi Tahap 1
- Login lokal: Nama + Password (hash PBKDF2, tersimpan terenkripsi), Ingat saya, animasi + loading
- Menu geser 5 opsi
- Credit (lengkap)
- VipEnkripsi (tahap 2): teks <-> biner dan teks <-> Morse, langsung terhitung saat mengetik, ada Salin dan Balik. Unit test: `app/src/test/.../VipCodecTest.kt` (jalankan lewat klik kanan > Run di Android Studio)
- Loster Legal, XipVOx, Chat AI: halaman placeholder, dibangun di tahap berikutnya

## Perbaikan dari laporan bug (29 Sep 2026)
1. Checkbox "Simpan data di perangkat ini": sekarang benar-benar dipakai — kalau TIDAK dicentang, profil otomatis terhapus saat Keluar.
2. Dialog reset profil sekarang mengembalikan semua checkbox ke default juga.
3. Gradle wrapper: `gradlew` dan `gradlew.bat` sudah ditambahkan. `gradle/wrapper/gradle-wrapper.jar` TETAP belum ada (perlu diunduh, tidak bisa dibuat dari sandbox tanpa internet) — Android Studio akan mengisinya otomatis saat Gradle Sync pertama, sama seperti sebelumnya.
4. Enkripsi lokal dipindah dari `androidx.security:security-crypto` (deprecated) ke `SecureStore.kt`, langsung pakai AndroidKeyStore.
5. Izin CAMERA/notifikasi/alarm/baterai/media dihapus dari manifest sampai fitur yang memakainya (Loster Legal, Chat AI) benar-benar dibangun.
6. `material-icons-extended` dihapus total, diganti 10 ikon custom ringan di `VrontalIcons.kt`.
7. `isMinifyEnabled = true` untuk build release + `proguard-rules.pro` dasar.
8. Password minimum dinaikkan dari 4 ke 6 karakter.

## Tahap 3 — Loster Legal
- Tombol Absen: sekali per hari, tercatat tanggal + jam, disimpan di database lokal (Room, file `vrontal.db` di perangkat).
- Alpha otomatis: dicek dua jalur — (1) AlarmManager jadwalkan alarm presis jam 11 pagi tiap hari (jalan walau app tertutup, lewat `AlphaAlarmReceiver`), dan (2) dicek ulang tiap kali layar Loster Legal dibuka/di-resume (jaga-jaga kalau alarm meleset). Alarm dijadwalkan ulang otomatis setelah HP restart (`BootReceiver`).
- Dashboard: status hari ini, navigasi bulan, daftar riwayat, jumlah Hadir/Alpha bulan berjalan.
- Menu titik tiga (kanan atas): "Check Alpha" dan "Check Hadir", masing-masing punya toggle Bulan/Tahun — Bulan menampilkan total bulan berjalan, Tahun menampilkan rekap 12 bulan + total.
- Izin baru yang dipakai: notifikasi (diminta saat layar ini dibuka), alarm presisi & optimasi baterai (ada kartu ajakan di dashboard kalau belum diizinkan — keduanya opsional, fitur tetap jalan tanpanya, cuma kurang presisi di beberapa HP).
- **Catatan jujur**: kode ini belum pernah dicompile di sandbox (tidak ada Android SDK/internet di sini). Sudah dicek: semua kurung seimbang, semua import lengkap, semua class/fungsi yang dipanggil ada definisinya. Tapi logika AlarmManager/BroadcastReceiver ini perlu dites langsung di HP — terutama setelah di-restart dan setelah dikasih izin alarm presisi — karena perilaku tiap merek Android soal background task beda-beda.

## Tahap 4 — XipVOx
- Mini-browser dalam aplikasi pakai WebView Android, bukan pembatasan sandbox seperti versi web dulu — jadi tidak ada lagi masalah "Failed to fetch".
- Tempel alamat apa saja (boleh tanpa "https://", otomatis ditambahkan) lalu Enter/tombol Go di keyboard.
- Multi-tab: tombol "+" buka tab baru, tiap tab di strip atas bisa diklik pindah atau ditutup (×). WebView tiap tab tetap hidup saat pindah tab, jadi riwayat/scroll tidak hilang.
- Kontrol mundur, reload, dan progress bar tipis saat halaman dimuat.
- JavaScript diaktifkan (perlu untuk sebagian besar situs modern), TAPI tidak ada `addJavascriptInterface` di mana pun — situs luar tidak pernah punya jalan masuk ke kode/data aplikasi.
- Izin: tidak ada tambahan, INTERNET sudah dideklarasikan sejak Tahap 1 untuk fitur ini.

## Tahap 5 — Chat AI (menu terakhir, semua 5 fitur sudah ada)
- **Bebas provider**: user isi sendiri endpoint URL, header (boleh banyak, mis. `Authorization: Bearer ...`), template body JSON, dan jalur ambil balasan dari respons (mis. `choices.0.message.content`). Tidak dikunci ke format OpenAI atau provider manapun.
- Template body pakai placeholder `{{PESAN}}` (wajib) dan `{{GAMBAR_BASE64}}` (opsional, kalau API-nya dukung kirim gambar).
- **Ganti-ganti AI**: bisa pasang banyak profil AI, pindah-pindah lewat nama di pojok kiri atas.
- Header & template body disimpan terenkripsi lewat `SecureStore` (AndroidKeyStore) — sama seperti password login.
- Riwayat chat tersimpan permanen di Room, per-profil AI (ganti AI = ganti riwayat juga).
- Timeout 10 menit; kalau gagal/timeout/jalur respons tidak ketemu, muncul bubble error merah yang jelas, bukan nge-hang atau diam saja.
- Input pesan: bisa pilih warna teks (7 pilihan + default), lampir gambar lewat Photo Picker Android (TIDAK butuh izin storage/media sama sekali — privacy-friendly). Avatar AI cuma ikon SVG + warna, tidak ada foto.
- Dependency baru: OkHttp (klien HTTP) dan Coil (tampilkan gambar lampiran).
- **Database naik ke versi 2** (tabel AI profile + chat message ditambahkan) — karena masih tahap development, dipasang `fallbackToDestructiveMigration()`. Artinya kalau sudah pernah install tahap sebelumnya, data Loster Legal lama (absen/alpha) ikut *kehapus* saat update ke tahap ini. Install bersih/uninstall dulu kalau mau data lama tidak masalah hilang.

## Status: 5/5 menu sudah dibangun
Login, VipEnkripsi, Loster Legal, Credit, XipVOx, Chat AI — semua sudah ada isinya, bukan placeholder lagi.
Yang BELUM pernah terjadi sampai titik ini: dikompilasi sungguhan jadi APK dan dicoba di HP asli.

## Pembaruan 0.5.1
- Gambar lampiran chat disalin ke penyimpanan internal app (`files/chat_images`), jadi tetap muncul di riwayat setelah app ditutup. File ikut terhapus saat riwayat dibersihkan atau profil AI dihapus.
- Database: `fallbackToDestructiveMigration()` diganti `MIGRATION_1_2` — data Loster Legal tidak hilang lagi saat update dari versi 1. Setiap kenaikan versi skema berikutnya WAJIB menambah Migration baru.
- Dekripsi profil AI yang gagal kini jadi bubble error, bukan crash. Batas gambar 8 MB.

## Pembaruan 0.6.0 — Streaming balasan AI
- Di form profil AI ada kolom baru "Jalur potongan balasan". Kosong = perilaku lama (tunggu balasan utuh). Diisi (mis. `choices.0.delta.content`) = balasan muncul bertahap lewat SSE.
- Template body juga harus meminta stream dari API-nya, mis. tambah `"stream":true` — format ini beda-beda tiap provider.
- Kalau server ternyata membalas JSON biasa, otomatis dipakai "Jalur balasan" biasa sebagai cadangan.
- Kalau koneksi putus di tengah, teks yang sudah masuk tetap tersimpan dan bubble error muncul di bawahnya.
- Database naik ke v3 lewat `MIGRATION_2_3` (data lama aman). Profil AI lama otomatis tanpa streaming.

## Pembaruan 0.7.0 — Tombol Stop & riwayat percakapan
- Tombol kirim berubah jadi ■ merah selama AI membalas; ditekan = koneksi/stream langsung diputus. Teks yang sudah sempat masuk tetap tersimpan, ditambah catatan "Dihentikan oleh pengguna".
- Placeholder baru `{{RIWAYAT}}` di template body: diganti array JSON `[{"role":"user"|"assistant","content":"..."}]` berisi 20 pesan terakhir (tanpa bubble error), sudah termasuk pesan yang baru dikirim. Contoh: `"messages":{{RIWAYAT}}`. Template boleh memakai `{{PESAN}}` ATAU `{{RIWAYAT}}`.
- Gambar tetap lewat `{{GAMBAR_BASE64}}` dan hanya untuk pesan terbaru, bukan riwayat.
- Substitusi placeholder sekarang satu kali lewat, jadi pesan user yang kebetulan memuat `{{PESAN}}` tidak ikut diganti ulang.
- Kirim ganda dicegah di ViewModel.

## Pembaruan 0.8.0 — Menu ke-6: Ingat
Dua tab, semua tersimpan di database lokal (Room) dan tetap ada sampai kamu hapus sendiri:
- **Barang**: catat barang + "ditaruh di mana" + foto/video opsional (Photo Picker, tanpa izin storage; file disalin ke penyimpanan internal app). "Update lokasi" menambah entri baru — semua entri tersimpan lengkap dengan tanggal & jam, jadi riwayat penempatan bisa dicek. Pencarian mencocokkan nama barang ATAU lokasi mana pun di riwayatnya. Tombol "Selesai" (dengan konfirmasi) menghapus barang + riwayat + file foto/videonya permanen. Batas: foto 20 MB, video 100 MB.
- **Alarm**: judul + jam, harian atau sekali; preset cepat Bangun / Cek absen / Cek gaji. Memakai `setAlarmClock` (presisi, tembus Doze, TIDAK butuh izin alarm presisi, ikon alarm tampil di status bar). Berbunyi lewat notifikasi dengan suara alarm + getar. Alarm "sekali" otomatis terhapus setelah berbunyi. Alarm dijadwalkan ulang setelah HP restart.
- Database naik ke v4 lewat `MIGRATION_3_4` (data lama aman).
- Keterbatasan jujur: alarm berbentuk notifikasi, bukan layar alarm penuh; sebagian merek HP (Xiaomi, Oppo, Vivo, dll.) perlu app ini diizinkan "autostart"/tanpa pembatasan baterai supaya alarm andal. Data hanya ada di perangkat — hapus app atau "clear data" = data hilang, karena `allowBackup` sengaja dimatikan.

---
## Aturan penamaan perubahan
Setiap revisi/upgrade/update mulai sekarang diberi nama **Tahap 6 [ai]**, lalu **Tahap 7 [ai]**, dst., supaya asal bug mudah dilacak. Perubahan sebelumnya setelah Tahap 5 (versi 0.5.1–0.8.0: salinan gambar + migrasi DB, streaming, tombol Stop, riwayat percakapan, menu Ingat) dianggap bagian dari fondasi sebelum Tahap 6.

## Tahap 6 [ai] — Evaluasi laporan pihak luar + perbaikan alarm
Laporan `laporan_evaluasi_temuan_bug_dan_ide_development.md` sudah dicocokkan dengan kode:
| Temuan laporan | Hasil cek | Tindakan |
|---|---|---|
| Crash `SecurityException` exact alarm | Sudah ditangkap (try/catch) + kartu izin di Loster. Tapi celahnya nyata: tanpa izin, jadwal jam 11 DILEWATKAN diam-diam | **Diperbaiki**: cadangan `setAndAllowWhileIdle` (`AlarmScheduler.kt`) |
| `BootReceiver` perlu `directBootAware` | Tidak berlaku: Room & Keystore butuh penyimpanan terbuka-kunci; `BOOT_COMPLETED` sudah dikirim setelah unlock | Tidak diubah |
| Pindah ke `EncryptedSharedPreferences` | Justru mundur: library itu deprecated, makanya sebelumnya dipindah ke AndroidKeystore langsung (`SecureStore.kt`, AES-256/GCM) | Tidak diubah |
| `VipCodec` rawan kripto / hardcoded key | `VipCodec` hanya konversi biner/Morse, tanpa kunci. Pencarian kode: tidak ada key/IV/salt/API key tertulis di source | Tidak diubah |
| `JsonPath` ganti `kotlinx.serialization` | `JsonPath` sudah aman null/tipe; jalur bebas dari user tidak bisa dimodelkan dengan class tetap | Tidak diubah |
| Timeout/freeze AI Chat | Panggilan sudah di `Dispatchers.IO`, error ditangkap jadi bubble, ada tombol Stop | Tidak diubah |
| WorkManager sebagai cadangan alarm | WorkManager tidak presisi waktu, tidak menolong untuk "tepat jam 11" | Tidak diubah |
Ide fitur yang masuk akal dan belum dikerjakan: render Markdown di Chat AI, kunci biometrik, ekspor/impor backup terenkripsi.

## Tahap 7 [ai] — Evaluasi laporan ke-2 + jeda WebView XipVOx
Laporan `laporan_bug_dan_rekomendasi_perbaikan_vrontal_app.md` dicocokkan dengan kode:
| Temuan laporan | Hasil cek | Tindakan |
|---|---|---|
| #1 `VipCodec` memakai XOR/enkripsi kustom | Salah: `VipCodec` hanya konversi teks↔biner dan teks↔Morse (encoding, bukan enkripsi), tanpa XOR/kunci. Enkripsi data sungguhan sudah AES-256/GCM di `SecureStore` (AndroidKeyStore) | Tidak diubah |
| #2 `JsonPath` rawan crash | Salah: sudah aman null/tipe/indeks; kegagalan jadi bubble error, bukan force close | Tidak diubah |
| #3 Alarm Android 12+ | Sudah ditangani di Tahap 6 [ai] (cadangan alarm tidak-presisi) + kartu izin di Loster | Tidak diubah lagi |
| #4 Visualizer audio/Canvas boros baterai di XipVOx | Premis salah: XipVOx adalah mini-browser WebView, tidak ada visualizer/Canvas. TAPI ada celah serupa yang nyata: WebView tidak dijeda saat app ke background (JS/media bisa terus jalan) | **Diperbaiki**: semua WebView `onPause()`+`pauseTimers()` saat layar ke background, hanya tab aktif yang dilanjutkan; tab yang tidak aktif ikut dijeda (`XipVoxViewModel.kt`, `XipVoxScreen.kt`) |
