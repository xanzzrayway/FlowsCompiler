package com.rafz.lock;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.Gravity;
import android.view.ViewGroup;
import android.graphics.Color;

public class MainActivity extends Activity {
    private static final int REQUEST_OVERLAY = 1001;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER);
        page.setPadding(32, 32, 32, 32);
        page.setBackgroundColor(Color.rgb(18, 18, 24));

        TextView title = new TextView(this);
        title.setText("RafzLock");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);

        TextView info = new TextView(this);
        info.setText("Demo peringatan overlay yang dapat ditutup. Aplikasi tidak mengunci perangkat atau mengubah file.");
        info.setTextColor(Color.LTGRAY);
        info.setTextSize(16);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, 24, 0, 24);

        Button permission = new Button(this);
        permission.setText("Izinkan overlay");
        permission.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_OVERLAY);
            } else {
                status.setText("Izin overlay sudah aktif.");
            }
        });

        Button show = new Button(this);
        show.setText("Tampilkan peringatan");
        show.setOnClickListener(v -> {
            if (Settings.canDrawOverlays(this)) {
                startService(new Intent(this, OverlayService.class));
                status.setText("Peringatan ditampilkan. Gunakan tombol Tutup pada kartu.");
            } else {
                status.setText("Aktifkan izin overlay terlebih dahulu.");
            }
        });

        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 20, 0, 0);

        page.addView(title, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        page.addView(info);
        page.addView(permission);
        page.addView(show);
        page.addView(status);
        setContentView(page);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY) {
            status.setText(Settings.canDrawOverlays(this)
                ? "Izin overlay berhasil diaktifkan."
                : "Izin overlay belum diaktifkan.");
        }
    }
}
