package com.rafz.lock;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager windowManager;
    private android.view.View overlay;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (overlay != null) return START_NOT_STICKY;

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(28, 24, 28, 24);
        card.setBackgroundColor(Color.rgb(35, 35, 45));

        TextView heading = new TextView(this);
        heading.setText("PERINGATAN PERANGKAT");
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(20);

        TextView message = new TextView(this);
        message.setText("Ini hanya demo tampilan overlay. Perangkat dan file Anda tidak dikunci atau diubah.");
        message.setTextColor(Color.LTGRAY);
        message.setTextSize(15);
        message.setPadding(0, 16, 0, 18);

        Button close = new Button(this);
        close.setText("Tutup");
        close.setOnClickListener(v -> stopSelf());

        card.addView(heading);
        card.addView(message);
        card.addView(close);

        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        params.y = 80;

        overlay = card;
        windowManager.addView(overlay, params);
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        if (overlay != null && windowManager != null) {
            try { windowManager.removeView(overlay); } catch (Exception ignored) {}
            overlay = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
