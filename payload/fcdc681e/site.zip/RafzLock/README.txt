RafzLock - overlay warning demo

Buka folder ini di Android Studio, tunggu Gradle Sync, lalu Build > Build APK(s).

Alur:
1. Buka aplikasi.
2. Tekan Izinkan overlay dan aktifkan izin pada pengaturan Android.
3. Kembali ke aplikasi.
4. Tekan Tampilkan peringatan.
5. Tutup overlay dengan tombol Tutup.

Aplikasi ini hanya menampilkan kartu peringatan yang dapat ditutup.
Aplikasi tidak mengunci navigasi, tidak berjalan diam-diam, tidak mengenkripsi,
menghapus, atau mengubah file, dan tidak mencegah pengguna menghentikan/
menghapus aplikasi.

Catatan: Gradle wrapper JAR tidak disertakan. Buka melalui Android Studio
dengan instalasi Gradle/Android Gradle Plugin yang sesuai.
