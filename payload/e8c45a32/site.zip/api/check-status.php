<?php
require_once '../env/config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

function logAPI($type, $data) {
    $logDir = __DIR__ . '/../logs/';
    if (!is_dir($logDir)) mkdir($logDir, 0755, true);
    $logFile = $logDir . 'check-' . date('Y-m-d') . '.log';
    $entry = date('c') . " [$type] " . json_encode($data) . PHP_EOL;
    file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
}

function loadOrder($orderId) {
    $ordersDir = __DIR__ . '/../orders/';
    $filename = $ordersDir . $orderId . '.json';
    if (!file_exists($filename)) return null;
    return json_decode(file_get_contents($filename), true);
}

function saveOrder($orderData) {
    $ordersDir = __DIR__ . '/../orders/';
    if (!is_dir($ordersDir)) mkdir($ordersDir, 0755, true);
    $filename = $ordersDir . $orderData['order_id'] . '.json';
    file_put_contents($filename, json_encode($orderData, JSON_PRETTY_PRINT));
}

function callSakurupiahCheckStatus($trxId) {
    $url = SAKURUPIAH_API_URL . 'status-transaction.php';
    
    $postFields = [
        'api_id' => SAKURUPIAH_API_ID,
        'method' => 'status',
        'trx_id' => $trxId
    ];
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($postFields),
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . SAKURUPIAH_API_KEY,
            'Content-Type: application/x-www-form-urlencoded'
        ]
    ]);
    
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        throw new Exception('cURL Error: ' . $error);
    }
    
    $data = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON response');
    }
    
    return $data;
}

function addBalance($amount) {
    $dataFile = __DIR__ . '/../data/balance.json';
    $data = json_decode(file_get_contents($dataFile), true) ?: ['balance' => 0, 'history' => []];
    $data['balance'] += $amount;
    $data['history'][] = [
        'type' => 'deposit',
        'amount' => $amount,
        'date' => date('d/m/Y H:i'),
        'detail' => 'Deposit via QRIS'
    ];
    file_put_contents($dataFile, json_encode($data, JSON_PRETTY_PRINT));
}

$input = json_decode(file_get_contents('php://input'), true);

try {
    $orderId = $input['order_id'] ?? '';
    if (empty($orderId)) {
        throw new Exception('Order ID diperlukan');
    }

    $order = loadOrder($orderId);
    if (!$order) {
        throw new Exception('Order tidak ditemukan');
    }

    if (in_array($order['status'], ['paid', 'expired'])) {
        echo json_encode(['ok' => true, 'status' => $order['status'], 'order' => $order]);
        exit;
    }

    // Cek expired
    if (isset($order['expired_at'])) {
        $expiry = strtotime($order['expired_at']);
        if ($expiry && time() > $expiry) {
            $order['status'] = 'expired';
            saveOrder($order);
            echo json_encode(['ok' => true, 'status' => 'expired', 'order' => $order]);
            exit;
        }
    }

    // Cek ke Sakurupiah
    if (!empty($order['trx_id'])) {
        try {
            $result = callSakurupiahCheckStatus($order['trx_id']);
            if (isset($result['status']) && $result['status'] === '200') {
                $remoteStatus = $result['data'][0]['status'] ?? '';
                if ($remoteStatus === 'berhasil') {
                    $order['status'] = 'paid';
                    $order['paid_at'] = date('c');
                    saveOrder($order);
                    addBalance($order['amount']);
                } elseif ($remoteStatus === 'expired') {
                    $order['status'] = 'expired';
                    saveOrder($order);
                }
            }
        } catch (Exception $e) {
            logAPI('CHECK_STATUS_ERROR', ['error' => $e->getMessage()]);
        }
    }

    echo json_encode(['ok' => true, 'status' => $order['status'], 'order' => $order]);

} catch (Exception $e) {
    logAPI('CHECK_ERROR', ['error' => $e->getMessage()]);
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}