<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

session_start();

$dataFile = __DIR__ . '/../data/balance.json';
$sessionFile = __DIR__ . '/../data/sessions.json';

function loadBalance() {
    global $dataFile;
    if (!file_exists($dataFile)) {
        $default = ['balance' => 0, 'history' => []];
        file_put_contents($dataFile, json_encode($default, JSON_PRETTY_PRINT));
        return $default;
    }
    return json_decode(file_get_contents($dataFile), true) ?: ['balance' => 0, 'history' => []];
}

function saveBalance($data) {
    global $dataFile;
    file_put_contents($dataFile, json_encode($data, JSON_PRETTY_PRINT));
}

function loadSessions() {
    global $sessionFile;
    if (!file_exists($sessionFile)) {
        file_put_contents($sessionFile, json_encode([]));
        return [];
    }
    return json_decode(file_get_contents($sessionFile), true) ?: [];
}

function saveSessions($data) {
    global $sessionFile;
    file_put_contents($sessionFile, json_encode($data, JSON_PRETTY_PRINT));
}

function getSessionId() {
    if (!isset($_SESSION['payrefer_id'])) {
        $_SESSION['payrefer_id'] = 'USER-' . time() . '-' . bin2hex(random_bytes(8));
    }
    return $_SESSION['payrefer_id'];
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $data = loadBalance();
    $sessions = loadSessions();
    $sessionId = getSessionId();
    
    // Cek apakah user sudah pernah create free
    $hasFreeCreate = isset($sessions[$sessionId]['free_used']) && $sessions[$sessionId]['free_used'] === true;
    
    echo json_encode([
        'ok' => true, 
        'balance' => $data['balance'], 
        'history' => $data['history'],
        'hasFreeCreate' => $hasFreeCreate,
        'sessionId' => $sessionId
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? '';
    $data = loadBalance();
    $sessions = loadSessions();
    $sessionId = getSessionId();

    if ($action === 'deduct') {
        $amount = (int)($input['amount'] ?? 0);
        if ($amount > $data['balance']) {
            echo json_encode(['ok' => false, 'error' => 'Saldo tidak cukup']);
            exit;
        }
        $data['balance'] -= $amount;
        $data['history'][] = [
            'type' => 'create',
            'amount' => $amount,
            'date' => date('d/m/Y H:i'),
            'detail' => $input['detail'] ?? 'Create AM Premium'
        ];
        saveBalance($data);
        echo json_encode(['ok' => true, 'balance' => $data['balance']]);
        exit;
    }

    if ($action === 'add') {
        $amount = (int)($input['amount'] ?? 0);
        $data['balance'] += $amount;
        $data['history'][] = [
            'type' => 'deposit',
            'amount' => $amount,
            'date' => date('d/m/Y H:i'),
            'detail' => 'Deposit via QRIS'
        ];
        saveBalance($data);
        echo json_encode(['ok' => true, 'balance' => $data['balance']]);
        exit;
    }

    if ($action === 'use_free') {
        if (isset($sessions[$sessionId]['free_used']) && $sessions[$sessionId]['free_used'] === true) {
            echo json_encode(['ok' => false, 'error' => 'Free create sudah digunakan']);
            exit;
        }
        $sessions[$sessionId]['free_used'] = true;
        $sessions[$sessionId]['free_used_at'] = date('c');
        saveSessions($sessions);
        
        // Tambah history free
        $data['history'][] = [
            'type' => 'free',
            'amount' => 1000,
            'date' => date('d/m/Y H:i'),
            'detail' => 'FREE Create AM Premium (1x gratis)'
        ];
        saveBalance($data);
        
        echo json_encode(['ok' => true, 'free_used' => true]);
        exit;
    }

    echo json_encode(['ok' => false, 'error' => 'Action tidak valid']);
}