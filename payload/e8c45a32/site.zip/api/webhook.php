<?php
require_once '../env/config.php';

header('Content-Type: application/json');

function logAPI($type, $data) {
    $logDir = __DIR__ . '/../logs/';
    if (!is_dir($logDir)) mkdir($logDir, 0755, true);
    $logFile = $logDir . 'webhook-' . date('Y-m-d') . '.log';
    $entry = date('c') . " [$type] " . json_encode($data) . PHP_EOL;
    file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
}

function verifySignature($payload, $signature) {
    $expected = hash_hmac('sha256', $payload, SAKURUPIAH_API_KEY);
    return hash_equals($expected, $signature);
}

function loadOrder($orderId) {
    $ordersDir = __DIR__ . '/../orders/';
    $filename = $ordersDir . $orderId . '.json';
    if (!file_exists($filename)) return null;
    return json_decode(file_get_contents($filename), true);
}

function saveOrder($orderData) {
    $ordersDir = __DIR__ . '/../orders/';
    if (!is_dir($ordersDir)) mkdir($ordersDir, 0755, true);
    $filename = $ordersDir . $orderData['order_id'] . '.json';
    file_put_contents($filename, json_encode($orderData, JSON_PRETTY_PRINT));
}

function addBalance($amount) {
    $dataFile = __DIR__ . '/../data/balance.json';
    $data = json_decode(file_get_contents($dataFile), true) ?: ['balance' => 0, 'history' => []];
    $data['balance'] += $amount;
    $data['history'][] = [
        'type' => 'deposit',
        'amount' => $amount,
        'date' => date('d/m/Y H:i'),
        'detail' => 'Deposit via QRIS (Webhook)'
    ];
    file_put_contents($dataFile, json_encode($data, JSON_PRETTY_PRINT));
}

$rawInput = file_get_contents('php://input');
$signature = $_SERVER['HTTP_X_CALLBACK_SIGNATURE'] ?? '';

logAPI('WEBHOOK_RAW', ['body' => $rawInput, 'signature' => $signature]);

if (!verifySignature($rawInput, $signature)) {
    logAPI('WEBHOOK_SIGNATURE_FAILED', ['signature' => $signature]);
    http_response_code(401);
    echo json_encode(['status' => false, 'error' => 'Invalid signature']);
    exit;
}

$input = json_decode($rawInput, true);

try {
    $trxId = $input['trx_id'] ?? '';
    $merchantRef = $input['merchant_ref'] ?? '';
    $status = $input['status'] ?? '';
    $statusKode = $input['status_kode'] ?? '';

    if ($status !== 'berhasil' || $statusKode != 1) {
        echo json_encode(['status' => true, 'message' => 'Event ignored']);
        exit;
    }

    if (empty($merchantRef)) {
        throw new Exception('Merchant Ref tidak ditemukan');
    }

    $order = loadOrder($merchantRef);
    if (!$order) {
        echo json_encode(['status' => true, 'message' => 'Order tidak ditemukan']);
        exit;
    }

    if ($order['status'] === 'paid') {
        echo json_encode(['status' => true, 'message' => 'Already processed']);
        exit;
    }

    $order['status'] = 'paid';
    $order['paid_at'] = date('c');
    saveOrder($order);

    // Tambah saldo
    if (!empty($order['amount'])) {
        addBalance($order['amount']);
    }

    logAPI('WEBHOOK_SUCCESS', ['order_id' => $order['order_id'], 'trx_id' => $trxId]);

    echo json_encode(['status' => true, 'message' => 'Webhook processed successfully']);

} catch (Exception $e) {
    logAPI('WEBHOOK_ERROR', ['error' => $e->getMessage()]);
    http_response_code(200);
    echo json_encode(['status' => true, 'message' => 'Webhook diterima: ' . $e->getMessage()]);
}