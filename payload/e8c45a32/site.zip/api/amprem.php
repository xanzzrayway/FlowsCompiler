<?php
/**
 * API Create Alight Motion Premium
 * 
 * Endpoint: /api/amprem.php
 * 
 * Actions:
 * - GET ?action=session -> cek free create
 * - POST {action: "free"} -> create gratis (1x)
 * - POST {action: "pay"} -> create payment QRIS
 * - POST {action: "check", order_id: "xxx"} -> cek status payment
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// ============================================
//  KONFIGURASI
// ============================================
define('NEXADEV_API_URL', 'https://api.nexadev.my.id/am/bulk/');
define('NEXADEV_API_KEY', 'RS-Tgizfy%2');

define('SAKURUPIAH_API_ID', 'ID-31457001644');
define('SAKURUPIAH_API_KEY', 'KEY-3tK5xUnItPpMXB75FmMJYvxOSiD3a');
define('SAKURUPIAH_API_URL', 'https://sakurupiah.id/api/');

define('DATA_PATH', __DIR__ . '/../data/');
define('SESSIONS_FILE', DATA_PATH . 'sessions.json');
define('ORDERS_FILE', DATA_PATH . 'orders.json');

// ============================================
//  FUNGSI
// ============================================
function logAPI($type, $data) {
    $logDir = __DIR__ . '/../logs/';
    if (!is_dir($logDir)) mkdir($logDir, 0755, true);
    $logFile = $logDir . 'api-' . date('Y-m-d') . '.log';
    $entry = date('c') . " [$type] " . json_encode($data) . PHP_EOL;
    file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
}

function getSessionId() {
    session_start();
    if (!isset($_SESSION['payrefer_id'])) {
        $_SESSION['payrefer_id'] = 'USER-' . time() . '-' . bin2hex(random_bytes(8));
    }
    return $_SESSION['payrefer_id'];
}

function loadSessions() {
    if (!file_exists(SESSIONS_FILE)) {
        file_put_contents(SESSIONS_FILE, json_encode([]));
        return [];
    }
    return json_decode(file_get_contents(SESSIONS_FILE), true) ?: [];
}

function saveSessions($data) {
    file_put_contents(SESSIONS_FILE, json_encode($data, JSON_PRETTY_PRINT));
}

function loadOrders() {
    if (!file_exists(ORDERS_FILE)) {
        file_put_contents(ORDERS_FILE, json_encode([]));
        return [];
    }
    return json_decode(file_get_contents(ORDERS_FILE), true) ?: [];
}

function saveOrders($data) {
    file_put_contents(ORDERS_FILE, json_encode($data, JSON_PRETTY_PRINT));
}

function generateMerchantRef() {
    return 'AM-' . time() . '-' . strtoupper(substr(uniqid(), -6));
}

function generateSignature($apiId, $method, $merchantRef, $amount, $apiKey) {
    return hash_hmac('sha256', $apiId . $method . $merchantRef . $amount, $apiKey);
}

function callNexaDevAPI() {
    $url = NEXADEV_API_URL . '?key=' . urlencode(NEXADEV_API_KEY) . '&amount=1';
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_FOLLOWLOCATION => true,
    ]);
    
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        throw new Exception('cURL Error: ' . $error);
    }
    
    $data = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON response from NexaDev');
    }
    
    return $data;
}

function callSakurupiahCreatePayment($amount, $merchantRef) {
    $url = SAKURUPIAH_API_URL . 'create.php';
    $signature = generateSignature(
        SAKURUPIAH_API_ID,
        'QRIS',
        $merchantRef,
        $amount,
        SAKURUPIAH_API_KEY
    );
    
    $postFields = [
        'api_id' => SAKURUPIAH_API_ID,
        'method' => 'QRIS',
        'name' => 'Customer',
        'email' => 'customer@email.com',
        'phone' => '628123456789',
        'amount' => $amount,
        'merchant_ref' => $merchantRef,
        'expired' => '24',
        'callback_url' => 'https://' . $_SERVER['HTTP_HOST'] . '/api/amprem.php?action=webhook',
        'return_url' => 'https://' . $_SERVER['HTTP_HOST'] . '/',
        'signature' => $signature
    ];
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($postFields),
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . SAKURUPIAH_API_KEY,
            'Content-Type: application/x-www-form-urlencoded'
        ]
    ]);
    
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        throw new Exception('cURL Error: ' . $error);
    }
    
    $data = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON response from Sakurupiah');
    }
    
    if (!isset($data['status']) || $data['status'] !== '200') {
        $errorMsg = $data['message'] ?? 'Unknown error from Sakurupiah';
        throw new Exception('Sakurupiah API Error: ' . $errorMsg);
    }
    
    return $data;
}

function callSakurupiahCheckStatus($trxId) {
    $url = SAKURUPIAH_API_URL . 'status-transaction.php';
    
    $postFields = [
        'api_id' => SAKURUPIAH_API_ID,
        'method' => 'status',
        'trx_id' => $trxId
    ];
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($postFields),
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . SAKURUPIAH_API_KEY,
            'Content-Type: application/x-www-form-urlencoded'
        ]
    ]);
    
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        throw new Exception('cURL Error: ' . $error);
    }
    
    $data = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON response');
    }
    
    return $data;
}

// ============================================
//  MAIN LOGIC
// ============================================
try {
    $sessionId = getSessionId();
    $sessions = loadSessions();
    $orders = loadOrders();
    $method = $_SERVER['REQUEST_METHOD'];
    
    // ============================================
    //  GET - SESSION
    // ============================================
    if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'session') {
        $hasFreeCreate = !(isset($sessions[$sessionId]['free_used']) && $sessions[$sessionId]['free_used'] === true);
        echo json_encode([
            'ok' => true,
            'hasFreeCreate' => $hasFreeCreate,
            'sessionId' => $sessionId
        ]);
        exit;
    }
    
    // ============================================
    //  WEBHOOK
    // ============================================
    if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'webhook') {
        $rawInput = file_get_contents('php://input');
        $input = json_decode($rawInput, true);
        
        logAPI('WEBHOOK', ['body' => $input]);
        
        $trxId = $input['trx_id'] ?? '';
        $merchantRef = $input['merchant_ref'] ?? '';
        $status = $input['status'] ?? '';
        
        if ($status === 'berhasil' && $merchantRef) {
            foreach ($orders as &$order) {
                if ($order['order_id'] === $merchantRef) {
                    $order['status'] = 'paid';
                    $order['paid_at'] = date('c');
                    break;
                }
            }
            saveOrders($orders);
        }
        
        echo json_encode(['status' => true]);
        exit;
    }
    
    // ============================================
    //  POST
    // ============================================
    if ($method !== 'POST') {
        throw new Exception('Method not allowed', 405);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? '';
    
    // ============================================
    //  FREE CREATE
    // ============================================
    if ($action === 'free') {
        if (isset($sessions[$sessionId]['free_used']) && $sessions[$sessionId]['free_used'] === true) {
            throw new Exception('Anda sudah menggunakan free create', 400);
        }
        
        $result = callNexaDevAPI();
        
        if (!$result['status']) {
            throw new Exception($result['message'] ?? 'Gagal membuat akun');
        }
        
        $sessions[$sessionId]['free_used'] = true;
        $sessions[$sessionId]['free_used_at'] = date('c');
        saveSessions($sessions);
        
        echo json_encode([
            'ok' => true,
            'type' => 'free',
            'account' => $result
        ]);
        exit;
    }
    
    // ============================================
    //  PAY - CREATE PAYMENT
    // ============================================
    if ($action === 'pay') {
        $amount = 1000;
        $merchantRef = generateMerchantRef();
        
        $sakurupiahResult = callSakurupiahCreatePayment($amount, $merchantRef);
        $paymentData = $sakurupiahResult['data'][0];
        
        $orderData = [
            'order_id' => $merchantRef,
            'type' => 'create_am',
            'amount' => $amount,
            'trx_id' => $paymentData['trx_id'] ?? '',
            'qr_image' => $paymentData['qr'] ?? '',
            'payment_no' => $paymentData['payment_no'] ?? '',
            'status' => 'pending',
            'created_at' => date('c'),
            'expired_at' => $paymentData['expired'] ?? date('c', strtotime('+24 hours'))
        ];
        
        $orders[] = $orderData;
        saveOrders($orders);
        
        echo json_encode([
            'ok' => true,
            'type' => 'pay',
            'order_id' => $merchantRef,
            'trx_id' => $paymentData['trx_id'] ?? '',
            'qr_image' => $paymentData['qr'] ?? '',
            'payment_no' => $paymentData['payment_no'] ?? '',
            'expired_at' => $paymentData['expired'] ?? date('c', strtotime('+24 hours'))
        ]);
        exit;
    }
    
    // ============================================
    //  CHECK STATUS
    // ============================================
    if ($action === 'check') {
        $orderId = $input['order_id'] ?? '';
        if (empty($orderId)) {
            throw new Exception('Order ID diperlukan');
        }
        
        $order = null;
        foreach ($orders as &$o) {
            if ($o['order_id'] === $orderId) {
                $order = &$o;
                break;
            }
        }
        
        if (!$order) {
            throw new Exception('Order tidak ditemukan');
        }
        
        if (in_array($order['status'], ['paid', 'expired'])) {
            $account = null;
            if ($order['status'] === 'paid' && isset($order['account'])) {
                $account = $order['account'];
            }
            echo json_encode([
                'ok' => true,
                'status' => $order['status'],
                'account' => $account
            ]);
            exit;
        }
        
        if (isset($order['expired_at'])) {
            $expiry = strtotime($order['expired_at']);
            if ($expiry && time() > $expiry) {
                $order['status'] = 'expired';
                saveOrders($orders);
                echo json_encode(['ok' => true, 'status' => 'expired']);
                exit;
            }
        }
        
        $status = 'pending';
        if (!empty($order['trx_id'])) {
            try {
                $result = callSakurupiahCheckStatus($order['trx_id']);
                if (isset($result['status']) && $result['status'] === '200') {
                    $remoteStatus = $result['data'][0]['status'] ?? '';
                    if ($remoteStatus === 'berhasil') {
                        $status = 'paid';
                        $order['status'] = 'paid';
                        $order['paid_at'] = date('c');
                        
                        // Create akun setelah payment berhasil
                        $nexaResult = callNexaDevAPI();
                        if ($nexaResult['status']) {
                            $order['account'] = $nexaResult;
                        }
                        
                        saveOrders($orders);
                    } elseif ($remoteStatus === 'expired') {
                        $order['status'] = 'expired';
                        saveOrders($orders);
                        $status = 'expired';
                    }
                }
            } catch (Exception $e) {
                logAPI('CHECK_ERROR', ['error' => $e->getMessage()]);
            }
        }
        
        echo json_encode([
            'ok' => true,
            'status' => $status,
            'account' => $order['account'] ?? null
        ]);
        exit;
    }
    
    throw new Exception('Action tidak valid');
    
} catch (Exception $e) {
    $code = $e->getCode() ?: 400;
    http_response_code($code);
    echo json_encode([
        'ok' => false,
        'error' => $e->getMessage()
    ]);
}