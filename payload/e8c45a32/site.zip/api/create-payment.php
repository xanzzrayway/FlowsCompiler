<?php
require_once '../env/config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

function logAPI($type, $data) {
    $logDir = __DIR__ . '/../logs/';
    if (!is_dir($logDir)) mkdir($logDir, 0755, true);
    $logFile = $logDir . 'api-' . date('Y-m-d') . '.log';
    $entry = date('c') . " [$type] " . json_encode($data) . PHP_EOL;
    file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
}

function generateMerchantRef() {
    return 'DEP-' . time() . '-' . strtoupper(substr(uniqid(), -6));
}

function generateSignature($apiId, $method, $merchantRef, $amount, $apiKey) {
    return hash_hmac('sha256', $apiId . $method . $merchantRef . $amount, $apiKey);
}

function callSakurupiahCreatePayment($data) {
    $url = SAKURUPIAH_API_URL . 'create.php';
    
    $postFields = [
        'api_id' => SAKURUPIAH_API_ID,
        'method' => 'QRISMU',
        'name' => 'Customer',
        'email' => 'customer@email.com',
        'phone' => '628123456789',
        'amount' => $data['amount'],
        // 'merchant_fee' => '0',  // DIHAPUS - tidak diperlukan
        'merchant_ref' => $data['merchant_ref'],
        'expired' => '24',
        'callback_url' => 'https://' . $_SERVER['HTTP_HOST'] . '/api/webhook.php',
        'return_url' => 'https://' . $_SERVER['HTTP_HOST'] . '/deposit.html',
        'signature' => $data['signature']
    ];
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($postFields),
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . SAKURUPIAH_API_KEY,
            'Content-Type: application/x-www-form-urlencoded'
        ]
    ]);
    
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        throw new Exception('cURL Error: ' . $error);
    }
    
    $data = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON response from Sakurupiah');
    }
    
    if (!isset($data['status']) || $data['status'] !== '200') {
        $errorMsg = $data['message'] ?? 'Unknown error from Sakurupiah';
        throw new Exception('Sakurupiah API Error: ' . $errorMsg);
    }
    
    return $data;
}

function saveOrder($orderData) {
    $ordersDir = __DIR__ . '/../orders/';
    if (!is_dir($ordersDir)) mkdir($ordersDir, 0755, true);
    $filename = $ordersDir . $orderData['order_id'] . '.json';
    file_put_contents($filename, json_encode($orderData, JSON_PRETTY_PRINT));
}

$input = json_decode(file_get_contents('php://input'), true);

try {
    $amount = (int)($input['amount'] ?? 0);
    
    if ($amount < 1000) {
        throw new Exception('Minimal deposit Rp1.000');
    }
    if ($amount > 10000) {
        throw new Exception('Maksimal deposit Rp10.000');
    }

    $merchantRef = generateMerchantRef();
    $signature = generateSignature(
        SAKURUPIAH_API_ID,
        'QRISMU',
        $merchantRef,
        $amount,
        SAKURUPIAH_API_KEY
    );

    $sakurupiahData = [
        'method' => 'QRISMU',
        'amount' => $amount,
        'merchant_ref' => $merchantRef,
        'signature' => $signature
    ];

    $sakurupiahResponse = callSakurupiahCreatePayment($sakurupiahData);
    $paymentData = $sakurupiahResponse['data'][0];

    $orderData = [
        'order_id' => $merchantRef,
        'type' => 'deposit',
        'amount' => $amount,
        'total_payment' => $paymentData['total'] ?? $amount,
        'payment_method' => 'QRISMU',
        'trx_id' => $paymentData['trx_id'] ?? '',
        'payment_no' => $paymentData['payment_no'] ?? '',
        'qr_image' => $paymentData['qr'] ?? '',
        'status' => 'pending',
        'created_at' => date('c'),
        'expired_at' => $paymentData['expired'] ?? date('c', strtotime('+24 hours'))
    ];

    saveOrder($orderData);

    echo json_encode([
        'ok' => true,
        'order_id' => $merchantRef,
        'trx_id' => $paymentData['trx_id'] ?? '',
        'amount' => $amount,
        'total_payment' => $paymentData['total'] ?? $amount,
        'payment_method' => 'QRISMU',
        'qr_image' => $paymentData['qr'] ?? '',
        'payment_no' => $paymentData['payment_no'] ?? '',
        'expired_at' => $paymentData['expired'] ?? date('c', strtotime('+24 hours'))
    ]);

} catch (Exception $e) {
    logAPI('CREATE_PAYMENT_ERROR', ['error' => $e->getMessage()]);
    http_response_code(400);
    echo json_encode([
        'ok' => false,
        'error' => $e->getMessage()
    ]);
}