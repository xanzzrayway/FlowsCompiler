<?php
/**
 * Payrefer - Konfigurasi API
 */

// ============================================
//  NEXADEV API - Create Alight Motion Premium
// ============================================
define('NEXADEV_API_URL', 'https://api.nexadev.my.id/am/bulk/');
define('NEXADEV_API_KEY', 'RS-Tgizfy%2');

// ============================================
//  SAKURUPIAH API - Payment Gateway (QRISMU only)
// ============================================
define('SAKURUPIAH_API_ID', 'ID-31457001644');
define('SAKURUPIAH_API_KEY', 'KEY-3tK5xUnItPpMXB75FmMJYvxOSiD3a');
define('SAKURUPIAH_API_URL', 'https://sakurupiah.id/api/');

// Payment Method - ONLY QRISMU
define('PAYMENT_METHOD', 'QRISMU');