# Shop Demo Android

Đây là **Android app**, không phải website. Vì vậy GitHub Actions phải chạy Gradle để build APK, không được kiểm tra `index.html`.

## Build trên GitHub
1. Upload toàn bộ project lên repository.
2. Vào **Actions**.
3. Chọn **Build Android APK**.
4. Bấm **Run workflow**.
5. Khi chạy xong, vào phần **Artifacts** tải `ShopDemo-debug-apk`.

## Build trên Android Studio
Mở thư mục project → Sync → Run.

## APK
File sau khi build:
`app/build/outputs/apk/debug/app-debug.apk`
