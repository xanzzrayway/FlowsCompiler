using UnityEngine;

namespace MiniCraft
{
    /// <summary>Луч от камеры (DDA по воксельной сетке), подсветка блока, ломание (удержание) и установка/еда (тап).</summary>
    public class BlockInteraction : MonoBehaviour
    {
        const float Reach = 5f;
        public float BreakProgress { get; private set; }

        GameManager gm; PlayerController pc; GameObject highlight;
        bool breaking, hasCur; Vector3Int cur; float timer;

        public void Setup(GameManager g, PlayerController p)
        {
            gm = g; pc = p;
            highlight = GameObject.CreatePrimitive(PrimitiveType.Cube);
            Destroy(highlight.GetComponent<Collider>());
            highlight.name = "BlockHighlight";
            highlight.transform.localScale = Vector3.one * 1.005f;
            var mat = new Material(g.Map.WaterMat) { mainTexture = Texture2D.whiteTexture };
            mat.color = new Color(0, 0, 0, .3f);
            var mr = highlight.GetComponent<MeshRenderer>();
            mr.sharedMaterial = mat; mr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            highlight.SetActive(false);
        }

        void OnDestroy() { if (highlight != null) Destroy(highlight); }

        public void SetBreaking(bool on)
        {
            breaking = on;
            if (!on) { timer = 0; BreakProgress = 0; hasCur = false; }
        }

        float HeldPower() => Items.Get(gm.Inv.Held.id).PickPower;

        void Update()
        {
            if (gm.State != GameState.Playing) { highlight.SetActive(false); return; }
            Vector3Int blk, nrm;
            bool hit = Cast(out blk, out nrm);
            highlight.SetActive(hit);
            if (hit) highlight.transform.position = new Vector3(blk.x + .5f, blk.y + .5f, blk.z + .5f);

            if (!(breaking && hit)) { timer = 0; BreakProgress = 0; hasCur = false; return; }
            if (!hasCur || blk != cur) { cur = blk; hasCur = true; timer = 0; }

            byte id = gm.Map.GetBlock(blk.x, blk.y, blk.z);
            var info = Items.Get(id);
            float need = gm.Creative ? 0.2f : Mathf.Max(0.1f, info.Hardness / (info.NeedsPickaxe ? HeldPower() : 1f));
            timer += Time.deltaTime;
            BreakProgress = Mathf.Clamp01(timer / need);
            if (timer >= need) { Break(blk, id); timer = 0; hasCur = false; BreakProgress = 0; }
        }

        void Break(Vector3Int b, byte id)
        {
            if (b.y <= 0) return;   // нижний слой мира неразрушим
            gm.Map.SetBlock(b.x, b.y, b.z, Block.Air);
            if (gm.Creative) return;
            var info = Items.Get(id);
            if (info.Drop != 0 && (!info.NeedsPickaxe || HeldPower() > 1f)) gm.Inv.Add((ItemId)info.Drop, 1);
            if (id == Block.Leaves && Random.value < 0.08f) gm.Inv.Add(ItemId.Apple, 1);
        }

        /// <summary>Короткий тап: съесть еду или поставить блок в выбранную грань.</summary>
        public void Place()
        {
            var held = gm.Inv.Held;
            if (held.IsEmpty) return;
            var info = Items.Get(held.id);
            if (info.Food > 0)
            {
                if (!gm.Creative && gm.Stats.Hunger < PlayerStats.Max) { gm.Stats.Eat(info.Food); gm.Inv.ConsumeSelected(); }
                return;
            }
            if (!info.IsBlock) return;
            Vector3Int blk, nrm;
            if (!Cast(out blk, out nrm) || nrm == Vector3Int.zero) return;
            var t = blk + nrm;
            byte now = gm.Map.GetBlock(t.x, t.y, t.z);
            if ((now != Block.Air && now != Block.Water) || t.y < 1 || t.y >= World.CH) return;
            if (info.Solid && Overlaps(t)) return;
            gm.Map.SetBlock(t.x, t.y, t.z, (byte)held.id);
            if (!gm.Creative) gm.Inv.ConsumeSelected();
        }

        bool Overlaps(Vector3Int t)
        {
            Vector3 p = pc.transform.position; const float hw = PlayerController.HalfWidth;
            return p.x + hw > t.x && p.x - hw < t.x + 1 && p.z + hw > t.z && p.z - hw < t.z + 1
                && p.y + PlayerController.Height > t.y && p.y < t.y + 1;
        }

        /// <summary>Алгоритм Амануатидеса–Ву: проход луча по клеткам. Вода не «ловится» лучом.</summary>
        bool Cast(out Vector3Int block, out Vector3Int normal)
        {
            Vector3 o = gm.Cam.transform.position, d = gm.Cam.transform.forward;
            int x = Mathf.FloorToInt(o.x), y = Mathf.FloorToInt(o.y), z = Mathf.FloorToInt(o.z);
            int sx = d.x > 0 ? 1 : -1, sy = d.y > 0 ? 1 : -1, sz = d.z > 0 ? 1 : -1;
            float ax = Mathf.Abs(d.x), ay = Mathf.Abs(d.y), az = Mathf.Abs(d.z), inf = float.PositiveInfinity;
            float dx = ax < 1e-6f ? inf : 1f / ax, dy = ay < 1e-6f ? inf : 1f / ay, dz = az < 1e-6f ? inf : 1f / az;
            float tx = ax < 1e-6f ? inf : (sx > 0 ? x + 1 - o.x : o.x - x) * dx;
            float ty = ay < 1e-6f ? inf : (sy > 0 ? y + 1 - o.y : o.y - y) * dy;
            float tz = az < 1e-6f ? inf : (sz > 0 ? z + 1 - o.z : o.z - z) * dz;
            normal = Vector3Int.zero; block = default;
            while (true)
            {
                if (Items.SolidTbl[gm.Map.GetBlock(x, y, z)]) { block = new Vector3Int(x, y, z); return true; }
                float t;
                if (tx < ty && tx < tz) { t = tx; x += sx; tx += dx; normal = new Vector3Int(-sx, 0, 0); }
                else if (ty < tz) { t = ty; y += sy; ty += dy; normal = new Vector3Int(0, -sy, 0); }
                else { t = tz; z += sz; tz += dz; normal = new Vector3Int(0, 0, -sz); }
                if (t > Reach) return false;
            }
        }
    }
}
