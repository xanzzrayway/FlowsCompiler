using UnityEngine;

namespace MiniCraft
{
    /// <summary>
    /// Движение игрока. Своя воксельная физика (AABB 0.6×1.8 против сетки блоков) — без Rigidbody и коллайдеров,
    /// поэтому изменения мира не требуют перестройки физики. Есть: ходьба, прыжок, автопрыжок на 1 блок,
    /// плавание, урон от падения (выживание), полёт (креатив).
    /// </summary>
    public class PlayerController : MonoBehaviour
    {
        public const float HalfWidth = 0.3f, Height = 1.8f, Eye = 1.62f;
        const float Gravity = 28f, JumpSpeed = 8.4f;

        public BlockInteraction Interaction { get; private set; }
        public bool Flying { get; private set; }
        public bool InWater { get; private set; }
        public bool HeadInWater { get; private set; }
        public bool IsReady { get; private set; }
        public bool AutoJump = true;

        GameManager gm; World world; Camera cam; PlayerStats stats;
        Joystick joystick; HoldButton jumpBtn, downBtn;
        float yaw, pitch, fallStart; Vector3 vel; bool onGround, wasGround;

        public void Setup(GameManager g)
        {
            gm = g; world = g.Map; cam = g.Cam; stats = g.Stats;
            Interaction = gameObject.AddComponent<BlockInteraction>();
            Interaction.Setup(g, this);
        }

        public void SetControls(Joystick j, HoldButton jump, HoldButton down) { joystick = j; jumpBtn = jump; downBtn = down; }

        public void Teleport(Vector3 p) { transform.position = p; vel = Vector3.zero; fallStart = p.y; }
        public void ToggleFly() { if (gm.Creative) { Flying = !Flying; vel.y = 0; } }

        /// <summary>Поворот камеры по свайпу (в пикселях), независимо от разрешения экрана.</summary>
        public void Look(Vector2 delta)
        {
            float k = 220f / Mathf.Max(Screen.width, 1);
            yaw += delta.x * k; pitch = Mathf.Clamp(pitch - delta.y * k, -89f, 89f);
            transform.rotation = Quaternion.Euler(0, yaw, 0);
            cam.transform.localRotation = Quaternion.Euler(pitch, 0, 0);
        }

        void Update()
        {
            if (gm == null || gm.State != GameState.Playing) return;
            int fx = Mathf.FloorToInt(transform.position.x), fz = Mathf.FloorToInt(transform.position.z);
            IsReady = world.IsLoaded(fx, fz);
            if (!IsReady) return;                       // ждём, пока под ногами появится мир
            float dt = Mathf.Min(Time.deltaTime, 0.05f);

            // --- ввод ---
            Vector2 mv = joystick != null ? joystick.Value : Vector2.zero;
            bool jump = jumpBtn != null && jumpBtn.Held, down = downBtn != null && downBtn.Held;
            mv += new Vector2((Kb.Held(KeyCode.D) ? 1 : 0) - (Kb.Held(KeyCode.A) ? 1 : 0), (Kb.Held(KeyCode.W) ? 1 : 0) - (Kb.Held(KeyCode.S) ? 1 : 0));
            jump |= Kb.Held(KeyCode.Space); down |= Kb.Held(KeyCode.LeftShift);
            mv = Vector2.ClampMagnitude(mv, 1f);

            // --- среда ---
            Vector3 p = transform.position;
            InWater = world.GetBlock(fx, Mathf.FloorToInt(p.y + 0.4f), fz) == Block.Water;
            HeadInWater = world.GetBlock(fx, Mathf.FloorToInt(p.y + Eye), fz) == Block.Water;

            // --- скорость ---
            float speed = Flying ? 10f : InWater ? 2.6f : 4.4f;
            Vector3 wish = Quaternion.Euler(0, yaw, 0) * new Vector3(mv.x, 0, mv.y) * speed;
            vel.x = wish.x; vel.z = wish.z;
            if (Flying) vel.y = jump ? 8f : down ? -8f : 0f;
            else if (InWater) vel.y = Mathf.MoveTowards(vel.y, jump ? 3.5f : -2.2f, 18f * dt);
            else { vel.y = Mathf.Max(vel.y - Gravity * dt, -45f); if (jump && onGround) vel.y = JumpSpeed; }

            // --- перемещение по осям с коллизиями ---
            MoveAxis(0, vel.x * dt); MoveAxis(2, vel.z * dt);
            onGround = false; MoveAxis(1, vel.y * dt);
            if (Flying && onGround) Flying = false;     // приземлились — полёт выключается

            // --- урон от падения ---
            p = transform.position;
            if (onGround && !wasGround && !InWater && !Flying && !gm.Creative)
            {
                float d = fallStart - p.y;
                if (d > 3.2f) stats.Damage(Mathf.Floor(d - 3f));
            }
            fallStart = (onGround || InWater || Flying) ? p.y : Mathf.Max(fallStart, p.y);
            wasGround = onGround;

            if (!gm.Creative)
            {
                stats.Tick(dt, mv.sqrMagnitude > 0.01f);
                if (stats.Dead) gm.OnPlayerDied();
            }
            if (p.y < -30f) Teleport(world.FindSpawn());
        }

        bool Collides(Vector3 p)
        {
            int x0 = Mathf.FloorToInt(p.x - HalfWidth), x1 = Mathf.FloorToInt(p.x + HalfWidth);
            int y0 = Mathf.FloorToInt(p.y), y1 = Mathf.FloorToInt(p.y + Height);
            int z0 = Mathf.FloorToInt(p.z - HalfWidth), z1 = Mathf.FloorToInt(p.z + HalfWidth);
            for (int y = y0; y <= y1; y++) for (int z = z0; z <= z1; z++) for (int x = x0; x <= x1; x++)
                if (Items.SolidTbl[world.GetBlock(x, y, z)]) return true;
            return false;
        }

        /// <summary>Двигает по одной оси мелкими шагами (≤0.4), при ударе «прилипает» к грани блока.</summary>
        void MoveAxis(int axis, float d)
        {
            Vector3 pos = transform.position;
            while (Mathf.Abs(d) > 1e-6f)
            {
                float s = Mathf.Clamp(d, -0.4f, 0.4f); d -= s;
                Vector3 q = pos; q[axis] += s;
                if (!Collides(q)) { pos = q; continue; }

                if (axis == 1)
                {
                    if (s < 0) { pos.y = Mathf.Floor(q.y) + 1.001f; onGround = true; }
                    else pos.y = Mathf.Floor(q.y + Height) - Height - 0.001f;
                    vel.y = 0;
                }
                else
                {
                    if (AutoJump && onGround && !Flying && !InWater && !Collides(q + Vector3.up)) vel.y = JumpSpeed;   // ступенька в 1 блок
                    if (axis == 0)
                    {
                        pos.x = s > 0 ? Mathf.Floor(q.x + HalfWidth) - HalfWidth - 0.001f : Mathf.Floor(q.x - HalfWidth) + 1f + HalfWidth + 0.001f;
                        vel.x = 0;
                    }
                    else
                    {
                        pos.z = s > 0 ? Mathf.Floor(q.z + HalfWidth) - HalfWidth - 0.001f : Mathf.Floor(q.z - HalfWidth) + 1f + HalfWidth + 0.001f;
                        vel.z = 0;
                    }
                }
                break;
            }
            transform.position = pos;
        }
    }
}
