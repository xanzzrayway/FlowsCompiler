using UnityEngine;

namespace MiniCraft
{
    /// <summary>Здоровье и голод (режим «Выживание»). Шкалы 0–20 (10 иконок по 2 единицы).</summary>
    public class PlayerStats
    {
        public const float Max = 20f;
        public float Health = Max, Hunger = Max;
        float hungerT, regenT;
        public bool Dead => Health <= 0f;

        public void Reset() { Health = Hunger = Max; hungerT = regenT = 0f; }
        public void Damage(float a) { Health = Mathf.Max(0f, Health - a); }
        public void Eat(float f) { Hunger = Mathf.Min(Max, Hunger + f); }

        public void Tick(float dt, bool moving)
        {
            hungerT += dt * (moving ? 1.6f : 1f);
            if (hungerT >= 25f) { hungerT = 0f; Hunger = Mathf.Max(0f, Hunger - 1f); }
            regenT += dt;
            if (Hunger >= 18f && Health < Max) { if (regenT >= 3f) { regenT = 0f; Health = Mathf.Min(Max, Health + 1f); } }
            else if (Hunger <= 0f) { if (regenT >= 4f) { regenT = 0f; Health = Mathf.Max(0f, Health - 1f); } }
            else regenT = 0f;
        }
    }
}
