namespace MiniCraft
{
    /// <summary>ID блоков (хранятся как byte внутри чанка).</summary>
    public static class Block
    {
        public const byte Air = 0, Grass = 1, Dirt = 2, Stone = 3, Sand = 4, Water = 5, Log = 6, Leaves = 7, Planks = 8, Cobble = 9;
    }

    /// <summary>ID предметов. Для блоков значения совпадают с Block.* (блок = предмет).</summary>
    public enum ItemId : byte
    {
        None = 0, Grass = Block.Grass, Dirt = Block.Dirt, Stone = Block.Stone, Sand = Block.Sand, Water = Block.Water,
        Log = Block.Log, Leaves = Block.Leaves, Planks = Block.Planks, Cobble = Block.Cobble,
        Stick = 20, Apple = 21, WoodPickaxe = 22, StonePickaxe = 23
    }

    public class ItemInfo
    {
        public string Name = "";
        public bool IsBlock, Solid, Opaque, NeedsPickaxe;
        public float Hardness = 1f, PickPower = 1f;
        public int Food, MaxStack = 64, Top, Side, Bottom;
        public byte Drop;
        public int Icon => Side;   // тайл атласа для иконки
    }

    /// <summary>База данных блоков и предметов. Чтобы добавить новый — одна строка в статическом конструкторе.</summary>
    public static class Items
    {
        static readonly ItemInfo[] table = new ItemInfo[32];
        public static readonly bool[] SolidTbl = new bool[256], OpaqueTbl = new bool[256];
        public static readonly ItemId[] Palette =
        {
            ItemId.Grass, ItemId.Dirt, ItemId.Stone, ItemId.Sand, ItemId.Water, ItemId.Log, ItemId.Leaves,
            ItemId.Planks, ItemId.Cobble, ItemId.Stick, ItemId.Apple, ItemId.WoodPickaxe, ItemId.StonePickaxe
        };

        static Items()
        {
            table[0] = new ItemInfo();
            Blk(ItemId.Grass, "Трава", .6f, Atlas.GrassTop, Atlas.GrassSide, Atlas.Dirt, drop: ItemId.Dirt);
            Blk(ItemId.Dirt, "Земля", .5f, Atlas.Dirt, Atlas.Dirt, Atlas.Dirt);
            Blk(ItemId.Stone, "Камень", 1.5f, Atlas.Stone, Atlas.Stone, Atlas.Stone, drop: ItemId.Cobble, pick: true);
            Blk(ItemId.Sand, "Песок", .5f, Atlas.Sand, Atlas.Sand, Atlas.Sand);
            Blk(ItemId.Water, "Вода", 99f, Atlas.Water, Atlas.Water, Atlas.Water, opaque: false, solid: false, noDrop: true);
            Blk(ItemId.Log, "Бревно", 1f, Atlas.LogTop, Atlas.LogSide, Atlas.LogTop);
            Blk(ItemId.Leaves, "Листва", .2f, Atlas.Leaves, Atlas.Leaves, Atlas.Leaves, opaque: false, noDrop: true);
            Blk(ItemId.Planks, "Доски", 1f, Atlas.Planks, Atlas.Planks, Atlas.Planks);
            Blk(ItemId.Cobble, "Булыжник", 2f, Atlas.Cobble, Atlas.Cobble, Atlas.Cobble, pick: true);
            Itm(ItemId.Stick, "Палка", Atlas.Stick);
            Itm(ItemId.Apple, "Яблоко", Atlas.Apple, food: 4);
            Itm(ItemId.WoodPickaxe, "Деревянная кирка", Atlas.WoodPick, power: 3f, stack: 1);
            Itm(ItemId.StonePickaxe, "Каменная кирка", Atlas.StonePick, power: 5f, stack: 1);

            for (int i = 0; i < table.Length; i++)
                if (table[i] != null && table[i].IsBlock) { SolidTbl[i] = table[i].Solid; OpaqueTbl[i] = table[i].Opaque; }
        }

        static void Blk(ItemId id, string name, float hard, int top, int side, int bottom, ItemId? drop = null,
                        bool opaque = true, bool pick = false, bool solid = true, bool noDrop = false)
        {
            table[(int)id] = new ItemInfo
            {
                Name = name, IsBlock = true, Hardness = hard, Top = top, Side = side, Bottom = bottom,
                Opaque = opaque, Solid = solid, NeedsPickaxe = pick, Drop = noDrop ? (byte)0 : (byte)(drop ?? id)
            };
        }

        static void Itm(ItemId id, string name, int tile, int food = 0, float power = 1f, int stack = 64)
        {
            table[(int)id] = new ItemInfo { Name = name, Top = tile, Side = tile, Bottom = tile, Food = food, PickPower = power, MaxStack = stack };
        }

        public static ItemInfo Get(byte id) => table[id];
        public static ItemInfo Get(ItemId id) => table[(int)id];
    }
}
