using System.Text;

namespace MiniCraft
{
    public class Recipe
    {
        public readonly ItemId Result; public readonly int Count; public readonly (ItemId id, int n)[] Inputs;
        public Recipe(ItemId result, int count, params (ItemId id, int n)[] inputs) { Result = result; Count = count; Inputs = inputs; }

        public bool CanCraft(Inventory inv)
        {
            foreach (var i in Inputs) if (inv.Count(i.id) < i.n) return false;
            return inv.Room(Result) >= Count;
        }

        public bool Craft(Inventory inv)
        {
            if (!CanCraft(inv)) return false;
            foreach (var i in Inputs) inv.Take(i.id, i.n);
            inv.Add(Result, Count);
            return true;
        }

        public string Describe()
        {
            var s = new StringBuilder();
            for (int i = 0; i < Inputs.Length; i++)
            {
                if (i > 0) s.Append(" + ");
                s.Append(Items.Get(Inputs[i].id).Name).Append(" ×").Append(Inputs[i].n);
            }
            return s.ToString();
        }
    }

    /// <summary>Список рецептов. Новый рецепт = одна строка.</summary>
    public static class Recipes
    {
        public static readonly Recipe[] All =
        {
            new Recipe(ItemId.Planks, 4, (ItemId.Log, 1)),
            new Recipe(ItemId.Stick, 4, (ItemId.Planks, 2)),
            new Recipe(ItemId.WoodPickaxe, 1, (ItemId.Planks, 3), (ItemId.Stick, 2)),
            new Recipe(ItemId.StonePickaxe, 1, (ItemId.Cobble, 3), (ItemId.Stick, 2)),
        };
    }
}
