using UnityEngine;

namespace MiniCraft
{
    /// <summary>Процедурный атлас текстур 4×4 тайла по 16 px (никаких внешних картинок) + спрайты иконок для UI.</summary>
    public static class Atlas
    {
        public const int N = 4, TS = 16, Size = N * TS;
        public const int GrassTop = 0, GrassSide = 1, Dirt = 2, Stone = 3, Sand = 4, Water = 5, LogSide = 6, LogTop = 7,
            Leaves = 8, Planks = 9, Cobble = 10, Stick = 11, Apple = 12, WoodPick = 13, StonePick = 14;

        public static Texture2D Texture { get; private set; }
        static Color32[] px;
        static readonly Sprite[] sprites = new Sprite[N * N];

        public static void Build()
        {
            if (Texture != null) return;
            px = new Color32[Size * Size];
            var r = new System.Random(7);
            Noise(GrassTop, 95, 159, 53, 14); Noise(Dirt, 134, 96, 67, 10); Noise(GrassSide, 134, 96, 67, 10);
            for (int x = 0; x < TS; x++)
            {
                int h = 3 + r.Next(0, 2);
                for (int y = TS - h; y < TS; y++) Put(GrassSide, x, y, Col(95, 159, 53, r.Next(-12, 13)));
            }
            Noise(Stone, 125, 125, 125, 10); Noise(Sand, 219, 207, 142, 8); Noise(Water, 45, 90, 200, 6, 170);
            Noise(Leaves, 55, 135, 40, 18);
            for (int y = 0; y < TS; y++) for (int x = 0; x < TS; x++)
            {
                if (r.Next(100) < 16) Put(Leaves, x, y, new Color32(0, 0, 0, 0));
                Put(LogSide, x, y, Col(102, 81, 50, r.Next(-5, 6) - (x % 4 == 1 ? 18 : 0)));
                float d = Mathf.Max(Mathf.Abs(x - 7.5f), Mathf.Abs(y - 7.5f));
                Put(LogTop, x, y, d > 6.5f ? Col(102, 81, 50, r.Next(-5, 6)) : ((int)d % 3 == 1 ? Col(139, 108, 62, r.Next(-4, 5)) : Col(176, 144, 92, r.Next(-4, 5))));
                int pn = r.Next(-4, 5) - (y % 4 == 3 ? 28 : 0) - (x == ((y / 4) % 2 == 0 ? 3 : 11) ? 20 : 0);
                Put(Planks, x, y, Col(162, 130, 78, pn));
                int cell = (x / 4 + (y / 4) * 3) % 4;
                Put(Cobble, x, y, Col(112, 112, 112, cell * 14 - 20 + r.Next(-8, 9) - ((x % 4 == 0 || y % 4 == 0) ? 22 : 0)));
            }
            // Предметы
            Line(Stick, 3, 3, 12, 12, Col(122, 88, 48)); Line(Stick, 4, 3, 13, 12, Col(100, 70, 36));
            for (int y = 0; y < TS; y++) for (int x = 0; x < TS; x++)
                if ((x - 7.5f) * (x - 7.5f) + (y - 6.5f) * (y - 6.5f) <= 27f) Put(Apple, x, y, Col(205, 35, 35, r.Next(-10, 11)));
            Put(Apple, 5, 8, Col(255, 150, 150)); Put(Apple, 8, 12, Col(100, 70, 36)); Put(Apple, 8, 13, Col(100, 70, 36)); Put(Apple, 9, 13, Col(70, 160, 50));
            Pick(WoodPick, Col(150, 115, 60)); Pick(StonePick, Col(125, 125, 125));

            Texture = new Texture2D(Size, Size, TextureFormat.RGBA32, false)
            { filterMode = FilterMode.Point, wrapMode = TextureWrapMode.Clamp, name = "MiniCraftAtlas" };
            Texture.SetPixels32(px); Texture.Apply();
        }

        public static void Uv(int tile, out float u0, out float v0, out float u1, out float v1)
        {
            const float e = 0.0005f, s = 1f / N;
            u0 = (tile % N) * s + e; v0 = (tile / N) * s + e; u1 = u0 + s - 2 * e; v1 = v0 + s - 2 * e;
        }

        public static Sprite Icon(int tile)
        {
            if (sprites[tile] == null)
                sprites[tile] = Sprite.Create(Texture, new Rect((tile % N) * TS, (tile / N) * TS, TS, TS), new Vector2(.5f, .5f), TS, 0, SpriteMeshType.FullRect);
            return sprites[tile];
        }

        static byte Cl(int v) => (byte)Mathf.Clamp(v, 0, 255);
        static Color32 Col(int r, int g, int b, int n = 0, int a = 255) => new Color32(Cl(r + n), Cl(g + n), Cl(b + n), (byte)a);
        static void Put(int t, int x, int y, Color32 c) { px[((t / N) * TS + y) * Size + (t % N) * TS + x] = c; }

        static void Noise(int t, int r, int g, int b, int v, int a = 255)
        {
            var rnd = new System.Random(t * 97 + 3);
            for (int y = 0; y < TS; y++) for (int x = 0; x < TS; x++) Put(t, x, y, Col(r, g, b, rnd.Next(-v, v + 1), a));
        }

        static void Line(int t, int x0, int y0, int x1, int y1, Color32 c)
        {
            int n = Mathf.Max(Mathf.Abs(x1 - x0), Mathf.Abs(y1 - y0));
            for (int i = 0; i <= n; i++) Put(t, x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n, c);
        }

        static void Pick(int t, Color32 head)
        {
            var wood = Col(110, 78, 40);
            Line(t, 2, 2, 11, 11, wood); Line(t, 3, 2, 12, 11, wood);
            for (int i = 4; i <= 13; i++) { Put(t, i, 13, head); Put(t, i, 12, head); Put(t, 13, i, head); Put(t, 12, i, head); }
        }
    }
}
