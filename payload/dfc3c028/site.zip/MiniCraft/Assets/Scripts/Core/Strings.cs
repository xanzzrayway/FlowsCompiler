namespace MiniCraft
{
    /// <summary>Все тексты интерфейса в одном месте (упростит локализацию).</summary>
    public static class Strings
    {
        public const string Title = "MINICRAFT", Subtitle = "Этап 1 · ядро игры";
        public const string Survival = "Выживание", Creative = "Креатив", Quit = "Выход";
        public const string RenderDist = "Дальность прорисовки", Resume = "Продолжить", ToMenu = "В главное меню";
        public const string Paused = "Пауза", Inventory = "Инвентарь", Backpack = "Рюкзак", Crafting = "Крафт";
        public const string Palette = "Все предметы", Close = "Закрыть", Dead = "Вы погибли", Respawn = "Возродиться";
        public const string Loading = "Загрузка мира...", Jump = "Прыжок", Down = "Вниз", Fly = "Полёт", InvShort = "Инв.";
        public const string CreativeHint = "Креатив: предметы бесконечны.\nВыберите слот внизу и коснитесь предмета слева.";
        public const string CraftHint = "Коснитесь рецепта, чтобы скрафтить.";
    }
}
