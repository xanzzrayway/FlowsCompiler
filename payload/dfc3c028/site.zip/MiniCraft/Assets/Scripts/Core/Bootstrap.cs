using UnityEngine;

namespace MiniCraft
{
    /// <summary>Точка входа. Создаёт GameManager в любой сцене — ручная настройка сцены не нужна.</summary>
    public static class Bootstrap
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Init()
        {
            if (GameManager.I != null) return;
            Application.targetFrameRate = 60;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            Screen.autorotateToPortrait = Screen.autorotateToPortraitUpsideDown = false;
            Screen.autorotateToLandscapeLeft = Screen.autorotateToLandscapeRight = true;
            Screen.orientation = ScreenOrientation.AutoRotation;
            new GameObject("MiniCraft").AddComponent<GameManager>();
        }
    }

    /// <summary>Безопасный доступ к клавиатуре (для тестов в редакторе / кнопка «Назад» на Android).</summary>
    public static class Kb
    {
        static bool ok = true;
        public static bool Held(KeyCode k) { if (!ok) return false; try { return Input.GetKey(k); } catch { ok = false; return false; } }
        public static bool Down(KeyCode k) { if (!ok) return false; try { return Input.GetKeyDown(k); } catch { ok = false; return false; } }
    }
}
