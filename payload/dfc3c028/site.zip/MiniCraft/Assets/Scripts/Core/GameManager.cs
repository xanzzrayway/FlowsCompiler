using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace MiniCraft
{
    public enum GameState { Menu, Playing, Paused, Inventory, Dead }
    public enum GameMode { Survival, Creative }

    /// <summary>Главный «дирижёр»: состояния игры, запуск/остановка мира, владелец UI.</summary>
    public class GameManager : MonoBehaviour
    {
        public static GameManager I { get; private set; }
        public GameState State { get; private set; }
        public GameMode Mode { get; private set; }
        public bool Creative => Mode == GameMode.Creative;
        public int RenderDistance = 4;

        public Camera Cam { get; private set; }
        public World Map { get; private set; }
        public PlayerController Player { get; private set; }
        public Inventory Inv { get; private set; }
        public PlayerStats Stats { get; private set; }

        MainMenu menu; Hud hud; InventoryScreen inventoryScreen; PauseScreen pause; DeathScreen death;

        void Awake()
        {
            I = this;
            Atlas.Build();
            SetupCamera();
            SetupUI();
            SetState(GameState.Menu);
        }

        void SetupCamera()
        {
            foreach (var c in Camera.allCameras) c.gameObject.SetActive(false);
            var go = new GameObject("GameCamera") { tag = "MainCamera" };
            go.AddComponent<AudioListener>();
            Cam = go.AddComponent<Camera>();
            Cam.clearFlags = CameraClearFlags.SolidColor;
            Cam.backgroundColor = World.SkyColor;
            Cam.nearClipPlane = 0.1f; Cam.fieldOfView = 70f;
        }

        void SetupUI()
        {
            var cgo = new GameObject("UI"); cgo.transform.SetParent(transform);
            var canvas = cgo.AddComponent<Canvas>(); canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var sc = cgo.AddComponent<CanvasScaler>();
            sc.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            sc.referenceResolution = new Vector2(1280, 720);
            sc.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight; sc.matchWidthOrHeight = 0.5f;
            cgo.AddComponent<GraphicRaycaster>();
            if (EventSystem.current == null) new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));

            // Safe Area (вырезы/«чёлки» телефонов)
            var safe = UIKit.Node("Safe", cgo.transform);
            var sa = Screen.safeArea;
            safe.anchorMin = new Vector2(sa.xMin / Screen.width, sa.yMin / Screen.height);
            safe.anchorMax = new Vector2(sa.xMax / Screen.width, sa.yMax / Screen.height);
            safe.offsetMin = safe.offsetMax = Vector2.zero;

            menu = new MainMenu(safe, this);
            hud = Hud.Create(safe, this);
            inventoryScreen = new InventoryScreen(safe, this);
            pause = new PauseScreen(safe, this);
            death = new DeathScreen(safe, this);
        }

        public void SetState(GameState s)
        {
            if (State == GameState.Inventory && s != GameState.Inventory) inventoryScreen.Close();
            State = s;
            Time.timeScale = s == GameState.Playing ? 1f : 0f;
            menu.Root.SetActive(s == GameState.Menu);
            hud.gameObject.SetActive(s == GameState.Playing);
            pause.Root.SetActive(s == GameState.Paused);
            death.Root.SetActive(s == GameState.Dead);
            inventoryScreen.Root.SetActive(s == GameState.Inventory);
            if (s == GameState.Inventory) inventoryScreen.Open();
        }

        public void StartGame(GameMode mode)
        {
            Cleanup();
            Mode = mode;
            var pgo = new GameObject("Player");
            pgo.transform.position = new Vector3(0.5f, 40f, 0.5f);
            Map = new GameObject("World").AddComponent<World>();
            Map.Init(Random.Range(1, 999999), RenderDistance, pgo.transform);

            Cam.transform.SetParent(pgo.transform, false);
            Cam.transform.localPosition = new Vector3(0, PlayerController.Eye, 0);
            Cam.transform.localRotation = Quaternion.identity;
            Cam.farClipPlane = Map.FogEnd + 48f;

            Inv = new Inventory(); Stats = new PlayerStats();
            if (Creative) Inv.FillCreativeHotbar();
            Player = pgo.AddComponent<PlayerController>();
            Player.Setup(this);
            Player.Teleport(Map.FindSpawn());
            hud.Bind(this);
            SetState(GameState.Playing);
        }

        public void ExitToMenu() { Cleanup(); SetState(GameState.Menu); }
        public void Pause() { if (State == GameState.Playing) SetState(GameState.Paused); }
        public void Resume() { if (State == GameState.Paused || State == GameState.Inventory) SetState(GameState.Playing); }
        public void OpenInventory() { if (State == GameState.Playing) SetState(GameState.Inventory); }
        public void CloseInventory() { Resume(); }
        public void OnPlayerDied() { if (State == GameState.Playing) SetState(GameState.Dead); }
        public void Respawn() { Stats.Reset(); Player.Teleport(Map.FindSpawn()); SetState(GameState.Playing); }

        void Cleanup()
        {
            Cam.transform.SetParent(null);
            Cam.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
            if (Player != null) Destroy(Player.gameObject);
            if (Map != null) Destroy(Map.gameObject);
            Player = null; Map = null; Inv = null; Stats = null;
            RenderSettings.fog = false;
        }

        void Update()
        {
            if (Kb.Down(KeyCode.Escape)) { if (State == GameState.Playing) Pause(); else Resume(); }
            if (Kb.Down(KeyCode.E)) { if (State == GameState.Playing) OpenInventory(); else if (State == GameState.Inventory) Resume(); }
        }

        void OnApplicationPause(bool paused) { if (paused) Pause(); }
    }
}
