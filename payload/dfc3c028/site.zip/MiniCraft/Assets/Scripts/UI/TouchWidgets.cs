using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace MiniCraft
{
    /// <summary>Виртуальный джойстик (левый нижний угол). Value — вектор −1..1.</summary>
    public class Joystick : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IDragHandler
    {
        const float Radius = 90f;
        public Vector2 Value { get; private set; }
        RectTransform rt, knob; int pid = int.MinValue;

        public static Joystick Create(Transform parent)
        {
            var r = UIKit.Node("Joystick", parent);
            r.anchorMin = r.anchorMax = Vector2.zero; r.pivot = new Vector2(.5f, .5f);
            r.anchoredPosition = new Vector2(200, 190); r.sizeDelta = new Vector2(250, 250);
            var img = r.gameObject.AddComponent<Image>(); img.sprite = UIKit.Circle; img.color = new Color(1, 1, 1, .22f);
            var k = UIKit.Node("Knob", r);
            k.anchorMin = k.anchorMax = k.pivot = new Vector2(.5f, .5f); k.sizeDelta = new Vector2(110, 110);
            var ki = k.gameObject.AddComponent<Image>(); ki.sprite = UIKit.Circle; ki.color = new Color(1, 1, 1, .55f); ki.raycastTarget = false;
            var j = r.gameObject.AddComponent<Joystick>(); j.rt = r; j.knob = k;
            return j;
        }

        void Apply(PointerEventData e)
        {
            Vector2 lp;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(rt, e.position, e.pressEventCamera, out lp);
            Value = Vector2.ClampMagnitude(lp / Radius, 1f);
            knob.anchoredPosition = Value * Radius;
        }

        public void OnPointerDown(PointerEventData e) { if (pid != int.MinValue) return; pid = e.pointerId; Apply(e); }
        public void OnDrag(PointerEventData e) { if (e.pointerId == pid) Apply(e); }
        public void OnPointerUp(PointerEventData e) { if (e.pointerId == pid) Reset(); }
        void OnDisable() { Reset(); }
        void Reset() { pid = int.MinValue; Value = Vector2.zero; if (knob != null) knob.anchoredPosition = Vector2.zero; }
    }

    /// <summary>Кнопка, которую можно удерживать (прыжок / «вниз» при полёте).</summary>
    public class HoldButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
    {
        public bool Held { get; private set; }
        public void OnPointerDown(PointerEventData e) { Held = true; }
        public void OnPointerUp(PointerEventData e) { Held = false; }
        void OnDisable() { Held = false; }
    }

    /// <summary>
    /// Прозрачная панель на весь экран. Свайп — поворот камеры; короткий тап — поставить блок/съесть;
    /// удержание без движения — ломать блок (как в Minecraft PE).
    /// </summary>
    public class LookPad : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IDragHandler
    {
        const float HoldTime = 0.28f, MoveThreshold = 24f;
        public PlayerController player;
        int pid = int.MinValue; bool moved, holding; float t0; Vector2 start;

        public void OnPointerDown(PointerEventData e)
        {
            if (pid != int.MinValue) return;
            pid = e.pointerId; moved = holding = false; t0 = Time.unscaledTime; start = e.position;
        }

        public void OnDrag(PointerEventData e)
        {
            if (e.pointerId != pid || player == null) return;
            player.Look(e.delta);
            if (!holding && (e.position - start).magnitude > MoveThreshold) moved = true;
        }

        public void OnPointerUp(PointerEventData e)
        {
            if (e.pointerId != pid) return;
            if (!moved && !holding && Time.unscaledTime - t0 < HoldTime && player != null && player.Interaction != null) player.Interaction.Place();
            Stop();
        }

        void Update()
        {
            if (pid != int.MinValue && !moved && !holding && player != null && player.Interaction != null && Time.unscaledTime - t0 >= HoldTime)
            { holding = true; player.Interaction.SetBreaking(true); }
        }

        void Stop()
        {
            if (holding && player != null && player.Interaction != null) player.Interaction.SetBreaking(false);
            pid = int.MinValue; holding = moved = false;
        }

        void OnDisable() { Stop(); }
    }
}
