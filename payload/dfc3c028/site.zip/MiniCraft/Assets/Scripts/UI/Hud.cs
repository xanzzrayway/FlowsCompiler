using UnityEngine;
using UnityEngine.UI;

namespace MiniCraft
{
    /// <summary>Игровой интерфейс: прицел, хотбар, здоровье/голод, джойстик, кнопки, отладочная информация.</summary>
    public class Hud : MonoBehaviour
    {
        static readonly Color HeartFull = new Color(.9f, .15f, .2f), HeartHalf = new Color(.6f, .2f, .25f),
            FoodFull = new Color(.9f, .6f, .15f), FoodHalf = new Color(.6f, .42f, .2f), Empty = new Color(.2f, .2f, .22f, .7f);

        GameManager gm;
        Joystick joystick; HoldButton jump, down; LookPad look;
        readonly SlotView[] hotbar = new SlotView[Inventory.Hotbar];
        readonly Image[] hearts = new Image[10], food = new Image[10];
        GameObject statsRow, breakBar, downPad, flyBtn, underwater, loading;
        RectTransform breakFill; Image flyImg; Text info;
        float fps = 60f, infoTimer;

        public static Hud Create(Transform parent, GameManager gm)
        {
            var h = UIKit.Stretch(UIKit.Node("HUD", parent)).gameObject.AddComponent<Hud>();
            h.Build(gm);
            return h;
        }

        void Build(GameManager g)
        {
            gm = g; var t = transform;
            look = UIKit.Fill(t, "LookPad", new Color(0, 0, 0, 0)).gameObject.AddComponent<LookPad>();
            underwater = UIKit.Fill(t, "Underwater", new Color(.1f, .3f, .8f, .35f), false).gameObject;
            UIKit.Box(t, "CrossH", new Color(1, 1, 1, .85f), UIKit.C, Vector2.zero, new Vector2(24, 3));
            UIKit.Box(t, "CrossV", new Color(1, 1, 1, .85f), UIKit.C, Vector2.zero, new Vector2(3, 24));

            var bar = UIKit.Box(t, "BreakBar", new Color(0, 0, 0, .6f), UIKit.C, new Vector2(0, -40), new Vector2(90, 9));
            breakBar = bar.gameObject;
            breakFill = UIKit.Place(UIKit.Node("Fill", bar.transform), new Vector2(0, .5f), Vector2.zero, new Vector2(90, 9));
            breakFill.gameObject.AddComponent<Image>().raycastTarget = false;

            loading = UIKit.Label(t, Strings.Loading, 36, UIKit.C, new Vector2(0, 120), new Vector2(700, 60)).gameObject;
            info = UIKit.Label(t, "", 22, UIKit.TL, new Vector2(12, -10), new Vector2(760, 110), TextAnchor.UpperLeft);

            // Здоровье (слева) и голод (справа) над хотбаром
            var row = UIKit.Place(UIKit.Node("Stats", t), UIKit.BC, new Vector2(0, 92), new Vector2(666, 26));
            statsRow = row.gameObject;
            for (int i = 0; i < 10; i++)
            {
                hearts[i] = UIKit.Box(row, "H" + i, HeartFull, new Vector2(0, .5f), new Vector2(i * 27, 0), new Vector2(24, 24));
                food[i] = UIKit.Box(row, "F" + i, FoodFull, new Vector2(1, .5f), new Vector2(-i * 27, 0), new Vector2(24, 24));
            }

            // Хотбар: 9 слотов, выбор тапом
            for (int i = 0; i < hotbar.Length; i++)
            {
                int idx = i;
                hotbar[i] = SlotView.Create(t, UIKit.BC, new Vector2((i - 4) * 74, 12), 70, () => gm.Inv.Select(idx));
            }

            // Управление
            joystick = Joystick.Create(t);
            jump = UIKit.Pad(t, Strings.Jump, UIKit.BR, new Vector2(-30, 40), 150).gameObject.AddComponent<HoldButton>();
            var dp = UIKit.Pad(t, Strings.Down, UIKit.BR, new Vector2(-200, 40), 110, 22);
            downPad = dp.gameObject; down = downPad.AddComponent<HoldButton>();
            var fb = UIKit.Btn(t, Strings.Fly, UIKit.BR, new Vector2(-30, 215), new Vector2(150, 56), () => gm.Player.ToggleFly(), 24);
            flyBtn = fb.gameObject; flyImg = fb.image;

            UIKit.Btn(t, "II", UIKit.TR, new Vector2(-12, -10), new Vector2(80, 64), gm.Pause, 30);
            UIKit.Btn(t, Strings.InvShort, UIKit.TR, new Vector2(-104, -10), new Vector2(110, 64), gm.OpenInventory, 26);
        }

        /// <summary>Вызывается при старте каждой новой игры.</summary>
        public void Bind(GameManager g)
        {
            gm = g;
            gm.Inv.Changed += RefreshHotbar;
            RefreshHotbar();
            gm.Player.SetControls(joystick, jump, down);
            look.player = gm.Player;
            statsRow.SetActive(!gm.Creative);
            flyBtn.SetActive(gm.Creative);
        }

        void RefreshHotbar()
        {
            for (int i = 0; i < hotbar.Length; i++) hotbar[i].Set(gm.Inv.Slots[i], i == gm.Inv.Selected, !gm.Creative);
        }

        void Update()
        {
            if (gm == null || gm.Player == null) return;
            var p = gm.Player;
            fps = Mathf.Lerp(fps, 1f / Mathf.Max(Time.unscaledDeltaTime, 0.0001f), 0.05f);
            infoTimer -= Time.unscaledDeltaTime;
            if (infoTimer <= 0f)
            {
                infoTimer = 0.3f; var pos = p.transform.position;
                info.text = (gm.Creative ? Strings.Creative : Strings.Survival) + "   FPS " + fps.ToString("0") +
                            "\nXYZ " + pos.x.ToString("0") + " " + pos.y.ToString("0") + " " + pos.z.ToString("0") +
                            "\nChunks " + gm.Map.LoadedChunks;
            }
            underwater.SetActive(p.HeadInWater);
            loading.SetActive(!p.IsReady);
            downPad.SetActive(p.Flying);
            if (flyImg != null) flyImg.color = p.Flying ? new Color(.25f, .55f, .9f, .96f) : UIKit.ButtonColor;

            float bp = p.Interaction != null ? p.Interaction.BreakProgress : 0f;
            breakBar.SetActive(bp > 0.01f);
            breakFill.sizeDelta = new Vector2(90f * bp, 9f);

            if (!gm.Creative && gm.Stats != null)
            {
                float h = gm.Stats.Health, f = gm.Stats.Hunger;
                for (int i = 0; i < 10; i++)
                {
                    hearts[i].color = h >= (i + 1) * 2 ? HeartFull : h >= i * 2 + 1 ? HeartHalf : Empty;
                    food[i].color = f >= (i + 1) * 2 ? FoodFull : f >= i * 2 + 1 ? FoodHalf : Empty;
                }
            }
        }
    }
}
