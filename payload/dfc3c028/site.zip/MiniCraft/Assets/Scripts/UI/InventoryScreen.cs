using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace MiniCraft
{
    /// <summary>
    /// Экран инвентаря. Выживание: рюкзак 27 слотов + хотбар (перенос в 2 касания) + список рецептов крафта.
    /// Креатив: палитра всех предметов (тап кладёт предмет в выбранный слот хотбара) + хотбар.
    /// </summary>
    public class InventoryScreen
    {
        const float Cell = 78f;
        public GameObject Root { get; }
        readonly GameManager gm; readonly RectTransform content;
        SlotView[] slots = new SlotView[Inventory.Size];
        readonly List<Image> recipeBg = new List<Image>();
        int moveFrom = -1;

        public InventoryScreen(Transform parent, GameManager gm)
        {
            this.gm = gm;
            var dim = UIKit.Fill(parent, "InventoryScreen", new Color(0, 0, 0, .65f));
            Root = dim.gameObject;
            var panel = UIKit.Box(dim.transform, "Panel", UIKit.PanelColor, UIKit.C, Vector2.zero, new Vector2(1080, 620), true);
            UIKit.Label(panel.transform, Strings.Inventory, 38, UIKit.TL, new Vector2(30, -16), new Vector2(500, 50), TextAnchor.MiddleLeft);
            UIKit.Btn(panel.transform, Strings.Close, UIKit.TR, new Vector2(-20, -16), new Vector2(150, 54), gm.CloseInventory, 26);
            content = UIKit.Node("Content", panel.transform);
            UIKit.Stretch(content);
        }

        public void Open()
        {
            for (int i = content.childCount - 1; i >= 0; i--) Object.Destroy(content.GetChild(i).gameObject);
            slots = new SlotView[Inventory.Size]; recipeBg.Clear(); moveFrom = -1;
            var inv = gm.Inv; bool cre = gm.Creative;
            var hint = new Color(.8f, .85f, 1f);

            UIKit.Label(content, cre ? Strings.Palette : Strings.Backpack, 26, UIKit.TL, new Vector2(30, -78), new Vector2(500, 34), TextAnchor.MiddleLeft, hint);
            if (cre)
            {
                var pal = Items.Palette;
                for (int k = 0; k < pal.Length; k++)
                {
                    ItemId id = pal[k];
                    var v = SlotView.Create(content, UIKit.TL, new Vector2(30 + (k % 9) * Cell, -(120 + (k / 9) * Cell)), 72, () => inv.Set(inv.Selected, id, 1));
                    v.Set(new ItemStack(id, 1), false, false);
                }
            }
            else
            {
                for (int i = 9; i < Inventory.Size; i++)
                {
                    int idx = i;
                    slots[i] = SlotView.Create(content, UIKit.TL, new Vector2(30 + ((i - 9) % 9) * Cell, -(120 + ((i - 9) / 9) * Cell)), 72, () => Tap(idx));
                }
            }
            float hy = -(120 + 3 * Cell + 18);
            for (int i = 0; i < Inventory.Hotbar; i++)
            {
                int idx = i;
                slots[i] = SlotView.Create(content, UIKit.TL, new Vector2(30 + i * Cell, hy), 72, () => Tap(idx));
            }

            float rx = 30 + 9 * Cell + 20;
            if (cre)
            {
                UIKit.Label(content, Strings.CreativeHint, 22, UIKit.TL, new Vector2(rx, -120), new Vector2(290, 220), TextAnchor.UpperLeft, new Color(.8f, .8f, .85f));
            }
            else
            {
                UIKit.Label(content, Strings.Crafting, 26, UIKit.TL, new Vector2(rx, -78), new Vector2(290, 34), TextAnchor.MiddleLeft, hint);
                for (int n = 0; n < Recipes.All.Length; n++)
                {
                    var r = Recipes.All[n]; var res = Items.Get(r.Result);
                    var b = UIKit.Btn(content, null, UIKit.TL, new Vector2(rx, -(120 + n * 98)), new Vector2(298, 90), () => r.Craft(inv));
                    recipeBg.Add(b.image);
                    var ic = UIKit.Box(b.transform, "Icon", Color.white, UIKit.ML, new Vector2(10, 0), new Vector2(60, 60));
                    ic.sprite = Atlas.Icon(res.Icon); ic.preserveAspect = true;
                    UIKit.Label(b.transform, res.Name + " ×" + r.Count, 21, UIKit.ML, new Vector2(80, 17), new Vector2(210, 30), TextAnchor.MiddleLeft);
                    UIKit.Label(b.transform, r.Describe(), 17, UIKit.ML, new Vector2(80, -17), new Vector2(210, 40), TextAnchor.UpperLeft, new Color(.85f, .85f, .85f));
                }
            }
            inv.Changed -= Refresh; inv.Changed += Refresh;
            Refresh();
        }

        public void Close() { if (gm.Inv != null) gm.Inv.Changed -= Refresh; }

        void Tap(int i)
        {
            var inv = gm.Inv;
            if (gm.Creative) { if (i < Inventory.Hotbar) inv.Select(i); return; }
            if (moveFrom < 0) { if (!inv.Slots[i].IsEmpty) moveFrom = i; if (i < Inventory.Hotbar) inv.Selected = i; Refresh(); }
            else if (moveFrom == i) { moveFrom = -1; Refresh(); }
            else { int f = moveFrom; moveFrom = -1; inv.Swap(f, i); }
        }

        void Refresh()
        {
            var inv = gm.Inv; bool cre = gm.Creative;
            for (int i = 0; i < Inventory.Size; i++)
                if (slots[i] != null) slots[i].Set(inv.Slots[i], i == moveFrom || (i < Inventory.Hotbar && i == inv.Selected), !cre);
            for (int n = 0; n < recipeBg.Count; n++)
                recipeBg[n].color = Recipes.All[n].CanCraft(inv) ? new Color(.2f, .5f, .28f, .96f) : new Color(.22f, .22f, .26f, .96f);
        }
    }
}
