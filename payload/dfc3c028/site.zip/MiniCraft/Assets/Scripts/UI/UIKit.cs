using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace MiniCraft
{
    /// <summary>Мини-библиотека для построения uGUI из кода (никаких префабов и ручной настройки сцены).</summary>
    public static class UIKit
    {
        public static readonly Vector2 TL = new Vector2(0, 1), TC = new Vector2(.5f, 1), TR = new Vector2(1, 1),
            ML = new Vector2(0, .5f), C = new Vector2(.5f, .5f), BL = Vector2.zero, BC = new Vector2(.5f, 0), BR = new Vector2(1, 0);
        public static readonly Color PanelColor = new Color(.09f, .1f, .13f, .96f), ButtonColor = new Color(.28f, .3f, .38f, .96f), Glass = new Color(1, 1, 1, .22f);

        static Font font; static Sprite circle;

        public static Font Font
        {
            get
            {
                if (font == null)
#if UNITY_2022_2_OR_NEWER
                    font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
                    font = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
                return font;
            }
        }

        public static Sprite Circle
        {
            get
            {
                if (circle != null) return circle;
                const int n = 64;
                var tex = new Texture2D(n, n, TextureFormat.RGBA32, false) { filterMode = FilterMode.Bilinear };
                var px = new Color32[n * n];
                for (int y = 0; y < n; y++) for (int x = 0; x < n; x++)
                {
                    float d = Vector2.Distance(new Vector2(x + .5f, y + .5f), new Vector2(n / 2f, n / 2f));
                    px[y * n + x] = new Color32(255, 255, 255, (byte)(Mathf.Clamp01(n / 2f - d) * 255));
                }
                tex.SetPixels32(px); tex.Apply();
                return circle = Sprite.Create(tex, new Rect(0, 0, n, n), new Vector2(.5f, .5f), 100);
            }
        }

        public static RectTransform Node(string name, Transform parent)
        {
            var rt = new GameObject(name, typeof(RectTransform)).GetComponent<RectTransform>();
            rt.SetParent(parent, false);
            return rt;
        }

        /// <summary>Якорь = точка привязки = pivot; pos — смещение от якоря.</summary>
        public static RectTransform Place(RectTransform rt, Vector2 anchor, Vector2 pos, Vector2 size)
        {
            rt.anchorMin = rt.anchorMax = rt.pivot = anchor; rt.anchoredPosition = pos; rt.sizeDelta = size; return rt;
        }

        public static RectTransform Stretch(RectTransform rt)
        {
            rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.offsetMin = rt.offsetMax = Vector2.zero; return rt;
        }

        public static Image Box(Transform parent, string name, Color c, Vector2 anchor, Vector2 pos, Vector2 size, bool raycast = false)
        {
            var im = Place(Node(name, parent), anchor, pos, size).gameObject.AddComponent<Image>();
            im.color = c; im.raycastTarget = raycast; return im;
        }

        public static Image Fill(Transform parent, string name, Color c, bool raycast = true)
        {
            var im = Stretch(Node(name, parent)).gameObject.AddComponent<Image>();
            im.color = c; im.raycastTarget = raycast; return im;
        }

        public static Text Label(Transform parent, string s, int size, Vector2 anchor, Vector2 pos, Vector2 box,
                                 TextAnchor align = TextAnchor.MiddleCenter, Color? col = null)
        {
            var t = Place(Node("Label", parent), anchor, pos, box).gameObject.AddComponent<Text>();
            t.font = Font; t.text = s; t.fontSize = size; t.alignment = align; t.color = col ?? Color.white;
            t.raycastTarget = false; t.horizontalOverflow = HorizontalWrapMode.Wrap; t.verticalOverflow = VerticalWrapMode.Overflow;
            return t;
        }

        public static Button Btn(Transform parent, string text, Vector2 anchor, Vector2 pos, Vector2 size, UnityAction onClick, int fs = 30, Color? col = null)
        {
            var im = Box(parent, "Button", col ?? ButtonColor, anchor, pos, size, true);
            var b = im.gameObject.AddComponent<Button>(); b.targetGraphic = im;
            if (onClick != null) b.onClick.AddListener(onClick);
            if (!string.IsNullOrEmpty(text)) Stretch(Label(im.transform, text, fs, C, Vector2.zero, Vector2.zero).rectTransform);
            return b;
        }

        /// <summary>Круглая полупрозрачная кнопка (для удержания: прыжок, «вниз»).</summary>
        public static Image Pad(Transform parent, string text, Vector2 anchor, Vector2 pos, float size, int fs = 26)
        {
            var im = Box(parent, "Pad", Glass, anchor, pos, new Vector2(size, size), true);
            im.sprite = Circle;
            Stretch(Label(im.transform, text, fs, C, Vector2.zero, Vector2.zero).rectTransform);
            return im;
        }
    }

    /// <summary>Ячейка предмета (используется и в хотбаре HUD, и в инвентаре).</summary>
    public class SlotView
    {
        static readonly Color Normal = new Color(.12f, .12f, .15f, .9f), Highlight = new Color(.75f, .75f, .85f, .95f);
        Image bg, icon; Text count;

        public static SlotView Create(Transform parent, Vector2 anchor, Vector2 pos, float size, UnityAction onClick)
        {
            var v = new SlotView();
            v.bg = UIKit.Box(parent, "Slot", Normal, anchor, pos, new Vector2(size, size), true);
            var b = v.bg.gameObject.AddComponent<Button>(); b.targetGraphic = v.bg;
            if (onClick != null) b.onClick.AddListener(onClick);
            v.icon = UIKit.Box(v.bg.transform, "Icon", Color.white, UIKit.C, Vector2.zero, new Vector2(size - 14, size - 14));
            v.icon.preserveAspect = true;
            v.count = UIKit.Label(v.bg.transform, "", 22, UIKit.BR, new Vector2(-4, 4), new Vector2(size - 8, 28), TextAnchor.LowerRight);
            v.count.gameObject.AddComponent<Shadow>();
            return v;
        }

        public void Set(ItemStack s, bool highlight, bool showCount)
        {
            bg.color = highlight ? Highlight : Normal;
            icon.enabled = !s.IsEmpty;
            if (!s.IsEmpty) icon.sprite = Atlas.Icon(Items.Get(s.id).Icon);
            count.text = showCount && s.count > 1 ? s.count.ToString() : "";
        }
    }
}
