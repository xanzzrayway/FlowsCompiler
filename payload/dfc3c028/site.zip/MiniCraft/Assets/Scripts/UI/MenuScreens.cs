using UnityEngine;

namespace MiniCraft
{
    /// <summary>Главное меню: выбор режима и дальности прорисовки.</summary>
    public class MainMenu
    {
        static readonly int[] Distances = { 3, 4, 6 };
        public GameObject Root { get; }

        public MainMenu(Transform parent, GameManager gm)
        {
            var bg = UIKit.Fill(parent, "MainMenu", new Color(.06f, .09f, .16f, .88f));
            Root = bg.gameObject; var t = bg.transform;
            UIKit.Label(t, Strings.Title, 96, UIKit.TC, new Vector2(0, -60), new Vector2(900, 120));
            UIKit.Label(t, Strings.Subtitle, 28, UIKit.TC, new Vector2(0, -180), new Vector2(900, 40), TextAnchor.MiddleCenter, new Color(.7f, .8f, 1f));
            UIKit.Btn(t, Strings.Survival, UIKit.C, new Vector2(0, 40), new Vector2(460, 90), () => gm.StartGame(GameMode.Survival), 38, new Color(.2f, .5f, .25f, .97f));
            UIKit.Btn(t, Strings.Creative, UIKit.C, new Vector2(0, -70), new Vector2(460, 90), () => gm.StartGame(GameMode.Creative), 38, new Color(.2f, .4f, .75f, .97f));

            var dist = UIKit.Btn(t, null, UIKit.C, new Vector2(0, -170), new Vector2(460, 66), null);
            var lbl = UIKit.Label(dist.transform, "", 26, UIKit.C, Vector2.zero, Vector2.zero);
            UIKit.Stretch(lbl.rectTransform);
            int di = 1;
            void Refresh() { gm.RenderDistance = Distances[di]; lbl.text = Strings.RenderDist + ": " + Distances[di]; }
            dist.onClick.AddListener(() => { di = (di + 1) % Distances.Length; Refresh(); });
            Refresh();

            UIKit.Btn(t, Strings.Quit, UIKit.C, new Vector2(0, -250), new Vector2(460, 60), Application.Quit, 24);
        }
    }

    public class PauseScreen
    {
        public GameObject Root { get; }
        public PauseScreen(Transform parent, GameManager gm)
        {
            var dim = UIKit.Fill(parent, "Pause", new Color(0, 0, 0, .6f));
            Root = dim.gameObject;
            var p = UIKit.Box(dim.transform, "Panel", UIKit.PanelColor, UIKit.C, Vector2.zero, new Vector2(520, 380), true);
            UIKit.Label(p.transform, Strings.Paused, 46, UIKit.TC, new Vector2(0, -30), new Vector2(400, 60));
            UIKit.Btn(p.transform, Strings.Resume, UIKit.C, new Vector2(0, 20), new Vector2(400, 80), gm.Resume, 32);
            UIKit.Btn(p.transform, Strings.ToMenu, UIKit.C, new Vector2(0, -90), new Vector2(400, 80), gm.ExitToMenu, 30);
        }
    }

    public class DeathScreen
    {
        public GameObject Root { get; }
        public DeathScreen(Transform parent, GameManager gm)
        {
            var dim = UIKit.Fill(parent, "Death", new Color(.45f, 0, 0, .6f));
            Root = dim.gameObject;
            UIKit.Label(dim.transform, Strings.Dead, 70, UIKit.C, new Vector2(0, 120), new Vector2(900, 100));
            UIKit.Btn(dim.transform, Strings.Respawn, UIKit.C, new Vector2(0, 0), new Vector2(400, 80), gm.Respawn, 32, new Color(.2f, .5f, .25f, .97f));
            UIKit.Btn(dim.transform, Strings.ToMenu, UIKit.C, new Vector2(0, -100), new Vector2(400, 70), gm.ExitToMenu, 28);
        }
    }
}
