#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace MiniCraft.EditorTools
{
    /// <summary>
    /// Сборка APK в один клик: меню MiniCraft → Build Android APK.
    /// Сама создаёт пустую сцену, ставит настройки (IL2CPP, ARM64, API 24, альбомная ориентация).
    /// Из командной строки: Unity -batchmode -quit -projectPath . -executeMethod MiniCraft.EditorTools.BuildAndroid.BuildApk
    /// </summary>
    public static class BuildAndroid
    {
        const string ScenePath = "Assets/Scenes/Main.unity";

        [MenuItem("MiniCraft/Build Android APK")]
        public static void BuildApk()
        {
            Configure();
            string path = OutputPath();
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions
            {
                scenes = new[] { ScenePath }, locationPathName = path,
                target = BuildTarget.Android, targetGroup = BuildTargetGroup.Android, options = BuildOptions.None
            });
            bool ok = report.summary.result == BuildResult.Succeeded;
            Debug.Log(ok ? "APK готов: " + path + " (" + report.summary.totalSize / (1024 * 1024) + " МБ)" : "Сборка не удалась: " + report.summary.result);
            if (Application.isBatchMode) EditorApplication.Exit(ok ? 0 : 1);
            else if (ok) EditorUtility.RevealInFinder(path);
        }

        static void Configure()
        {
            if (!File.Exists(ScenePath))
            {
                Directory.CreateDirectory("Assets/Scenes");
                var s = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                EditorSceneManager.SaveScene(s, ScenePath);   // игра создаёт всё сама (Bootstrap), сцена может быть пустой
            }
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };

            PlayerSettings.companyName = "MiniCraft";
            PlayerSettings.productName = "MiniCraft";
            PlayerSettings.bundleVersion = "0.1.0";
            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "com.minicraft.game");
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.AutoRotation;
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.allowedAutorotateToLandscapeLeft = true;
            PlayerSettings.allowedAutorotateToLandscapeRight = true;
            EditorUserBuildSettings.buildAppBundle = false;   // нужен именно .apk, а не .aab
        }

        static string OutputPath()
        {
            var a = System.Environment.GetCommandLineArgs();   // game-ci передаёт -customBuildPath
            for (int i = 0; i < a.Length - 1; i++)
                if (a[i] == "-customBuildPath") return a[i + 1].EndsWith(".apk") ? a[i + 1] : Path.Combine(a[i + 1], "MiniCraft.apk");
            return "Builds/MiniCraft.apk";
        }
    }
}
#endif
