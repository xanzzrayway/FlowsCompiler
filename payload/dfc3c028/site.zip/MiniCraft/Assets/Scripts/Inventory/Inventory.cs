using UnityEngine;

namespace MiniCraft
{
    public struct ItemStack
    {
        public ItemId id; public int count;
        public ItemStack(ItemId id, int count) { this.id = id; this.count = count; }
        public bool IsEmpty => id == ItemId.None || count <= 0;
    }

    /// <summary>36 слотов: 0–8 — хотбар, 9–35 — рюкзак. UI подписывается на Changed.</summary>
    public class Inventory
    {
        public const int Size = 36, Hotbar = 9;
        public readonly ItemStack[] Slots = new ItemStack[Size];
        public int Selected;
        public event System.Action Changed;

        public ItemStack Held => Slots[Selected];
        public void Notify() { Changed?.Invoke(); }
        public void Select(int i) { Selected = Mathf.Clamp(i, 0, Hotbar - 1); Notify(); }

        /// <summary>Добавляет предметы, возвращает сколько не поместилось.</summary>
        public int Add(ItemId id, int n)
        {
            int max = Items.Get(id).MaxStack;
            for (int i = 0; i < Size && n > 0; i++)
                if (Slots[i].id == id && Slots[i].count < max) { int a = Mathf.Min(n, max - Slots[i].count); Slots[i].count += a; n -= a; }
            for (int i = 0; i < Size && n > 0; i++)
                if (Slots[i].IsEmpty) { int a = Mathf.Min(n, max); Slots[i] = new ItemStack(id, a); n -= a; }
            Notify();
            return n;
        }

        public int Count(ItemId id) { int c = 0; foreach (var s in Slots) if (s.id == id) c += s.count; return c; }

        public int Room(ItemId id)
        {
            int max = Items.Get(id).MaxStack, r = 0;
            foreach (var s in Slots) { if (s.IsEmpty) r += max; else if (s.id == id) r += max - s.count; }
            return r;
        }

        public bool Take(ItemId id, int n)
        {
            if (Count(id) < n) return false;
            for (int i = Size - 1; i >= 0 && n > 0; i--)
                if (Slots[i].id == id)
                {
                    int a = Mathf.Min(n, Slots[i].count);
                    Slots[i].count -= a; n -= a;
                    if (Slots[i].count <= 0) Slots[i] = default;
                }
            Notify();
            return true;
        }

        public void ConsumeSelected()
        {
            Slots[Selected].count--;
            if (Slots[Selected].count <= 0) Slots[Selected] = default;
            Notify();
        }

        public void Set(int slot, ItemId id, int n) { Slots[slot] = new ItemStack(id, n); Notify(); }

        /// <summary>Перенос/обмен/слияние стопок между двумя слотами.</summary>
        public void Swap(int a, int b)
        {
            if (a == b) return;
            if (!Slots[a].IsEmpty && Slots[a].id == Slots[b].id)
            {
                int m = Mathf.Min(Slots[a].count, Items.Get(Slots[a].id).MaxStack - Slots[b].count);
                Slots[b].count += m; Slots[a].count -= m;
                if (Slots[a].count <= 0) Slots[a] = default;
            }
            else { var t = Slots[a]; Slots[a] = Slots[b]; Slots[b] = t; }
            Notify();
        }

        public void FillCreativeHotbar()
        {
            ItemId[] f = { ItemId.Grass, ItemId.Dirt, ItemId.Stone, ItemId.Sand, ItemId.Log, ItemId.Leaves, ItemId.Planks, ItemId.Cobble, ItemId.Water };
            for (int i = 0; i < f.Length; i++) Slots[i] = new ItemStack(f[i], 1);
        }
    }
}
