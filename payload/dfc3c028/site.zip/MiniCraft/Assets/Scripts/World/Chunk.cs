using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace MiniCraft
{
    /// <summary>Чанк 16×64×16: данные блоков + меш (непрозрачный и водный сабмеши). Отрисовывает только видимые грани.</summary>
    public class Chunk
    {
        public const int S = 16, H = 64;
        public readonly int cx, cz;
        public readonly byte[] blocks = new byte[S * S * H];
        public int maxY;
        public bool modified;           // игрок менял блоки → данные не выбрасываем при выгрузке
        public bool needsMesh = true;

        readonly World world;
        GameObject go; Mesh mesh;

        public Chunk(World w, int cx, int cz)
        {
            world = w; this.cx = cx; this.cz = cz;
            TerrainGenerator.Fill(blocks, cx, cz, out maxY);
        }

        public static int Idx(int x, int y, int z) => x + z * S + y * S * S;

        byte Get(int x, int y, int z)
        {
            if (y < 0) return Block.Stone;
            if (y >= H) return Block.Air;
            if ((uint)x < S && (uint)z < S) return blocks[x + z * S + y * S * S];
            return world.GetBlock(cx * S + x, y, cz * S + z);
        }

        // ---- Построение меша ----
        static readonly List<Vector3> vs = new List<Vector3>();
        static readonly List<Vector2> uvs = new List<Vector2>();
        static readonly List<Color32> cols = new List<Color32>();
        static readonly List<int> triO = new List<int>(), triW = new List<int>();

        // Грани: 0:+X 1:-X 2:+Y 3:-Y 4:+Z 5:-Z; вершины заданы по часовой стрелке (лицевая сторона Unity)
        static readonly int[] DX = { 1, -1, 0, 0, 0, 0 }, DY = { 0, 0, 1, -1, 0, 0 }, DZ = { 0, 0, 0, 0, 1, -1 };
        static readonly Vector3[] FV =
        {
            new Vector3(1,0,0), new Vector3(1,1,0), new Vector3(1,1,1), new Vector3(1,0,1),
            new Vector3(0,0,1), new Vector3(0,1,1), new Vector3(0,1,0), new Vector3(0,0,0),
            new Vector3(0,1,0), new Vector3(0,1,1), new Vector3(1,1,1), new Vector3(1,1,0),
            new Vector3(0,0,0), new Vector3(1,0,0), new Vector3(1,0,1), new Vector3(0,0,1),
            new Vector3(1,0,1), new Vector3(1,1,1), new Vector3(0,1,1), new Vector3(0,0,1),
            new Vector3(0,0,0), new Vector3(0,1,0), new Vector3(1,1,0), new Vector3(1,0,0),
        };
        static Color32 Sh(float v) { byte b = (byte)(v * 255); return new Color32(b, b, b, 255); }
        static readonly Color32[] Shade = { Sh(.6f), Sh(.6f), Sh(1f), Sh(.5f), Sh(.8f), Sh(.8f) };

        public void BuildMesh()
        {
            needsMesh = false;
            vs.Clear(); uvs.Clear(); cols.Clear(); triO.Clear(); triW.Clear();
            int top = Mathf.Min(maxY, H - 1);
            for (int y = 0; y <= top; y++)
            for (int z = 0; z < S; z++)
            for (int x = 0; x < S; x++)
            {
                byte b = blocks[x + z * S + y * S * S];
                if (b == Block.Air) continue;
                var info = Items.Get(b);
                for (int f = 0; f < 6; f++)
                {
                    byte n = Get(x + DX[f], y + DY[f], z + DZ[f]);
                    if (Items.OpaqueTbl[n] || (n == b && !info.Opaque)) continue;   // грань скрыта
                    int tile = f == 2 ? info.Top : f == 3 ? info.Bottom : info.Side;
                    AddFace(f, x, y, z, tile, b == Block.Water ? triW : triO);
                }
            }
            Apply();
        }

        static void AddFace(int f, int x, int y, int z, int tile, List<int> tris)
        {
            int i = vs.Count;
            for (int k = 0; k < 4; k++)
            {
                var o = FV[f * 4 + k];
                vs.Add(new Vector3(x + o.x, y + o.y, z + o.z));
                cols.Add(Shade[f]);
            }
            float u0, v0, u1, v1; Atlas.Uv(tile, out u0, out v0, out u1, out v1);
            uvs.Add(new Vector2(u0, v0)); uvs.Add(new Vector2(u0, v1)); uvs.Add(new Vector2(u1, v1)); uvs.Add(new Vector2(u1, v0));
            tris.Add(i); tris.Add(i + 1); tris.Add(i + 2); tris.Add(i); tris.Add(i + 2); tris.Add(i + 3);
        }

        void Apply()
        {
            if (vs.Count == 0) { if (mesh != null) mesh.Clear(); return; }
            if (go == null)
            {
                go = new GameObject("Chunk " + cx + "," + cz);
                go.transform.SetParent(world.transform, false);
                go.transform.localPosition = new Vector3(cx * S, 0, cz * S);
                mesh = new Mesh { name = "ChunkMesh" };
                go.AddComponent<MeshFilter>().sharedMesh = mesh;
                var mr = go.AddComponent<MeshRenderer>();
                mr.sharedMaterials = new[] { world.OpaqueMat, world.WaterMat };
                mr.shadowCastingMode = ShadowCastingMode.Off; mr.receiveShadows = false;
            }
            mesh.Clear();
            mesh.indexFormat = vs.Count > 65000 ? IndexFormat.UInt32 : IndexFormat.UInt16;
            mesh.SetVertices(vs); mesh.SetUVs(0, uvs); mesh.SetColors(cols);
            mesh.subMeshCount = 2;
            mesh.SetTriangles(triO, 0); mesh.SetTriangles(triW, 1);
            mesh.RecalculateBounds();
        }

        public void DestroyMesh()
        {
            if (go != null) { Object.Destroy(mesh); Object.Destroy(go); go = null; mesh = null; }
            needsMesh = true;
        }
    }
}
