using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace MiniCraft
{
    /// <summary>
    /// Бесконечный мир. Каждый кадр: догенерирует данные чанков вокруг игрока (по возрастанию расстояния),
    /// строит меши (только когда готовы данные 4 соседей), раз в секунду выгружает далёкие чанки.
    /// Изменённые игроком чанки хранят данные в памяти даже после выгрузки меша.
    /// </summary>
    public class World : MonoBehaviour
    {
        public const int CS = Chunk.S, CH = Chunk.H;
        public static readonly Color SkyColor = new Color(.53f, .74f, .93f);

        public Material OpaqueMat { get; private set; }
        public Material WaterMat { get; private set; }
        public int RenderDistance { get; private set; }
        public float FogEnd => RenderDistance * CS - 6f;
        public int LoadedChunks => chunks.Count;

        readonly Dictionary<long, Chunk> chunks = new Dictionary<long, Chunk>();
        readonly List<long> removeBuf = new List<long>();
        Vector2Int[] offsets;
        Transform target;
        float unloadTimer;

        static long Key(int cx, int cz) => ((long)cx << 32) ^ (long)(uint)cz;

        public void Init(int seed, int renderDistance, Transform followTarget)
        {
            TerrainGenerator.SetSeed(seed);
            Atlas.Build();
            RenderDistance = renderDistance; target = followTarget;
            OpaqueMat = MakeMaterial(false); WaterMat = MakeMaterial(true);

            RenderSettings.fog = true; RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogColor = SkyColor;
            RenderSettings.fogEndDistance = FogEnd; RenderSettings.fogStartDistance = FogEnd * .55f;

            var l = new List<Vector2Int>(); int r = RenderDistance + 1;
            for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) if (dx * dx + dz * dz <= r * r) l.Add(new Vector2Int(dx, dz));
            l.Sort((a, b) => a.sqrMagnitude.CompareTo(b.sqrMagnitude));
            offsets = l.ToArray();

            Stream(100000, 9);   // стартовый мир: данные сразу, меши ближайших чанков
        }

        Material MakeMaterial(bool water)
        {
            var sh = Resources.Load<Shader>("MiniCraftVoxel");
            if (sh == null) sh = Shader.Find("MiniCraft/Voxel");
            if (sh == null) sh = Shader.Find("Unlit/Texture");
            var m = new Material(sh) { mainTexture = Atlas.Texture, name = water ? "Water" : "Opaque" };
            if (water)
            {
                m.SetFloat("_SrcBlend", (float)BlendMode.SrcAlpha); m.SetFloat("_DstBlend", (float)BlendMode.OneMinusSrcAlpha);
                m.SetFloat("_ZWrite", 0f); m.SetFloat("_Cull", 0f); m.SetFloat("_Cutoff", 0f);
                m.renderQueue = 3000;
            }
            return m;
        }

        void Update()
        {
            if (target == null) return;
            Stream(2, 1);
            unloadTimer += Time.unscaledDeltaTime;
            if (unloadTimer > 1f) { unloadTimer = 0; Unload(); }
        }

        Vector2Int CenterChunk() => new Vector2Int(Mathf.FloorToInt(target.position.x) >> 4, Mathf.FloorToInt(target.position.z) >> 4);

        void Stream(int genBudget, int meshBudget)
        {
            var c = CenterChunk();
            foreach (var o in offsets)
            {
                long k = Key(c.x + o.x, c.y + o.y);
                if (genBudget > 0 && !chunks.ContainsKey(k)) { chunks[k] = new Chunk(this, c.x + o.x, c.y + o.y); genBudget--; }
            }
            int rr = RenderDistance * RenderDistance;
            foreach (var o in offsets)
            {
                if (o.sqrMagnitude > rr) break;
                if (meshBudget <= 0) break;
                int cx = c.x + o.x, cz = c.y + o.y;
                if (chunks.TryGetValue(Key(cx, cz), out var ch) && ch.needsMesh && NeighborsReady(cx, cz)) { ch.BuildMesh(); meshBudget--; }
            }
        }

        bool NeighborsReady(int cx, int cz) =>
            chunks.ContainsKey(Key(cx + 1, cz)) && chunks.ContainsKey(Key(cx - 1, cz)) &&
            chunks.ContainsKey(Key(cx, cz + 1)) && chunks.ContainsKey(Key(cx, cz - 1));

        void Unload()
        {
            var c = CenterChunk(); int lim = (RenderDistance + 2) * (RenderDistance + 2);
            removeBuf.Clear();
            foreach (var kv in chunks)
            {
                int dx = kv.Value.cx - c.x, dz = kv.Value.cz - c.y;
                if (dx * dx + dz * dz <= lim) continue;
                kv.Value.DestroyMesh();
                if (!kv.Value.modified) removeBuf.Add(kv.Key);
            }
            foreach (var k in removeBuf) chunks.Remove(k);
        }

        // ---- Доступ к блокам (мировые координаты) ----
        public bool IsLoaded(int x, int z) => chunks.ContainsKey(Key(x >> 4, z >> 4));

        public byte GetBlock(int x, int y, int z)
        {
            if (y < 0) return Block.Stone;
            if (y >= CH) return Block.Air;
            return chunks.TryGetValue(Key(x >> 4, z >> 4), out var c) ? c.blocks[Chunk.Idx(x & 15, y, z & 15)] : Block.Air;
        }

        public void SetBlock(int x, int y, int z, byte id)
        {
            if (y < 0 || y >= CH) return;
            int cx = x >> 4, cz = z >> 4, lx = x & 15, lz = z & 15;
            if (!chunks.TryGetValue(Key(cx, cz), out var c)) return;
            c.blocks[Chunk.Idx(lx, y, lz)] = id;
            c.modified = true;
            if (id != Block.Air && y > c.maxY) c.maxY = y;
            c.BuildMesh();
            if (lx == 0) Remesh(cx - 1, cz);
            if (lx == 15) Remesh(cx + 1, cz);
            if (lz == 0) Remesh(cx, cz - 1);
            if (lz == 15) Remesh(cx, cz + 1);
        }

        void Remesh(int cx, int cz) { if (chunks.TryGetValue(Key(cx, cz), out var n) && !n.needsMesh) n.BuildMesh(); }

        /// <summary>Ищет место для спавна: ближайшая к (0,0) суша без дерева над головой.</summary>
        public Vector3 FindSpawn()
        {
            for (int r = 0; r < 40; r++)
            for (int dx = -r; dx <= r; dx++)
            for (int dz = -r; dz <= r; dz++)
            {
                if (Mathf.Max(Mathf.Abs(dx), Mathf.Abs(dz)) != r) continue;
                int h = TerrainGenerator.Height(dx, dz);
                if (h <= TerrainGenerator.SeaLevel + 1) continue;
                if (GetBlock(dx, h + 1, dz) != Block.Air || GetBlock(dx, h + 2, dz) != Block.Air) continue;
                return new Vector3(dx + .5f, h + 1.01f, dz + .5f);
            }
            return new Vector3(.5f, TerrainGenerator.SeaLevel + 3, .5f);
        }

        void OnDestroy()
        {
            foreach (var c in chunks.Values) c.DestroyMesh();
            if (OpaqueMat) Destroy(OpaqueMat);
            if (WaterMat) Destroy(WaterMat);
            RenderSettings.fog = false;
        }
    }
}
