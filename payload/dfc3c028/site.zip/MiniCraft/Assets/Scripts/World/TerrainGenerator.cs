using UnityEngine;

namespace MiniCraft
{
    /// <summary>
    /// Процедурная генерация. Всё детерминировано по (seed, x, z), поэтому:
    ///  • чанки можно выгружать и генерировать заново без потерь;
    ///  • деревья на границах чанков стыкуются без швов (каждый чанк сам досчитывает соседние деревья).
    /// </summary>
    public static class TerrainGenerator
    {
        public const int SeaLevel = 24;
        public static int Seed { get; private set; }
        static float ox, oz;

        public static void SetSeed(int seed)
        {
            Seed = seed;
            var r = new System.Random(seed);
            ox = r.Next(0, 100000) + 0.37f; oz = r.Next(0, 100000) + 0.61f;
        }

        static float Fbm(float x, float z, float freq, int octaves)
        {
            float sum = 0, amp = 1, norm = 0;
            for (int i = 0; i < octaves; i++)
            {
                sum += Mathf.PerlinNoise(x * freq + ox, z * freq + oz) * amp;
                norm += amp; amp *= .5f; freq *= 2f;
            }
            return sum / norm;
        }

        /// <summary>Высота поверхности (Y верхнего блока суши/дна) в мировой колонке.</summary>
        public static int Height(int x, int z)
        {
            float a = Fbm(x, z, 0.005f, 3);   // материки/океаны
            float b = Fbm(x, z, 0.035f, 3);   // холмы
            float h = SeaLevel + 3f + (a - .5f) * 60f + (b - .5f) * 14f;
            return Mathf.Clamp(Mathf.RoundToInt(h), 4, Chunk.H - 14);
        }

        static uint Hash(int x, int z)
        {
            unchecked
            {
                uint h = (uint)(x * 374761393) ^ (uint)(z * 668265263) ^ (uint)(Seed * 362437);
                h ^= h >> 13; h *= 1274126177u; h ^= h >> 16;
                return h;
            }
        }

        public static void Fill(byte[] blocks, int cx, int cz, out int maxY)
        {
            const int S = Chunk.S;
            int x0 = cx * S, z0 = cz * S;
            maxY = 0;

            // 1) Ландшафт: камень → земля → трава/песок, вода до уровня моря
            for (int lz = 0; lz < S; lz++)
            for (int lx = 0; lx < S; lx++)
            {
                int h = Height(x0 + lx, z0 + lz);
                bool beach = h <= SeaLevel + 1;
                for (int y = 0; y <= h; y++)
                {
                    byte b = y == h ? (beach ? Block.Sand : Block.Grass)
                           : y >= h - 3 ? (beach ? Block.Sand : Block.Dirt) : Block.Stone;
                    blocks[Chunk.Idx(lx, y, lz)] = b;
                }
                for (int y = h + 1; y <= SeaLevel; y++) blocks[Chunk.Idx(lx, y, lz)] = Block.Water;
                maxY = Mathf.Max(maxY, Mathf.Max(h, SeaLevel));
            }

            // 2) Деревья: проверяем колонки с запасом 2 блока вокруг чанка (радиус кроны)
            for (int wx = x0 - 2; wx < x0 + S + 2; wx++)
            for (int wz = z0 - 2; wz < z0 + S + 2; wz++)
            {
                uint hs = Hash(wx, wz);
                if (hs % 1000 >= 12) continue;                  // ~1.2% колонок
                int h = Height(wx, wz);
                if (h <= SeaLevel + 1) continue;                // только на траве
                int th = 4 + (int)((hs >> 8) % 3);              // высота ствола 4..6
                for (int dy = th - 2; dy <= th + 1; dy++)
                {
                    int r = dy >= th ? 1 : 2;
                    for (int dx = -r; dx <= r; dx++)
                    for (int dz = -r; dz <= r; dz++)
                    {
                        if (r == 2 && Mathf.Abs(dx) == 2 && Mathf.Abs(dz) == 2) continue;   // срезаем углы
                        if (dx == 0 && dz == 0 && dy <= th) continue;                        // здесь ствол
                        SetLocal(blocks, wx + dx - x0, h + dy, wz + dz - z0, Block.Leaves, true);
                    }
                }
                for (int dy = 1; dy <= th; dy++) SetLocal(blocks, wx - x0, h + dy, wz - z0, Block.Log, false);
                maxY = Mathf.Max(maxY, h + th + 1);
            }
        }

        static void SetLocal(byte[] blocks, int lx, int y, int lz, byte id, bool onlyAir)
        {
            if ((uint)lx >= Chunk.S || (uint)lz >= Chunk.S || y < 0 || y >= Chunk.H) return;
            int i = Chunk.Idx(lx, y, lz);
            if (!onlyAir || blocks[i] == Block.Air) blocks[i] = id;
        }
    }
}
