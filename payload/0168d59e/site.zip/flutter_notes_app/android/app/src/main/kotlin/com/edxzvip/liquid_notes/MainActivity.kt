package com.edxzvip.liquid_notes

import io.flutter.embedding.android.FlutterFragmentActivity

// FlutterFragmentActivity is required for local_auth biometric support
class MainActivity: FlutterFragmentActivity()
