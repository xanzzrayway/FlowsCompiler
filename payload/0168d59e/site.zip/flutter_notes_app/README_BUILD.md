# Liquid Notes — Flutter App

A professional notes application with **Liquid Glass** design, local encryption, biometric lock, two-step PIN verification, and multi-language support.

---

## Prerequisites

Install these on your machine before building:

| Tool | Version | Download |
|------|---------|----------|
| Flutter SDK | 3.19+ | https://docs.flutter.dev/get-started/install |
| Android Studio | 2023.1+ | https://developer.android.com/studio |
| JDK | 17 | bundled with Android Studio |
| Android SDK | API 34 | via Android Studio SDK Manager |

---

## Project Structure

```
liquid_notes/
├── lib/
│   ├── main.dart                  # Entry point
│   ├── models/
│   │   └── note.dart              # Note data model
│   ├── screens/
│   │   ├── onboarding_screen.dart # Welcome / intro
│   │   ├── home_screen.dart       # Bottom nav shell
│   │   ├── notes_screen.dart      # Notes list (Tab 1)
│   │   ├── note_editor_screen.dart# Add / Edit note
│   │   ├── coming_soon_screen.dart# Coming Soon (Tab 2)
│   │   ├── settings_screen.dart   # Settings (Tab 3)
│   │   └── auth_screen.dart       # Biometric + PIN screens
│   ├── services/
│   │   ├── database_service.dart  # SQLite + XOR encryption
│   │   └── auth_service.dart      # Biometric + PIN logic
│   ├── utils/
│   │   ├── app_theme.dart         # Color palette + TextTheme
│   │   └── app_localizations.dart # 5-language strings
│   └── widgets/
│       └── liquid_glass.dart      # Core Liquid Glass components
├── android/
│   ├── app/
│   │   ├── build.gradle
│   │   └── src/main/
│   │       ├── AndroidManifest.xml
│   │       ├── kotlin/com/edxzvip/liquid_notes/MainActivity.kt
│   │       └── res/  (mipmaps + drawables + styles)
│   ├── build.gradle
│   ├── settings.gradle
│   └── gradle.properties
├── assets/
│   └── images/
│       ├── app_icon.png
│       └── app_icon_fg.png
└── pubspec.yaml
```

---

## Build Steps

### 1. Open a terminal in the project root

```bash
cd path/to/liquid_notes
```

### 2. Get dependencies

```bash
flutter pub get
```

### 3. Verify the setup

```bash
flutter doctor -v
```
Fix any issues shown (accept Android licenses if prompted: `flutter doctor --android-licenses`).

### 4. Connect a device or start an emulator

```bash
# List available devices
flutter devices

# Or start emulator from Android Studio → Device Manager
```

### 5. Run in debug mode (test first)

```bash
flutter run
```

### 6. Build release APK

```bash
flutter build apk --release
```

Output: `build/apk/release/app-release.apk`

### 7. Build split APKs (smaller download, recommended)

```bash
flutter build apk --split-per-abi --release
```

Outputs:
- `build/apk/release/app-arm64-v8a-release.apk`   ← use this for modern phones
- `build/apk/release/app-armeabi-v7a-release.apk`
- `build/apk/release/app-x86_64-release.apk`

### 8. Install directly to connected device

```bash
flutter install
```

---

## App Icon

The app icon is pre-generated at `assets/images/app_icon.png`.

To regenerate or replace it:
1. Replace `assets/images/app_icon.png` with your 1024×1024 PNG
2. Run: `flutter pub run flutter_launcher_icons` (add `flutter_launcher_icons` to dev_dependencies first)

Or manually copy your icon into each `android/app/src/main/res/mipmap-*/` folder at the correct size.

---

## Signing for Production (Play Store)

```bash
# 1. Generate a keystore
keytool -genkey -v -keystore ~/upload-keystore.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias upload

# 2. Create android/key.properties
storePassword=<your-store-password>
keyPassword=<your-key-password>
keyAlias=upload
storeFile=<path-to>/upload-keystore.jks

# 3. Reference it in android/app/build.gradle (replace signingConfigs.debug):
signingConfigs {
    release {
        keyAlias keystoreProperties['keyAlias']
        keyPassword keystoreProperties['keyPassword']
        storeFile file(keystoreProperties['storeFile'])
        storePassword keystoreProperties['storePassword']
    }
}

# 4. Build
flutter build apk --release
```

---

## Features Implemented

### Onboarding (3 pages)
- Animated page transitions, floating icon with glow pulse
- Feature chips, page indicator dots, skip/next buttons with Liquid Glass style

### Bottom Navigation
- Telegram-style curved pill tabs (default)
- Long-press → morphs to Liquid Glass style with glow + blur
- Long-press + drag left/right → slides between tabs with haptic feedback
- Smooth `AnimatedContainer` + `BackdropFilter` transitions

### Tab 1 — Notes
- Search bar with live filtering
- Note cards with color-coded left accent bars, 4 rotating accent colors
- Pencil icon → bottom sheet → Edit or Delete options
- Pin/Unpin notes
- Add note FAB (Liquid Glass styled)
- Note editor with title + body, word/character count, append mode
- Full CRUD with SQLite persistence
- XOR + Base64 local encryption on all note content

### Tab 2 — Coming Soon
- Animated floating rocket icon
- Orbiting ambient background circles
- TikTok developer credit card: `@EDXZVIP`
- Status chips (In Development, v2.0 Feature, Beta Soon)

### Tab 3 — Settings
- Editable display name (dialog with text field)
- Privacy section (expandable):
  - **App Lock**: biometric/device-lock, requires auth before enabling
  - **Two-Step Verification**: 6-digit PIN, set+confirm flow, verified on note open
- Language picker: English, Indonesian, Malay, Chinese (Simplified), Russian
- About card with version info

### Security
- App Lock: `local_auth` → fingerprint, face, PIN/pattern (device choice)
- Two-Step: SHA-256 hashed 6-digit PIN stored in SharedPreferences
- Note encryption: XOR cipher with Base64 encoding (all titles + bodies)
- Auth screen with shake animation on failure

### Liquid Glass Design System (`widgets/liquid_glass.dart`)
- `LiquidGlass`: frosted `BackdropFilter` + shimmer gradient border + glow shadow
- `LiquidGlassButton`: press scale + long-press color morph + glow
- `LiquidNavPill`: animated pill with glass mode on long-press

---

## Minimum Requirements

- Android 6.0 (API 23) — required for biometric APIs
- ~30 MB storage

---

## Troubleshooting

**`flutter pub get` fails on `local_auth`**
→ Ensure `minSdkVersion 23` in `android/app/build.gradle`

**Biometric not working on emulator**
→ Use a physical device, or enroll a fingerprint in emulator settings under Security → Fingerprint

**Build fails with "Namespace not specified"**
→ Confirm `namespace "com.edxzvip.liquid_notes"` is in `android/app/build.gradle`

**`BackdropFilter` shows no blur**
→ This is an emulator GPU limitation. Works correctly on real device.
