import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  static final AuthService instance = AuthService._init();
  final LocalAuthentication _localAuth = LocalAuthentication();

  AuthService._init();

  // ─── App Lock (Biometric / Device Credentials) ───────────────────────────

  Future<bool> canCheckBiometrics() async {
    try {
      return await _localAuth.canCheckBiometrics;
    } catch (e) {
      return false;
    }
  }

  Future<bool> isDeviceSupported() async {
    try {
      return await _localAuth.isDeviceSupported();
    } catch (e) {
      return false;
    }
  }

  Future<List<BiometricType>> getAvailableBiometrics() async {
    try {
      return await _localAuth.getAvailableBiometrics();
    } catch (e) {
      return [];
    }
  }

  Future<bool> authenticateWithBiometrics({String? reason}) async {
    try {
      final isSupported = await isDeviceSupported();
      if (!isSupported) return false;

      return await _localAuth.authenticate(
        localizedReason: reason ?? 'Authenticate to access Liquid Notes',
        options: const AuthenticationOptions(
          stickyAuth: true,
          biometricOnly: false, // Allow device PIN/pattern/face as fallback
          useErrorDialogs: true,
        ),
      );
    } catch (e) {
      return false;
    }
  }

  Future<void> stopAuthentication() async {
    try {
      await _localAuth.stopAuthentication();
    } catch (e) {
      // Ignore
    }
  }

  // ─── App Lock Settings ───────────────────────────────────────────────────

  Future<bool> get isAppLockEnabled async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('app_lock_enabled') ?? false;
  }

  Future<void> setAppLockEnabled(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('app_lock_enabled', value);
  }

  // ─── Two-Step Verification (6-digit PIN) ─────────────────────────────────

  Future<bool> get isTwoStepEnabled async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('two_step_enabled') ?? false;
  }

  Future<void> setTwoStepEnabled(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('two_step_enabled', value);
  }

  Future<bool> hasTwoStepPin() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('two_step_pin_hash') != null;
  }

  String _hashPin(String pin) {
    final bytes = utf8.encode(pin + 'LiquidNotesSalt2024');
    final digest = sha256.convert(bytes);
    return digest.toString();
  }

  Future<void> setTwoStepPin(String pin) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('two_step_pin_hash', _hashPin(pin));
  }

  Future<bool> verifyTwoStepPin(String pin) async {
    final prefs = await SharedPreferences.getInstance();
    final storedHash = prefs.getString('two_step_pin_hash');
    if (storedHash == null) return false;
    return storedHash == _hashPin(pin);
  }

  Future<void> clearTwoStepPin() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('two_step_pin_hash');
    await prefs.setBool('two_step_enabled', false);
  }

  // ─── User Profile ────────────────────────────────────────────────────────

  Future<String> getDisplayName() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('display_name') ?? 'User';
  }

  Future<void> setDisplayName(String name) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('display_name', name);
  }
}
