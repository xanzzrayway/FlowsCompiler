import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:crypto/crypto.dart';
import '../models/note.dart';

class DatabaseService {
  static final DatabaseService instance = DatabaseService._init();
  static Database? _database;

  DatabaseService._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('liquid_notes.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        body TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL,
        is_pinned INTEGER NOT NULL DEFAULT 0
      )
    ''');
  }

  // Simple XOR-based encryption for note content (lightweight, no external deps issues)
  String _encryptText(String text) {
    final key = 'LiquidNotes2024SecureKey!';
    final keyBytes = utf8.encode(key);
    final textBytes = utf8.encode(text);
    final encrypted = List<int>.generate(
      textBytes.length,
      (i) => textBytes[i] ^ keyBytes[i % keyBytes.length],
    );
    return base64.encode(encrypted);
  }

  String _decryptText(String encrypted) {
    try {
      final key = 'LiquidNotes2024SecureKey!';
      final keyBytes = utf8.encode(key);
      final encryptedBytes = base64.decode(encrypted);
      final decrypted = List<int>.generate(
        encryptedBytes.length,
        (i) => encryptedBytes[i] ^ keyBytes[i % keyBytes.length],
      );
      return utf8.decode(decrypted);
    } catch (e) {
      return encrypted; // Return as-is if decryption fails (unencrypted legacy data)
    }
  }

  Note _encryptNote(Note note) {
    return note.copyWith(
      title: _encryptText(note.title),
      body: _encryptText(note.body),
    );
  }

  Note _decryptNote(Note note) {
    return note.copyWith(
      title: _decryptText(note.title),
      body: _decryptText(note.body),
    );
  }

  Future<Note> createNote(Note note) async {
    final db = await instance.database;
    final encryptedNote = _encryptNote(note);
    final id = await db.insert('notes', encryptedNote.toMap());
    return note.copyWith(id: id);
  }

  Future<Note?> readNote(int id) async {
    final db = await instance.database;
    final maps = await db.query(
      'notes',
      where: 'id = ?',
      whereArgs: [id],
    );
    if (maps.isEmpty) return null;
    return _decryptNote(Note.fromMap(maps.first));
  }

  Future<List<Note>> readAllNotes() async {
    final db = await instance.database;
    final result = await db.query(
      'notes',
      orderBy: 'is_pinned DESC, updated_at DESC',
    );
    return result.map((map) => _decryptNote(Note.fromMap(map))).toList();
  }

  Future<int> updateNote(Note note) async {
    final db = await instance.database;
    final encryptedNote = _encryptNote(note);
    return await db.update(
      'notes',
      encryptedNote.toMap(),
      where: 'id = ?',
      whereArgs: [note.id],
    );
  }

  Future<int> deleteNote(int id) async {
    final db = await instance.database;
    return await db.delete(
      'notes',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> togglePin(Note note) async {
    final db = await instance.database;
    return await db.update(
      'notes',
      {'is_pinned': note.isPinned ? 0 : 1},
      where: 'id = ?',
      whereArgs: [note.id],
    );
  }

  Future<List<Note>> searchNotes(String query) async {
    final allNotes = await readAllNotes();
    final lowerQuery = query.toLowerCase();
    return allNotes
        .where((note) =>
            note.title.toLowerCase().contains(lowerQuery) ||
            note.body.toLowerCase().contains(lowerQuery))
        .toList();
  }

  Future close() async {
    final db = await instance.database;
    db.close();
  }
}
