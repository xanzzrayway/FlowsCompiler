import 'dart:ui';
import 'package:flutter/material.dart';
import '../utils/app_theme.dart';

/// Core Liquid Glass widget — frosted glass with shimmer border and glow
class LiquidGlass extends StatefulWidget {
  final Widget child;
  final double borderRadius;
  final double blur;
  final Color? tint;
  final bool animate;
  final double? width;
  final double? height;
  final EdgeInsetsGeometry? padding;
  final VoidCallback? onTap;

  const LiquidGlass({
    super.key,
    required this.child,
    this.borderRadius = 24,
    this.blur = 20,
    this.tint,
    this.animate = false,
    this.width,
    this.height,
    this.padding,
    this.onTap,
  });

  @override
  State<LiquidGlass> createState() => _LiquidGlassState();
}

class _LiquidGlassState extends State<LiquidGlass>
    with SingleTickerProviderStateMixin {
  late AnimationController _shimmerController;
  late Animation<double> _shimmerAnim;

  @override
  void initState() {
    super.initState();
    _shimmerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    );
    _shimmerAnim = Tween<double>(begin: -1, end: 2).animate(
      CurvedAnimation(parent: _shimmerController, curve: Curves.easeInOut),
    );
    if (widget.animate) {
      _shimmerController.repeat();
    }
  }

  @override
  void dispose() {
    _shimmerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: _shimmerAnim,
        builder: (context, child) {
          return Container(
            width: widget.width,
            height: widget.height,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(widget.borderRadius),
              gradient: LinearGradient(
                begin: Alignment(_shimmerAnim.value - 1, -1),
                end: Alignment(_shimmerAnim.value + 1, 1),
                colors: [
                  (widget.tint ?? AppTheme.glassBase),
                  AppTheme.glassShimmer.withOpacity(0.06),
                  (widget.tint ?? AppTheme.glassBase),
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
              border: Border.all(
                color: AppTheme.glassBorder,
                width: 1.0,
              ),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.accentGlow.withOpacity(0.08),
                  blurRadius: 24,
                  spreadRadius: 0,
                ),
                BoxShadow(
                  color: Colors.black.withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(widget.borderRadius),
              child: BackdropFilter(
                filter: ImageFilter.blur(
                  sigmaX: widget.blur,
                  sigmaY: widget.blur,
                ),
                child: Container(
                  padding: widget.padding,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Colors.white.withOpacity(0.08),
                        Colors.white.withOpacity(0.02),
                      ],
                    ),
                  ),
                  child: child,
                ),
              ),
            ),
          );
        },
        child: widget.child,
      ),
    );
  }
}

/// Liquid Glass button — with press and long-press morphing
class LiquidGlassButton extends StatefulWidget {
  final Widget child;
  final VoidCallback? onPressed;
  final VoidCallback? onLongPress;
  final double borderRadius;
  final EdgeInsetsGeometry padding;
  final Color? accentColor;

  const LiquidGlassButton({
    super.key,
    required this.child,
    this.onPressed,
    this.onLongPress,
    this.borderRadius = 18,
    this.padding = const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
    this.accentColor,
  });

  @override
  State<LiquidGlassButton> createState() => _LiquidGlassButtonState();
}

class _LiquidGlassButtonState extends State<LiquidGlassButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _pressController;
  late Animation<double> _scaleAnim;
  late Animation<double> _glowAnim;
  bool _isLongPressed = false;

  @override
  void initState() {
    super.initState();
    _pressController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 180),
    );
    _scaleAnim = Tween<double>(begin: 1.0, end: 0.94).animate(
      CurvedAnimation(parent: _pressController, curve: Curves.easeOut),
    );
    _glowAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pressController, curve: Curves.easeOut),
    );
  }

  @override
  void dispose() {
    _pressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final accent = widget.accentColor ?? AppTheme.accent;
    return GestureDetector(
      onTapDown: (_) => _pressController.forward(),
      onTapUp: (_) {
        _pressController.reverse();
        setState(() => _isLongPressed = false);
      },
      onTapCancel: () {
        _pressController.reverse();
        setState(() => _isLongPressed = false);
      },
      onTap: widget.onPressed,
      onLongPressStart: (_) {
        setState(() => _isLongPressed = true);
        widget.onLongPress?.call();
      },
      onLongPressEnd: (_) => setState(() => _isLongPressed = false),
      child: AnimatedBuilder(
        animation: _pressController,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnim.value,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeOut,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(widget.borderRadius),
                gradient: _isLongPressed
                    ? LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          accent.withOpacity(0.3),
                          accent.withOpacity(0.1),
                        ],
                      )
                    : LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          accent.withOpacity(0.15),
                          accent.withOpacity(0.05),
                        ],
                      ),
                border: Border.all(
                  color: _isLongPressed
                      ? accent.withOpacity(0.7)
                      : accent.withOpacity(0.3),
                  width: _isLongPressed ? 1.5 : 1.0,
                ),
                boxShadow: _isLongPressed
                    ? [
                        BoxShadow(
                          color: accent.withOpacity(0.4),
                          blurRadius: 20,
                          spreadRadius: 2,
                        ),
                      ]
                    : [
                        BoxShadow(
                          color: accent.withOpacity(0.1),
                          blurRadius: 8,
                          spreadRadius: 0,
                        ),
                      ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(widget.borderRadius),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                  child: Padding(
                    padding: widget.padding,
                    child: child,
                  ),
                ),
              ),
            ),
          );
        },
        child: widget.child,
      ),
    );
  }
}

/// Morphing nav pill — transforms on long-press
class LiquidNavPill extends StatelessWidget {
  final bool isActive;
  final Widget icon;
  final Widget label;
  final VoidCallback onTap;
  final bool isGlassMode;
  final Color activeColor;
  final Color inactiveColor;

  const LiquidNavPill({
    super.key,
    required this.isActive,
    required this.icon,
    required this.label,
    required this.onTap,
    required this.isGlassMode,
    required this.activeColor,
    required this.inactiveColor,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeOutCubic,
        padding: EdgeInsets.symmetric(
          horizontal: isActive ? 20 : 16,
          vertical: 10,
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(isGlassMode ? 20 : 16),
          color: isGlassMode
              ? null
              : isActive
                  ? activeColor.withOpacity(0.15)
                  : Colors.transparent,
          gradient: isGlassMode
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    activeColor.withOpacity(0.25),
                    activeColor.withOpacity(0.08),
                  ],
                )
              : null,
          border: Border.all(
            color: isGlassMode
                ? activeColor.withOpacity(0.5)
                : isActive
                    ? activeColor.withOpacity(0.2)
                    : Colors.transparent,
            width: 1.0,
          ),
          boxShadow: isGlassMode
              ? [
                  BoxShadow(
                    color: activeColor.withOpacity(0.3),
                    blurRadius: 16,
                    spreadRadius: 1,
                  ),
                ]
              : null,
        ),
        child: AnimatedSize(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOutCubic,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              icon,
              if (isActive) ...[
                const SizedBox(width: 6),
                label,
              ],
            ],
          ),
        ),
      ),
    );
  }
}
