import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'screens/onboarding_screen.dart';
import 'screens/home_screen.dart';
import 'screens/auth_screen.dart';
import 'services/auth_service.dart';
import 'services/database_service.dart';
import 'utils/app_theme.dart';
import 'utils/app_localizations.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Set preferred orientations
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Initialize database
  await DatabaseService.instance.database;

  final prefs = await SharedPreferences.getInstance();
  final isFirstLaunch = prefs.getBool('is_first_launch') ?? true;
  final appLockEnabled = prefs.getBool('app_lock_enabled') ?? false;
  final savedLocale = prefs.getString('locale') ?? 'en';

  runApp(LiquidNotesApp(
    isFirstLaunch: isFirstLaunch,
    appLockEnabled: appLockEnabled,
    initialLocale: savedLocale,
  ));
}

class LiquidNotesApp extends StatefulWidget {
  final bool isFirstLaunch;
  final bool appLockEnabled;
  final String initialLocale;

  const LiquidNotesApp({
    super.key,
    required this.isFirstLaunch,
    required this.appLockEnabled,
    required this.initialLocale,
  });

  static _LiquidNotesAppState? of(BuildContext context) {
    return context.findAncestorStateOfType<_LiquidNotesAppState>();
  }

  @override
  State<LiquidNotesApp> createState() => _LiquidNotesAppState();
}

class _LiquidNotesAppState extends State<LiquidNotesApp> {
  late Locale _locale;

  @override
  void initState() {
    super.initState();
    _locale = Locale(widget.initialLocale);
  }

  void setLocale(String languageCode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('locale', languageCode);
    setState(() {
      _locale = Locale(languageCode);
    });
  }

  Locale get locale => _locale;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Catatan Penting',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      locale: _locale,
      supportedLocales: const [
        Locale('en'),
        Locale('id'),
        Locale('ms'),
        Locale('zh'),
        Locale('ru'),
      ],
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: widget.isFirstLaunch
          ? const OnboardingScreen()
          : widget.appLockEnabled
              ? const AuthScreen(nextRoute: 'home')
              : const HomeScreen(),
    );
  }
}
