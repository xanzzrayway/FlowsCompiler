import 'package:flutter/material.dart';

class AppLocalizations {
  final Locale locale;

  AppLocalizations(this.locale);

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  static const Map<String, Map<String, String>> _localizedStrings = {
    'en': {
      'app_name': 'Liquid Notes',
      'notes': 'Notes',
      'coming_soon': 'Coming Soon',
      'settings': 'Settings',
      'add_note': 'Add Note',
      'edit_note': 'Edit Note',
      'delete_note': 'Delete Note',
      'title': 'Title',
      'body': 'Content',
      'done': 'Done',
      'cancel': 'Cancel',
      'save': 'Save',
      'edit': 'Edit',
      'delete': 'Delete',
      'delete_confirm': 'Delete this note?',
      'delete_confirm_msg': 'This action cannot be undone.',
      'no_notes': 'No notes yet',
      'no_notes_sub': 'Tap + to create your first note',
      'search_notes': 'Search notes...',
      'profile': 'Profile',
      'display_name': 'Display Name',
      'privacy': 'Privacy',
      'app_lock': 'App Lock',
      'app_lock_desc': 'Require authentication to open app',
      'two_step': 'Two-Step Verification',
      'two_step_desc': 'Require PIN when opening notes',
      'language': 'Language',
      'set_pin': 'Set PIN',
      'confirm_pin': 'Confirm PIN',
      'enter_pin': 'Enter PIN',
      'pin_mismatch': 'PINs do not match. Try again.',
      'pin_incorrect': 'Incorrect PIN',
      'pin_set': 'PIN set successfully',
      'auth_required': 'Authentication required',
      'biometric_desc': 'Verify your identity to continue',
      'onboarding_1_title': 'Welcome to\nLiquid Notes',
      'onboarding_1_sub': 'Your thoughts, beautifully encrypted and always with you.',
      'onboarding_2_title': 'Encrypted\nby Default',
      'onboarding_2_sub': 'Every note is stored with local encryption — your words, only yours.',
      'onboarding_3_title': 'Secured\nYour Way',
      'onboarding_3_sub': 'Fingerprint, face, PIN — choose how you lock the door to your thoughts.',
      'get_started': 'Get Started',
      'next': 'Next',
      'skip': 'Skip',
      'append': 'Append',
      'note_hint_title': 'Give it a title...',
      'note_hint_body': 'Start writing...',
      'characters': 'characters',
      'words': 'words',
      'pinned': 'Pinned',
      'pin_note': 'Pin Note',
      'unpin_note': 'Unpin Note',
      'coming_soon_tiktok': 'TikTok Developer: @EDXZVIP',
    },
    'id': {
      'app_name': 'Liquid Notes',
      'notes': 'Catatan',
      'coming_soon': 'Segera Hadir',
      'settings': 'Pengaturan',
      'add_note': 'Tambah Catatan',
      'edit_note': 'Edit Catatan',
      'delete_note': 'Hapus Catatan',
      'title': 'Judul',
      'body': 'Isi',
      'done': 'Selesai',
      'cancel': 'Batal',
      'save': 'Simpan',
      'edit': 'Edit',
      'delete': 'Hapus',
      'delete_confirm': 'Hapus catatan ini?',
      'delete_confirm_msg': 'Tindakan ini tidak dapat dibatalkan.',
      'no_notes': 'Belum ada catatan',
      'no_notes_sub': 'Ketuk + untuk membuat catatan pertama',
      'search_notes': 'Cari catatan...',
      'profile': 'Profil',
      'display_name': 'Nama Tampilan',
      'privacy': 'Privasi',
      'app_lock': 'Kunci Aplikasi',
      'app_lock_desc': 'Wajib autentikasi untuk membuka aplikasi',
      'two_step': 'Verifikasi Dua Langkah',
      'two_step_desc': 'Wajib PIN saat membuka catatan',
      'language': 'Bahasa',
      'set_pin': 'Atur PIN',
      'confirm_pin': 'Konfirmasi PIN',
      'enter_pin': 'Masukkan PIN',
      'pin_mismatch': 'PIN tidak cocok. Coba lagi.',
      'pin_incorrect': 'PIN salah',
      'pin_set': 'PIN berhasil diatur',
      'auth_required': 'Autentikasi diperlukan',
      'biometric_desc': 'Verifikasi identitas Anda untuk melanjutkan',
      'onboarding_1_title': 'Selamat Datang\ndi Liquid Notes',
      'onboarding_1_sub': 'Pikiran Anda, terenkripsi dengan indah dan selalu bersama Anda.',
      'onboarding_2_title': 'Terenkripsi\nSecara Default',
      'onboarding_2_sub': 'Setiap catatan disimpan dengan enkripsi lokal — kata-katamu, hanya milikmu.',
      'onboarding_3_title': 'Diamankan\nSesuai Pilihan',
      'onboarding_3_sub': 'Sidik jari, wajah, PIN — pilih cara mengunci pintumu.',
      'get_started': 'Mulai',
      'next': 'Lanjut',
      'skip': 'Lewati',
      'append': 'Tambahkan',
      'note_hint_title': 'Beri judul...',
      'note_hint_body': 'Mulai menulis...',
      'characters': 'karakter',
      'words': 'kata',
      'pinned': 'Disematkan',
      'pin_note': 'Sematkan',
      'unpin_note': 'Lepas Sematan',
      'coming_soon_tiktok': 'TikTok Developer: @EDXZVIP',
    },
    'ms': {
      'app_name': 'Liquid Notes',
      'notes': 'Nota',
      'coming_soon': 'Akan Datang',
      'settings': 'Tetapan',
      'add_note': 'Tambah Nota',
      'edit_note': 'Edit Nota',
      'delete_note': 'Padam Nota',
      'title': 'Tajuk',
      'body': 'Kandungan',
      'done': 'Selesai',
      'cancel': 'Batal',
      'save': 'Simpan',
      'edit': 'Edit',
      'delete': 'Padam',
      'delete_confirm': 'Padam nota ini?',
      'delete_confirm_msg': 'Tindakan ini tidak boleh dibatalkan.',
      'no_notes': 'Tiada nota lagi',
      'no_notes_sub': 'Ketik + untuk cipta nota pertama',
      'search_notes': 'Cari nota...',
      'profile': 'Profil',
      'display_name': 'Nama Paparan',
      'privacy': 'Privasi',
      'app_lock': 'Kunci Apl',
      'app_lock_desc': 'Perlu pengesahan untuk buka apl',
      'two_step': 'Pengesahan Dua Langkah',
      'two_step_desc': 'Perlu PIN apabila membuka nota',
      'language': 'Bahasa',
      'set_pin': 'Tetap PIN',
      'confirm_pin': 'Sahkan PIN',
      'enter_pin': 'Masukkan PIN',
      'pin_mismatch': 'PIN tidak sepadan. Cuba lagi.',
      'pin_incorrect': 'PIN salah',
      'pin_set': 'PIN berjaya ditetapkan',
      'auth_required': 'Pengesahan diperlukan',
      'biometric_desc': 'Sahkan identiti anda untuk teruskan',
      'onboarding_1_title': 'Selamat Datang\nke Liquid Notes',
      'onboarding_1_sub': 'Fikiran anda, disulitkan dengan cantik dan sentiasa bersama anda.',
      'onboarding_2_title': 'Disulitkan\nSecara Lalai',
      'onboarding_2_sub': 'Setiap nota disimpan dengan penyulitan tempatan — kata-katamu, milikmu sahaja.',
      'onboarding_3_title': 'Dilindungi\nMengikut Pilihan',
      'onboarding_3_sub': 'Cap jari, muka, PIN — pilih cara anda kunci pemikiran.',
      'get_started': 'Mulakan',
      'next': 'Seterusnya',
      'skip': 'Langkau',
      'append': 'Tambah',
      'note_hint_title': 'Beri tajuk...',
      'note_hint_body': 'Mula menulis...',
      'characters': 'aksara',
      'words': 'patah perkataan',
      'pinned': 'Disematkan',
      'pin_note': 'Semat',
      'unpin_note': 'Nyahsemat',
      'coming_soon_tiktok': 'TikTok Developer: @EDXZVIP',
    },
    'zh': {
      'app_name': 'Liquid Notes',
      'notes': '笔记',
      'coming_soon': '即将推出',
      'settings': '设置',
      'add_note': '添加笔记',
      'edit_note': '编辑笔记',
      'delete_note': '删除笔记',
      'title': '标题',
      'body': '内容',
      'done': '完成',
      'cancel': '取消',
      'save': '保存',
      'edit': '编辑',
      'delete': '删除',
      'delete_confirm': '删除此笔记？',
      'delete_confirm_msg': '此操作无法撤销。',
      'no_notes': '暂无笔记',
      'no_notes_sub': '点击 + 创建第一条笔记',
      'search_notes': '搜索笔记...',
      'profile': '个人资料',
      'display_name': '显示名称',
      'privacy': '隐私',
      'app_lock': '应用锁定',
      'app_lock_desc': '打开应用时需要验证',
      'two_step': '两步验证',
      'two_step_desc': '打开笔记时需要 PIN',
      'language': '语言',
      'set_pin': '设置 PIN',
      'confirm_pin': '确认 PIN',
      'enter_pin': '输入 PIN',
      'pin_mismatch': 'PIN 不匹配，请重试。',
      'pin_incorrect': 'PIN 错误',
      'pin_set': 'PIN 设置成功',
      'auth_required': '需要验证',
      'biometric_desc': '验证您的身份以继续',
      'onboarding_1_title': '欢迎使用\nLiquid Notes',
      'onboarding_1_sub': '您的想法，经过精美加密，始终陪伴着您。',
      'onboarding_2_title': '默认\n加密保护',
      'onboarding_2_sub': '每条笔记都经过本地加密存储——您的文字，只属于您。',
      'onboarding_3_title': '按您的方式\n保护安全',
      'onboarding_3_sub': '指纹、面部、PIN——选择锁定思想的方式。',
      'get_started': '开始使用',
      'next': '下一步',
      'skip': '跳过',
      'append': '追加',
      'note_hint_title': '给它一个标题...',
      'note_hint_body': '开始书写...',
      'characters': '字符',
      'words': '词',
      'pinned': '已置顶',
      'pin_note': '置顶',
      'unpin_note': '取消置顶',
      'coming_soon_tiktok': 'TikTok 开发者: @EDXZVIP',
    },
    'ru': {
      'app_name': 'Liquid Notes',
      'notes': 'Заметки',
      'coming_soon': 'Скоро',
      'settings': 'Настройки',
      'add_note': 'Добавить заметку',
      'edit_note': 'Редактировать',
      'delete_note': 'Удалить заметку',
      'title': 'Заголовок',
      'body': 'Содержимое',
      'done': 'Готово',
      'cancel': 'Отмена',
      'save': 'Сохранить',
      'edit': 'Редактировать',
      'delete': 'Удалить',
      'delete_confirm': 'Удалить эту заметку?',
      'delete_confirm_msg': 'Это действие нельзя отменить.',
      'no_notes': 'Нет заметок',
      'no_notes_sub': 'Нажмите + чтобы создать первую заметку',
      'search_notes': 'Поиск заметок...',
      'profile': 'Профиль',
      'display_name': 'Отображаемое имя',
      'privacy': 'Конфиденциальность',
      'app_lock': 'Блокировка приложения',
      'app_lock_desc': 'Требовать аутентификацию при открытии',
      'two_step': 'Двухэтапная проверка',
      'two_step_desc': 'Требовать PIN при открытии заметок',
      'language': 'Язык',
      'set_pin': 'Установить PIN',
      'confirm_pin': 'Подтвердить PIN',
      'enter_pin': 'Введите PIN',
      'pin_mismatch': 'PIN не совпадают. Попробуйте снова.',
      'pin_incorrect': 'Неверный PIN',
      'pin_set': 'PIN успешно установлен',
      'auth_required': 'Требуется аутентификация',
      'biometric_desc': 'Подтвердите личность для продолжения',
      'onboarding_1_title': 'Добро пожаловать\nв Liquid Notes',
      'onboarding_1_sub': 'Ваши мысли — красиво зашифрованы и всегда с вами.',
      'onboarding_2_title': 'Шифрование\nпо умолчанию',
      'onboarding_2_sub': 'Каждая заметка хранится с локальным шифрованием — ваши слова, только ваши.',
      'onboarding_3_title': 'Защита\nна ваш выбор',
      'onboarding_3_sub': 'Отпечаток, лицо, PIN — выберите, как запереть дверь к мыслям.',
      'get_started': 'Начать',
      'next': 'Далее',
      'skip': 'Пропустить',
      'append': 'Дополнить',
      'note_hint_title': 'Дайте ему заголовок...',
      'note_hint_body': 'Начните писать...',
      'characters': 'символов',
      'words': 'слов',
      'pinned': 'Закреплено',
      'pin_note': 'Закрепить',
      'unpin_note': 'Открепить',
      'coming_soon_tiktok': 'Разработчик TikTok: @EDXZVIP',
    },
  };

  String get(String key) {
    final langCode = locale.languageCode;
    final strings = _localizedStrings[langCode] ?? _localizedStrings['en']!;
    return strings[key] ?? _localizedStrings['en']![key] ?? key;
  }

  // Convenience getters
  String get appName => get('app_name');
  String get notes => get('notes');
  String get comingSoon => get('coming_soon');
  String get settings => get('settings');
  String get addNote => get('add_note');
  String get editNote => get('edit_note');
  String get deleteNote => get('delete_note');
  String get title => get('title');
  String get body => get('body');
  String get done => get('done');
  String get cancel => get('cancel');
  String get save => get('save');
  String get edit => get('edit');
  String get delete => get('delete');
  String get deleteConfirm => get('delete_confirm');
  String get deleteConfirmMsg => get('delete_confirm_msg');
  String get noNotes => get('no_notes');
  String get noNotesSub => get('no_notes_sub');
  String get searchNotes => get('search_notes');
  String get profile => get('profile');
  String get displayName => get('display_name');
  String get privacy => get('privacy');
  String get appLock => get('app_lock');
  String get appLockDesc => get('app_lock_desc');
  String get twoStep => get('two_step');
  String get twoStepDesc => get('two_step_desc');
  String get language => get('language');
  String get setPin => get('set_pin');
  String get confirmPin => get('confirm_pin');
  String get enterPin => get('enter_pin');
  String get pinMismatch => get('pin_mismatch');
  String get pinIncorrect => get('pin_incorrect');
  String get pinSet => get('pin_set');
  String get authRequired => get('auth_required');
  String get biometricDesc => get('biometric_desc');
  String get getStarted => get('get_started');
  String get next => get('next');
  String get skip => get('skip');
  String get append => get('append');
  String get noteHintTitle => get('note_hint_title');
  String get noteHintBody => get('note_hint_body');
  String get characters => get('characters');
  String get words => get('words');
  String get pinned => get('pinned');
  String get pinNote => get('pin_note');
  String get unpinNote => get('unpin_note');
  String get comingSoonTiktok => get('coming_soon_tiktok');
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    return ['en', 'id', 'ms', 'zh', 'ru'].contains(locale.languageCode);
  }

  @override
  Future<AppLocalizations> load(Locale locale) async {
    return AppLocalizations(locale);
  }

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}
