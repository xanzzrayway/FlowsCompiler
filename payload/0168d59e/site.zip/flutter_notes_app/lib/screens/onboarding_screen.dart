import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/app_theme.dart';
import '../utils/app_localizations.dart';
import '../widgets/liquid_glass.dart';
import 'home_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen>
    with TickerProviderStateMixin {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  late List<AnimationController> _itemControllers;
  late List<Animation<double>> _itemFadeAnims;
  late List<Animation<Offset>> _itemSlideAnims;

  final int _totalPages = 3;

  @override
  void initState() {
    super.initState();
    _itemControllers = List.generate(
      _totalPages,
      (i) => AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 700),
      ),
    );
    _itemFadeAnims = _itemControllers
        .map((c) => Tween<double>(begin: 0, end: 1).animate(
              CurvedAnimation(parent: c, curve: Curves.easeOut),
            ))
        .toList();
    _itemSlideAnims = _itemControllers
        .map((c) => Tween<Offset>(
              begin: const Offset(0, 0.2),
              end: Offset.zero,
            ).animate(CurvedAnimation(parent: c, curve: Curves.easeOutCubic)))
        .toList();

    // Animate first page in
    Future.delayed(const Duration(milliseconds: 200), () {
      if (mounted) _itemControllers[0].forward();
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    for (final c in _itemControllers) {
      c.dispose();
    }
    super.dispose();
  }

  void _nextPage() {
    if (_currentPage < _totalPages - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOutCubic,
      );
    } else {
      _finish();
    }
  }

  Future<void> _finish() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('is_first_launch', false);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, a1, a2) => const HomeScreen(),
        transitionsBuilder: (_, anim, __, child) => FadeTransition(
          opacity: anim,
          child: child,
        ),
        transitionDuration: const Duration(milliseconds: 500),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: Stack(
        children: [
          // Ambient background orbs
          _buildAmbientBg(size),

          // Page view
          PageView(
            controller: _pageController,
            onPageChanged: (index) {
              setState(() => _currentPage = index);
              _itemControllers[index].forward(from: 0);
            },
            children: [
              _OnboardingPage(
                fadeAnim: _itemFadeAnims[0],
                slideAnim: _itemSlideAnims[0],
                icon: _buildEncryptIcon(),
                title: loc?.onboarding1Title ?? 'Welcome to\nLiquid Notes',
                subtitle: loc?.onboarding1Sub ??
                    'Your thoughts, beautifully encrypted and always with you.',
                accentColor: AppTheme.accent,
              ),
              _OnboardingPage(
                fadeAnim: _itemFadeAnims[1],
                slideAnim: _itemSlideAnims[1],
                icon: _buildShieldIcon(),
                title: loc?.onboarding2Title ?? 'Encrypted\nby Default',
                subtitle: loc?.onboarding2Sub ??
                    'Every note is stored with local encryption — your words, only yours.',
                accentColor: const Color(0xFF5BEFB8),
              ),
              _OnboardingPage(
                fadeAnim: _itemFadeAnims[2],
                slideAnim: _itemSlideAnims[2],
                icon: _buildFingerprintIcon(),
                title: loc?.onboarding3Title ?? 'Secured\nYour Way',
                subtitle: loc?.onboarding3Sub ??
                    'Fingerprint, face, PIN — choose how you lock the door to your thoughts.',
                accentColor: const Color(0xFFBF5BEF),
              ),
            ],
          ),

          // Bottom controls
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: _buildBottomControls(loc, size),
          ),
        ],
      ),
    );
  }

  Widget _buildAmbientBg(Size size) {
    return Stack(
      children: [
        // Top-left orb
        Positioned(
          top: -size.height * 0.15,
          left: -size.width * 0.3,
          child: _buildOrb(size.width * 0.8, AppTheme.accent.withOpacity(0.12)),
        ),
        // Bottom-right orb
        Positioned(
          bottom: -size.height * 0.1,
          right: -size.width * 0.2,
          child: _buildOrb(size.width * 0.7, const Color(0xFF5BEFB8).withOpacity(0.08)),
        ),
        // Center subtle orb
        Positioned(
          top: size.height * 0.3,
          left: size.width * 0.2,
          child: _buildOrb(size.width * 0.5, const Color(0xFFBF5BEF).withOpacity(0.06)),
        ),
      ],
    );
  }

  Widget _buildOrb(double size, Color color) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
      ),
    );
  }

  Widget _buildEncryptIcon() {
    return _AnimatedGlowIcon(
      color: AppTheme.accent,
      child: const Icon(Icons.auto_awesome_rounded, size: 56, color: Colors.white),
    );
  }

  Widget _buildShieldIcon() {
    return _AnimatedGlowIcon(
      color: const Color(0xFF5BEFB8),
      child: const Icon(Icons.shield_rounded, size: 56, color: Colors.white),
    );
  }

  Widget _buildFingerprintIcon() {
    return _AnimatedGlowIcon(
      color: const Color(0xFFBF5BEF),
      child: const Icon(Icons.fingerprint_rounded, size: 56, color: Colors.white),
    );
  }

  Widget _buildBottomControls(AppLocalizations? loc, Size size) {
    final isLast = _currentPage == _totalPages - 1;
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).padding.bottom + 32,
        left: 32,
        right: 32,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Page dots
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              _totalPages,
              (i) => _PageDot(isActive: i == _currentPage),
            ),
          ),
          const SizedBox(height: 32),
          // Buttons row
          Row(
            children: [
              if (!isLast)
                GestureDetector(
                  onTap: _finish,
                  child: Text(
                    loc?.skip ?? 'Skip',
                    style: const TextStyle(
                      color: AppTheme.pearlDim,
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              const Spacer(),
              LiquidGlassButton(
                onPressed: _nextPage,
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                accentColor: AppTheme.accent,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      isLast ? (loc?.getStarted ?? 'Get Started') : (loc?.next ?? 'Next'),
                      style: const TextStyle(
                        color: AppTheme.pearl,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(width: 8),
                    const Icon(
                      Icons.arrow_forward_rounded,
                      color: AppTheme.pearl,
                      size: 18,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _OnboardingPage extends StatelessWidget {
  final Animation<double> fadeAnim;
  final Animation<Offset> slideAnim;
  final Widget icon;
  final String title;
  final String subtitle;
  final Color accentColor;

  const _OnboardingPage({
    required this.fadeAnim,
    required this.slideAnim,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.accentColor,
  });

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        children: [
          SizedBox(height: size.height * 0.18),
          // Icon with glow card
          FadeTransition(
            opacity: fadeAnim,
            child: SlideTransition(
              position: slideAnim,
              child: LiquidGlass(
                borderRadius: 36,
                animate: true,
                width: 140,
                height: 140,
                padding: const EdgeInsets.all(32),
                tint: accentColor.withOpacity(0.08),
                child: Center(child: icon),
              ),
            ),
          ),
          SizedBox(height: size.height * 0.06),
          // Title
          FadeTransition(
            opacity: fadeAnim,
            child: SlideTransition(
              position: slideAnim,
              child: Text(
                title,
                style: Theme.of(context).textTheme.displayMedium?.copyWith(
                  color: AppTheme.pearl,
                  height: 1.1,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ),
          const SizedBox(height: 20),
          // Subtitle
          FadeTransition(
            opacity: fadeAnim,
            child: SlideTransition(
              position: slideAnim,
              child: Text(
                subtitle,
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: AppTheme.pearlDim,
                  height: 1.65,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ),
          // Features list
          const SizedBox(height: 36),
          FadeTransition(
            opacity: fadeAnim,
            child: _buildFeatureChips(accentColor),
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureChips(Color accent) {
    final features = [
      ('🔒', 'Local Storage'),
      ('✨', 'Liquid Glass UI'),
      ('🔐', 'Biometric Lock'),
    ];
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: features
          .map((f) => Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: accent.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: accent.withOpacity(0.2),
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(f.$1, style: const TextStyle(fontSize: 14)),
                    const SizedBox(width: 6),
                    Text(
                      f.$2,
                      style: TextStyle(
                        color: AppTheme.pearl.withOpacity(0.8),
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ))
          .toList(),
    );
  }
}

class _PageDot extends StatelessWidget {
  final bool isActive;

  const _PageDot({required this.isActive});

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOutCubic,
      margin: const EdgeInsets.symmetric(horizontal: 4),
      width: isActive ? 24 : 8,
      height: 8,
      decoration: BoxDecoration(
        color: isActive ? AppTheme.accent : AppTheme.accent.withOpacity(0.25),
        borderRadius: BorderRadius.circular(4),
      ),
    );
  }
}

class _AnimatedGlowIcon extends StatefulWidget {
  final Widget child;
  final Color color;

  const _AnimatedGlowIcon({required this.child, required this.color});

  @override
  State<_AnimatedGlowIcon> createState() => _AnimatedGlowIconState();
}

class _AnimatedGlowIconState extends State<_AnimatedGlowIcon>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _pulseAnim,
      builder: (context, child) => Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: widget.color.withOpacity(0.3 * _pulseAnim.value),
              blurRadius: 30 * _pulseAnim.value,
              spreadRadius: 4 * _pulseAnim.value,
            ),
          ],
        ),
        child: child,
      ),
      child: widget.child,
    );
  }
}

extension on AppLocalizations {
  String get onboarding1Title => get('onboarding_1_title');
  String get onboarding1Sub => get('onboarding_1_sub');
  String get onboarding2Title => get('onboarding_2_title');
  String get onboarding2Sub => get('onboarding_2_sub');
  String get onboarding3Title => get('onboarding_3_title');
  String get onboarding3Sub => get('onboarding_3_sub');
}
