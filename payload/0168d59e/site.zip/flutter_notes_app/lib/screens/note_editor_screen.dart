import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../utils/app_theme.dart';
import '../utils/app_localizations.dart';
import '../models/note.dart';
import '../services/database_service.dart';
import '../widgets/liquid_glass.dart';

class NoteEditorScreen extends StatefulWidget {
  final Note? note;

  const NoteEditorScreen({super.key, this.note});

  @override
  State<NoteEditorScreen> createState() => _NoteEditorScreenState();
}

class _NoteEditorScreenState extends State<NoteEditorScreen>
    with SingleTickerProviderStateMixin {
  late TextEditingController _titleController;
  late TextEditingController _bodyController;
  late FocusNode _titleFocus;
  late FocusNode _bodyFocus;
  bool _hasChanges = false;
  bool _isSaving = false;
  bool _isAppendMode = false;

  // For word/char count
  int get _charCount => _bodyController.text.length;
  int get _wordCount {
    final text = _bodyController.text.trim();
    if (text.isEmpty) return 0;
    return text.split(RegExp(r'\s+')).length;
  }

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.note?.title ?? '');
    _bodyController = TextEditingController(text: widget.note?.body ?? '');
    _titleFocus = FocusNode();
    _bodyFocus = FocusNode();

    _titleController.addListener(_onChanged);
    _bodyController.addListener(_onChanged);

    // Auto-focus body if editing existing note
    if (widget.note != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        // Don't auto-focus on edit to let user scroll
      });
    } else {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _titleFocus.requestFocus();
      });
    }
  }

  void _onChanged() {
    setState(() => _hasChanges = true);
  }

  @override
  void dispose() {
    _titleController.removeListener(_onChanged);
    _bodyController.removeListener(_onChanged);
    _titleController.dispose();
    _bodyController.dispose();
    _titleFocus.dispose();
    _bodyFocus.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_isSaving) return;
    final title = _titleController.text.trim();
    final body = _bodyController.text.trim();

    if (title.isEmpty && body.isEmpty) {
      Navigator.of(context).pop();
      return;
    }

    setState(() => _isSaving = true);

    try {
      final now = DateTime.now();

      if (widget.note == null) {
        // New note
        final note = Note(
          title: title.isEmpty ? 'Untitled' : title,
          body: body,
          createdAt: now,
          updatedAt: now,
        );
        await DatabaseService.instance.createNote(note);
      } else {
        // Update existing note
        String updatedBody = widget.note!.body;
        if (_isAppendMode) {
          // Append new content with separator
          final newContent = _bodyController.text.trim();
          if (newContent.isNotEmpty) {
            updatedBody = '${widget.note!.body}\n\n─── Appended ───\n$newContent';
          }
        } else {
          updatedBody = body;
        }

        final updated = widget.note!.copyWith(
          title: title.isEmpty ? 'Untitled' : title,
          body: updatedBody,
          updatedAt: now,
        );
        await DatabaseService.instance.updateNote(updated);
      }

      HapticFeedback.lightImpact();
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      setState(() => _isSaving = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Failed to save note'),
            backgroundColor: AppTheme.danger,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        );
      }
    }
  }

  Future<bool> _onWillPop() async {
    if (!_hasChanges) return true;

    final loc = AppLocalizations.of(context);
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: LiquidGlass(
          borderRadius: 24,
          blur: 20,
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Discard changes?',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 8),
              const Text(
                'Your unsaved changes will be lost.',
                style: TextStyle(color: AppTheme.pearlDim),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Navigator.of(ctx).pop(false),
                      child: Text(
                        loc?.cancel ?? 'Cancel',
                        style: const TextStyle(color: AppTheme.pearlDim),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.of(ctx).pop(true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.danger,
                      ),
                      child: const Text('Discard'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    return result ?? false;
  }

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);
    final isEditing = widget.note != null;

    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        backgroundColor: AppTheme.background,
        appBar: _buildAppBar(loc, isEditing),
        body: _buildBody(loc, isEditing),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(AppLocalizations? loc, bool isEditing) {
    return AppBar(
      backgroundColor: AppTheme.background,
      leading: GestureDetector(
        onTap: () async {
          if (await _onWillPop()) Navigator.of(context).pop();
        },
        child: Container(
          margin: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: AppTheme.surfaceElevated,
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Icon(Icons.arrow_back_ios_new_rounded,
              size: 18, color: AppTheme.pearlDim),
        ),
      ),
      title: Text(
        isEditing ? (loc?.editNote ?? 'Edit Note') : (loc?.addNote ?? 'Add Note'),
        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
      ),
      actions: [
        if (isEditing)
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: TextButton(
              onPressed: () {
                setState(() {
                  _isAppendMode = !_isAppendMode;
                  if (_isAppendMode) {
                    _bodyController.clear();
                    _bodyFocus.requestFocus();
                  } else {
                    _bodyController.text = widget.note!.body;
                  }
                });
              },
              child: Text(
                _isAppendMode ? 'Edit All' : (loc?.append ?? 'Append'),
                style: TextStyle(
                  color: _isAppendMode ? AppTheme.warning : AppTheme.accent,
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                ),
              ),
            ),
          ),
        Padding(
          padding: const EdgeInsets.only(right: 16),
          child: GestureDetector(
            onTap: _isSaving ? null : _save,
            child: LiquidGlass(
              borderRadius: 14,
              animate: false,
              tint: AppTheme.accent.withOpacity(0.12),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
              child: _isSaving
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: AppTheme.pearl),
                    )
                  : Text(
                      loc?.done ?? 'Done',
                      style: const TextStyle(
                        color: AppTheme.pearl,
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                      ),
                    ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildBody(AppLocalizations? loc, bool isEditing) {
    return Column(
      children: [
        // Append mode banner
        if (_isAppendMode)
          Container(
            width: double.infinity,
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 0),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: AppTheme.warning.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.warning.withOpacity(0.3),
              ),
            ),
            child: Row(
              children: [
                Icon(Icons.add_circle_outline_rounded,
                    size: 16, color: AppTheme.warning.withOpacity(0.8)),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Append mode — content will be added below your existing note',
                    style: TextStyle(
                      color: AppTheme.warning.withOpacity(0.8),
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
          ),
        // Editor
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Title field
                if (!_isAppendMode)
                  TextField(
                    controller: _titleController,
                    focusNode: _titleFocus,
                    style: const TextStyle(
                      color: AppTheme.pearl,
                      fontSize: 24,
                      fontWeight: FontWeight.w700,
                      height: 1.3,
                    ),
                    decoration: InputDecoration(
                      hintText: loc?.noteHintTitle ?? 'Give it a title...',
                      hintStyle: TextStyle(
                        color: AppTheme.pearlDim.withOpacity(0.4),
                        fontSize: 24,
                        fontWeight: FontWeight.w700,
                      ),
                      border: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      contentPadding: EdgeInsets.zero,
                      filled: false,
                    ),
                    onSubmitted: (_) => _bodyFocus.requestFocus(),
                    textInputAction: TextInputAction.next,
                    maxLines: null,
                  ),
                if (!_isAppendMode) const SizedBox(height: 4),
                if (!_isAppendMode)
                  Container(
                    height: 1,
                    color: AppTheme.surfaceElevated,
                    margin: const EdgeInsets.symmetric(vertical: 12),
                  ),
                // Body field
                if (isEditing && !_isAppendMode) ...[
                  // Show existing content as read context
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppTheme.surfaceElevated.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: const Color(0xFF1E2A48), width: 1),
                    ),
                    child: TextField(
                      controller: _bodyController,
                      focusNode: _bodyFocus,
                      style: const TextStyle(
                        color: AppTheme.pearl,
                        fontSize: 16,
                        height: 1.7,
                      ),
                      decoration: InputDecoration(
                        hintText: loc?.noteHintBody ?? 'Start writing...',
                        hintStyle: TextStyle(
                          color: AppTheme.pearlDim.withOpacity(0.4),
                          fontSize: 16,
                        ),
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        contentPadding: EdgeInsets.zero,
                        filled: false,
                      ),
                      maxLines: null,
                      minLines: 8,
                      keyboardType: TextInputType.multiline,
                    ),
                  ),
                ] else
                  TextField(
                    controller: _bodyController,
                    focusNode: _bodyFocus,
                    style: const TextStyle(
                      color: AppTheme.pearl,
                      fontSize: 16,
                      height: 1.7,
                    ),
                    decoration: InputDecoration(
                      hintText: _isAppendMode
                          ? 'Add content to append...'
                          : (loc?.noteHintBody ?? 'Start writing...'),
                      hintStyle: TextStyle(
                        color: AppTheme.pearlDim.withOpacity(0.4),
                        fontSize: 16,
                      ),
                      border: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      contentPadding: EdgeInsets.zero,
                      filled: false,
                    ),
                    maxLines: null,
                    minLines: 8,
                    keyboardType: TextInputType.multiline,
                  ),
              ],
            ),
          ),
        ),
        // Status bar
        _buildStatusBar(loc),
      ],
    );
  }

  Widget _buildStatusBar(AppLocalizations? loc) {
    return AnimatedBuilder(
      animation: _bodyController,
      builder: (context, _) {
        return Container(
          padding: EdgeInsets.only(
            left: 24,
            right: 24,
            top: 10,
            bottom: MediaQuery.of(context).padding.bottom + 12,
          ),
          decoration: BoxDecoration(
            color: AppTheme.surface,
            border: const Border(
              top: BorderSide(color: Color(0xFF1A2240), width: 0.5),
            ),
          ),
          child: Row(
            children: [
              Icon(Icons.text_fields_rounded,
                  size: 14, color: AppTheme.pearlDim.withOpacity(0.5)),
              const SizedBox(width: 6),
              Text(
                '$_wordCount ${loc?.words ?? 'words'}  ·  $_charCount ${loc?.characters ?? 'characters'}',
                style: TextStyle(
                  color: AppTheme.pearlDim.withOpacity(0.5),
                  fontSize: 12,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
