import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../utils/app_theme.dart';
import '../utils/app_localizations.dart';
import '../widgets/liquid_glass.dart';

class ComingSoonScreen extends StatefulWidget {
  const ComingSoonScreen({super.key});

  @override
  State<ComingSoonScreen> createState() => _ComingSoonScreenState();
}

class _ComingSoonScreenState extends State<ComingSoonScreen>
    with TickerProviderStateMixin {
  late AnimationController _floatController;
  late AnimationController _orbController;
  late Animation<double> _floatAnim;
  late Animation<double> _orbAnim;

  @override
  void initState() {
    super.initState();
    _floatController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3000),
    )..repeat(reverse: true);

    _orbController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 8000),
    )..repeat();

    _floatAnim = Tween<double>(begin: -10, end: 10).animate(
      CurvedAnimation(parent: _floatController, curve: Curves.easeInOut),
    );

    _orbAnim = Tween<double>(begin: 0, end: 2 * math.pi).animate(
      CurvedAnimation(parent: _orbController, curve: Curves.linear),
    );
  }

  @override
  void dispose() {
    _floatController.dispose();
    _orbController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: Stack(
        children: [
          // Animated orbs background
          AnimatedBuilder(
            animation: _orbAnim,
            builder: (context, _) {
              return Stack(
                children: [
                  Positioned(
                    left: size.width * 0.5 +
                        math.cos(_orbAnim.value) * size.width * 0.3,
                    top: size.height * 0.3 +
                        math.sin(_orbAnim.value) * size.height * 0.1,
                    child: Container(
                      width: 200,
                      height: 200,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xFF5B8DEF).withOpacity(0.06),
                      ),
                    ),
                  ),
                  Positioned(
                    left: size.width * 0.1 +
                        math.cos(_orbAnim.value + math.pi) * size.width * 0.2,
                    top: size.height * 0.5 +
                        math.sin(_orbAnim.value + math.pi) *
                            size.height *
                            0.15,
                    child: Container(
                      width: 150,
                      height: 150,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xFFBF5BEF).withOpacity(0.05),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),

          // Main content
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Column(
                children: [
                  const SizedBox(height: 60),
                  // Animated floating icon
                  AnimatedBuilder(
                    animation: _floatAnim,
                    builder: (context, child) => Transform.translate(
                      offset: Offset(0, _floatAnim.value),
                      child: child,
                    ),
                    child: LiquidGlass(
                      borderRadius: 40,
                      animate: true,
                      width: 140,
                      height: 140,
                      tint: const Color(0xFF5B8DEF).withOpacity(0.1),
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // Construction stripes
                          Positioned.fill(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(40),
                              child: _ConstructionStripes(),
                            ),
                          ),
                          Container(
                            width: 72,
                            height: 72,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: AppTheme.background.withOpacity(0.6),
                            ),
                            child: const Icon(
                              Icons.rocket_launch_rounded,
                              size: 36,
                              color: AppTheme.accent,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 40),

                  Text(
                    loc?.comingSoon ?? 'Coming Soon',
                    style: Theme.of(context)
                        .textTheme
                        .displayMedium
                        ?.copyWith(height: 1.1),
                    textAlign: TextAlign.center,
                  ),

                  const SizedBox(height: 16),

                  Text(
                    'Something exciting is on the way.\nStay tuned for the next update.',
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          color: AppTheme.pearlDim,
                        ),
                    textAlign: TextAlign.center,
                  ),

                  const SizedBox(height: 48),

                  // TikTok developer card
                  LiquidGlass(
                    borderRadius: 24,
                    animate: true,
                    tint: const Color(0xFFEF5B9A).withOpacity(0.05),
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 48,
                              height: 48,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(14),
                                gradient: const LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [
                                    Color(0xFF010101),
                                    Color(0xFF1A1A2E),
                                  ],
                                ),
                              ),
                              child: const Center(
                                child: Text(
                                  '𝕋',
                                  style: TextStyle(
                                    fontSize: 26,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    loc?.comingSoonTiktok ??
                                        'TikTok Developer: @EDXZVIP',
                                    style: const TextStyle(
                                      color: AppTheme.pearl,
                                      fontSize: 15,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    'Follow for updates & sneak peeks',
                                    style: TextStyle(
                                      color: AppTheme.pearlDim.withOpacity(0.7),
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 32),

                  // Status chips
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    alignment: WrapAlignment.center,
                    children: [
                      _StatusChip(
                          label: 'In Development',
                          color: AppTheme.warning,
                          icon: Icons.code_rounded),
                      _StatusChip(
                          label: 'v2.0 Feature',
                          color: AppTheme.accent,
                          icon: Icons.star_rounded),
                      _StatusChip(
                          label: 'Beta Soon',
                          color: AppTheme.success,
                          icon: Icons.science_rounded),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ConstructionStripes extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _StripePainter(),
    );
  }
}

class _StripePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppTheme.warning.withOpacity(0.03)
      ..strokeWidth = 20
      ..style = PaintingStyle.stroke;

    for (int i = -10; i < 20; i++) {
      final x = i * 20.0;
      canvas.drawLine(
        Offset(x, 0),
        Offset(x + size.height, size.height),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _StatusChip extends StatelessWidget {
  final String label;
  final Color color;
  final IconData icon;

  const _StatusChip({
    required this.label,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.25), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}
