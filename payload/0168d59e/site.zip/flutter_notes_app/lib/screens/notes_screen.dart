import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../utils/app_theme.dart';
import '../utils/app_localizations.dart';
import '../models/note.dart';
import '../services/database_service.dart';
import '../services/auth_service.dart';
import '../widgets/liquid_glass.dart';
import 'note_editor_screen.dart';
import 'auth_screen.dart';

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen>
    with AutomaticKeepAliveClientMixin {
  List<Note> _notes = [];
  List<Note> _filteredNotes = [];
  bool _isLoading = true;
  bool _isSearching = false;
  final TextEditingController _searchController = TextEditingController();

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _loadNotes();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadNotes() async {
    setState(() => _isLoading = true);
    try {
      final notes = await DatabaseService.instance.readAllNotes();
      if (mounted) {
        setState(() {
          _notes = notes;
          _filteredNotes = notes;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _onSearchChanged(String q) {
    final lower = q.toLowerCase();
    setState(() {
      _filteredNotes = q.isEmpty
          ? _notes
          : _notes
              .where((n) =>
                  n.title.toLowerCase().contains(lower) ||
                  n.body.toLowerCase().contains(lower))
              .toList();
    });
  }

  Future<void> _openNote(Note note) async {
    final twoStepEnabled = await AuthService.instance.isTwoStepEnabled;
    if (!mounted) return;

    if (twoStepEnabled) {
      final result = await Navigator.of(context).push<bool>(
        PageRouteBuilder(
          pageBuilder: (_, a1, a2) => PinVerifyScreen(
            onSuccess: () => Navigator.of(context).pop(true),
            onCancel: () => Navigator.of(context).pop(false),
          ),
          transitionsBuilder: (_, anim, __, child) => FadeTransition(
            opacity: anim,
            child: child,
          ),
        ),
      );
      if (result != true || !mounted) return;
    }

    await Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (_, a1, a2) => NoteEditorScreen(note: note),
        transitionsBuilder: (_, anim, __, child) => SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.04),
            end: Offset.zero,
          ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
          child: FadeTransition(opacity: anim, child: child),
        ),
      ),
    );
    _loadNotes();
  }

  Future<void> _addNote() async {
    await Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (_, a1, a2) => const NoteEditorScreen(),
        transitionsBuilder: (_, anim, __, child) => SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.08),
            end: Offset.zero,
          ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
          child: FadeTransition(opacity: anim, child: child),
        ),
      ),
    );
    _loadNotes();
  }

  Future<void> _deleteNote(Note note) async {
    await DatabaseService.instance.deleteNote(note.id!);
    HapticFeedback.mediumImpact();
    _loadNotes();
  }

  Future<void> _togglePin(Note note) async {
    await DatabaseService.instance.togglePin(note);
    _loadNotes();
  }

  void _showNoteOptions(BuildContext context, Note note) {
    final loc = AppLocalizations.of(context);
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _NoteOptionsSheet(
        note: note,
        loc: loc,
        onEdit: () {
          Navigator.of(ctx).pop();
          _openNote(note);
        },
        onDelete: () {
          Navigator.of(ctx).pop();
          _confirmDelete(context, note);
        },
        onTogglePin: () {
          Navigator.of(ctx).pop();
          _togglePin(note);
        },
      ),
    );
  }

  Future<void> _confirmDelete(BuildContext context, Note note) async {
    final loc = AppLocalizations.of(context);
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => _DeleteDialog(loc: loc),
    );
    if (confirmed == true) _deleteNote(note);
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final loc = AppLocalizations.of(context);

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            // Header
            _buildHeader(loc),
            // Search
            _buildSearchBar(loc),
            // Notes list
            Expanded(
              child: _isLoading
                  ? const Center(
                      child: CircularProgressIndicator(color: AppTheme.accent))
                  : _filteredNotes.isEmpty
                      ? _buildEmptyState(loc)
                      : _buildNotesList(loc),
            ),
          ],
        ),
      ),
      floatingActionButton: _buildFAB(loc),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }

  Widget _buildHeader(AppLocalizations? loc) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 8),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                loc?.notes ?? 'Notes',
                style: Theme.of(context).textTheme.headlineLarge,
              ),
              Text(
                '${_notes.length} ${_notes.length == 1 ? 'note' : 'notes'}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar(AppLocalizations? loc) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 4, 24, 16),
      child: Container(
        decoration: BoxDecoration(
          color: AppTheme.surfaceElevated,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _isSearching
                ? AppTheme.accent.withOpacity(0.4)
                : const Color(0xFF1E2A48),
            width: 1,
          ),
        ),
        child: TextField(
          controller: _searchController,
          onChanged: _onSearchChanged,
          onTap: () => setState(() => _isSearching = true),
          onEditingComplete: () => setState(() => _isSearching = false),
          style: const TextStyle(color: AppTheme.pearl, fontSize: 15),
          decoration: InputDecoration(
            hintText: loc?.searchNotes ?? 'Search notes...',
            hintStyle: const TextStyle(color: AppTheme.pearlDim, fontSize: 15),
            prefixIcon: const Icon(Icons.search_rounded,
                color: AppTheme.pearlDim, size: 20),
            suffixIcon: _searchController.text.isNotEmpty
                ? GestureDetector(
                    onTap: () {
                      _searchController.clear();
                      _onSearchChanged('');
                      setState(() => _isSearching = false);
                    },
                    child: const Icon(Icons.close_rounded,
                        color: AppTheme.pearlDim, size: 18),
                  )
                : null,
            border: InputBorder.none,
            enabledBorder: InputBorder.none,
            focusedBorder: InputBorder.none,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          ),
        ),
      ),
    );
  }

  Widget _buildNotesList(AppLocalizations? loc) {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(24, 0, 24, 120),
      itemCount: _filteredNotes.length,
      itemBuilder: (context, i) {
        final note = _filteredNotes[i];
        return _NoteCard(
          note: note,
          onTap: () => _openNote(note),
          onOptionsTap: () => _showNoteOptions(context, note),
          key: ValueKey(note.id),
        );
      },
    );
  }

  Widget _buildEmptyState(AppLocalizations? loc) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            LiquidGlass(
              borderRadius: 32,
              width: 96,
              height: 96,
              animate: true,
              padding: const EdgeInsets.all(24),
              child: const Icon(
                Icons.edit_note_rounded,
                size: 44,
                color: AppTheme.pearlDim,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              loc?.noNotes ?? 'No notes yet',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    color: AppTheme.pearlDim,
                  ),
            ),
            const SizedBox(height: 8),
            Text(
              loc?.noNotesSub ?? 'Tap + to create your first note',
              style: Theme.of(context).textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFAB(AppLocalizations? loc) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 80),
      child: GestureDetector(
        onTap: _addNote,
        child: LiquidGlass(
          borderRadius: 20,
          width: 58,
          height: 58,
          animate: true,
          tint: AppTheme.accent.withOpacity(0.15),
          child: const Icon(
            Icons.add_rounded,
            color: AppTheme.pearl,
            size: 28,
          ),
        ),
      ),
    );
  }
}

class _NoteCard extends StatefulWidget {
  final Note note;
  final VoidCallback onTap;
  final VoidCallback onOptionsTap;

  const _NoteCard({
    required this.note,
    required this.onTap,
    required this.onOptionsTap,
    super.key,
  });

  @override
  State<_NoteCard> createState() => _NoteCardState();
}

class _NoteCardState extends State<_NoteCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final note = widget.note;
    final cardColors = [
      const Color(0xFF0F1830),
      const Color(0xFF0F1E20),
      const Color(0xFF1A0F24),
      const Color(0xFF1A180F),
    ];
    final accentColors = [
      AppTheme.accent,
      const Color(0xFF5BEFB8),
      const Color(0xFFBF5BEF),
      const Color(0xFFEFC15B),
    ];
    final colorIndex = (note.id ?? 0) % 4;
    final cardColor = cardColors[colorIndex];
    final accentColor = accentColors[colorIndex];

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: widget.onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        margin: const EdgeInsets.only(bottom: 12),
        transform: Matrix4.identity()..scale(_pressed ? 0.97 : 1.0),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: accentColor.withOpacity(0.15),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: accentColor.withOpacity(0.05),
              blurRadius: 16,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Left accent bar
              Container(
                width: 3,
                height: 48,
                margin: const EdgeInsets.only(right: 16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      accentColor,
                      accentColor.withOpacity(0.2),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              // Content
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        if (note.isPinned) ...[
                          Icon(
                            Icons.push_pin_rounded,
                            size: 14,
                            color: accentColor.withOpacity(0.7),
                          ),
                          const SizedBox(width: 4),
                        ],
                        Expanded(
                          child: Text(
                            note.title,
                            style: const TextStyle(
                              color: AppTheme.pearl,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              letterSpacing: -0.2,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    if (note.preview.isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Text(
                        note.preview,
                        style: const TextStyle(
                          color: AppTheme.pearlDim,
                          fontSize: 13.5,
                          height: 1.5,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                    const SizedBox(height: 10),
                    Text(
                      note.formattedDate,
                      style: TextStyle(
                        color: accentColor.withOpacity(0.6),
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              // Edit icon
              GestureDetector(
                onTap: widget.onOptionsTap,
                child: Padding(
                  padding: const EdgeInsets.only(left: 12, top: 2),
                  child: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: accentColor.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: accentColor.withOpacity(0.15),
                      ),
                    ),
                    child: Icon(
                      Icons.edit_rounded,
                      size: 16,
                      color: accentColor.withOpacity(0.8),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NoteOptionsSheet extends StatelessWidget {
  final Note note;
  final AppLocalizations? loc;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onTogglePin;

  const _NoteOptionsSheet({
    required this.note,
    required this.loc,
    required this.onEdit,
    required this.onDelete,
    required this.onTogglePin,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(16),
      child: LiquidGlass(
        borderRadius: 28,
        animate: false,
        blur: 24,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 8),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      note.title,
                      style: Theme.of(context).textTheme.titleLarge,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  GestureDetector(
                    onTap: () => Navigator.of(context).pop(),
                    child: Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: AppTheme.surfaceElevated,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.close_rounded,
                          size: 16, color: AppTheme.pearlDim),
                    ),
                  ),
                ],
              ),
            ),
            const Divider(color: Color(0xFF1E2A48), thickness: 0.5),
            _SheetOption(
              icon: Icons.edit_outlined,
              label: loc?.edit ?? 'Edit',
              color: AppTheme.accent,
              onTap: onEdit,
            ),
            _SheetOption(
              icon: note.isPinned
                  ? Icons.push_pin_outlined
                  : Icons.push_pin_rounded,
              label: note.isPinned
                  ? (loc?.unpinNote ?? 'Unpin Note')
                  : (loc?.pinNote ?? 'Pin Note'),
              color: const Color(0xFFEFC15B),
              onTap: onTogglePin,
            ),
            _SheetOption(
              icon: Icons.delete_outline_rounded,
              label: loc?.delete ?? 'Delete',
              color: AppTheme.danger,
              onTap: onDelete,
            ),
            SizedBox(
              height: MediaQuery.of(context).padding.bottom + 16,
            ),
          ],
        ),
      ),
    );
  }
}

class _SheetOption extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _SheetOption({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 16),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 15,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DeleteDialog extends StatelessWidget {
  final AppLocalizations? loc;

  const _DeleteDialog({required this.loc});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: LiquidGlass(
        borderRadius: 24,
        blur: 20,
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.delete_forever_rounded,
              color: AppTheme.danger,
              size: 48,
            ),
            const SizedBox(height: 16),
            Text(
              loc?.deleteConfirm ?? 'Delete this note?',
              style: Theme.of(context).textTheme.headlineSmall,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              loc?.deleteConfirmMsg ?? 'This action cannot be undone.',
              style: Theme.of(context).textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: () => Navigator.of(context).pop(false),
                    child: Text(
                      loc?.cancel ?? 'Cancel',
                      style: const TextStyle(color: AppTheme.pearlDim),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Navigator.of(context).pop(true),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.danger,
                    ),
                    child: Text(loc?.delete ?? 'Delete'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
