import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../utils/app_theme.dart';
import '../utils/app_localizations.dart';
import '../services/auth_service.dart';
import '../widgets/liquid_glass.dart';
import 'home_screen.dart';

class AuthScreen extends StatefulWidget {
  final String nextRoute;

  const AuthScreen({super.key, required this.nextRoute});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _shakeController;
  late Animation<double> _shakeAnim;
  bool _isAuthenticating = false;
  String _error = '';

  @override
  void initState() {
    super.initState();
    _shakeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _shakeAnim = Tween<double>(begin: 0, end: 1).animate(_shakeController);

    WidgetsBinding.instance.addPostFrameCallback((_) => _authenticate());
  }

  @override
  void dispose() {
    _shakeController.dispose();
    super.dispose();
  }

  Future<void> _authenticate() async {
    if (_isAuthenticating) return;
    setState(() {
      _isAuthenticating = true;
      _error = '';
    });

    final success = await AuthService.instance.authenticateWithBiometrics(
      reason: 'Authenticate to access Liquid Notes',
    );

    if (!mounted) return;

    if (success) {
      _navigateNext();
    } else {
      setState(() {
        _isAuthenticating = false;
        _error = 'Authentication failed';
      });
      HapticFeedback.heavyImpact();
      _shakeController.forward(from: 0);
    }
  }

  void _navigateNext() {
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, a1, a2) => const HomeScreen(),
        transitionsBuilder: (_, anim, __, child) => FadeTransition(
          opacity: anim,
          child: child,
        ),
        transitionDuration: const Duration(milliseconds: 400),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: Stack(
        children: [
          // Background orbs
          Positioned(
            top: -size.height * 0.1,
            right: -size.width * 0.2,
            child: Container(
              width: size.width * 0.7,
              height: size.width * 0.7,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppTheme.accent.withOpacity(0.08),
              ),
            ),
          ),
          Positioned(
            bottom: -size.height * 0.05,
            left: -size.width * 0.2,
            child: Container(
              width: size.width * 0.6,
              height: size.width * 0.6,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFFBF5BEF).withOpacity(0.06),
              ),
            ),
          ),
          // Content
          Center(
            child: AnimatedBuilder(
              animation: _shakeAnim,
              builder: (context, child) {
                final offset = _shakeAnim.value == 0
                    ? 0.0
                    : 12 *
                        (0.5 - (_shakeAnim.value * 3).clamp(0, 1).abs()) *
                        ((_shakeAnim.value * 8).toInt() % 2 == 0 ? 1 : -1);
                return Transform.translate(
                  offset: Offset(offset, 0),
                  child: child,
                );
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Lock icon with glow
                    _buildLockIcon(),
                    const SizedBox(height: 40),

                    Text(
                      loc?.authRequired ?? 'Authentication Required',
                      style: Theme.of(context).textTheme.headlineMedium,
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      loc?.biometricDesc ??
                          'Verify your identity to continue',
                      style: Theme.of(context).textTheme.bodyMedium,
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 48),

                    // Auth button
                    LiquidGlassButton(
                      onPressed: _isAuthenticating ? null : _authenticate,
                      accentColor: AppTheme.accent,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          if (_isAuthenticating)
                            const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: AppTheme.pearl,
                              ),
                            )
                          else
                            const Icon(
                              Icons.fingerprint_rounded,
                              color: AppTheme.pearl,
                              size: 22,
                            ),
                          const SizedBox(width: 12),
                          Text(
                            _isAuthenticating ? 'Authenticating...' : 'Unlock',
                            style: const TextStyle(
                              color: AppTheme.pearl,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),

                    if (_error.isNotEmpty) ...[
                      const SizedBox(height: 24),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 10),
                        decoration: BoxDecoration(
                          color: AppTheme.danger.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: AppTheme.danger.withOpacity(0.3),
                          ),
                        ),
                        child: Text(
                          _error,
                          style: const TextStyle(
                            color: AppTheme.danger,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLockIcon() {
    return LiquidGlass(
      borderRadius: 32,
      width: 120,
      height: 120,
      animate: true,
      padding: const EdgeInsets.all(28),
      child: const Icon(
        Icons.lock_rounded,
        size: 52,
        color: AppTheme.accent,
      ),
    );
  }
}

/// Two-step PIN verification screen
class PinVerifyScreen extends StatefulWidget {
  final VoidCallback onSuccess;
  final VoidCallback? onCancel;

  const PinVerifyScreen({
    super.key,
    required this.onSuccess,
    this.onCancel,
  });

  @override
  State<PinVerifyScreen> createState() => _PinVerifyScreenState();
}

class _PinVerifyScreenState extends State<PinVerifyScreen>
    with SingleTickerProviderStateMixin {
  final List<String> _enteredDigits = [];
  bool _hasError = false;
  late AnimationController _shakeController;

  @override
  void initState() {
    super.initState();
    _shakeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
  }

  @override
  void dispose() {
    _shakeController.dispose();
    super.dispose();
  }

  void _addDigit(String digit) {
    if (_enteredDigits.length >= 6) return;
    setState(() {
      _enteredDigits.add(digit);
      _hasError = false;
    });
    if (_enteredDigits.length == 6) {
      _verify();
    }
  }

  void _removeDigit() {
    if (_enteredDigits.isEmpty) return;
    setState(() => _enteredDigits.removeLast());
  }

  Future<void> _verify() async {
    final pin = _enteredDigits.join();
    final correct = await AuthService.instance.verifyTwoStepPin(pin);
    if (!mounted) return;

    if (correct) {
      widget.onSuccess();
    } else {
      HapticFeedback.heavyImpact();
      setState(() {
        _hasError = true;
        _enteredDigits.clear();
      });
      _shakeController.forward(from: 0);
    }
  }

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        leading: widget.onCancel != null
            ? IconButton(
                icon: const Icon(Icons.close_rounded),
                onPressed: widget.onCancel,
              )
            : null,
        backgroundColor: Colors.transparent,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            children: [
              const SizedBox(height: 40),
              const Icon(
                Icons.lock_outline_rounded,
                size: 52,
                color: AppTheme.accent,
              ),
              const SizedBox(height: 20),
              Text(
                loc?.enterPin ?? 'Enter PIN',
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              const SizedBox(height: 8),
              Text(
                loc?.twoStepDesc ?? 'Enter your 6-digit PIN to continue',
                style: Theme.of(context).textTheme.bodyMedium,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 48),
              // PIN dots
              AnimatedBuilder(
                animation: _shakeController,
                builder: (context, child) {
                  final shake = _hasError
                      ? 10 *
                          (0.5 -
                              (_shakeController.value * 3).clamp(0, 1).abs()) *
                          ((_shakeController.value * 8).toInt() % 2 == 0
                              ? 1
                              : -1)
                      : 0.0;
                  return Transform.translate(
                    offset: Offset(shake, 0),
                    child: child,
                  );
                },
                child: _PinDots(
                  count: 6,
                  filled: _enteredDigits.length,
                  hasError: _hasError,
                ),
              ),
              if (_hasError) ...[
                const SizedBox(height: 12),
                Text(
                  loc?.pinIncorrect ?? 'Incorrect PIN',
                  style: const TextStyle(
                    color: AppTheme.danger,
                    fontSize: 14,
                  ),
                ),
              ],
              const Spacer(),
              // Numpad
              _NumPad(
                onDigit: _addDigit,
                onDelete: _removeDigit,
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }
}

class _PinDots extends StatelessWidget {
  final int count;
  final int filled;
  final bool hasError;

  const _PinDots({
    required this.count,
    required this.filled,
    required this.hasError,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(count, (i) {
        final isFilled = i < filled;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          margin: const EdgeInsets.symmetric(horizontal: 10),
          width: 16,
          height: 16,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: hasError
                ? AppTheme.danger
                : isFilled
                    ? AppTheme.accent
                    : AppTheme.surfaceElevated,
            border: Border.all(
              color: hasError
                  ? AppTheme.danger.withOpacity(0.5)
                  : isFilled
                      ? AppTheme.accent
                      : AppTheme.pearlDim.withOpacity(0.3),
              width: 1.5,
            ),
          ),
        );
      }),
    );
  }
}

class _NumPad extends StatelessWidget {
  final void Function(String) onDigit;
  final VoidCallback onDelete;

  const _NumPad({required this.onDigit, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    final digits = [
      ['1', '2', '3'],
      ['4', '5', '6'],
      ['7', '8', '9'],
      ['', '0', 'del'],
    ];
    return Column(
      children: digits.map((row) {
        return Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: row.map((key) {
            if (key.isEmpty) return const SizedBox(width: 80, height: 80);
            if (key == 'del') {
              return _NumKey(
                label: const Icon(Icons.backspace_outlined,
                    size: 22, color: AppTheme.pearlDim),
                onTap: () => onDelete(),
              );
            }
            return _NumKey(
              label: Text(
                key,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w500,
                    ),
              ),
              onTap: () => onDigit(key),
            );
          }).toList(),
        );
      }).toList(),
    );
  }
}

class _NumKey extends StatefulWidget {
  final Widget label;
  final VoidCallback onTap;

  const _NumKey({required this.label, required this.onTap});

  @override
  State<_NumKey> createState() => _NumKeyState();
}

class _NumKeyState extends State<_NumKey> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) {
        setState(() => _pressed = true);
        HapticFeedback.lightImpact();
      },
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: widget.onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        width: 80,
        height: 80,
        margin: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _pressed
              ? AppTheme.accent.withOpacity(0.2)
              : AppTheme.surfaceElevated,
          border: Border.all(
            color: _pressed
                ? AppTheme.accent.withOpacity(0.4)
                : AppTheme.surfaceElevated,
          ),
        ),
        child: Center(child: widget.label),
      ),
    );
  }
}
