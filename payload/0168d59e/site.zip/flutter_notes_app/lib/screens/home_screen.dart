import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../utils/app_theme.dart';
import '../utils/app_localizations.dart';
import '../widgets/liquid_glass.dart';
import 'notes_screen.dart';
import 'coming_soon_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with TickerProviderStateMixin {
  int _currentIndex = 0;
  bool _isNavGlassMode = false;
  double _navDragStart = 0;
  int _tempGlassIndex = 0;

  late AnimationController _navMorphController;
  late Animation<double> _navMorphAnim;
  late AnimationController _pageController;
  late Animation<double> _pageFadeAnim;

  final List<Widget> _screens = const [
    NotesScreen(),
    ComingSoonScreen(),
    SettingsScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _navMorphController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 350),
    );
    _navMorphAnim = CurvedAnimation(
      parent: _navMorphController,
      curve: Curves.easeOutCubic,
    );
    _pageController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
      value: 1.0,
    );
    _pageFadeAnim = CurvedAnimation(
      parent: _pageController,
      curve: Curves.easeOut,
    );
  }

  @override
  void dispose() {
    _navMorphController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _switchTab(int index) async {
    if (index == _currentIndex) return;
    HapticFeedback.selectionClick();

    await _pageController.animateTo(0,
        duration: const Duration(milliseconds: 120), curve: Curves.easeIn);
    setState(() => _currentIndex = index);
    await _pageController.animateTo(1,
        duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
  }

  void _onNavLongPress(int index) {
    HapticFeedback.mediumImpact();
    setState(() {
      _isNavGlassMode = true;
      _tempGlassIndex = index;
    });
    _navMorphController.forward();
  }

  void _onNavLongPressEnd() {
    _navMorphController.reverse().then((_) {
      if (mounted) {
        setState(() => _isNavGlassMode = false);
      }
    });
  }

  void _onNavDragStart(double x) {
    _navDragStart = x;
  }

  void _onNavDragUpdate(double x) {
    if (!_isNavGlassMode) return;
    final delta = x - _navDragStart;
    final screenWidth = MediaQuery.of(context).size.width;
    final step = screenWidth / 3;

    if (delta > step * 0.4 && _tempGlassIndex < 2) {
      setState(() => _tempGlassIndex = (_tempGlassIndex + 1).clamp(0, 2));
      _navDragStart = x;
      HapticFeedback.selectionClick();
    } else if (delta < -step * 0.4 && _tempGlassIndex > 0) {
      setState(() => _tempGlassIndex = (_tempGlassIndex - 1).clamp(0, 2));
      _navDragStart = x;
      HapticFeedback.selectionClick();
    }
  }

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);

    return Scaffold(
      backgroundColor: AppTheme.background,
      extendBody: true,
      body: FadeTransition(
        opacity: _pageFadeAnim,
        child: IndexedStack(
          index: _currentIndex,
          children: _screens,
        ),
      ),
      bottomNavigationBar: _buildNavBar(loc),
    );
  }

  Widget _buildNavBar(AppLocalizations? loc) {
    final labels = [
      loc?.notes ?? 'Notes',
      loc?.comingSoon ?? 'Soon',
      loc?.settings ?? 'Settings',
    ];
    final icons = [
      Icons.notes_rounded,
      Icons.explore_outlined,
      Icons.settings_outlined,
    ];
    final activeIcons = [
      Icons.notes_rounded,
      Icons.explore_rounded,
      Icons.settings_rounded,
    ];

    return GestureDetector(
      onHorizontalDragStart: (d) => _onNavDragStart(d.globalPosition.dx),
      onHorizontalDragUpdate: (d) => _onNavDragUpdate(d.globalPosition.dx),
      onHorizontalDragEnd: (_) {
        if (_isNavGlassMode) {
          _switchTab(_tempGlassIndex);
          _onNavLongPressEnd();
        }
      },
      child: AnimatedBuilder(
        animation: _navMorphAnim,
        builder: (context, child) {
          return ClipRect(
            child: BackdropFilter(
              filter: ImageFilter.blur(
                sigmaX: 20 * _navMorphAnim.value,
                sigmaY: 20 * _navMorphAnim.value,
              ),
              child: child!,
            ),
          );
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 350),
          curve: Curves.easeOutCubic,
          decoration: BoxDecoration(
            color: _isNavGlassMode
                ? AppTheme.navBackground.withOpacity(0.4)
                : AppTheme.navBackground.withOpacity(0.97),
            border: Border(
              top: BorderSide(
                color: _isNavGlassMode
                    ? AppTheme.glassBorder
                    : AppTheme.navBackground.withOpacity(0.0),
                width: 0.5,
              ),
            ),
          ),
          child: SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: List.generate(3, (i) {
                  final isActive = _currentIndex == i;
                  final isGlassActive = _isNavGlassMode && _tempGlassIndex == i;
                  final color = isActive ? AppTheme.navActive : AppTheme.navInactive;

                  return GestureDetector(
                    onTap: () => _switchTab(i),
                    onLongPressStart: (_) => _onNavLongPress(i),
                    onLongPressEnd: (_) {
                      if (!_isNavGlassMode) return;
                      _switchTab(_tempGlassIndex);
                      _onNavLongPressEnd();
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 350),
                      curve: Curves.easeOutCubic,
                      padding: EdgeInsets.symmetric(
                        horizontal: isActive ? 18 : 14,
                        vertical: 10,
                      ),
                      decoration: isGlassActive
                          ? BoxDecoration(
                              borderRadius: BorderRadius.circular(22),
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  AppTheme.accent.withOpacity(0.35),
                                  AppTheme.accent.withOpacity(0.12),
                                ],
                              ),
                              border: Border.all(
                                color: AppTheme.accent.withOpacity(0.6),
                                width: 1.0,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: AppTheme.accent.withOpacity(0.35),
                                  blurRadius: 18,
                                  spreadRadius: 1,
                                ),
                              ],
                            )
                          : BoxDecoration(
                              borderRadius: BorderRadius.circular(18),
                              color: isActive
                                  ? AppTheme.navActive.withOpacity(0.14)
                                  : Colors.transparent,
                            ),
                      child: AnimatedSize(
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeOutCubic,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            AnimatedSwitcher(
                              duration: const Duration(milliseconds: 200),
                              child: Icon(
                                isActive ? activeIcons[i] : icons[i],
                                key: ValueKey(isActive),
                                color: isGlassActive
                                    ? Colors.white
                                    : isActive
                                        ? AppTheme.navActive
                                        : AppTheme.navInactive,
                                size: 22,
                              ),
                            ),
                            if (isActive && !_isNavGlassMode) ...[
                              const SizedBox(width: 6),
                              Text(
                                labels[i],
                                style: TextStyle(
                                  color: AppTheme.navActive,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                            if (isGlassActive) ...[
                              const SizedBox(width: 6),
                              Text(
                                labels[i],
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
