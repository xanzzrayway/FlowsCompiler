import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../utils/app_theme.dart';
import '../utils/app_localizations.dart';
import '../services/auth_service.dart';
import '../widgets/liquid_glass.dart';
import '../main.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen>
    with AutomaticKeepAliveClientMixin {
  String _displayName = 'User';
  bool _appLockEnabled = false;
  bool _twoStepEnabled = false;
  bool _privacyExpanded = false;
  bool _isLoadingAuth = false;

  static const List<Map<String, String>> _languages = [
    {'code': 'en', 'label': 'English', 'native': 'English'},
    {'code': 'id', 'label': 'Indonesian', 'native': 'Bahasa Indonesia'},
    {'code': 'ms', 'label': 'Malay', 'native': 'Bahasa Melayu'},
    {'code': 'zh', 'label': 'Chinese (Simplified)', 'native': '简体中文'},
    {'code': 'ru', 'label': 'Russian', 'native': 'Русский'},
  ];

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final name = await AuthService.instance.getDisplayName();
    final appLock = await AuthService.instance.isAppLockEnabled;
    final twoStep = await AuthService.instance.isTwoStepEnabled;
    if (mounted) {
      setState(() {
        _displayName = name;
        _appLockEnabled = appLock;
        _twoStepEnabled = twoStep;
      });
    }
  }

  Future<void> _toggleAppLock(bool value) async {
    if (_isLoadingAuth) return;

    if (value) {
      // Check device support first
      final supported = await AuthService.instance.isDeviceSupported();
      if (!supported) {
        if (mounted) {
          _showSnack('Device does not support biometric/screen lock', isError: true);
        }
        return;
      }
      // Require auth before enabling
      setState(() => _isLoadingAuth = true);
      final ok = await AuthService.instance.authenticateWithBiometrics(
        reason: 'Authenticate to enable App Lock',
      );
      setState(() => _isLoadingAuth = false);
      if (!ok) return;
    }

    await AuthService.instance.setAppLockEnabled(value);
    setState(() => _appLockEnabled = value);
    HapticFeedback.selectionClick();
  }

  Future<void> _toggleTwoStep(bool value) async {
    if (value) {
      final hasPIN = await AuthService.instance.hasTwoStepPin();
      if (!hasPIN) {
        await _setupPin();
        return;
      }
    }
    await AuthService.instance.setTwoStepEnabled(value);
    setState(() => _twoStepEnabled = value);
    HapticFeedback.selectionClick();
  }

  Future<void> _setupPin() async {
    final result = await showModalBottomSheet<bool>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _SetPinSheet(
        onPinSet: (pin) async {
          await AuthService.instance.setTwoStepPin(pin);
          await AuthService.instance.setTwoStepEnabled(true);
        },
      ),
    );
    if (result == true) {
      setState(() => _twoStepEnabled = true);
      _showSnack(AppLocalizations.of(context)?.pinSet ?? 'PIN set successfully');
    }
  }

  Future<void> _editDisplayName() async {
    final ctrl = TextEditingController(text: _displayName);
    final loc = AppLocalizations.of(context);
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: LiquidGlass(
          borderRadius: 24,
          blur: 20,
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(loc?.displayName ?? 'Display Name',
                  style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 16),
              TextField(
                controller: ctrl,
                autofocus: true,
                style: const TextStyle(color: AppTheme.pearl),
                decoration: InputDecoration(
                  hintText: 'Your name...',
                  filled: true,
                  fillColor: AppTheme.surfaceElevated,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Navigator.of(ctx).pop(),
                      child: Text(loc?.cancel ?? 'Cancel',
                          style:
                              const TextStyle(color: AppTheme.pearlDim)),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () =>
                          Navigator.of(ctx).pop(ctrl.text.trim()),
                      child: Text(loc?.save ?? 'Save'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    if (result != null && result.isNotEmpty) {
      await AuthService.instance.setDisplayName(result);
      setState(() => _displayName = result);
    }
  }

  void _showLanguagePicker() {
    final loc = AppLocalizations.of(context);
    final currentCode =
        LiquidNotesApp.of(context)?.locale.languageCode ?? 'en';
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _LanguageSheet(
        languages: _languages,
        currentCode: currentCode,
        loc: loc,
        onSelect: (code) {
          LiquidNotesApp.of(context)?.setLocale(code);
          Navigator.of(context).pop();
        },
      ),
    );
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: isError ? AppTheme.danger : AppTheme.success,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final loc = AppLocalizations.of(context);
    final currentLang = _languages.firstWhere(
      (l) => l['code'] == (LiquidNotesApp.of(context)?.locale.languageCode ?? 'en'),
      orElse: () => _languages.first,
    );

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 120),
          children: [
            // Header
            Text(loc?.settings ?? 'Settings',
                style: Theme.of(context).textTheme.headlineLarge),
            const SizedBox(height: 28),

            // ── Profile ──────────────────────────────────────────
            _SectionLabel(label: loc?.profile ?? 'Profile'),
            const SizedBox(height: 12),
            LiquidGlass(
              borderRadius: 20,
              blur: 16,
              child: Padding(
                padding: const EdgeInsets.all(4),
                child: ListTile(
                  onTap: _editDisplayName,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                  leading: CircleAvatar(
                    radius: 24,
                    backgroundColor: AppTheme.accent.withOpacity(0.15),
                    child: Text(
                      _displayName.isNotEmpty
                          ? _displayName[0].toUpperCase()
                          : 'U',
                      style: const TextStyle(
                        color: AppTheme.accent,
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  title: Text(_displayName,
                      style: const TextStyle(
                          color: AppTheme.pearl,
                          fontWeight: FontWeight.w600,
                          fontSize: 16)),
                  subtitle: Text(loc?.displayName ?? 'Display Name',
                      style: const TextStyle(
                          color: AppTheme.pearlDim, fontSize: 13)),
                  trailing: const Icon(Icons.edit_rounded,
                      color: AppTheme.pearlDim, size: 18),
                ),
              ),
            ),

            const SizedBox(height: 24),

            // ── Privacy ───────────────────────────────────────────
            _SectionLabel(label: loc?.privacy ?? 'Privacy'),
            const SizedBox(height: 12),
            LiquidGlass(
              borderRadius: 20,
              blur: 16,
              child: Column(
                children: [
                  // Privacy header (expandable)
                  InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () =>
                        setState(() => _privacyExpanded = !_privacyExpanded),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 16),
                      child: Row(
                        children: [
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: AppTheme.accent.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(Icons.shield_outlined,
                                color: AppTheme.accent, size: 20),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Text(loc?.privacy ?? 'Privacy',
                                style: const TextStyle(
                                    color: AppTheme.pearl,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 15)),
                          ),
                          AnimatedRotation(
                            turns: _privacyExpanded ? 0.5 : 0,
                            duration: const Duration(milliseconds: 250),
                            child: const Icon(Icons.expand_more_rounded,
                                color: AppTheme.pearlDim),
                          ),
                        ],
                      ),
                    ),
                  ),
                  // Expanded content
                  AnimatedCrossFade(
                    firstChild: const SizedBox.shrink(),
                    secondChild: Column(
                      children: [
                        const Divider(
                            color: Color(0xFF1A2240), thickness: 0.5,
                            indent: 20, endIndent: 20),
                        // App Lock
                        Padding(
                          padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
                          child: Row(
                            children: [
                              Container(
                                width: 36,
                                height: 36,
                                decoration: BoxDecoration(
                                  color:
                                      AppTheme.success.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: _isLoadingAuth
                                    ? const Padding(
                                        padding: EdgeInsets.all(8),
                                        child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                            color: AppTheme.success),
                                      )
                                    : const Icon(
                                        Icons.fingerprint_rounded,
                                        color: AppTheme.success,
                                        size: 18,
                                      ),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(loc?.appLock ?? 'App Lock',
                                        style: const TextStyle(
                                            color: AppTheme.pearl,
                                            fontWeight: FontWeight.w500,
                                            fontSize: 14)),
                                    Text(
                                        loc?.appLockDesc ??
                                            'Require auth on open',
                                        style: const TextStyle(
                                            color: AppTheme.pearlDim,
                                            fontSize: 12)),
                                  ],
                                ),
                              ),
                              Switch(
                                value: _appLockEnabled,
                                onChanged: _toggleAppLock,
                                activeColor: AppTheme.success,
                                activeTrackColor:
                                    AppTheme.success.withOpacity(0.3),
                                inactiveThumbColor: AppTheme.pearlDim,
                                inactiveTrackColor:
                                    AppTheme.surfaceElevated,
                              ),
                            ],
                          ),
                        ),
                        const Divider(
                            color: Color(0xFF1A2240), thickness: 0.5,
                            indent: 20, endIndent: 20),
                        // Two-Step Verification
                        Padding(
                          padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
                          child: Row(
                            children: [
                              Container(
                                width: 36,
                                height: 36,
                                decoration: BoxDecoration(
                                  color:
                                      AppTheme.warning.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: const Icon(Icons.lock_clock_rounded,
                                    color: AppTheme.warning, size: 18),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(loc?.twoStep ?? 'Two-Step',
                                        style: const TextStyle(
                                            color: AppTheme.pearl,
                                            fontWeight: FontWeight.w500,
                                            fontSize: 14)),
                                    Text(
                                        loc?.twoStepDesc ??
                                            'PIN required on note open',
                                        style: const TextStyle(
                                            color: AppTheme.pearlDim,
                                            fontSize: 12)),
                                  ],
                                ),
                              ),
                              Switch(
                                value: _twoStepEnabled,
                                onChanged: _toggleTwoStep,
                                activeColor: AppTheme.warning,
                                activeTrackColor:
                                    AppTheme.warning.withOpacity(0.3),
                                inactiveThumbColor: AppTheme.pearlDim,
                                inactiveTrackColor:
                                    AppTheme.surfaceElevated,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    crossFadeState: _privacyExpanded
                        ? CrossFadeState.showSecond
                        : CrossFadeState.showFirst,
                    duration: const Duration(milliseconds: 300),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // ── Language ──────────────────────────────────────────
            _SectionLabel(label: loc?.language ?? 'Language'),
            const SizedBox(height: 12),
            LiquidGlass(
              borderRadius: 20,
              blur: 16,
              child: Padding(
                padding: const EdgeInsets.all(4),
                child: ListTile(
                  onTap: _showLanguagePicker,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                  leading: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: const Color(0xFFBF5BEF).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.language_rounded,
                        color: Color(0xFFBF5BEF), size: 20),
                  ),
                  title: Text(currentLang['label'] ?? 'English',
                      style: const TextStyle(
                          color: AppTheme.pearl,
                          fontWeight: FontWeight.w600,
                          fontSize: 15)),
                  subtitle: Text(currentLang['native'] ?? '',
                      style: const TextStyle(
                          color: AppTheme.pearlDim, fontSize: 12)),
                  trailing: const Icon(Icons.chevron_right_rounded,
                      color: AppTheme.pearlDim),
                ),
              ),
            ),

            const SizedBox(height: 24),

            // ── App Info ─────────────────────────────────────────
            _SectionLabel(label: 'About'),
            const SizedBox(height: 12),
            LiquidGlass(
              borderRadius: 20,
              blur: 16,
              animate: true,
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          AppTheme.accent,
                          AppTheme.accent.withOpacity(0.5),
                        ],
                      ),
                    ),
                    child: const Icon(Icons.auto_awesome_rounded,
                        color: Colors.white, size: 26),
                  ),
                  const SizedBox(width: 16),
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Liquid Notes',
                          style: TextStyle(
                              color: AppTheme.pearl,
                              fontWeight: FontWeight.w700,
                              fontSize: 16)),
                      SizedBox(height: 2),
                      Text('Version 1.0.0',
                          style: TextStyle(
                              color: AppTheme.pearlDim, fontSize: 13)),
                      Text('by @EDXZVIP',
                          style: TextStyle(
                              color: AppTheme.pearlDim, fontSize: 12)),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4),
      child: Text(
        label.toUpperCase(),
        style: const TextStyle(
          color: AppTheme.pearlDim,
          fontSize: 11,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.4,
        ),
      ),
    );
  }
}

// ─── Set PIN bottom sheet ────────────────────────────────────────────────────

class _SetPinSheet extends StatefulWidget {
  final Future<void> Function(String pin) onPinSet;
  const _SetPinSheet({required this.onPinSet});

  @override
  State<_SetPinSheet> createState() => _SetPinSheetState();
}

class _SetPinSheetState extends State<_SetPinSheet> {
  final List<String> _pin = [];
  final List<String> _confirmPin = [];
  bool _isConfirming = false;
  bool _hasError = false;
  bool _isSaving = false;

  List<String> get _current => _isConfirming ? _confirmPin : _pin;

  void _addDigit(String d) {
    if (_current.length >= 6) return;
    setState(() {
      _current.add(d);
      _hasError = false;
    });
    if (_current.length == 6) {
      if (_isConfirming) {
        _verify();
      } else {
        Future.delayed(const Duration(milliseconds: 150), () {
          if (mounted) setState(() => _isConfirming = true);
        });
      }
    }
  }

  void _removeDigit() {
    if (_current.isEmpty) return;
    setState(() => _current.removeLast());
  }

  Future<void> _verify() async {
    if (_pin.join() != _confirmPin.join()) {
      HapticFeedback.heavyImpact();
      setState(() {
        _hasError = true;
        _confirmPin.clear();
      });
      return;
    }
    setState(() => _isSaving = true);
    await widget.onPinSet(_pin.join());
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);
    return Container(
      margin: const EdgeInsets.all(16),
      child: LiquidGlass(
        borderRadius: 28,
        blur: 24,
        child: Padding(
          padding: EdgeInsets.only(
            left: 24,
            right: 24,
            top: 24,
            bottom: MediaQuery.of(context).padding.bottom + 16,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Handle bar
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppTheme.pearlDim.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 24),
              Text(
                _isConfirming
                    ? (loc?.confirmPin ?? 'Confirm PIN')
                    : (loc?.setPin ?? 'Set PIN'),
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 8),
              Text(
                _isConfirming
                    ? 'Re-enter your 6-digit PIN'
                    : 'Choose a 6-digit PIN for notes',
                style: Theme.of(context).textTheme.bodyMedium,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),
              // PIN dots
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(6, (i) {
                  final filled = i < _current.length;
                  return AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    width: 16,
                    height: 16,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _hasError
                          ? AppTheme.danger
                          : filled
                              ? AppTheme.accent
                              : AppTheme.surfaceElevated,
                      border: Border.all(
                        color: _hasError
                            ? AppTheme.danger.withOpacity(0.5)
                            : filled
                                ? AppTheme.accent
                                : AppTheme.pearlDim.withOpacity(0.3),
                        width: 1.5,
                      ),
                    ),
                  );
                }),
              ),
              if (_hasError) ...[
                const SizedBox(height: 12),
                Text(
                  loc?.pinMismatch ?? 'PINs do not match. Try again.',
                  style: const TextStyle(color: AppTheme.danger, fontSize: 13),
                  textAlign: TextAlign.center,
                ),
              ],
              const SizedBox(height: 32),
              // Numpad
              ...[
                ['1', '2', '3'],
                ['4', '5', '6'],
                ['7', '8', '9'],
                ['', '0', 'del'],
              ].map((row) => Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: row.map((key) {
                      if (key.isEmpty) {
                        return const SizedBox(width: 72, height: 72);
                      }
                      return _PinKey(
                        label: key == 'del'
                            ? const Icon(Icons.backspace_outlined,
                                size: 20, color: AppTheme.pearlDim)
                            : Text(key,
                                style: const TextStyle(
                                    color: AppTheme.pearl,
                                    fontSize: 22,
                                    fontWeight: FontWeight.w500)),
                        onTap: () =>
                            key == 'del' ? _removeDigit() : _addDigit(key),
                      );
                    }).toList(),
                  )),
              if (_isSaving)
                const Padding(
                  padding: EdgeInsets.only(top: 16),
                  child: CircularProgressIndicator(color: AppTheme.accent),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PinKey extends StatefulWidget {
  final Widget label;
  final VoidCallback onTap;
  const _PinKey({required this.label, required this.onTap});

  @override
  State<_PinKey> createState() => _PinKeyState();
}

class _PinKeyState extends State<_PinKey> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) {
        setState(() => _pressed = true);
        HapticFeedback.lightImpact();
      },
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: widget.onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 100),
        width: 72,
        height: 72,
        margin: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _pressed
              ? AppTheme.accent.withOpacity(0.2)
              : AppTheme.surfaceElevated,
        ),
        child: Center(child: widget.label),
      ),
    );
  }
}

// ─── Language picker sheet ───────────────────────────────────────────────────

class _LanguageSheet extends StatelessWidget {
  final List<Map<String, String>> languages;
  final String currentCode;
  final AppLocalizations? loc;
  final void Function(String) onSelect;

  const _LanguageSheet({
    required this.languages,
    required this.currentCode,
    required this.loc,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(16),
      child: LiquidGlass(
        borderRadius: 28,
        blur: 24,
        child: Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).padding.bottom + 16,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 12),
                child: Row(
                  children: [
                    Text(loc?.language ?? 'Language',
                        style: Theme.of(context).textTheme.headlineSmall),
                    const Spacer(),
                    GestureDetector(
                      onTap: () => Navigator.of(context).pop(),
                      child: Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: AppTheme.surfaceElevated,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.close_rounded,
                            size: 16, color: AppTheme.pearlDim),
                      ),
                    ),
                  ],
                ),
              ),
              const Divider(color: Color(0xFF1A2240), thickness: 0.5),
              ...languages.map((lang) {
                final isSelected = lang['code'] == currentCode;
                return InkWell(
                  onTap: () => onSelect(lang['code']!),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24, vertical: 14),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                lang['label']!,
                                style: TextStyle(
                                  color: isSelected
                                      ? AppTheme.accent
                                      : AppTheme.pearl,
                                  fontWeight: isSelected
                                      ? FontWeight.w600
                                      : FontWeight.w400,
                                  fontSize: 15,
                                ),
                              ),
                              Text(
                                lang['native']!,
                                style: TextStyle(
                                  color: isSelected
                                      ? AppTheme.accent.withOpacity(0.7)
                                      : AppTheme.pearlDim,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (isSelected)
                          const Icon(Icons.check_circle_rounded,
                              color: AppTheme.accent, size: 20),
                      ],
                    ),
                  ),
                );
              }),
            ],
          ),
        ),
      ),
    );
  }
}
