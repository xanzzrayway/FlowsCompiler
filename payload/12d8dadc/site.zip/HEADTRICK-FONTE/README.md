# HEADTRICK 7XIS — reconstrução editável

Projeto Android em Java criado a partir de inspeção do APK fornecido. **Não é o código-fonte original** nem preserva login, serviços, assinatura ou a identidade do aplicativo instalado. O aplicativo gerado usa pacote próprio `com.headtrick.recriado`.

## O que foi identificado no APK

- Tela principal preta/vermelha, logotipo, abas **Auxílios** e **Visão Geral**.
- Cartões: “Não passar da cabeça”, “Ativar modo 120 FPS”, “Calibrar sensibilidade”, “Desativar mira trêmula” e “Alterar resolução”.
- Comandos embutidos relacionados a `settings put` para taxa de atualização, animações e tempos de toque, além de `wm size`/`wm density`.

## Esta reconstrução

- Replica a organização visual e acrescenta a aba **Otimizador**.
- Permite escolher e copiar comandos ADB. **O app não executa esses comandos** e não relata que aplicou ajustes.
- `optimizer-adb.sh` traz ações independentes para Android 8–15 e uma opção para restaurar configurações comuns. Rode cada opção explicitamente com ADB autorizado.
- Recursos de mira foram apresentados como indisponíveis: seu comportamento não foi recuperado. Nenhum controle simula alteração de mira.
- Foram omitidas propriedades `ro.*` imutáveis sem root, desligamento térmico, desativação de serviços, supressão de logs e ajustes por fabricante sem comprovação de compatibilidade.

## Abrir

Abra esta pasta no Android Studio, instale o SDK Android 35 e sincronize o Gradle. Em seguida execute o módulo `app`. O projeto não inclui a chave de assinatura original. A compilação não foi testada neste ambiente, que não dispõe do Android SDK.

## Script

```sh
adb push optimizer-adb.sh /sdcard/optimizer-adb.sh
adb shell sh /sdcard/optimizer-adb.sh info
adb shell sh /sdcard/optimizer-adb.sh animacoes
adb shell sh /sdcard/optimizer-adb.sh restaurar
```

As opções `fps120`, `dns` e `limpar` são executadas do mesmo modo. Veja comentários no script.

## Resolução e FPS: Free Fire e Free Fire MAX

A aba **Jogos** copia comandos ADB para estes arquivos. Execute os comandos no terminal do computador, estando no diretório dos scripts (não dentro de `adb shell`):

```sh
adb devices
adb push resolucao.sh /data/local/tmp/resolucao.sh
adb shell sh /data/local/tmp/resolucao.sh 720
adb shell sh /data/local/tmp/resolucao.sh 1080
adb shell sh /data/local/tmp/resolucao.sh reset
adb push fps_monitor.sh /data/local/tmp/fps_monitor.sh
adb shell sh /data/local/tmp/fps_monitor.sh com.dts.freefireth
adb shell sh /data/local/tmp/fps_monitor.sh com.dts.freefiremax
```

O monitor usa a camada SurfaceFlinger, quando disponível. A taxa exibida é uma estimativa do intervalo mais recente entre quadros, e pode mostrar `--` ou não encontrar a camada conforme a versão do Android. O comando de resolução modifica a tela inteira, não somente o jogo; restaure após jogar. A redução de resolução não garante FPS maior.

## Interface v3.0

Interface atualizada com tema preto/vermelho, cartões escuros arredondados, menu lateral e oito áreas: Início, Desempenho, Tela, Jogos, Rede, Monitor FPS, Ferramentas e Ajuda. O menu mostra o estado do Shizuku e o modelo local do aparelho. A navegação inferior também permite trocar de área. Há atalhos para abrir Free Fire e Free Fire MAX quando instalados, consultar os modos de tela, abrir configurações do Android, solicitar o painel flutuante e copiar comandos ADB. O app continua sem executar ADB diretamente fora da lista permitida pelo Shizuku.

Os elementos de revenda, créditos e geração de chaves mostrados nas referências visuais não fazem parte deste app de otimização e não foram incluídos. A interface não guarda credenciais de API.

## Painel flutuante (35 ações)

Abra a aba **Jogos** e toque em **Abrir painel flutuante**. Autorize “exibir sobre outros apps” no Android. Arraste o topo para mover o painel, arraste o canto inferior para **esticar o próprio painel** e toque em ✕ para fechar. Uma notificação permite retornar ao app ou encerrar o serviço. Dependendo das restrições do aparelho/jogo, a sobreposição pode não aparecer por cima de algumas telas.

As ações 1–20 fazem ajustes/diagnósticos de tela, animações, rede e jogo: com Shizuku autorizado, as operações da lista segura executam no próprio aparelho; sem conexão, as compatíveis copiam comandos para o terminal de um computador via ADB: quatro modos de resolução (720, 900, 1080 e restaurar), DPI 80% e restaurar, indicador de Hz ligado/desligado, taxa 120 Hz/restaurar, quatro velocidades de animação, DNS privado/restaurar, fechar apps em segundo plano, monitor FPS para os dois jogos e `adb devices`. As ações 21–30 **abrem dez telas de configurações** do Android. As ações 31–35 **mostram/copiam cinco informações** locais. O painel não recebe privilégios de ADB automaticamente e não altera a resolução da tela sem que os comandos sejam executados fora do aplicativo.

O modo `dpi80` do `resolucao.sh` calcula a densidade com base na densidade física. Para restaurar tamanho e densidade, use `reset`. Os controles de resolução modificam a exibição de todo o sistema, não apenas de Free Fire ou Free Fire MAX.

A compilação e o comportamento sobre jogos ainda precisam ser testados em um aparelho Android com Android Studio e SDK 35. Não é possível garantir 100% de compatibilidade com todos os fabricantes e versões apenas pela análise do APK e do código-fonte.

## Ativação com Shizuku

O projeto usa `dev.rikka.shizuku:api` e `provider` 13.1.5, pela integração oficial. O ZIP enviado (`Shizuku-13.6.0.zip`) contém o código-fonte do gerenciador; ele não é uma biblioteca pronta para importar nem um APK instalável. O projeto usa a API publicada pelo mantenedor, sem incorporar os fontes do gerenciador.

1. Instale o app Shizuku oficial no telefone, inicie o serviço dentro dele e volte ao HEADTRICK.
2. Em Android 11 ou superior, o Shizuku pode ser iniciado no próprio aparelho com Depuração sem fio; pareie e inicie o serviço conforme as instruções do Shizuku. Em Android 10 e anteriores sem root, é necessário iniciar usando ADB de um computador e repetir após reiniciar o telefone.
3. No HEADTRICK, abra **Jogos** e toque em **Conectar via Shizuku**. Aceite a autorização solicitada para este app.
4. Abra o painel flutuante. As opções permitidas de resolução, DPI, animações, DNS e taxa de atualização tentam executar via Shizuku. Se não houver conexão/autorização, as ações aplicáveis copiam os comandos ADB de reserva. O monitor contínuo de FPS e `adb devices` continuam no computador. O serviço remoto aceita somente os comandos declarados em `ShellUserService.java`; operações com valores físicos desconhecidos ou indisponíveis retornam erro sem alegar sucesso.

A autorização é concedida explicitamente pelo usuário no Shizuku. O UserService aceita somente operações enumeradas no código, não recebe comandos arbitrários. A identidade/alcance depende de como o Shizuku foi iniciado: modo ADB oferece UID shell; modo root exige aparelho com root configurado. A permissão Shizuku não ativa o serviço sozinha.

Para compilar, o Gradle precisa baixar a API oficial pelo Maven Central; faça a sincronização do projeto no Android Studio com acesso à internet. Este ambiente não tem Android SDK/Gradle instalado e não executou a compilação ou uma sessão Shizuku real. Compatibilidade do overlay, permissões e comandos precisa ser confirmada em cada versão/fabricante Android.

### Créditos e licença

Integração da API Shizuku (`dev.rikka.shizuku`) conforme a documentação oficial do projeto RikkaApps; consulte a licença MIT em <https://github.com/RikkaApps/Shizuku-API/blob/master/LICENSE>. O código-fonte do app Shizuku anexado pertence ao projeto RikkaApps e não foi copiado para esta recriação.

## Credencial OpenAI (servidor)

A chave OpenAI **não é armazenada no aplicativo Android, no código-fonte nem no ZIP**. A chave enviada nesta conversa deve ser revogada e substituída, pois já foi exposta. Para uma chave nova, copie `backend/.env.example` para `backend/.env`, defina `OPENAI_API_KEY` e um `PROXY_CLIENT_TOKEN` separado e proteja o arquivo (`chmod 600 backend/.env`). Nunca envie o `.env` ao Git nem o compartilhe no app.

O proxy de desenvolvimento `backend/openai_proxy.py` aceita `POST /v1/responses`, exige `X-Client-Token`, limita o corpo a 1 MiB e encaminha a chamada ao endpoint oficial usando a chave só no servidor. Para testar localmente: `python3 backend/openai_proxy.py`. Para uso pela internet, implante atrás de HTTPS, limite requisições e proteja o token do cliente. O proxy é um ponto de partida de desenvolvimento, não uma implantação pronta para produção; HTTPS/rate-limit devem ser providos pelo gateway/servidor.

Para configurar após revogar a chave exposta e criar uma nova: execute `python3 backend/configure.py` em um terminal privado e cole a chave quando solicitado (a digitação fica oculta). O script cria `backend/.env` com permissão somente para o proprietário e gera um token de cliente diferente. Esse arquivo é ignorado pelo Git e fica fora do ZIP; o proxy lê a chave no servidor e não a registra nos logs.
