#!/system/bin/sh
# Uso: adb shell sh /data/local/tmp/resolucao.sh 720|900|1080|dpi80|reset
case "${1:-}" in 720|900|1080|dpi80|reset) ;; *) echo 'Uso: resolucao.sh 720|900|1080|dpi80|reset' >&2; exit 2 ;; esac
if [ "$1" = reset ]; then
  wm size reset || exit 1
  wm density reset || exit 1
  echo 'Resolução e DPI restaurados.'
  exit 0
fi
# "Physical size" e "Physical density" são preferíveis aos valores já sobrescritos.
size=$(wm size 2>/dev/null | sed -n 's/^Physical size: \([0-9][0-9]*x[0-9][0-9]*\).*/\1/p' | head -n 1)
dpi=$(wm density 2>/dev/null | sed -n 's/^Physical density: \([0-9][0-9]*\).*/\1/p' | head -n 1)
[ -n "$size" ] && [ -n "$dpi" ] || { echo 'Não foi possível ler a tela física; nenhuma alteração feita.' >&2; exit 1; }
if [ "$1" = dpi80 ]; then
  newdpi=$(( (dpi * 80 + 50) / 100 ))
  wm density "$newdpi" || exit 1
  echo "DPI físico: $dpi; configurado: $newdpi"
  exit 0
fi
w=${size%x*}; h=${size#*x}
# Mantém a orientação física (paisagem ou retrato).
if [ "$w" -le "$h" ]; then base=$w; neww=$1; newh=$(( (h * neww + base / 2) / base ));
else base=$h; newh=$1; neww=$(( (w * newh + base / 2) / base )); fi
newdpi=$(( (dpi * $1 + base / 2) / base ))
[ "$neww" -gt 0 ] && [ "$newh" -gt 0 ] && [ "$newdpi" -gt 0 ] || exit 1
wm size "${neww}x${newh}" || exit 1
if ! wm density "$newdpi"; then
  echo 'Falha ao alterar o DPI; restaurando a resolução.' >&2
  wm size reset
  exit 1
fi
echo "Tela física: $size / $dpi dpi"
echo "Tela configurada: ${neww}x${newh} / $newdpi dpi"
echo 'Afeta todo o sistema; o ganho de FPS depende do jogo e dispositivo.'
