#!/system/bin/sh
# Uso: adb shell sh /data/local/tmp/fps_monitor.sh com.dts.freefireth|com.dts.freefiremax
case "${1:-}" in
  com.dts.freefireth|com.dts.freefiremax) pkg=$1 ;;
  *) echo 'Uso: fps_monitor.sh com.dts.freefireth|com.dts.freefiremax' >&2; exit 2 ;;
esac
command -v dumpsys >/dev/null 2>&1 || exit 1
i=0; layer=
while [ "$i" -lt 15 ]; do
  layer=$(dumpsys SurfaceFlinger --list 2>/dev/null | grep -iF "$pkg" | grep -i 'surfaceview' | tail -n 1)
  [ -n "$layer" ] || layer=$(dumpsys SurfaceFlinger --list 2>/dev/null | grep -iF "$pkg" | tail -n 1)
  [ -n "$layer" ] && break
  sleep 1; i=$((i+1))
done
[ -n "$layer" ] || { echo 'Camada não encontrada. Abra o jogo; o sistema também pode restringir o acesso.' >&2; exit 1; }
echo "Camada: $layer"
echo 'Estimativa de quadros apresentados; a latência pode não estar disponível. Ctrl+C para encerrar.'
while :; do
  # Ao contrário de contar todos os quadros no histórico, compara apenas o último intervalo.
  fps=$(dumpsys SurfaceFlinger --latency "$layer" 2>/dev/null | awk '
    NR>1 && $2>0 && $3>0 { if (last>0 && $3>last) { delta=$3-last; if(delta>0) fps=1000000000/delta } last=$3 }
    END { if(fps>0 && fps<1000) printf "%.0f",fps; else print "--" }')
  printf 'FPS estimado: %s\n' "$fps"
  sleep 1
done
