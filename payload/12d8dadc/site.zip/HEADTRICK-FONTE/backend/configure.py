#!/usr/bin/env python3
"""Create a private server environment file without echoing the provider key."""
from getpass import getpass
from pathlib import Path
import os, secrets

HERE=Path(__file__).resolve().parent
DEST=HERE/'.env'
if DEST.exists():
    raise SystemExit('backend/.env já existe. Edite-o localmente se precisar trocar as credenciais.')
key=getpass('Cole uma chave OpenAI NOVA e rotacionada (entrada oculta): ').strip()
if not key.startswith('sk-') or len(key)<20:
    raise SystemExit('Formato de chave não reconhecido; nenhum arquivo foi criado.')
client=secrets.token_urlsafe(36)
content='OPENAI_API_KEY="'+key.replace('\\','\\\\').replace('"','\\"')+'"\nPROXY_CLIENT_TOKEN="'+client+'"\nPROXY_HOST=127.0.0.1\nPROXY_PORT=8787\n'
fd=os.open(DEST,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w',encoding='utf-8') as f: f.write(content)
if os.name!='nt': os.chmod(DEST,0o600)
print('Configuração local salva com permissão restrita. Os valores secretos não foram exibidos.')
