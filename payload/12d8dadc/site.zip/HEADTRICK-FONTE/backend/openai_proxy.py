#!/usr/bin/env python3
"""Small development proxy. Keeps the OpenAI credential on the server, never in Android."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from pathlib import Path
import hmac, json, os, secrets, sys
import threading, time

ROOT = Path(__file__).resolve().parent

def load_env():
    # Read a private local .env without adding a dependency. Existing process env wins.
    path = ROOT / ".env"
    if path.exists():
        if os.name != "nt" and path.stat().st_mode & 0o077:
            raise RuntimeError("Permissões inseguras em backend/.env; execute chmod 600 backend/.env")
        for raw in path.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line: continue
            name, value = line.split("=", 1)
            name, value = name.strip(), value.strip().strip('"').strip("'")
            if name and name not in os.environ: os.environ[name] = value

load_env()
OPENAI_KEY = os.getenv("OPENAI_API_KEY", "")
CLIENT_TOKEN = os.getenv("PROXY_CLIENT_TOKEN", "")
HOST = os.getenv("PROXY_HOST", "127.0.0.1")
PORT = int(os.getenv("PROXY_PORT", "8787"))
MAX_BODY = 1_048_576
RATE_LOCK = threading.Lock()
RATE = {}

class Handler(BaseHTTPRequestHandler):
    server_version = "HeadtrickProxy"
    def log_message(self, fmt, *args):
        # Never log headers, request bodies, or credentials.
        sys.stderr.write("%s %s\n" % (self.log_date_time_string(), fmt % args))
    def reply(self, status, data):
        raw = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(status); self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw))); self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff"); self.end_headers(); self.wfile.write(raw)
    def do_GET(self):
        if self.path != "/health": return self.reply(404, {"error":"not_found"})
        self.reply(200, {"ok":True, "service":"headtrick-openai-proxy"})
    def do_POST(self):
        if self.path != "/v1/responses": return self.reply(404, {"error":"not_found"})
        if not CLIENT_TOKEN or not hmac.compare_digest(self.headers.get("X-Client-Token", ""), CLIENT_TOKEN):
            return self.reply(401, {"error":"unauthorized"})
        now=time.time(); ip=self.client_address[0]
        with RATE_LOCK:
            recent=[stamp for stamp in RATE.get(ip,[]) if now-stamp<60]
            if len(recent)>=20: return self.reply(429,{"error":"rate_limited"})
            recent.append(now); RATE[ip]=recent
        if not OPENAI_KEY: return self.reply(503, {"error":"server_key_not_configured"})
        try: size = int(self.headers.get("Content-Length", "-1"))
        except ValueError: size = -1
        if size < 2 or size > MAX_BODY: return self.reply(413, {"error":"body_size_invalid"})
        try:
            body = json.loads(self.rfile.read(size))
            if not isinstance(body, dict) or not isinstance(body.get("model"), str) or not body["model"].strip() or "input" not in body:
                return self.reply(400, {"error":"expected_model_and_input"})
            if body.get("stream") is True: return self.reply(400, {"error":"streaming_not_supported_by_this_proxy"})
            payload = json.dumps(body).encode()
            req = Request("https://api.openai.com/v1/responses", data=payload, method="POST", headers={
                "Authorization":"Bearer "+OPENAI_KEY, "Content-Type":"application/json", "Accept":"application/json"})
            with urlopen(req, timeout=45) as response:
                result = response.read(MAX_BODY + 1)
                if len(result) > MAX_BODY: return self.reply(502, {"error":"upstream_response_too_large"})
                self.send_response(response.status); self.send_header("Content-Type","application/json")
                self.send_header("Content-Length",str(len(result))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(result)
        except HTTPError as exc:
            # Forward a bounded API error body, but never include request headers/secret.
            data = exc.read(MAX_BODY)
            self.send_response(exc.code); self.send_header("Content-Type","application/json")
            self.send_header("Content-Length",str(len(data))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(data)
        except (json.JSONDecodeError, UnicodeDecodeError): self.reply(400,{"error":"invalid_json"})
        except (URLError, TimeoutError): self.reply(502,{"error":"upstream_unavailable"})
        except Exception: self.reply(500,{"error":"internal_error"})

if __name__ == "__main__":
    if not CLIENT_TOKEN:
        print("Defina PROXY_CLIENT_TOKEN no ambiente/backend/.env antes de iniciar.", file=sys.stderr); raise SystemExit(2)
    if HOST not in ("127.0.0.1", "localhost", "::1"):
        print("Aviso: use somente atrás de um proxy HTTPS com limitação de acesso e taxa.", file=sys.stderr)
    print("Proxy iniciado em %s:%d (credencial OpenAI carregada do servidor)." % (HOST, PORT))
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
