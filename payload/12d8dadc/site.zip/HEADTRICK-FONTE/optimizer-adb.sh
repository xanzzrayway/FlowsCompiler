#!/system/bin/sh
# HEADTRICK - comandos ADB para Android 8 a 15
# Copie para o aparelho: adb push optimizer-adb.sh /sdcard/optimizer-adb.sh
# Execute: adb shell sh /sdcard/optimizer-adb.sh info|animacoes|fps120|dns|limpar|restaurar
# Cada ação é opcional e relata falhas. Não requer root.
run() { if "$@"; then echo "OK: $*"; else echo "FALHOU: $*" >&2; return 1; fi; }
case "${1:-info}" in
  info)
    echo "Marca: $(getprop ro.product.brand)"
    echo "Modelo: $(getprop ro.product.model)"
    echo "Android: $(getprop ro.build.version.release) (SDK $(getprop ro.build.version.sdk))"
    echo "Taxa configurada: $(settings get system peak_refresh_rate 2>/dev/null)"
    ;;
  animacoes)
    run settings put global window_animation_scale 0.25
    run settings put global transition_animation_scale 0.25
    run settings put global animator_duration_scale 0.25
    ;;
  fps120)
    echo 'Aplica preferência de 120 Hz somente se o hardware/sistema permitir; não aumenta FPS de jogos.'
    run settings put system peak_refresh_rate 120.0
    run settings put system min_refresh_rate 120.0
    ;;
  dns)
    run settings put global private_dns_mode hostname
    run settings put global private_dns_specifier one.one.one.one
    ;;
  limpar)
    echo 'Fecha apps em segundo plano; tarefas abertas podem ser interrompidas.'
    run am kill-all
    ;;
  restaurar)
    run settings put global window_animation_scale 1.0
    run settings put global transition_animation_scale 1.0
    run settings put global animator_duration_scale 1.0
    run settings delete system peak_refresh_rate
    run settings delete system min_refresh_rate
    run settings put global private_dns_mode opportunistic
    run settings delete global private_dns_specifier
    ;;
  *) echo 'Uso: sh optimizer-adb.sh info|animacoes|fps120|dns|limpar|restaurar' >&2; exit 2 ;;
esac
