package com.headtrick.recriado;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Painel móvel e redimensionável. Não executa comandos ADB nem altera resolução sem autorização externa. */
public class OverlayService extends Service {
    private static final int RED=0xffed202c, BACK=0xff141417, CARD=0xff242429;
    private static final String CHANNEL="headtrick_overlay";
    private WindowManager window;
    private WindowManager.LayoutParams params;
    private View panel;
    private TextView counter;
    private int calls;
    private int d(float n) { return (int)(n*getResources().getDisplayMetrics().density+.5f); }
    private GradientDrawable shape(int color,int radius) { GradientDrawable b=new GradientDrawable(); b.setColor(color); b.setCornerRadius(d(radius)); return b; }
    private TextView text(String s,int sp,int color) { TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); return t; }
    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if(intent!=null && "STOP".equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        manager.createNotificationChannel(new NotificationChannel(CHANNEL,"Painel flutuante",NotificationManager.IMPORTANCE_LOW));
        Intent open=new Intent(this,MainActivity.class);
        PendingIntent openPending=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent close=new Intent(this,OverlayService.class).setAction("STOP");
        PendingIntent closePending=PendingIntent.getService(this,1,close,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification notification=new Notification.Builder(this,CHANNEL).setContentTitle("HEADTRICK • Painel ativo")
            .setContentText("Toque para voltar ao app").setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentIntent(openPending).addAction(android.R.drawable.ic_menu_close_clear_cancel,"Fechar",closePending).build();
        startForeground(41,notification);
        if(panel==null && Settings.canDrawOverlays(this)) create();
        else if(panel==null) { Toast.makeText(this,"Autorize exibição sobre outros apps.",Toast.LENGTH_LONG).show(); stopSelf(); }
        return START_NOT_STICKY;
    }
    private void create() {
        window=(WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout outer=new LinearLayout(this); outer.setOrientation(LinearLayout.VERTICAL); outer.setBackground(shape(BACK,18));
        outer.setElevation(d(12)); panel=outer;
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(d(13),0,d(10),0);
        bar.setBackground(shape(0xff3b151c,18)); outer.addView(bar,new LinearLayout.LayoutParams(-1,d(49)));
        TextView title=text("⠿  7XIS  •  PAINEL",15,Color.WHITE); title.setTypeface(null,1);
        bar.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView close=text("✕",21,Color.WHITE); close.setPadding(d(10),d(7),d(7),d(7)); bar.addView(close);
        close.setOnClickListener(v->stopSelf());
        TextView note=text("Arraste o topo para mover • arraste o canto inferior para esticar o painel. Resolução do Android exige ADB.",11,0xffc5b6b8);
        note.setPadding(d(14),d(10),d(14),d(10)); outer.addView(note);
        counter=text("35 ações disponíveis · 0 usos",11,RED); counter.setPadding(d(14),0,d(10),d(8)); outer.addView(counter);
        TextView activation=text(ShizukuController.isConnected()?"● SHIZUKU CONECTADO":"◉ CONFIGURAR / AUTORIZAR SHIZUKU",11,Color.WHITE);
        activation.setPadding(d(14),d(8),d(10),d(10)); outer.addView(activation);
        activation.setOnClickListener(v->{Intent i=new Intent(this,MainActivity.class).putExtra("screen",3).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);});
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(false);
        outer.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout items=new LinearLayout(this); items.setOrientation(LinearLayout.VERTICAL); items.setPadding(d(9),d(3),d(9),d(6)); scroll.addView(items);
        populate(items);
        TextView handle=text("↘  ARRASTE PARA REDIMENSIONAR",11,Color.WHITE); handle.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        handle.setPadding(d(10),0,d(15),0); handle.setBackground(shape(0xff341a20,10));
        outer.addView(handle,new LinearLayout.LayoutParams(-1,d(35)));
        params=new WindowManager.LayoutParams(d(320),d(520),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.LEFT; params.x=d(25); params.y=d(90);
        bar.setOnTouchListener(new View.OnTouchListener(){float x,y;int sx,sy;
            public boolean onTouch(View v,MotionEvent e) {switch(e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: x=e.getRawX(); y=e.getRawY(); sx=params.x; sy=params.y; return true;
                case MotionEvent.ACTION_MOVE: params.x=Math.max(0,sx+(int)(e.getRawX()-x)); params.y=Math.max(0,sy+(int)(e.getRawY()-y)); update(); return true;
                default: return true; }} });
        handle.setOnTouchListener(new View.OnTouchListener(){float x,y;int sw,sh;
            public boolean onTouch(View v,MotionEvent e) {switch(e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: x=e.getRawX(); y=e.getRawY(); sw=params.width; sh=params.height; return true;
                case MotionEvent.ACTION_MOVE:
                    DisplayMetrics m=getResources().getDisplayMetrics();
                    params.width=Math.max(d(245),Math.min(m.widthPixels,sw+(int)(e.getRawX()-x)));
                    params.height=Math.max(d(280),Math.min(m.heightPixels-d(45),sh+(int)(e.getRawY()-y)));
                    update(); return true;
                default:return true; }} });
        try { window.addView(panel,params); } catch(Exception ex) {panel=null; stopSelf();}
    }
    private void update() {if(panel!=null) try {window.updateViewLayout(panel,params);} catch(Exception ignored) {} }
    private void add(LinearLayout list,int number,String title,String caption,String kind,String value) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(d(12),d(10),d(12),d(10));
        box.setBackground(shape(CARD,11)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=d(7); list.addView(box,lp);
        TextView t=text(String.format(java.util.Locale.ROOT,"%02d   %s",number,title),13,Color.WHITE); t.setTypeface(null,1); box.addView(t);
        TextView sub=text(caption,11,0xffa9a9b1); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.topMargin=d(4); box.addView(sub,cp);
        box.setOnClickListener(v->act(title,kind,value));
    }
    private void act(String title,String kind,String value) {
        if("adb".equals(kind)) {
            if(ShizukuController.isConnected() && !requiresComputer(value)) {
                String requested=value;
                if(requested.startsWith("@resolution:")) requested=requested;
                else if(requested.startsWith("@density:")) requested=requested;
                else requested=requested.replace("adb shell ","");
                final String operation=requested;
                ShizukuController.run(operation,result->new Handler(Looper.getMainLooper()).post(()->{
                    calls++; counter.setText("35 ações disponíveis · "+calls+" usos");
                    Toast.makeText(this,result,Toast.LENGTH_LONG).show();}));
                Toast.makeText(this,"Executando com a autorização do Shizuku…",Toast.LENGTH_SHORT).show(); return;
            }
            if(value.startsWith("@resolution:")) value="adb push resolucao.sh /data/local/tmp/resolucao.sh\nadb shell sh /data/local/tmp/resolucao.sh "+value.substring(12);
            else if(value.startsWith("@density:")) value="adb push resolucao.sh /data/local/tmp/resolucao.sh\nadb shell sh /data/local/tmp/resolucao.sh "+value.substring(9);
            ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText(title,value));
            calls++; counter.setText("35 ações disponíveis · "+calls+" usos");
            Toast.makeText(this,"Copiado. Execute no computador com ADB autorizado.",Toast.LENGTH_LONG).show();
        } else if("settings".equals(kind)) {
            try { Intent intent=new Intent(value).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } catch(Exception ex) {Toast.makeText(this,"Tela indisponível neste aparelho.",Toast.LENGTH_SHORT).show();}
        } else {
            String result;
            DisplayMetrics m=getResources().getDisplayMetrics();
            switch(value) {
                case "model": result=Build.MANUFACTURER+" "+Build.MODEL; break;
                case "android": result="Android "+Build.VERSION.RELEASE+" • API "+Build.VERSION.SDK_INT; break;
                case "screen": result=m.widthPixels+" × "+m.heightPixels+" px (janela atual)"; break;
                case "dpi": result=m.densityDpi+" dpi (métrica do app)"; break;
                default: result="1. Autorize a depuração USB. 2. Verifique adb devices. 3. Execute o comando copiado no computador.";
            }
            ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText(title,result));
            Toast.makeText(this,result,Toast.LENGTH_LONG).show();
        }
    }
    private boolean requiresComputer(String command) {
        return command.contains("adb push") || command.contains("fps_monitor.sh") || command.equals("adb devices");
    }
    private void populate(LinearLayout list) {
        add(list,1,"Tela 720","Lado menor em 720 px; todo o Android","adb","@resolution:720");
        add(list,2,"Tela 900","Lado menor em 900 px; todo o Android","adb","@resolution:900");
        add(list,3,"Tela 1080","Lado menor em 1080 px; todo o Android","adb","@resolution:1080");
        add(list,4,"Restaurar resolução e DPI","Volta aos valores padrão","adb","@resolution:reset");
        add(list,5,"Densidade 80%","Escala visual temporária; exige ADB ou Shizuku","adb","@density:80");
        add(list,6,"Restaurar densidade","Remove ajuste de DPI","adb","@density:reset");
        add(list,7,"Indicador de Hz ligado","Mostra a taxa da tela, não FPS do jogo","adb","adb shell setprop debug.sf.show_refresh_rate_overlay 1");
        add(list,8,"Indicador de Hz desligado","Oculta indicador da tela","adb","adb shell setprop debug.sf.show_refresh_rate_overlay 0");
        add(list,9,"Preferência 120 Hz","Somente aparelhos compatíveis","adb","adb shell settings put system peak_refresh_rate 120.0\nadb shell settings put system min_refresh_rate 120.0");
        add(list,10,"Restaurar taxa da tela","Remove preferências de atualização","adb","adb shell settings delete system peak_refresh_rate\nadb shell settings delete system min_refresh_rate");
        add(list,11,"Animações 0×","Remove transições visuais","adb",animation("0.0"));
        add(list,12,"Animações 0,25×","Transições mais rápidas","adb",animation("0.25"));
        add(list,13,"Animações 0,5×","Transições intermediárias","adb",animation("0.5"));
        add(list,14,"Animações 1×","Restaura velocidade típica","adb",animation("1.0"));
        add(list,15,"DNS Cloudflare","Configura DNS privado","adb","adb shell settings put global private_dns_mode hostname\nadb shell settings put global private_dns_specifier one.one.one.one");
        add(list,16,"Restaurar DNS","Retorna ao modo automático","adb","adb shell settings put global private_dns_mode opportunistic\nadb shell settings delete global private_dns_specifier");
        add(list,17,"Fechar apps de fundo","Pode interromper tarefas abertas","adb","adb shell am kill-all");
        add(list,18,"FPS Free Fire","Estimativa SurfaceFlinger; jogo aberto","adb",fps("com.dts.freefireth"));
        add(list,19,"FPS Free Fire MAX","Estimativa SurfaceFlinger; jogo aberto","adb",fps("com.dts.freefiremax"));
        add(list,20,"Verificar ADB","Lista dispositivos autorizados","adb","adb devices");
        add(list,21,"Wi-Fi","Abrir ajuste do Android","settings",Settings.ACTION_WIFI_SETTINGS);
        add(list,22,"Bluetooth","Abrir ajuste do Android","settings",Settings.ACTION_BLUETOOTH_SETTINGS);
        add(list,23,"Tela","Brilho e exibição","settings",Settings.ACTION_DISPLAY_SETTINGS);
        add(list,24,"Som","Volume e áudio","settings",Settings.ACTION_SOUND_SETTINGS);
        add(list,25,"Acessibilidade","Opções de acessibilidade","settings",Settings.ACTION_ACCESSIBILITY_SETTINGS);
        add(list,26,"Opções do desenvolvedor","Se disponíveis no aparelho","settings",Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS);
        add(list,27,"Bateria","Gerenciamento do aparelho","settings",Settings.ACTION_BATTERY_SAVER_SETTINGS);
        add(list,28,"Rede","Configurações de conexão","settings",Settings.ACTION_WIRELESS_SETTINGS);
        add(list,29,"Aplicativos","Gerenciar aplicativos","settings",Settings.ACTION_APPLICATION_SETTINGS);
        add(list,30,"Idioma","Idioma e entrada de texto","settings",Settings.ACTION_LOCALE_SETTINGS);
        add(list,31,"Modelo do aparelho","Consultar e copiar","info","model");
        add(list,32,"Versão Android","Consultar e copiar","info","android");
        add(list,33,"Pixels da tela","Métrica visível para o app","info","screen");
        add(list,34,"Densidade atual","Métrica visível para o app","info","dpi");
        add(list,35,"Como usar ADB","Instruções resumidas","info","help");
    }
    private String animation(String n) {return "adb shell settings put global window_animation_scale "+n+"\nadb shell settings put global transition_animation_scale "+n+"\nadb shell settings put global animator_duration_scale "+n;}
    private String fps(String pkg) {return "adb push fps_monitor.sh /data/local/tmp/fps_monitor.sh\nadb shell sh /data/local/tmp/fps_monitor.sh "+pkg;}
    @Override public void onDestroy() {if(panel!=null && window!=null) {try {window.removeView(panel);} catch(Exception ignored) {} panel=null;} super.onDestroy();}
}
