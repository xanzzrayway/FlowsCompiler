package com.headtrick.recriado;

import android.util.DisplayMetrics;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Executa uma lista fechada de operações aprovadas pelo usuário via Shizuku UserService. */
public final class ShellUserService extends IHeadtrickShell.Stub {
    @Override public String execute(String action) {
        try {
            if (action == null) return "Ação vazia.";
            if (action.startsWith("@resolution:")) return resolution(action.substring(12));
            if (action.startsWith("@density:")) return density(action.substring(9));
            String[] commands=action.split("\\n"); StringBuilder result=new StringBuilder();
            for(String raw:commands) {
                String cmd=raw.trim(); if(cmd.isEmpty()) continue;
                if(cmd.startsWith("adb shell ")) cmd=cmd.substring(10);
                if(cmd.startsWith("adb ") || cmd.startsWith("#") || cmd.contains("/data/local/tmp") || cmd.contains("fps_monitor"))
                    return "Esta ação precisa do ADB no computador; nenhuma alteração foi feita pelo Shizuku.";
                if(!(cmd.startsWith("settings put global window_animation_scale ") ||
                     cmd.startsWith("settings put global transition_animation_scale ") ||
                     cmd.startsWith("settings put global animator_duration_scale ") ||
                     cmd.startsWith("settings put global private_dns_mode ") ||
                     cmd.startsWith("settings put global private_dns_specifier ") ||
                     cmd.startsWith("settings delete global private_dns_specifier") ||
                     cmd.startsWith("settings put system peak_refresh_rate ") ||
                     cmd.startsWith("settings put system min_refresh_rate ") ||
                     cmd.startsWith("settings delete system peak_refresh_rate") ||
                     cmd.startsWith("settings delete system min_refresh_rate") ||
                     cmd.startsWith("settings put secure long_press_timeout ") ||
                     cmd.startsWith("settings put secure multi_press_timeout ") ||
                     cmd.equals("am kill-all") || cmd.startsWith("setprop debug.sf.show_refresh_rate_overlay ")))
                    return "Comando fora da lista permitida; nenhuma alteração feita.";
                result.append(run(cmd)).append('\n');
            }
            return result.length()==0 ? "Nenhum comando executado." : result.toString().trim();
        } catch(Exception e) { return "Falha: "+e.getClass().getSimpleName()+": "+e.getMessage(); }
    }
    private String resolution(String mode) throws Exception {
        if("reset".equals(mode)) return run("wm size reset")+"\n"+run("wm density reset");
        int target=Integer.parseInt(mode);
        if(target!=720 && target!=900 && target!=1080) return "Resolução não permitida.";
        String size=run("wm size"); Matcher sm=Pattern.compile("Physical size: (\\d+)x(\\d+)").matcher(size);
        String density=run("wm density"); Matcher dm=Pattern.compile("Physical density: (\\d+)").matcher(density);
        if(!sm.find() || !dm.find()) return "Não consegui ler os valores físicos da tela.";
        int w=Integer.parseInt(sm.group(1)), h=Integer.parseInt(sm.group(2)), dpi=Integer.parseInt(dm.group(1));
        int base=Math.min(w,h), shortSide=target, longSide=(int)(((long)Math.max(w,h)*target+base/2)/base);
        int nw=w<=h?shortSide:longSide, nh=w<=h?longSide:shortSide, ndpi=(int)(((long)dpi*target+base/2)/base);
        String a=run("wm size "+nw+"x"+nh);
        try { String b=run("wm density "+ndpi); return a+"\n"+b; }
        catch(Exception e) { run("wm size reset"); throw e; }
    }
    private String density(String mode) throws Exception {
        if("reset".equals(mode)) return run("wm density reset");
        if(!"80".equals(mode)) return "DPI não permitido.";
        Matcher m=Pattern.compile("Physical density: (\\d+)").matcher(run("wm density"));
        if(!m.find()) return "Não consegui ler o DPI físico.";
        int original=Integer.parseInt(m.group(1)); return run("wm density "+((original*80+50)/100));
    }
    private String run(String command) throws Exception {
        Process p=new ProcessBuilder("/system/bin/sh","-c",command).redirectErrorStream(true).start();
        StringBuilder out=new StringBuilder();
        try(BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream()))) {String line; while((line=r.readLine())!=null) out.append(line).append('\n');}
        if(!p.waitFor(8,TimeUnit.SECONDS)) {p.destroyForcibly(); throw new IllegalStateException("tempo limite");}
        String s=out.toString().trim(); if(p.exitValue()!=0) throw new IllegalStateException(s.isEmpty()?"código "+p.exitValue():s);
        return s.isEmpty()?"OK: "+command:s;
    }
}
