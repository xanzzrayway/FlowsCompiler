package com.headtrick.recriado;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.IBinder;
import android.os.RemoteException;
import android.provider.Settings;
import android.widget.Toast;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import rikka.shizuku.Shizuku;

/** Fluxo de autorização explícita e conexão com o Shizuku UserService. */
public final class ShizukuController {
    private static final int REQUEST_CODE=7441;
    private static IHeadtrickShell shell;
    private static boolean binding;
    private static boolean listenerAdded;
    private static final ExecutorService worker=Executors.newSingleThreadExecutor();
    private static final Shizuku.OnRequestPermissionResultListener permissionListener=(requestCode,grantResult)->{
        if(requestCode==REQUEST_CODE && grantResult==PackageManager.PERMISSION_GRANTED) bind();
    };
    private static final ServiceConnection connection=new ServiceConnection(){
        @Override public void onServiceConnected(ComponentName name,IBinder binder) {shell=IHeadtrickShell.Stub.asInterface(binder); binding=false;}
        @Override public void onServiceDisconnected(ComponentName name) {shell=null; binding=false;}
    };
    private ShizukuController() {}
    public static synchronized void addListener() { if(!listenerAdded) { Shizuku.addRequestPermissionResultListener(permissionListener); listenerAdded=true; } }
    public static boolean isConnected() { return shell!=null && shell.asBinder().pingBinder(); }
    public static void activate(Activity activity) {
        try {
            if(!Shizuku.pingBinder()) {
                Intent app=activity.getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if(app!=null) activity.startActivity(app);
                else activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")));
                new android.app.AlertDialog.Builder(activity).setTitle("Inicie o Shizuku")
                    .setMessage("No Shizuku, inicie o serviço por depuração sem fio ou root. Depois volte aqui e toque em Conectar novamente.")
                    .setPositiveButton("Entendi",null).show(); return;
            }
            if(Shizuku.isPreV11()) {Toast.makeText(activity,"Atualize o Shizuku para v11 ou superior.",Toast.LENGTH_LONG).show();return;}
            if(Shizuku.checkSelfPermission()==PackageManager.PERMISSION_GRANTED) {
                bind(); Toast.makeText(activity,"Conectando ao serviço Shizuku…",Toast.LENGTH_SHORT).show(); return;
            }
            addListener();
            Shizuku.requestPermission(REQUEST_CODE);
        } catch(Exception e) {Toast.makeText(activity,"Shizuku indisponível: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private static synchronized void bind() {
        if(binding || shell!=null) return;
        if(!Shizuku.pingBinder() || Shizuku.checkSelfPermission()!=PackageManager.PERMISSION_GRANTED) return;
        try {
            Shizuku.UserServiceArgs args=new Shizuku.UserServiceArgs(new ComponentName("com.headtrick.recriado",ShellUserService.class.getName()))
                .tag("headtrick_shell_v1").version(1).processNameSuffix("shizuku").daemon(false).debuggable(false);
            binding=true; Shizuku.bindUserService(args,connection);
        } catch(Exception e) {binding=false;}
    }
    public interface Result { void done(String text); }
    public static void run(String action,Result result) {
        worker.execute(()->{
            try {
                IHeadtrickShell current=shell;
                if(current==null || !current.asBinder().pingBinder()) { result.done("Shizuku não conectado. Abra o painel principal e toque em Conectar Shizuku."); return; }
                result.done(current.execute(action));
            } catch(RemoteException|RuntimeException e) { result.done("Falha Shizuku: "+e.getMessage()); }
        });
    }
}
