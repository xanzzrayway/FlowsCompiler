package com.headtrick.recriado;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.LinkedHashSet;

/** Recriação independente da interface. Os comandos são apenas copiados, nunca executados pelo app. */
public class MainActivity extends Activity {
    private static final int BACK = 0xff09090b, PANEL = 0xff17171b, PANEL2 = 0xff202025;
    private static final int RED = 0xffed202c, LIGHT = 0xfff8f8fa, MUTED = 0xffa5a5ad, LINE = 0xff35353c;
    private LinearLayout content;
    private final LinkedHashSet<String> selected = new LinkedHashSet<>();
    private int screen = 0;
    private boolean waitingOverlayPermission;
    private PopupWindow drawer;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private LinearLayout column() { LinearLayout v = new LinearLayout(this); v.setOrientation(LinearLayout.VERTICAL); return v; }
    private LinearLayout row() { LinearLayout v = new LinearLayout(this); v.setOrientation(LinearLayout.HORIZONTAL); v.setGravity(Gravity.CENTER_VERTICAL); return v; }
    private GradientDrawable shape(int color, int radius, int border) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius));
        if(border != 0) g.setStroke(dp(1), border); return g;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if(bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private void copy(String title, String value) {
        ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText(title,value));
        new AlertDialog.Builder(this).setTitle("Comandos copiados")
            .setMessage("Cole no terminal do computador com ADB autorizado. Nenhum comando foi executado pelo aplicativo.")
            .setPositiveButton("Entendi", null).show();
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); getWindow().setStatusBarColor(BACK); getWindow().setNavigationBarColor(BACK);
        ShizukuController.addListener(); show(getIntent().getIntExtra("screen",0));
    }
    @Override protected void onResume() {
        super.onResume();
        if(waitingOverlayPermission && Settings.canDrawOverlays(this)) { waitingOverlayPermission=false; startPanel(); }
    }
    private void startPanel() {
        try { startForegroundService(new Intent(this,OverlayService.class));
            new AlertDialog.Builder(this).setMessage("Painel flutuante iniciado. Você pode movê-lo e esticá-lo pelo canto inferior.").setPositiveButton("OK",null).show();
        } catch(Exception ex) {new AlertDialog.Builder(this).setMessage("Não foi possível abrir o painel neste aparelho.").setPositiveButton("OK",null).show();}
    }
    private void requestPanel() {
        if(Settings.canDrawOverlays(this)) {startPanel(); return;}
        waitingOverlayPermission=true;
        try {startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));}
        catch(Exception ex) {waitingOverlayPermission=false;new AlertDialog.Builder(this).setMessage("A configuração de sobreposição não está disponível.").setPositiveButton("OK",null).show();}
    }
    private void show(int target) {
        screen = Math.max(0, Math.min(7, target));
        LinearLayout root = column(); root.setBackgroundColor(BACK); root.setFitsSystemWindows(true); setContentView(root);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false); scroll.setVerticalScrollBarEnabled(false);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        content = column(); content.setPadding(dp(18),dp(16),dp(18),dp(22)); scroll.addView(content);
        top();
        switch(screen) {
            case 0: home(); break;
            case 1: optimizer(); break;
            case 2: display(); break;
            case 3: games(); break;
            case 4: network(); break;
            case 5: monitor(); break;
            case 6: tools(); break;
            default: help(); break;
        }
        navigation(root);
    }
    private void top() {
        LinearLayout brand=row(); content.addView(brand);
        TextView mark=text("☰",21,Color.WHITE,true); mark.setGravity(Gravity.CENTER); mark.setBackground(shape(0xff211316,11,0xff54252d));
        brand.addView(mark,new LinearLayout.LayoutParams(dp(46),dp(46))); mark.setContentDescription("Abrir menu"); mark.setOnClickListener(v->openDrawer());
        LinearLayout words=column(); words.setPadding(dp(12),0,0,0); brand.addView(words);
        words.addView(text("HEADTRICK",18,LIGHT,true));
        TextView subtitle=text("7XIS  /  ANDROID TOOLKIT",10,MUTED,true); subtitle.setLetterSpacing(.13f); words.addView(subtitle);
        TextView version=text("v3.0",11,RED,true); version.setPadding(dp(10),dp(6),dp(10),dp(6));
        version.setBackground(shape(0xff30171b,30,0)); LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-2,-2); vp.weight=1;
        LinearLayout spacer=row(); brand.addView(spacer,vp); brand.addView(version);

        TextView areas=text("PAINEL DE OTIMIZAÇÃO  •  8 ÁREAS",10,MUTED,true);
        areas.setLetterSpacing(.12f);
        LinearLayout.LayoutParams sl=new LinearLayout.LayoutParams(-1,-2); sl.topMargin=dp(18); content.addView(areas,sl);
    }
    private void navigation(LinearLayout root) {
        android.widget.HorizontalScrollView hsv=new android.widget.HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false); hsv.setFillViewport(false); hsv.setBackground(shape(0xff111115,0,LINE));
        root.addView(hsv,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout nav=row(); nav.setPadding(dp(6),dp(6),dp(6),dp(8)); hsv.addView(nav);
        String[] titles={"Início","Desemp.","Tela","Jogos","Rede","FPS","Extras","Ajuda"};
        String[] icons={"⌂","✦","▣","▶","⌁","◷","⚙","?"};
        for(int i=0;i<titles.length;i++) {
            final int target=i; LinearLayout item=column(); item.setGravity(Gravity.CENTER); item.setPadding(dp(1),dp(5),dp(1),dp(5));
            TextView icon=text(icons[i],22,i==screen?RED:MUTED,true); icon.setGravity(Gravity.CENTER); item.addView(icon);
            TextView label=text(titles[i],10,i==screen?LIGHT:MUTED,i==screen); label.setGravity(Gravity.CENTER); item.addView(label);
            item.setContentDescription(titles[i]);
            nav.addView(item,new LinearLayout.LayoutParams(dp(68),dp(54))); item.setOnClickListener(v->show(target));
        }
    }
    private void openDrawer() {
        if(drawer!=null && drawer.isShowing()) {drawer.dismiss();return;}
        LinearLayout panel=column(); panel.setPadding(dp(20),dp(42),dp(16),dp(18)); panel.setBackground(shape(0xff0d0d0f,0,LINE));
        LinearLayout heading=row(); panel.addView(heading,new LinearLayout.LayoutParams(-1,-2));
        TextView logo=text("7X",16,Color.WHITE,true); logo.setGravity(Gravity.CENTER); logo.setBackground(shape(RED,10,0)); heading.addView(logo,new LinearLayout.LayoutParams(dp(42),dp(42)));
        LinearLayout brand=column(); brand.setPadding(dp(12),0,0,0); heading.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        brand.addView(text("HEADTRICK",16,LIGHT,true)); brand.addView(text("CENTRAL DE OTIMIZAÇÃO",9,MUTED,true));
        TextView close=text("×",26,MUTED,true); heading.addView(close); close.setOnClickListener(v->{if(drawer!=null)drawer.dismiss();});
        TextView account=text(Build.MODEL==null?"Dispositivo Android":"Painel · "+Build.MODEL,12,MUTED,false);
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2); ap.topMargin=dp(32); ap.bottomMargin=dp(13); panel.addView(account,ap);
        ScrollView menuScroll=new ScrollView(this); menuScroll.setVerticalScrollBarEnabled(false); panel.addView(menuScroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout menuItems=column(); menuScroll.addView(menuItems);
        String[] names={"Painel inicial","Desempenho","Tela e resolução","Free Fire & MAX","Rede","Monitor FPS","Ferramentas","Ajuda e segurança"};
        String[] symbols={"▦","✦","▣","▶","⌁","◷","⚙","ⓘ"};
        for(int i=0;i<names.length;i++) {
            final int target=i; LinearLayout item=row(); item.setPadding(dp(12),dp(12),dp(8),dp(12));
            item.setBackground(shape(i==screen?0xff301216:0xff0d0d0f,12,i==screen?0xff68232c:0));
            TextView symbol=text(symbols[i],19,i==screen?RED:MUTED,true); item.addView(symbol,new LinearLayout.LayoutParams(dp(34),-2));
            TextView name=text(names[i],14,i==screen?LIGHT:0xffb8b8bd,i==screen); item.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2); ip.topMargin=dp(5); menuItems.addView(item,ip);
            item.setOnClickListener(v->{if(drawer!=null)drawer.dismiss();show(target);});
        }
        LinearLayout status=column(); status.setPadding(dp(13),dp(13),dp(13),dp(13)); status.setBackground(shape(PANEL,14,LINE));
        LinearLayout.LayoutParams statusParams=new LinearLayout.LayoutParams(-1,-2); statusParams.topMargin=dp(12); panel.addView(status,statusParams);
        status.addView(text("STATUS DO ACESSO",10,RED,true));
        TextView state=text(ShizukuController.isConnected()?"● Shizuku conectado":"○ Shizuku não conectado",12,LIGHT,false);
        LinearLayout.LayoutParams st=new LinearLayout.LayoutParams(-1,-2); st.topMargin=dp(7); status.addView(state,st);
        drawer=new PopupWindow(panel,dp(292),-1,true); drawer.setBackgroundDrawable(shape(0xff0d0d0f,0,LINE));
        drawer.setOutsideTouchable(true); drawer.setElevation(dp(18)); drawer.showAtLocation(getWindow().getDecorView(),Gravity.START|Gravity.TOP,0,0);
    }
    private void section(String tag, String title, String body) {
        TextView small=text(tag.toUpperCase(),11,RED,true); small.setLetterSpacing(.14f);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2); sp.topMargin=dp(28); content.addView(small,sp);
        TextView h=text(title,23,LIGHT,true); LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2); hp.topMargin=dp(5); content.addView(h,hp);
        TextView d=text(body,13,MUTED,false); d.setLineSpacing(dp(3),1f);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.topMargin=dp(7); lp.bottomMargin=dp(13); content.addView(d,lp);
    }
    private LinearLayout card(String icon, String title, String detail, String category) {
        LinearLayout box=column(); box.setPadding(dp(16),dp(16),dp(16),dp(15)); box.setBackground(shape(PANEL,16,LINE));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(10); content.addView(box,p);
        LinearLayout line=row(); box.addView(line);
        TextView symbol=text(icon,21,RED,true); symbol.setGravity(Gravity.CENTER); symbol.setBackground(shape(0xff33181d,12,0));
        line.addView(symbol,new LinearLayout.LayoutParams(dp(40),dp(40)));
        LinearLayout labels=column(); labels.setPadding(dp(12),0,dp(4),0); line.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
        labels.addView(text(title,16,LIGHT,true));
        TextView type=text(category.toUpperCase(),10,RED,true); type.setLetterSpacing(.08f); labels.addView(type);
        TextView description=text(detail,13,MUTED,false); description.setLineSpacing(dp(3),1f);
        LinearLayout.LayoutParams d=new LinearLayout.LayoutParams(-1,-2); d.topMargin=dp(11); box.addView(description,d);
        return box;
    }
    private void selectable(String icon, String title, String detail, String category, String command) {
        LinearLayout box=card(icon,title,detail,category);
        TextView control=text(selected.contains(command)?"✓  ADICIONADO":"+  ADICIONAR À SELEÇÃO",11,selected.contains(command)?LIGHT:RED,true);
        control.setGravity(Gravity.CENTER); control.setPadding(dp(10),dp(10),dp(10),dp(10));
        control.setBackground(shape(selected.contains(command)?RED:0xff32191e,9,0));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.topMargin=dp(13); box.addView(control,cp);
        control.setOnClickListener(v->{ if(selected.contains(command)) selected.remove(command); else selected.add(command);
            boolean on=selected.contains(command); control.setText(on?"✓  ADICIONADO":"+  ADICIONAR À SELEÇÃO");
            control.setTextColor(on?LIGHT:RED); control.setBackground(shape(on?RED:0xff32191e,9,0)); });
    }
    private void feature(String icon, String title, String detail, String category, String cmd) {
        LinearLayout box=card(icon,title,detail,category);
        if(cmd!=null) {
            TextView action=text("COPIAR COMANDOS  →",11,RED,true); action.setPadding(0,dp(13),0,dp(3)); box.addView(action);
            box.setOnClickListener(v->copy(title,cmd));
        }
    }
    private void banner(String message) {
        TextView box=text(message,12,0xffffd1d4,false); box.setLineSpacing(dp(3),1f);
        box.setPadding(dp(16),dp(14),dp(16),dp(14)); box.setBackground(shape(0xff30191f,13,0xff6a3039));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(4); p.bottomMargin=dp(14); content.addView(box,p);
    }
    private void home() {
        section("1 / 8 · painel", "Seu painel. Suas escolhas.", "Oito áreas para preparar, ajustar e acompanhar seu Android e seus jogos.");
        LinearLayout hero=column(); hero.setPadding(dp(19),dp(18),dp(19),dp(18));
        GradientDrawable gradient=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff3a1018,0xff1c1419,0xff121215});
        gradient.setCornerRadius(dp(20)); gradient.setStroke(dp(1),0xff713039); hero.setBackground(gradient);
        content.addView(hero,new LinearLayout.LayoutParams(-1,-2));
        hero.addView(text("HEADTRICK 7XIS",12,0xffff8990,true));
        TextView title=text("Tudo em um só lugar",24,LIGHT,true); LinearLayout.LayoutParams tl=new LinearLayout.LayoutParams(-1,-2); tl.topMargin=dp(8); hero.addView(title,tl);
        TextView desc=text("Use os cartões para consultar, preparar ou copiar ajustes. Cada ação informa quando precisa de ADB, Shizuku ou do computador.",13,0xffd5c6c9,false); desc.setLineSpacing(dp(3),1f); tl=new LinearLayout.LayoutParams(-1,-2); tl.topMargin=dp(7); hero.addView(desc,tl);
        section("Seu aparelho", "Resumo", "Informações locais; nenhuma configuração é alterada nesta tela.");
        feature("▣","Dispositivo",Build.MANUFACTURER+" "+Build.MODEL+"\nAndroid "+Build.VERSION.RELEASE+" • API "+Build.VERSION.SDK_INT,"Sistema",null);
        feature("⌁","Acesso avançado",ShizukuController.isConnected()?"Shizuku conectado. As ações autorizadas estão disponíveis no painel flutuante.":"Shizuku desconectado. Ainda é possível copiar comandos ADB para executar no computador.","Status",null);
        feature("35","Ações no painel","Resolução, densidade, animações, atalhos de sistema, diagnósticos e mais.","Painel flutuante",null);
        feature("2","Jogos compatíveis","Atalhos para Free Fire e Free Fire MAX, quando estiverem instalados.","Jogos",null);
        section("Registro", "Atividade recente", "Nenhuma ação foi executada pelo app nesta sessão.");
        banner("Escolha uma das oito abas abaixo. A compatibilidade de ajustes depende do Android e do fabricante.");
        button("ABRIR PAINEL FLUTUANTE",this::requestPanel);
    }
    private void optimizer() {
        section("2 / 8 · desempenho", "Ajustes rápidos", "Selecione os comandos desejados e copie um bloco para executar com ADB autorizado.");
        selectable("✦","Animações 0,25×","Reduz a duração das animações do Android; você pode restaurar o valor 1×.","Interface","settings put global window_animation_scale 0.25\nsettings put global transition_animation_scale 0.25\nsettings put global animator_duration_scale 0.25");
        selectable("⟡","Animações 0×","Remove transições visuais; valor identificado no APK de referência.","Interface","settings put global window_animation_scale 0.0\nsettings put global transition_animation_scale 0.0\nsettings put global animator_duration_scale 0.0");
        selectable("◉","DNS privado","Configura one.one.one.one. Algumas redes podem não aceitar DNS privado.","Rede","settings put global private_dns_mode hostname\nsettings put global private_dns_specifier one.one.one.one");
        selectable("×","Fechar apps em segundo plano","Pode encerrar tarefas abertas. Não libera memória de forma permanente.","Processos","am kill-all");
        selectable("◇","Resposta ao toque","Ajusta o tempo de pressionamento longo; restaure se algum gesto deixar de funcionar.","Interação","settings put secure long_press_timeout 300\nsettings put secure multi_press_timeout 300");
        TextView copy=text("COPIAR SELEÇÃO  →",13,LIGHT,true); copy.setGravity(Gravity.CENTER); copy.setPadding(dp(16),dp(16),dp(16),dp(16)); copy.setBackground(shape(RED,13,0));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.topMargin=dp(13); content.addView(copy,cp);
        copy.setOnClickListener(v->{ if(selected.isEmpty()) {new AlertDialog.Builder(this).setMessage("Adicione pelo menos um ajuste.").setPositiveButton("OK",null).show(); return;}
            StringBuilder commands=new StringBuilder("# Cole no terminal do computador com ADB autorizado\n");
            for(String block:selected) for(String line:block.split("\\n")) commands.append("adb shell ").append(line).append('\n');
            copy("Ajustes HEADTRICK",commands.toString()); });
        TextView foot=text("Para retornar ao padrão de animação, selecione 1×. Ajustes de terceiros podem ignorar esses valores.",12,MUTED,false);
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,-2); fp.topMargin=dp(13); content.addView(foot,fp);
    }
    private void games() {
        section("4 / 8 · jogos", "Free Fire & MAX", "Abra o jogo instalado e acesse os auxílios. O app não altera mira, sensibilidade nem arquivos do jogo.");
        button("ABRIR FREE FIRE",()->launchGame("com.dts.freefireth","Free Fire"));
        button("ABRIR FREE FIRE MAX",()->launchGame("com.dts.freefiremax","Free Fire MAX"));
        TextView floating=text("ABRIR PAINEL FLUTUANTE  ↗",13,LIGHT,true);
        floating.setGravity(Gravity.CENTER); floating.setPadding(dp(16),dp(16),dp(16),dp(16)); floating.setBackground(shape(RED,13,0));
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,-2); fp.bottomMargin=dp(10); content.addView(floating,fp);
        floating.setOnClickListener(v->requestPanel());
        TextView shizuku=text(ShizukuController.isConnected()?"SHIZUKU CONECTADO  •  GERENCIAR":"CONECTAR VIA SHIZUKU  •  CONFIGURAR",13,LIGHT,true);
        shizuku.setGravity(Gravity.CENTER); shizuku.setPadding(dp(16),dp(16),dp(16),dp(16)); shizuku.setBackground(shape(0xff2b1c32,13,0xff684c7a));
        LinearLayout.LayoutParams shp=new LinearLayout.LayoutParams(-1,-2); shp.bottomMargin=dp(10); content.addView(shizuku,shp);
        shizuku.setOnClickListener(v->ShizukuController.activate(this));
        TextView stop=text("FECHAR PAINEL FLUTUANTE",11,RED,true); stop.setGravity(Gravity.CENTER); stop.setPadding(dp(10),dp(10),dp(10),dp(10));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2); sp.bottomMargin=dp(12); content.addView(stop,sp);
        stop.setOnClickListener(v->stopService(new Intent(this,OverlayService.class)));
        banner("Os comandos de resolução afetam o Android inteiro; restaure quando terminar. O painel flutuante precisa de autorização de sobreposição.");
        String push="adb push resolucao.sh /data/local/tmp/resolucao.sh\n";
        feature("⇣","Modo 720","Mantém a proporção da tela e ajusta o DPI. Pode reduzir a carga gráfica, sem garantir mais FPS.","Resolução",push+"adb shell sh /data/local/tmp/resolucao.sh 720");
        feature("⇡","Modo 1080","Define o lado menor como 1080 pixels e ajusta o DPI proporcionalmente.","Resolução",push+"adb shell sh /data/local/tmp/resolucao.sh 1080");
        feature("↺","Restaurar tela","Remove as alterações de tamanho e densidade feitas por wm.","Restaurar",push+"adb shell sh /data/local/tmp/resolucao.sh reset");
        String monitor="adb push fps_monitor.sh /data/local/tmp/fps_monitor.sh\nadb shell sh /data/local/tmp/fps_monitor.sh ";
        feature("◷","FPS • Free Fire","Estimativa pela camada gráfica com.dts.freefireth. Abra o jogo antes de monitorar.","Monitor",monitor+"com.dts.freefireth");
        feature("◷","FPS • Free Fire MAX","Estimativa pela camada gráfica com.dts.freefiremax. Pare no terminal com Ctrl+C.","Monitor",monitor+"com.dts.freefiremax");
        feature("●","Indicador de taxa da tela","Mostra a taxa de atualização da tela, que pode diferir dos FPS do jogo.","Sistema","adb shell setprop debug.sf.show_refresh_rate_overlay 1");
    }
    private void display() {
        section("3 / 8 · tela", "Tela e resolução", "Taxa de atualização e resolução são preferências do sistema. O ajuste de resolução afeta a tela inteira.");
        selectable("↗","Preferir 120 Hz","Pede até 120 Hz quando o aparelho oferece esse modo. Não aumenta automaticamente os FPS do jogo.","Taxa da tela","settings put system peak_refresh_rate 120.0\nsettings put system min_refresh_rate 120.0");
        selectable("↺","Remover preferência de 120 Hz","Apaga os limites personalizados de taxa de atualização.","Restaurar","settings delete system peak_refresh_rate\nsettings delete system min_refresh_rate");
        String push="adb push resolucao.sh /data/local/tmp/resolucao.sh\n";
        feature("⇣","Resolução 720","Aplica proporção e DPI pelo script; requer ADB no computador ou painel com Shizuku.","Resolução",push+"adb shell sh /data/local/tmp/resolucao.sh 720");
        feature("⇡","Resolução 1080","Define o lado menor em 1080 px. Pode não ser apropriado em telas pequenas.","Resolução",push+"adb shell sh /data/local/tmp/resolucao.sh 1080");
        feature("↺","Restaurar resolução e DPI","Restaura o tamanho e densidade padrão do sistema.","Restaurar",push+"adb shell sh /data/local/tmp/resolucao.sh reset");
        banner("Confirme que sabe executar a restauração. Menor resolução não garante aumento de FPS.");
    }
    private void network() {
        section("5 / 8 · rede", "Conexão", "Ative DNS privado opcional ou abra as configurações de rede do Android.");
        selectable("⌁","DNS privado Cloudflare","Define one.one.one.one. Se a rede não resolver nomes, volte para DNS automático.","DNS","settings put global private_dns_mode hostname\nsettings put global private_dns_specifier one.one.one.one");
        selectable("↺","DNS automático","Remove o DNS personalizado e usa a configuração automática da rede.","Restaurar","settings put global private_dns_mode opportunistic\nsettings delete global private_dns_specifier");
        button("ABRIR CONFIGURAÇÕES DE WI-FI",()->openSettings(Settings.ACTION_WIFI_SETTINGS));
        button("ABRIR CONFIGURAÇÕES DE REDE",()->openSettings(Settings.ACTION_WIRELESS_SETTINGS));
        banner("Este app só copia os comandos selecionados; confirme sua rede antes de alterar DNS.");
    }
    private void monitor() {
        section("6 / 8 · monitor", "FPS e tela", "O contador usa dados de SurfaceFlinger quando disponíveis. É uma estimativa, não substitui o contador do jogo.");
        feature("◷","Monitor • Free Fire","Abra o jogo antes de iniciar. Interrompa no computador com Ctrl+C.","ADB","adb push fps_monitor.sh /data/local/tmp/fps_monitor.sh\nadb shell sh /data/local/tmp/fps_monitor.sh com.dts.freefireth");
        feature("◷","Monitor • Free Fire MAX","Abra o jogo antes de iniciar. Interrompa no computador com Ctrl+C.","ADB","adb push fps_monitor.sh /data/local/tmp/fps_monitor.sh\nadb shell sh /data/local/tmp/fps_monitor.sh com.dts.freefiremax");
        StringBuilder modes=new StringBuilder();
        if(Build.VERSION.SDK_INT>=23) {
            android.view.Display display=getWindowManager().getDefaultDisplay();
            for(android.view.Display.Mode mode:display.getSupportedModes()) modes.append(mode.getPhysicalWidth()).append(" × ").append(mode.getPhysicalHeight()).append(" px · ").append(String.format(java.util.Locale.US,"%.0f",mode.getRefreshRate())).append(" Hz\n");
        }
        feature("▣","Modos de tela suportados",modes.length()==0?"Não foi possível consultar os modos neste aparelho.":modes.toString().trim(),"Leitura local",null);
        feature("●","Indicador de taxa","O comando mostra Hz da tela; pode não funcionar em todos os aparelhos.","ADB","adb shell setprop debug.sf.show_refresh_rate_overlay 1");
    }
    private void tools() {
        section("7 / 8 · extras", "Ferramentas", "Atalhos locais e utilitários. Ações administrativas sempre mostram o método necessário.");
        button("ABRIR PAINEL FLUTUANTE",this::requestPanel);
        button(ShizukuController.isConnected()?"SHIZUKU CONECTADO · GERENCIAR":"CONECTAR / CONFIGURAR SHIZUKU",()->ShizukuController.activate(this));
        button("ENCERRAR PAINEL FLUTUANTE",()->{stopService(new Intent(this,OverlayService.class));toast("Solicitação de encerramento enviada.");});
        feature("▣","Modelo e versão",Build.MANUFACTURER+" "+Build.MODEL+"\nAndroid "+Build.VERSION.RELEASE+" · API "+Build.VERSION.SDK_INT,"Diagnóstico",null);
        feature("⌁","Estado de conexão","Conecte por ADB no computador e use adb devices para confirmar a autorização.","ADB","adb devices");
        banner("O painel tem 35 ações. Shizuku executa somente ações da lista permitida; tarefas de monitor que dependem de scripts continuam no computador.");
    }
    private void help() {
        section("8 / 8 · ajuda", "Comece por aqui", "Passo a passo, limites conhecidos e restauração dos ajustes.");
        feature("1","Conectar ADB","Ative Depuração USB, conecte ao computador, aceite o diálogo no telefone e execute adb devices.","Preparação",null);
        feature("2","Usar Shizuku","Inicie o serviço Shizuku, volte ao app e toque em Conectar. Autorize somente se reconhecer este aplicativo.","Acesso opcional",null);
        feature("3","Restaurar alterações","Use 1× para animações; DNS automático para rede; reset no resolucao.sh para resolução e DPI.","Segurança",null);
        feature("Limites","Mira e anti-recoil","A mira e os arquivos internos de jogos não são modificados. FPS depende do jogo, aparelho e temperatura.","Compatibilidade",null);
        button("SOLICITAR PAINEL FLUTUANTE",this::requestPanel);
        banner("Comandos copiados podem alterar configurações do sistema. Leia o texto antes de executá-los; nenhum ajuste é garantido em todos os Android.");
    }
    private void button(String label,Runnable action) {
        TextView b=text(label,12,LIGHT,true); b.setGravity(Gravity.CENTER); b.setPadding(dp(14),dp(15),dp(14),dp(15)); b.setBackground(shape(RED,13,0));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(5); p.bottomMargin=dp(9); content.addView(b,p); b.setOnClickListener(v->action.run());
    }
    private void openSettings(String action) { try {startActivity(new Intent(action));} catch(Exception ex) {toast("Configuração indisponível neste aparelho.");} }
    private void launchGame(String pkg,String label) {
        try { Intent i=getPackageManager().getLaunchIntentForPackage(pkg); if(i==null) {toast(label+" não está instalado.");return;} startActivity(i); }
        catch(Exception ex) {toast("Não foi possível abrir "+label+".");}
    }
    private void toast(String message) { android.widget.Toast.makeText(this,message,android.widget.Toast.LENGTH_LONG).show(); }
}
