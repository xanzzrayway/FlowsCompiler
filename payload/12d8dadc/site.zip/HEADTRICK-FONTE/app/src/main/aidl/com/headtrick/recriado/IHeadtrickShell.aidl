package com.headtrick.recriado;
interface IHeadtrickShell {
    String execute(String action);
}
