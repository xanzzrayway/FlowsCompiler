import { UnlimitedAI } from "../../src/scraper/unlimitedai.js";
import te from "../../src/lib/jexk-error.js";

const pluginConfig = {
  name: "jexk-ai",
  alias: ["jexkai", "jexk"],
  category: "ai",
  description: "Chat dengan jexk AI — Asisten bot cerdas",
  usage: ".jexk-ai <pertanyaan>",
  example: ".jexk-ai Apa itu Node.js?",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  energi: 2,
  isEnabled: true,
};

async function handler(m, { sock }) {
  const text = m.args.join(" ");
  if (!text) {
    return m.reply(
      `🤖 *jexk AI*\n\n` +
        `> Asisten cerdas siap membantu\n\n` +
        `*PENGGUNAAN:*\n` +
        `> *${m.prefix}jexk-ai <pertanyaan>*\n\n` +
        `*CONTOH:*\n` +
        `> *${m.prefix}jexk-ai Apa itu Node.js?*`
    );
  }

  await m.react("🕕");

  try {
    const result = await UnlimitedAI(text, "jexk-ai");

    if (!result.status) {
      await m.react("☢");
      return m.reply(`❌ *jexk AI Error*\n\n> ${result.error || "Gagal mendapatkan respons"}`);
    }

    await m.react("✅");
    const reply = result.answer;
    await m.reply(reply.length > 4096 ? reply.slice(0, 4096) + "..." : reply);
  } catch (e) {
    console.error(e);
    await m.react("☢");
    m.reply(te(m.prefix, m.command, m.pushName));
  }
}

export { pluginConfig as config, handler };
