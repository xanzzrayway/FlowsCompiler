========================================================================
   HƯỚNG DẪN BUILD APK TỪ FILE .ZIP BỞI LONGNEYY TOOLS
========================================================================

Tên ứng dụng : LongNeyy APK
Package ID   : com.longneyy.html2apk
Phiên bản    : 1.0.0
Ngày tạo     : 22:29:44 24/10/2026

CÁC BƯỚC CHUYỂN BỘ .ZIP NÀY THÀNH FILE .APK LÊN ĐIỆN THOẠI:

------------------------------------------------------------------------
CÁCH 1: NẠP VÀO WEB INTO APP (KHUYÊN DÙNG - KHÔNG CẦN CÀI PHẦN MỀM)
------------------------------------------------------------------------
1. Truy cập https://www.webintoapp.com
2. Chọn "Create App" -> Chọn "HTML / JS / CSS File"
3. Tải trực tiếp file .ZIP này lên.
4. Nhập tên ứng dụng "LongNeyy APK" và chọn Icon mong muốn.
5. Bấm "Make App" và tải file .APK về điện thoại để cài đặt!

------------------------------------------------------------------------
CÁCH 2: DÙNG SPCK EDITOR / PHONEGAP / CORDOVA TRÊN ĐIỆN THOẠI
------------------------------------------------------------------------
1. Tải Spck Editor trên Google Play Store.
2. Nạp/Giải nén file .zip này vào Spck Editor.
3. Chọn tùy chọn "Export / Build APK".

Cảm ơn bạn đã sử dụng HTML to APK Converter Studio - LongNeyy Tools!
========================================================================