FLOATING TAP — PROYEK ANDROID

Fitur:
- Gelembung mengambang yang dapat digeser.
- Ketuk gelembung untuk membuka panel daftar aplikasi.
- Ketuk nama aplikasi untuk menjalankan aplikasi tersebut.
- Panel dapat ditutup; layanan bisa dihentikan dari aplikasi utama.

PENTING:
Aplikasi Android biasa tidak dapat menjalankan aplikasi lain di dalam panel overlay seperti virtualisasi/desktop mode. Proyek ini menampilkan kontrol mengambang untuk membuka aplikasi lain, bukan menanamkan layar aplikasi lain ke dalam jendela floating.

Cara build:
1. Buka folder proyek ini di Android Studio.
2. Tunggu Gradle selesai sinkronisasi.
3. Build > Build APK(s).
4. Instal APK hasil build.
5. Buka Floating Tap, izinkan "Tampil di atas aplikasi lain", lalu mulai.

Catatan:
- Memerlukan Android 6.0+.
- Daftar aplikasi berasal dari aplikasi launcher yang terpasang.
- Izin overlay berisiko jika diberikan ke aplikasi yang tidak dipercaya; gunakan hanya pada proyek yang Anda pahami.
