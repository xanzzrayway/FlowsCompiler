package com.vexzano.floatingtap

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (bubble == null) createBubble()
        return START_STICKY
    }

    private fun overlayType() =
        if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun createBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = TextView(this).apply {
            text = "FT"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(20, 110, 90))
                setStroke(3, Color.WHITE)
            }
            elevation = 12f
        }
        bubbleParams = WindowManager.LayoutParams(
            dp(58), dp(58), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(20); y = dp(160) }

        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=bubbleParams.x; oy=bubbleParams.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt()
                        if (kotlin.math.abs(dx)>5 || kotlin.math.abs(dy)>5) moved=true
                        bubbleParams.x=ox+dx; bubbleParams.y=oy+dy
                        wm.updateViewLayout(b, bubbleParams); return true
                    }
                    MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); return true }
                }
                return false
            }
        })
        bubble = b
        wm.addView(b, bubbleParams)
    }

    private fun togglePanel() {
        if (panel != null) { closePanel(); return }
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.rgb(248, 248, 248))
                cornerRadius = dp(16).toFloat()
                setStroke(dp(2), Color.rgb(20, 110, 90))
            }
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "Floating Tap • Aplikasi"
            textSize = 16f; setTextColor(Color.BLACK)
        }, LinearLayout.LayoutParams(0, dp(42), 1f))
        header.addView(TextView(this).apply {
            text = "TUTUP"; textSize = 12f; setTextColor(Color.rgb(180, 30, 30))
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { closePanel() }
        })
        outer.addView(header)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .mapNotNull { ri ->
                val ai = ri.activityInfo ?: return@mapNotNull null
                if (ai.packageName == packageName) null else Triple(
                    ri.loadLabel(pm).toString(), ai.packageName, ai.name
                )
            }.distinctBy { it.second }.sortedBy { it.first.lowercase() }

        if (apps.isEmpty()) {
            list.addView(TextView(this).apply { text = "Tidak ada aplikasi yang bisa dibuka."; setTextColor(Color.BLACK) })
        }
        apps.forEach { (label, pkg, activityName) ->
            val item = TextView(this).apply {
                text = "▸  $label"
                textSize = 15f
                setTextColor(Color.BLACK)
                setPadding(dp(10), dp(12), dp(10), dp(12))
                setOnClickListener {
                    val launch = packageManager.getLaunchIntentForPackage(pkg)
                    if (launch != null) {
                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(launch)
                    }
                    closePanel()
                }
            }
            list.addView(item)
            val line = View(this).apply { setBackgroundColor(Color.LTGRAY) }
            list.addView(line, LinearLayout.LayoutParams(-1, dp(1)))
        }
        scroll.addView(list)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        panelParams = WindowManager.LayoutParams(
            dp(290), dp(420), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(12); y = dp(230) }
        panel = outer
        wm.addView(outer, panelParams)
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }
}
