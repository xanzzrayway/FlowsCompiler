package com.vexzano.floatingtap

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        root.addView(TextView(this).apply {
            text = "FLOATING TAP\n\nBuka gelembung mengambang untuk mengakses daftar aplikasi."
            textSize = 20f
            gravity = Gravity.CENTER
        })
        root.addView(Button(this).apply {
            text = "1. Izinkan tampil di atas aplikasi"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else startFloating()
            }
        })
        root.addView(Button(this).apply {
            text = "2. Mulai Floating Tap"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) startFloating()
                else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        })
        root.addView(Button(this).apply {
            text = "Hentikan Floating Tap"
            setOnClickListener { stopService(Intent(this@MainActivity, FloatingService::class.java)) }
        })
        setContentView(root)
    }

    private fun startFloating() {
        startService(Intent(this, FloatingService::class.java))
        finish()
    }
}
