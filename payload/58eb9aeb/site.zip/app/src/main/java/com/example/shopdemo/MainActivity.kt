package com.example.shopdemo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Product(val id: Int, val name: String, val price: Long, val emoji: String)

val products = listOf(
    Product(1, "Áo thun Basic", 99000, "👕"),
    Product(2, "Quần jean nam", 249000, "👖"),
    Product(3, "Áo khoác thời trang", 299000, "🧥"),
    Product(4, "Giày sneaker", 399000, "👟"),
    Product(5, "Túi đeo chéo", 159000, "👜")
)

fun money(v: Long) = "%,d₫".format(v).replace(',', '.')

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ShopApp() }
    }
}

@Composable
fun ShopApp() {
    var cart by remember { mutableStateOf(listOf<Product>()) }
    var screen by remember { mutableStateOf("home") }
    var ordered by remember { mutableStateOf(false) }

    MaterialTheme {
        when (screen) {
            "cart" -> CartScreen(
                cart = cart,
                onBack = { screen = "home" },
                onDelete = { p -> cart = cart.toMutableList().also { it.remove(p) } },
                onOrder = { ordered = true; cart = emptyList() }
            )
            else -> HomeScreen(
                cartCount = cart.size,
                ordered = ordered,
                onCart = { screen = "cart" },
                onAdd = { p -> cart = cart + p }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    cartCount: Int,
    ordered: Boolean,
    onCart: () -> Unit,
    onAdd: (Product) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("SHOP DEMO", fontWeight = FontWeight.Bold) },
                actions = {
                    BadgedBox(
                        badge = { if (cartCount > 0) Badge { Text(cartCount.toString()) } }
                    ) {
                        IconButton(onClick = onCart) {
                            Icon(Icons.Default.ShoppingCart, "Giỏ hàng")
                        }
                    }
                }
            )
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            item {
                Text("Sản phẩm nổi bật", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Demo bán hàng offline", color = Color.Gray)
                Spacer(Modifier.height(8.dp))
                if (ordered) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("✅ Đặt hàng demo thành công!", modifier = Modifier.padding(16.dp))
                    }
                }
            }
            items(products) { p ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(70.dp).background(Color(0xFFF3F3F3), RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) { Text(p.emoji, fontSize = 34.sp) }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(money(p.price), color = Color(0xFFD32F2F), fontWeight = FontWeight.Bold)
                        }
                        FilledTonalIconButton(onClick = { onAdd(p) }) {
                            Icon(Icons.Default.AddShoppingCart, "Thêm")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(
    cart: List<Product>,
    onBack: () -> Unit,
    onDelete: (Product) -> Unit,
    onOrder: () -> Unit
) {
    val total = cart.sumOf { it.price }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Giỏ hàng") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "Quay lại")
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)) {
            if (cart.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("🛒 Giỏ hàng đang trống", fontSize = 20.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(cart) { p ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(
                                Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(p.emoji, fontSize = 30.sp)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, fontWeight = FontWeight.Bold)
                                    Text(money(p.price), color = Color(0xFFD32F2F))
                                }
                                IconButton(onClick = { onDelete(p) }) {
                                    Icon(Icons.Default.Delete, "Xóa")
                                }
                            }
                        }
                    }
                }
                HorizontalDivider()
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Tổng cộng", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text(money(total), fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD32F2F))
                }
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = onOrder,
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text("ĐẶT HÀNG DEMO", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
