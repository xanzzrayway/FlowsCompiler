# Shop Demo Android

Ứng dụng bán hàng demo chạy offline.

## Chức năng
- Danh sách 5 sản phẩm mẫu
- Thêm sản phẩm vào giỏ hàng
- Xóa sản phẩm
- Tính tổng tiền
- Đặt hàng demo
- Không cần server/API

## Mở project
1. Giải nén ZIP.
2. Mở thư mục `shop_demo_android` bằng Android Studio.
3. Chờ Gradle Sync.
4. Chọn điện thoại/emulator.
5. Run để chạy.

## Build APK
Android Studio → Build → Build APK(s).

APK debug thường nằm ở:
`app/build/outputs/apk/debug/app-debug.apk`
