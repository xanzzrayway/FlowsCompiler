const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
// Melayani file frontend (index.html) dari folder 'public'
app.use(express.static(path.join(__dirname, 'public'))); 

// Inisialisasi Database SQLite
const db = new sqlite3.Database('./photobooth.db', (err) => {
    if (err) console.error('Database connection error:', err.message);
    else console.log('Connected to the SQLite database.');
});

// Membuat Tabel jika belum ada
db.serialize(() => {
    // Tabel User
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        username TEXT UNIQUE,
        password TEXT
    )`);

    // Tabel Ruangan (Rooms)
    db.run(`CREATE TABLE IF NOT EXISTS rooms (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE,
        host_id INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);
});

// ENDPOINT: Register
app.post('/api/auth/register', (req, res) => {
    const { name, username, password } = req.body;
    const stmt = db.prepare(`INSERT INTO users (name, username, password) VALUES (?, ?, ?)`);
    
    stmt.run([name, username, password], function(err) {
        if (err) return res.status(400).json({ error: 'Username sudah digunakan atau data tidak valid' });
        res.status(201).json({ id: this.lastID, name, username });
    });
});

// ENDPOINT: Login
app.post('/api/auth/login', (req, res) => {
    const { username, password } = req.body;
    db.get(`SELECT id, name, username FROM users WHERE username = ? AND password = ?`, [username, password], (err, row) => {
        if (err || !row) return res.status(401).json({ error: 'Username atau password salah' });
        res.json(row); // Berhasil login
    });
});

// ENDPOINT: Create Room
app.post('/api/rooms', (req, res) => {
    const { userId } = req.body;
    // Generate 6 digit random code
    const code = Math.floor(100000 + Math.random() * 900000).toString(); 
    
    db.run(`INSERT INTO rooms (code, host_id) VALUES (?, ?)`, [code, userId], function(err) {
        if (err) return res.status(500).json({ error: 'Gagal membuat ruangan' });
        res.status(201).json({ code });
    });
});

// ENDPOINT: Join Room
app.get('/api/rooms/:code', (req, res) => {
    const { code } = req.params;
    db.get(`SELECT code FROM rooms WHERE code = ?`, [code], (err, row) => {
        if (err || !row) return res.status(404).json({ error: 'Ruangan tidak ditemukan' });
        res.json({ valid: true, code: row.code });
    });
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server is running! Frontend & Backend ready at http://localhost:${PORT}`);
    console.log(`Buka file index.html di browser atau jalankan server ini dan akses http://localhost:${PORT}`);
});