// ============================================================
// FastApp — shared types, API helpers, upload/download, time, sound
// ============================================================

export interface UserProfile {
  id: string;
  email: string;
  phone: string;
  name: string;
  username: string;
  avatar_url: string;
  bio: string;
  is_online: boolean;
  last_seen: string;
  last_seen_visibility: 'everyone' | 'contacts' | 'nobody';
  avatar_visibility: 'everyone' | 'contacts' | 'nobody';
  read_receipts: boolean;
  notif_settings: Record<string, boolean>;
  created_at: string;
  updated_at: string;
}

export interface Member {
  id: number;
  chat_id: number;
  user_id: string;
  role: 'admin' | 'member';
  muted: boolean;
  archived: boolean;
  pinned: boolean;
  last_read_at: string | null;
  joined_at: string;
  user?: UserProfile | null;
}

export interface Receipt {
  id: number;
  message_id: number;
  user_id: string;
  status: 'sent' | 'delivered' | 'read';
  created_at: string;
  updated_at: string;
}

export interface Reaction {
  id: number;
  message_id: number;
  user_id: string;
  emoji: string;
  created_at: string;
}

export interface Message {
  id: number;
  chat_id: number;
  sender_id: string;
  kind: string;
  body: string;
  media_url: string;
  media_name: string;
  media_size: number;
  media_mime: string;
  duration: number;
  contact_data: { name?: string; phone?: string } | null;
  location_data: { lat?: number; lng?: number; label?: string } | null;
  reply_to: number | null;
  forwarded: boolean;
  forwarded_from: string;
  edited: boolean;
  edited_at: string | null;
  is_pinned: boolean;
  is_deleted: boolean;
  deleted_for: string[];
  created_at: string;
}

export interface Chat {
  id: number;
  type: 'direct' | 'group';
  name: string;
  avatar_url: string;
  description: string;
  created_by: string;
  created_at: string;
  updated_at: string;
  members: Member[];
  my: { muted: boolean; archived: boolean; pinned: boolean; role: 'admin' | 'member'; last_read_at: string | null };
  last_message: Message | null;
  last_receipts: Receipt[];
  unread: number;
}

export interface StatusItem {
  id: number;
  user_id: string;
  kind: string;
  body: string;
  media_url: string;
  bg: string;
  created_at: string;
  expires_at: string;
  user?: UserProfile | null;
  views?: { id: number; status_id: number; viewer_id: string; viewed_at: string }[];
}

export interface CallRow {
  id: number;
  chat_id: number | null;
  caller_id: string;
  callee_id: string;
  call_type: 'voice' | 'video';
  status: string;
  created_at: string;
  ended_at: string | null;
}

export interface Signal {
  id: number;
  call_id: number;
  from_id: string;
  to_id: string | null;
  kind: string;
  payload: Record<string, unknown>;
  created_at: string;
}

export interface NotifRow {
  id: number;
  user_id: string;
  title: string;
  body: string;
  chat_id: number | null;
  kind: string;
  is_read: boolean;
  created_at: string;
}

// ---------------- HTTP ----------------
async function req<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...init,
  });
  let data: unknown = null;
  try { data = await res.json(); } catch { data = null; }
  if (!res.ok) {
    const msg = (data as { error?: string } | null)?.error || `Permintaan gagal (${res.status})`;
    throw new Error(msg);
  }
  return data as T;
}

export const apiGet = <T>(path: string): Promise<T> => req<T>(path);
export const apiPost = <T>(path: string, body: unknown): Promise<T> =>
  req<T>(path, { method: 'POST', body: JSON.stringify(body) });
export const apiPut = <T>(path: string, body: unknown): Promise<T> =>
  req<T>(path, { method: 'PUT', body: JSON.stringify(body) });
export const apiDelete = <T>(path: string, body?: unknown): Promise<T> =>
  req<T>(path, { method: 'DELETE', body: body ? JSON.stringify(body) : undefined });

// ---------------- Upload (signed URL + progress) ----------------
export function uploadFile(
  file: File,
  onProgress?: (pct: number) => void,
): Promise<{ url: string; path: string }> {
  return (async () => {
    const meta = await apiPost<{ uploadUrl: string; publicUrl: string; path: string }>('/api/upload', {
      fileName: file.name || 'file',
      contentType: file.type || 'application/octet-stream',
    });
    await new Promise<void>((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('PUT', meta.uploadUrl);
      xhr.setRequestHeader('Content-Type', file.type || 'application/octet-stream');
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable && onProgress) onProgress(Math.round((e.loaded / e.total) * 100));
      };
      xhr.onload = () => {
        if (onProgress) onProgress(100);
        if (xhr.status >= 200 && xhr.status < 300) resolve();
        else reject(new Error(`Upload gagal (${xhr.status})`));
      };
      xhr.onerror = () => reject(new Error('Upload gagal: periksa koneksi internet'));
      xhr.onabort = () => reject(new Error('Upload dibatalkan'));
      xhr.send(file);
    });
    return { url: meta.publicUrl, path: meta.path };
  })();
}

// ---------------- Download with progress ----------------
export async function downloadFile(url: string, filename: string, onProgress?: (pct: number) => void): Promise<void> {
  const res = await fetch(url);
  if (!res.ok) throw new Error('Unduhan gagal');
  const total = Number(res.headers.get('content-length') || 0);
  const reader = res.body?.getReader();
  if (!reader) {
    const blob = await res.blob();
    triggerSave(URL.createObjectURL(blob), filename);
    return;
  }
  const chunks: BlobPart[] = [];
  let loaded = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value);
    loaded += value.length;
    if (total && onProgress) onProgress(Math.round((loaded / total) * 100));
  }
  if (onProgress) onProgress(100);
  const blob = new Blob(chunks);
  triggerSave(URL.createObjectURL(blob), filename);
}

function triggerSave(objectUrl: string, filename: string) {
  const a = document.createElement('a');
  a.href = objectUrl;
  a.download = filename || 'fastapp-file';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(objectUrl);
  }, 1500);
}

// ---------------- Time & format ----------------
function d(iso: string | null | undefined): Date | null {
  if (!iso) return null;
  const t = new Date(iso);
  return Number.isNaN(t.getTime()) ? null : t;
}

export function fmtClock(iso: string): string {
  const t = d(iso);
  if (!t) return '';
  return t.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }).replace('.', ':');
}

export function fmtListTime(iso: string): string {
  const t = d(iso);
  if (!t) return '';
  const now = new Date();
  const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const startT = new Date(t.getFullYear(), t.getMonth(), t.getDate()).getTime();
  const diffDays = Math.round((startToday - startT) / 86400000);
  if (diffDays <= 0) return fmtClock(iso);
  if (diffDays === 1) return 'Kemarin';
  if (diffDays < 7) return t.toLocaleDateString('id-ID', { weekday: 'short' });
  return t.toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: '2-digit' });
}

export function dayLabel(iso: string): string {
  const t = d(iso);
  if (!t) return '';
  const now = new Date();
  const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const startT = new Date(t.getFullYear(), t.getMonth(), t.getDate()).getTime();
  const diffDays = Math.round((startToday - startT) / 86400000);
  if (diffDays <= 0) return 'Hari ini';
  if (diffDays === 1) return 'Kemarin';
  if (diffDays < 7) return t.toLocaleDateString('id-ID', { weekday: 'long' });
  return t.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
}

export function sameDay(a: string, b: string): boolean {
  const ta = d(a); const tb = d(b);
  if (!ta || !tb) return false;
  return ta.getFullYear() === tb.getFullYear() && ta.getMonth() === tb.getMonth() && ta.getDate() === tb.getDate();
}

export function timeAgo(iso: string): string {
  const t = d(iso);
  if (!t) return '';
  const s = Math.max(0, Math.floor((Date.now() - t.getTime()) / 1000));
  if (s < 45) return 'baru saja';
  const m = Math.floor(s / 60);
  if (m < 1) return `${s} dtk lalu`;
  if (m < 60) return `${m} mnt lalu`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} jam lalu`;
  const dd = Math.floor(h / 24);
  if (dd < 7) return `${dd} hari lalu`;
  return t.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
}

export function fmtDuration(sec: number): string {
  const s = Math.max(0, Math.round(sec || 0));
  const m = Math.floor(s / 60);
  return `${m}:${String(s % 60).padStart(2, '0')}`;
}

export function fmtBytes(n: number): string {
  if (!n) return '0 B';
  const u = ['B', 'KB', 'MB', 'GB'];
  let v = n; let i = 0;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return `${v >= 100 ? Math.round(v) : v.toFixed(1)} ${u[i]}`;
}

export function fmtFullDate(iso: string): string {
  const t = d(iso);
  if (!t) return '';
  return t.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }) +
    ' • ' + fmtClock(iso);
}

// ---------------- Misc ----------------
export function initials(name: string): string {
  const parts = (name || '?').trim().split(/\s+/);
  if (parts.length === 1) return (parts[0][0] || '?').toUpperCase();
  return ((parts[0][0] || '') + (parts[1][0] || '')).toUpperCase();
}

const PALETTE = [
  'from-teal-500 to-emerald-600', 'from-violet-500 to-purple-600', 'from-sky-500 to-blue-600',
  'from-amber-500 to-orange-600', 'from-rose-500 to-pink-600', 'from-cyan-500 to-teal-600',
  'from-indigo-500 to-blue-600', 'from-lime-500 to-green-600',
];
export function colorFor(id: string): string {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return PALETTE[h % PALETTE.length];
}

export function isOnlyEmoji(s: string): boolean {
  const t = (s || '').trim();
  if (!t || t.length > 24) return false;
  try {
    return /^(\p{Extended_Pictographic}|\u200d|\uFE0F|\s)+$/u.test(t);
  } catch { return false; }
}

const KIND_LABEL: Record<string, string> = {
  image: '📷 Foto', video: '🎬 Video', audio: '🎵 Audio', voice: '🎙️ Pesan suara',
  document: '📄 Dokumen', contact: '👤 Kontak', location: '📍 Lokasi', sticker: '😀 Stiker', gif: '🎞️ GIF',
};
export function previewFor(m: Message | null): string {
  if (!m) return 'Belum ada pesan';
  if (m.is_deleted) return '🚫 Pesan ini telah dihapus';
  if (m.kind === 'system') return m.body;
  if (m.kind === 'text') return m.body || '';
  const base = KIND_LABEL[m.kind] || 'Pesan';
  return m.body ? `${base} • ${m.body}` : base;
}

export function canSee(viewerId: string, owner: UserProfile | null | undefined, field: 'last_seen' | 'avatar', shareChat: boolean): boolean {
  if (!owner) return false;
  if (viewerId === owner.id) return true;
  const v = field === 'last_seen' ? owner.last_seen_visibility : owner.avatar_visibility;
  if (v === 'everyone') return true;
  if (v === 'nobody') return false;
  return shareChat; // contacts ≈ pernah berbagi chat
}

export function uid(): string {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export function mentionNames(body: string): string[] {
  const out: string[] = [];
  const re = /@([a-zA-Z0-9_.-]+)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(body || ''))) out.push(m[1].toLowerCase());
  return [...new Set(out)];
}

// ---------------- Sounds (WebAudio, no assets) ----------------
let actx: AudioContext | null = null;
export function ensureAudio(): void {
  try {
    if (!actx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (AC) actx = new AC();
    }
    if (actx && actx.state === 'suspended') void actx.resume();
  } catch { /* noop */ }
}

function beep(freq: number, dur: number, delay = 0, type: OscillatorType = 'sine', gain = 0.12): void {
  try {
    if (!actx) return;
    const t0 = actx.currentTime + delay;
    const o = actx.createOscillator();
    const g = actx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t0);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain, t0 + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(actx.destination);
    o.start(t0); o.stop(t0 + dur + 0.05);
  } catch { /* noop */ }
}

export function playSend(): void { ensureAudio(); beep(920, 0.09, 0, 'sine', 0.1); }
export function playReceive(): void {
  ensureAudio();
  beep(660, 0.1, 0, 'sine', 0.12);
  beep(880, 0.14, 0.1, 'sine', 0.12);
  try { navigator.vibrate?.(40); } catch { /* noop */ }
}
export function startRing(): () => void {
  ensureAudio();
  let alive = true;
  const loop = () => {
    if (!alive) return;
    beep(740, 0.2, 0, 'sine', 0.14);
    beep(988, 0.28, 0.24, 'sine', 0.14);
    try { navigator.vibrate?.([120, 80, 120]); } catch { /* noop */ }
    window.setTimeout(loop, 1400);
  };
  loop();
  return () => { alive = false; };
}

export function notifyBrowser(title: string, body: string, onClick?: () => void): void {
  try {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    const n = new Notification(title, { body: body.slice(0, 140), icon: '/favicon.svg', tag: 'fastapp' });
    if (onClick) n.onclick = () => { try { window.focus(); onClick(); n.close(); } catch { /* noop */ } };
    window.setTimeout(() => { try { n.close(); } catch { /* noop */ } }, 6000);
  } catch { /* noop */ }
}
