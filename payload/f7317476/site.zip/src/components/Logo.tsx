interface Props {
  className?: string;
  size?: number;
}

/** Logo orisinal FastApp: petir di dalam gelembung chat. */
export default function Logo({ className = '', size = 40 }: Props) {
  return (
    <span
      className={`inline-flex items-center justify-center rounded-2xl bg-gradient-to-br from-teal-500 via-teal-600 to-emerald-700 shadow-lg shadow-teal-600/30 ${className}`}
      style={{ width: size, height: size }}
      aria-label="FastApp"
    >
      <svg width={size * 0.62} height={size * 0.62} viewBox="0 0 24 24" fill="none">
        <path
          d="M12 2.5c-5.25 0-9.5 3.9-9.5 8.7 0 2.7 1.4 5.1 3.6 6.7l-.9 3.1 3.4-1.7c1.1.3 2.2.5 3.4.5 5.25 0 9.5-3.9 9.5-8.7S17.25 2.5 12 2.5Z"
          fill="rgba(255,255,255,0.22)"
        />
        <path
          d="M13.1 6.2 7.6 12.6c-.2.25-.05.6.27.66l3.06.5c.22.04.34.28.22.46l-1.9 2.9c-.2.3.15.67.47.5l5.5-3.1c.25-.14.28-.5.05-.67l-2.9-2.1c-.16-.12-.2-.35-.08-.5l1.25-1.7c.2-.28-.1-.63-.42-.5l-1.9 1.1c-.2.12-.47.02-.55-.2l-.35-1.2c-.1-.34-.56-.4-.72-.08Z"
          fill="#fff"
        />
        <path d="M13.4 6.4 9.2 11.4l2.6.44 2.35 1.72-1.15-.9 1.9-1.06-1.5-2.3-.6-2.1-.4-.8Z" fill="#d9f99d" opacity="0.55" />
      </svg>
    </span>
  );
}
