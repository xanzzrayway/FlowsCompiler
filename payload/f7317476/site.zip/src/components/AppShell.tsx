import { useCallback, useEffect, useRef, useState } from 'react';
import { Archive, Bell, BellOff, CheckCheck, LogOut, Pin, PinOff, Trash2, VolumeX, Phone, PhoneCall, X } from 'lucide-react';
import supabase from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../components/Toast';
import { usePresence } from '../hooks/usePresence';
import ChatList, { chatTitle } from '../components/ChatList';
import ChatWindow from '../components/ChatWindow';
import ChatInfo from '../components/ChatInfo';
import Settings from '../components/Settings';
import ProfileModal from '../components/ProfileModal';
import MediaGallery from '../components/MediaGallery';
import CallScreen, { IncomingBanner } from '../components/CallScreen';
import { NewChatModal, NewGroupModal } from '../components/NewChat';
import { StatusViewer, StatusComposer } from '../components/StatusView';
import Logo from '../components/Logo';
import Avatar from '../components/Avatar';
import {
  apiGet, apiPost, apiPut, apiDelete, notifyBrowser, playReceive,
  type Chat, type StatusItem, type CallRow, type UserProfile, type NotifRow,
} from '../lib/api';

export default function AppShell() {
  const { profile } = useAuth();
  const toast = useToast();
  const myId = profile?.id || '';
  usePresence(myId || null);

  const [dark, setDark] = useState(() => {
    try {
      const saved = localStorage.getItem('fastapp-theme');
      if (saved) return saved === 'dark';
      return window.matchMedia?.('(prefers-color-scheme: dark)').matches ?? false;
    } catch { return false; }
  });
  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark);
    try { localStorage.setItem('fastapp-theme', dark ? 'dark' : 'light'); } catch { /* abaikan */ }
  }, [dark]);

  const [chats, setChats] = useState<Chat[]>([]);
  const [loadingChats, setLoadingChats] = useState(true);
  const [activeId, setActiveId] = useState<number | null>(null);
  const [search, setSearch] = useState('');
  const [statuses, setStatuses] = useState<StatusItem[]>([]);
  const [notifs, setNotifs] = useState<NotifRow[]>([]);
  const [showNotifs, setShowNotifs] = useState(false);

  const [showNewChat, setShowNewChat] = useState(false);
  const [showNewGroup, setShowNewGroup] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showChatInfo, setShowChatInfo] = useState(false);
  const [profileUser, setProfileUser] = useState<string | null>(null);
  const [gallery, setGallery] = useState<'media' | 'docs' | null>(null);
  const [showStatuses, setShowStatuses] = useState(false);
  const [statusUser, setStatusUser] = useState<string | null>(null);
  const [showComposer, setShowComposer] = useState(false);
  const [showCalls, setShowCalls] = useState(false);
  const [ctxMenu, setCtxMenu] = useState<{ x: number; y: number; chat: Chat } | null>(null);

  // calls
  const [activeCall, setActiveCall] = useState<CallRow | null>(null);
  const [callRole, setCallRole] = useState<'caller' | 'callee'>('caller');
  const [callPeer, setCallPeer] = useState<UserProfile | null>(null);
  const [incoming, setIncoming] = useState<CallRow | null>(null);

  const [refreshTick, setRefreshTick] = useState(0);
  const chatsRef = useRef(chats);
  chatsRef.current = chats;
  const activeRef = useRef(activeId);
  activeRef.current = activeId;
  const notifRef = useRef(notifs);
  notifRef.current = notifs;

  // ---------------- load chats ----------------
  const fetchChats = useCallback(async (silent = false) => {
    if (!myId) return;
    try {
      if (!silent) setLoadingChats(true);
      const data = await apiGet<Chat[]>(`/api/chats?user_id=${myId}`);
      setChats(data);
    } catch (e) {
      console.error(e);
      if (!silent) toast('Gagal memuat chat', 'error');
    } finally {
      setLoadingChats(false);
    }
  }, [myId, toast]);

  const fetchStatuses = useCallback(async () => {
    try {
      const data = await apiGet<StatusItem[]>('/api/statuses');
      setStatuses(data);
    } catch { /* abaikan */ }
  }, []);

  const fetchNotifs = useCallback(async () => {
    if (!myId) return;
    try {
      const data = await apiGet<NotifRow[]>(`/api/notifications?user_id=${myId}`);
      setNotifs(data);
    } catch { /* abaikan */ }
  }, [myId]);

  useEffect(() => {
    void fetchChats();
    void fetchStatuses();
    void fetchNotifs();
  }, [fetchChats, fetchStatuses, fetchNotifs]);

  // realtime refresh daftar chat saat ada pesan baru di chat manapun
  useEffect(() => {
    if (!myId) return;
    const ch = supabase.channel('chats-overview')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, () => {
        void fetchChats(true);
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'chats' }, () => {
        void fetchChats(true);
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'chat_members' }, () => {
        void fetchChats(true);
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'statuses' }, () => {
        void fetchStatuses();
      })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${myId}` }, (pl) => {
        const n = pl.new as NotifRow;
        setNotifs((prev) => [n, ...prev].slice(0, 30));
        const ns = profile?.notif_settings || {};
        const kindOk = n.kind === 'mention' ? ns.mention !== false : n.kind === 'call' ? ns.call !== false : ns.message !== false;
        const isMutedChat = n.chat_id ? chatsRef.current.find((c) => c.id === n.chat_id)?.my.muted : false;
        if (kindOk && !isMutedChat && n.chat_id !== activeRef.current) {
          if (ns.sound !== false) playReceive();
          notifyBrowser(n.title || 'FastApp', ns.preview === false ? 'Pesan baru' : (n.body || 'Pesan baru'), () => {
            if (n.chat_id) setActiveId(n.chat_id);
          });
        }
      })
      .subscribe();
    const poll = window.setInterval(() => {
      void fetchChats(true);
      void fetchNotifs();
    }, 12000);
    return () => {
      window.clearInterval(poll);
      void supabase.removeChannel(ch);
    };
  }, [myId, fetchChats, fetchStatuses, fetchNotifs, profile?.notif_settings]);

  // ---------------- incoming calls ----------------
  useEffect(() => {
    if (!myId || activeCall) return;
    let alive = true;
    const check = async () => {
      try {
        const rows = await apiGet<CallRow[]>(`/api/calls?user_id=${myId}`);
        if (!alive) return;
        const inc = rows.find((c) => c.callee_id === myId && c.status === 'ringing');
        if (inc && !incoming) {
          setIncoming(inc);
          const u = await apiGet<UserProfile | null>(`/api/users?id=${inc.caller_id}`).catch(() => null);
          if (alive && u) setCallPeer(u);
          const ns = profile?.notif_settings || {};
          if (ns.call !== false) {
            notifyBrowser(`Panggilan ${inc.call_type === 'video' ? 'video' : 'suara'} dari ${u?.name || 'seseorang'}`, 'Ketuk untuk menjawab');
          }
        } else if (!inc && incoming) {
          setIncoming(null);
        }
      } catch { /* abaikan */ }
    };
    const ch = supabase.channel('calls-me')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'calls' }, () => { void check(); })
      .subscribe();
    void check();
    const t = window.setInterval(check, 2500);
    return () => { alive = false; window.clearInterval(t); void supabase.removeChannel(ch); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [myId, activeCall]);

  const startCall = async (type: 'voice' | 'video', peerId: string) => {
    try {
      // pastikan perangkat tersedia
      try {
        const s = await navigator.mediaDevices.getUserMedia({ audio: true, video: type === 'video' });
        s.getTracks().forEach((t) => t.stop());
      } catch {
        toast('Izin kamera/mikrofon dibutuhkan. Aktifkan di Pengaturan → Notifikasi & Izin.', 'error');
        setShowSettings(true);
        return;
      }
      const active = chats.find((c) => c.id === activeId);
      const call = await apiPost<CallRow>('/api/calls', {
        chat_id: active && active.type === 'direct' ? active.id : null,
        caller_id: myId, callee_id: peerId, call_type: type,
      });
      const u = await apiGet<UserProfile | null>(`/api/users?id=${peerId}`).catch(() => null);
      setCallPeer(u);
      setCallRole('caller');
      setActiveCall(call);
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Gagal memulai panggilan', 'error');
    }
  };

  const acceptIncoming = () => {
    if (!incoming) return;
    setActiveCall(incoming);
    setCallRole('callee');
    setIncoming(null);
  };
  const rejectIncoming = async () => {
    if (!incoming) return;
    try {
      await apiPost('/api/signals', { call_id: incoming.id, from_id: myId, to_id: incoming.caller_id, kind: 'reject', payload: {} });
      await apiPut('/api/calls', { id: incoming.id, status: 'rejected' });
    } catch { /* abaikan */ }
    setIncoming(null);
  };

  // ---------------- chat actions ----------------
  const activeChat = chats.find((c) => c.id === activeId) || null;

  const patchChat = (c: Chat) => {
    setChats((prev) => prev.map((x) => (x.id === c.id ? { ...x, ...c } : x)));
  };

  const openChatWith = async (userId: string) => {
    if (userId === myId) return;
    try {
      const chat = await apiPost<{ id: number }>('/api/chats', { type: 'direct', created_by: myId, member_ids: [myId, userId] });
      await fetchChats(true);
      setActiveId(chat.id);
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Gagal membuka chat', 'error');
    }
  };

  const ctxAction = async (kind: string) => {
    const chat = ctxMenu?.chat;
    setCtxMenu(null);
    if (!chat) return;
    try {
      if (kind === 'pin') {
        await apiPut('/api/members', { chat_id: chat.id, user_id: myId, pinned: !chat.my.pinned });
        patchChat({ ...chat, my: { ...chat.my, pinned: !chat.my.pinned } });
        await fetchChats(true);
        toast(chat.my.pinned ? 'Pin dilepas' : 'Chat disematkan 📌', 'success');
      } else if (kind === 'mute') {
        await apiPut('/api/members', { chat_id: chat.id, user_id: myId, muted: !chat.my.muted });
        patchChat({ ...chat, my: { ...chat.my, muted: !chat.my.muted } });
        toast(chat.my.muted ? 'Notifikasi dinyalakan' : 'Chat dibisukan 🔕', 'success');
      } else if (kind === 'archive') {
        await apiPut('/api/members', { chat_id: chat.id, user_id: myId, archived: !chat.my.archived });
        patchChat({ ...chat, my: { ...chat.my, archived: !chat.my.archived } });
        toast(chat.my.archived ? 'Dikeluarkan dari arsip' : 'Chat diarsipkan', 'success');
      } else if (kind === 'read') {
        await apiPut('/api/receipts', { chat_id: chat.id, user_id: myId, status: 'read' });
        await apiPut('/api/members', { chat_id: chat.id, user_id: myId, last_read_at: new Date().toISOString() });
        await fetchChats(true);
        toast('Ditandai sudah dibaca ✓✓', 'success');
      } else if (kind === 'clear') {
        if (!window.confirm('Bersihkan semua pesan di chat ini untuk Anda?')) return;
        await apiPut('/api/messages', { chat_id: chat.id, clear_chat_for: myId });
        await fetchChats(true);
        setRefreshTick((t) => t + 1);
        toast('Riwayat dibersihkan', 'success');
      } else if (kind === 'delete') {
        if (!window.confirm(chat.type === 'group' ? 'Keluar dari grup ini?' : 'Hapus percakapan ini?')) return;
        await apiDelete('/api/chats', { id: chat.id, user_id: myId });
        if (activeId === chat.id) setActiveId(null);
        await fetchChats(true);
        toast('Chat dihapus', 'success');
      }
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Gagal', 'error');
    }
  };

  const unreadTotal = chats.filter((c) => !c.my.archived).reduce((a, c) => a + c.unread, 0);
  useEffect(() => {
    document.title = unreadTotal > 0 ? `(${unreadTotal}) FastApp` : 'FastApp — Chat Super Cepat';
  }, [unreadTotal]);

  if (!profile) return null;

  return (
    <div className="h-full flex bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 overflow-hidden">
      {/* ===== sidebar ===== */}
      <aside className={`${activeId ? 'hidden lg:flex' : 'flex'} w-full lg:w-[360px] xl:w-[400px] shrink-0 flex-col border-r border-slate-200 dark:border-slate-800 relative`}>
        {loadingChats && chats.length === 0 ? (
          <div className="h-full bg-white dark:bg-slate-900 p-4 space-y-3">
            <div className="flex items-center gap-3">
              <div className="skeleton w-11 h-11 rounded-full" />
              <div className="flex-1 space-y-2"><div className="skeleton h-4 w-32 rounded" /><div className="skeleton h-3 w-20 rounded" /></div>
            </div>
            <div className="skeleton h-11 rounded-2xl" />
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="flex items-center gap-3 py-2">
                <div className="skeleton w-[52px] h-[52px] rounded-full shrink-0" />
                <div className="flex-1 space-y-2"><div className="skeleton h-4 w-3/4 rounded" /><div className="skeleton h-3 w-1/2 rounded" /></div>
              </div>
            ))}
          </div>
        ) : (
          <ChatList
            chats={chats}
            myId={myId}
            activeId={activeId}
            onSelect={(id) => {
              setActiveId(id);
              const c = chats.find((x) => x.id === id);
              if (c && c.unread > 0) {
                setChats((prev) => prev.map((x) => (x.id === id ? { ...x, unread: 0 } : x)));
              }
            }}
            onNewChat={() => setShowNewChat(true)}
            onNewGroup={() => setShowNewGroup(true)}
            onOpenSettings={() => setShowSettings(true)}
            myAvatar={profile.avatar_url}
            myName={profile.name}
            statuses={statuses}
            onOpenStatuses={() => { setStatusUser(null); setShowStatuses(true); }}
            onAddStatus={() => setShowComposer(true)}
            search={search}
            onSearch={setSearch}
            contextChat={(chat, x, y) => setCtxMenu({ x: Math.min(x, window.innerWidth - 240), y: Math.min(y, window.innerHeight - 300), chat })}
          />
        )}
        {/* bottom bar mobile */}
        <div className="lg:hidden flex items-center justify-around border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-1.5 shrink-0">
          <MTab icon={<Logo size={22} className="!rounded-lg" />} t="Chat" active badge={unreadTotal} />
          <button onClick={() => { setStatusUser(null); setShowStatuses(true); }} className="flex flex-col items-center gap-0.5 px-6 py-1.5 text-slate-500">
            <span className="relative">
              <Avatar name="Status" src="" size={22} className="!rounded-full" />
              {statuses.length > 0 && <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-teal-500" />}
            </span>
            <span className="text-[10px] font-bold">Status</span>
          </button>
          <button onClick={() => setShowCalls(true)} className="flex flex-col items-center gap-0.5 px-6 py-1.5 text-slate-500">
            <PhoneCall size={22} />
            <span className="text-[10px] font-bold">Panggilan</span>
          </button>
          <button onClick={() => { setShowNotifs(true); }} className="relative flex flex-col items-center gap-0.5 px-6 py-1.5 text-slate-500">
            <Bell size={22} />
            {notifs.filter((n) => !n.is_read).length > 0 && (
              <span className="absolute top-0.5 right-5 min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 text-white text-[10px] font-extrabold flex items-center justify-center">
                {notifs.filter((n) => !n.is_read).length}
              </span>
            )}
            <span className="text-[10px] font-bold">Notifikasi</span>
          </button>
        </div>
        {/* floating notif button desktop */}
        <button
          onClick={() => setShowNotifs(true)}
          className="hidden lg:flex absolute bottom-5 right-5 w-12 h-12 rounded-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 items-center justify-center shadow-xl"
          title="Notifikasi"
        >
          <Bell size={20} />
          {notifs.filter((n) => !n.is_read).length > 0 && (
            <span className="absolute -top-1 -right-1 min-w-[20px] h-5 px-1 rounded-full bg-rose-500 text-white text-[11px] font-extrabold flex items-center justify-center">
              {notifs.filter((n) => !n.is_read).length}
            </span>
          )}
        </button>
      </aside>

      {/* ===== main ===== */}
      <main className={`${activeId ? 'flex' : 'hidden lg:flex'} flex-1 flex-col min-w-0 chat-wallpaper relative`}>
        {activeChat ? (
          <ChatWindow
            key={activeChat.id}
            chat={activeChat}
            onBack={() => setActiveId(null)}
            onChatPatched={patchChat}
            onOpenInfo={() => setShowChatInfo(true)}
            onStartCall={(type, peerId) => void startCall(type, peerId)}
            onOpenProfile={(uid) => setProfileUser(uid)}
            refreshSignal={refreshTick}
          />
        ) : (
          <EmptyState
            onNewChat={() => setShowNewChat(true)}
            onOpenCalls={() => setShowCalls(true)}
            onOpenStatuses={() => { setStatusUser(null); setShowStatuses(true); }}
          />
        )}
      </main>

      {/* ===== overlays ===== */}
      {showNewChat && <NewChatModal myId={myId} onClose={() => setShowNewChat(false)} onChatCreated={(id) => { void fetchChats(true); setActiveId(id); }} />}
      {showNewGroup && <NewGroupModal myId={myId} onClose={() => setShowNewGroup(false)} onChatCreated={(id) => { void fetchChats(true); setActiveId(id); }} />}
      {showSettings && <Settings onClose={() => setShowSettings(false)} dark={dark} onToggleDark={() => setDark(!dark)} />}
      {showChatInfo && activeChat && (
        <ChatInfo
          chat={activeChat}
          myId={myId}
          onClose={() => setShowChatInfo(false)}
          onChatPatched={patchChat}
          onChatRemoved={() => { setShowChatInfo(false); setActiveId(null); void fetchChats(true); }}
          onOpenProfile={(uid) => setProfileUser(uid)}
          onStartCall={(type, peerId) => { setShowChatInfo(false); void startCall(type, peerId); }}
          onOpenMediaTab={(t) => setGallery(t)}
        />
      )}
      {profileUser && (
        <ProfileModal
          userId={profileUser}
          myId={myId}
          onClose={() => setProfileUser(null)}
          onChat={(uid) => void openChatWith(uid)}
          onCall={(type, uid) => void startCall(type, uid)}
        />
      )}
      {gallery && activeChat && (
        <MediaGallery chatId={activeChat.id} myId={myId} tab={gallery} onClose={() => setGallery(null)} />
      )}
      {showStatuses && (
        <StatusViewer
          myId={myId}
          statuses={statuses}
          onChanged={() => void fetchStatuses()}
          initialUser={statusUser}
          onClose={() => setShowStatuses(false)}
        />
      )}
      {showComposer && (
        <StatusComposer myId={myId} onDone={() => void fetchStatuses()} onClose={() => setShowComposer(false)} />
      )}
      {showCalls && (
        <CallHistory myId={myId} onClose={() => setShowCalls(false)} onCall={(t, uid) => { setShowCalls(false); void startCall(t, uid); }} />
      )}
      {showNotifs && (
        <NotifPanel
          items={notifs}
          chats={chats}
          myId={myId}
          onClose={() => setShowNotifs(false)}
          onOpen={(chatId) => {
            setShowNotifs(false);
            if (chatId) setActiveId(chatId);
          }}
          onReadAll={() => {
            void apiPut('/api/notifications', { user_id: myId, all: true }).then(() => {
              setNotifs((prev) => prev.map((n) => ({ ...n, is_read: true })));
            });
          }}
          onClear={() => {
            void fetch(`/api/notifications?user_id=${myId}`, { method: 'DELETE' }).then(() => setNotifs([]));
          }}
        />
      )}

      {/* context menu daftar chat */}
      {ctxMenu && (
        <>
          <span className="fixed inset-0 z-40" onClick={() => setCtxMenu(null)} />
          <span
            className="fixed z-50 w-56 bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 py-1.5 fa-animate-pop"
            style={{ left: ctxMenu.x, top: ctxMenu.y }}
          >
            <CMItem icon={ctxMenu.chat.my.pinned ? <PinOff size={17} /> : <Pin size={17} />} t={ctxMenu.chat.my.pinned ? 'Lepas sematan' : 'Sematkan chat'} onClick={() => void ctxAction('pin')} />
            <CMItem icon={ctxMenu.chat.my.muted ? <Bell size={17} /> : <VolumeX size={17} />} t={ctxMenu.chat.my.muted ? 'Nyalakan notifikasi' : 'Bisukan'} onClick={() => void ctxAction('mute')} />
            <CMItem icon={<Archive size={17} />} t={ctxMenu.chat.my.archived ? 'Keluarkan dari arsip' : 'Arsipkan'} onClick={() => void ctxAction('archive')} />
            <CMItem icon={<CheckCheck size={17} />} t="Tandai dibaca" onClick={() => void ctxAction('read')} />
            <CMItem icon={<Trash2 size={17} />} t="Bersihkan riwayat" danger onClick={() => void ctxAction('clear')} />
            <CMItem icon={<LogOut size={17} />} t={ctxMenu.chat.type === 'group' ? 'Keluar grup' : 'Hapus chat'} danger onClick={() => void ctxAction('delete')} />
          </span>
        </>
      )}

      {/* calls */}
      {incoming && !activeCall && (
        <IncomingBanner
          peer={callPeer}
          callType={incoming.call_type}
          onAccept={acceptIncoming}
          onReject={() => void rejectIncoming()}
        />
      )}
      {activeCall && (
        <CallScreen
          call={activeCall}
          me={profile}
          peer={callPeer}
          role={callRole}
          onEnd={() => { setActiveCall(null); setIncoming(null); }}
        />
      )}
    </div>
  );
}

function MTab({ icon, t, active, badge }: { icon: React.ReactNode; t: string; active?: boolean; badge?: number }) {
  return (
    <span className={`relative flex flex-col items-center gap-0.5 px-6 py-1.5 ${active ? 'text-teal-600' : 'text-slate-500'}`}>
      {icon}
      {badge ? (
        <span className="absolute top-0 right-4 min-w-[18px] h-[18px] px-1 rounded-full bg-teal-600 text-white text-[10px] font-extrabold flex items-center justify-center">{badge > 99 ? '99+' : badge}</span>
      ) : null}
      <span className="text-[10px] font-bold">{t}</span>
    </span>
  );
}

function CMItem({ icon, t, onClick, danger }: { icon: React.ReactNode; t: string; onClick: () => void; danger?: boolean }) {
  return (
    <button onClick={onClick} className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm font-semibold ${danger ? 'text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40' : 'hover:bg-slate-100 dark:hover:bg-slate-700/60'}`}>
      {icon} {t}
    </button>
  );
}

function EmptyState({ onNewChat, onOpenCalls, onOpenStatuses }: { onNewChat: () => void; onOpenCalls: () => void; onOpenStatuses: () => void }) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center text-center px-8">
      <Logo size={88} className="!rounded-[26px]" />
      <h1 className="text-3xl font-extrabold mt-5 tracking-tight">FastApp</h1>
      <p className="text-slate-500 dark:text-slate-400 mt-2 max-w-sm">
        Pilih chat di sebelah kiri untuk mulai ngobrol — atau buat percakapan baru. Cepat, ringan, dan seru! ⚡
      </p>
      <div className="flex flex-wrap justify-center gap-2 mt-6">
        <button onClick={onNewChat} className="px-5 py-2.5 rounded-full bg-teal-600 hover:bg-teal-700 text-white text-sm font-bold shadow-lg shadow-teal-600/25 transition">
          💬 Chat Baru
        </button>
        <button onClick={onOpenStatuses} className="px-5 py-2.5 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-bold transition">
          ⭕ Lihat Status
        </button>
        <button onClick={onOpenCalls} className="px-5 py-2.5 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-bold transition">
          📞 Riwayat Panggilan
        </button>
      </div>
      <p className="text-xs text-slate-400 mt-8 flex items-center gap-1.5">
        <BellOff size={13} /> Tips: klik kanan pada chat untuk sematkan, bisukan, arsipkan & lainnya.
      </p>
    </div>
  );
}

function CallHistory({ myId, onClose, onCall }: { myId: string; onClose: () => void; onCall: (t: 'voice' | 'video', uid: string) => void }) {
  const [rows, setRows] = useState<CallRow[]>([]);
  const [users, setUsers] = useState<Record<string, UserProfile>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const data = await apiGet<CallRow[]>(`/api/calls?user_id=${myId}&history=1`);
        setRows(data);
        const ids = [...new Set(data.flatMap((c) => [c.caller_id, c.callee_id]).filter((u) => u !== myId))];
        if (ids.length) {
          const us = await apiGet<UserProfile[]>(`/api/users?ids=${ids.join(',')}`);
          setUsers(Object.fromEntries(us.map((u) => [u.id, u])));
        }
      } catch { /* abaikan */ }
      finally { setLoading(false); }
    })();
  }, [myId]);

  return (
    <div className="fixed inset-0 z-[78] bg-black/60 flex items-end sm:items-center justify-center sm:p-4" onClick={onClose}>
      <div className="w-full sm:max-w-md bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl max-h-[85vh] flex flex-col fa-animate-fade-up" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-200 dark:border-slate-800">
          <button onClick={onClose} className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800"><X size={20} /></button>
          <p className="font-extrabold flex-1">Riwayat Panggilan</p>
          <Phone size={18} className="text-teal-600" />
        </div>
        <div className="overflow-y-auto p-2">
          {loading ? (
            <p className="text-center text-sm text-slate-400 py-10">Memuat…</p>
          ) : rows.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <p className="text-5xl mb-3">📞</p>
              <p className="font-bold text-slate-500">Belum ada panggilan</p>
              <p className="text-sm mt-1">Mulai telepon dari dalam chat ya!</p>
            </div>
          ) : rows.map((c) => {
            const otherId = c.caller_id === myId ? c.callee_id : c.caller_id;
            const u = users[otherId];
            const missed = ['missed', 'rejected'].includes(c.status) && c.callee_id === myId;
            return (
              <div key={c.id} className="flex items-center gap-3 px-3 py-2.5 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800">
                <Avatar name={u?.name || '?'} src={u?.avatar_url || ''} size={44} />
                <span className="flex-1 min-w-0">
                  <span className={`font-bold block truncate ${missed ? 'text-rose-500' : ''}`}>{u?.name || 'Pengguna'}</span>
                  <span className="text-xs text-slate-500 block">
                    {c.caller_id === myId ? '↗ Keluar' : missed ? '↙ Tak terjawab' : '↙ Masuk'} • {c.call_type === 'video' ? 'Video' : 'Suara'} • {new Date(c.created_at).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}
                  </span>
                </span>
                <button onClick={() => onCall('voice', otherId)} className="p-2.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 text-teal-600"><Phone size={18} /></button>
                <button onClick={() => onCall('video', otherId)} className="p-2.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 text-teal-600"><Video size={18} /></button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function NotifPanel({ items, chats, myId, onClose, onOpen, onReadAll, onClear }: {
  items: NotifRow[]; chats: Chat[]; myId: string; onClose: () => void;
  onOpen: (chatId: number | null) => void; onReadAll: () => void; onClear: () => void;
}) {
  return (
    <div className="fixed inset-0 z-[78] bg-black/60 flex items-end sm:items-center justify-center sm:p-4" onClick={onClose}>
      <div className="w-full sm:max-w-md bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl max-h-[85vh] flex flex-col fa-animate-fade-up" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-200 dark:border-slate-800">
          <button onClick={onClose} className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800"><X size={20} /></button>
          <p className="font-extrabold flex-1">Notifikasi</p>
          <button onClick={onReadAll} className="text-[13px] font-bold text-teal-600">Tandai dibaca</button>
        </div>
        <div className="overflow-y-auto p-2 flex-1">
          {items.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <p className="text-5xl mb-3">🔔</p>
              <p className="font-bold text-slate-500">Semua sudah dibaca</p>
              <p className="text-sm mt-1">Notifikasi baru akan muncul di sini.</p>
            </div>
          ) : items.map((n) => {
            const chat = n.chat_id ? chats.find((c) => c.id === n.chat_id) : null;
            return (
              <button
                key={n.id}
                onClick={() => onOpen(n.chat_id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl text-left ${n.is_read ? '' : 'bg-teal-50 dark:bg-teal-950/40'} hover:bg-slate-100 dark:hover:bg-slate-800`}
              >
                <span className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 text-lg ${n.kind === 'mention' ? 'bg-amber-100 dark:bg-amber-900/40' : n.kind === 'call' ? 'bg-emerald-100 dark:bg-emerald-900/40' : 'bg-teal-100 dark:bg-teal-900/40'}`}>
                  {n.kind === 'mention' ? '@' : n.kind === 'call' ? '📞' : '💬'}
                </span>
                <span className="flex-1 min-w-0">
                  <span className="font-bold text-sm block truncate">{n.title || 'FastApp'}</span>
                  <span className="text-[13px] text-slate-500 block truncate">{n.body}</span>
                  <span className="text-[11px] text-slate-400">
                    {chat ? `${chatTitle(chat, myId)} • ` : ''}{new Date(n.created_at).toLocaleString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                  </span>
                </span>
                {!n.is_read && <span className="w-2.5 h-2.5 rounded-full bg-teal-500 shrink-0" />}
              </button>
            );
          })}
        </div>
        {items.length > 0 && (
          <div className="p-3 border-t border-slate-200 dark:border-slate-800">
            <button onClick={onClear} className="w-full py-2.5 rounded-2xl border border-slate-300 dark:border-slate-700 font-bold text-sm text-slate-500">
              Hapus Semua Notifikasi
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function Video({ size, className }: { size: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="m16 10 6-3v10l-6-3" /><rect x="2" y="6" width="14" height="12" rx="2" />
    </svg>
  );
}
