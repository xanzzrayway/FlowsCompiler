import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Download, X, Play, Pause, Mic, FileText, MapPin, User as UserIcon, Sticker as StickerIcon,
  ChevronLeft, ChevronRight, Phone, Quote,
} from 'lucide-react';
import Avatar from './Avatar';
import Tick from './Tick';
import { fmtClock, dayLabel, sameDay, fmtDuration, fmtBytes, isOnlyEmoji, downloadFile, type Message, type UserProfile, type Reaction, type Receipt } from '../lib/api';

interface Props {
  msg: Message;
  mine: boolean;
  sender?: UserProfile | null;
  showSender: boolean;
  isGroup: boolean;
  quoted?: Message | null;
  quotedSenderName?: string;
  reactions: Reaction[];
  receipt: 'sent' | 'delivered' | 'read';
  readReceiptsOn: boolean;
  continued: boolean;
  newDay: boolean;
  selected: boolean;
  highlight: boolean;
  onContext: (e: React.MouseEvent, msg: Message) => void;
  onOpenMedia: (msg: Message) => void;
  onQuoteClick: (id: number) => void;
  onReact: (msg: Message, emoji: string) => void;
  onTapSelect: (msg: Message) => void;
  onAvatarClick: (userId: string) => void;
  namesOf: (uid: string) => string;
}

const QUICK = ['❤️', '👍', '😂', '😮', '😢', '🙏'];

export default function MessageBubble(props: Props) {
  const { msg: m, mine } = props;
  const [showQuick, setShowQuick] = useState(false);
  const longT = useRef<number | null>(null);

  useEffect(() => () => { if (longT.current) window.clearTimeout(longT.current); }, []);

  const grouped = useMemo(() => {
    const map = new Map<string, Reaction[]>();
    for (const r of props.reactions) {
      const arr = map.get(r.emoji) || [];
      arr.push(r);
      map.set(r.emoji, arr);
    }
    return [...map.entries()];
  }, [props.reactions]);

  if (m.is_deleted) {
    return (
      <div className={`flex ${mine ? 'justify-end' : 'justify-start'} px-3 sm:px-6`}>
        <div className="max-w-[78%] sm:max-w-[65%] px-3.5 py-2 rounded-2xl bg-white/85 dark:bg-slate-800/85 text-slate-400 italic text-sm flex items-center gap-2 border border-slate-200/60 dark:border-slate-700/60">
          <span>🚫</span> Pesan ini telah dihapus
          <span className="text-[10px] not-italic ml-1">{fmtClock(m.created_at)}</span>
        </div>
      </div>
    );
  }

  if (m.kind === 'system') {
    return (
      <div className="flex justify-center px-6">
        <div className="max-w-[85%] px-4 py-1.5 rounded-xl bg-amber-100/90 dark:bg-slate-800/90 text-amber-900 dark:text-amber-200/90 text-[12px] text-center shadow-sm">
          {m.body}
        </div>
      </div>
    );
  }

  const bigEmoji = m.kind === 'text' && isOnlyEmoji(m.body);

  return (
    <>
      {props.newDay && (
        <div className="flex justify-center my-1">
          <span className="px-3.5 py-1.5 rounded-xl bg-white/85 dark:bg-slate-800/90 text-[12px] font-bold text-slate-500 dark:text-slate-300 shadow-sm">
            {dayLabel(m.created_at)}
          </span>
        </div>
      )}
      <div
        id={`msg-${m.id}`}
        className={`flex ${mine ? 'justify-end' : 'justify-start'} px-3 sm:px-6 scroll-mt-24 ${props.highlight ? 'msg-flash' : ''}`}
      >
        <div className={`flex items-end gap-1.5 max-w-[82%] sm:max-w-[68%] ${mine ? 'flex-row-reverse' : ''}`}>
          {!mine && !props.continued && props.isGroup && (
            <button onClick={() => props.onAvatarClick(m.sender_id)} className="shrink-0 mb-0.5">
              <Avatar name={props.sender?.name || '?'} src={props.sender?.avatar_url || ''} size={28} />
            </button>
          )}
          {!mine && (props.continued || !props.isGroup) && <span className="w-0 shrink-0" />}

          <div className="relative min-w-0">
            {/* quick react popup */}
            {showQuick && (
              <>
                <span className="fixed inset-0 z-30" onClick={() => setShowQuick(false)} />
                <span className={`absolute z-40 -top-11 ${mine ? 'right-0' : 'left-0'} flex gap-0.5 bg-white dark:bg-slate-800 rounded-full shadow-xl border border-slate-200 dark:border-slate-700 p-1 fa-animate-pop`}>
                  {QUICK.map((e) => (
                    <button
                      key={e}
                      onClick={() => { props.onReact(m, e); setShowQuick(false); }}
                      className="text-xl hover:scale-125 transition p-0.5"
                    >
                      {e}
                    </button>
                  ))}
                </span>
              </>
            )}

            <div
              onContextMenu={(e) => props.onContext(e, m)}
              onDoubleClick={() => { if (!props.selected) setShowQuick(true); }}
              onTouchStart={() => {
                if (longT.current) window.clearTimeout(longT.current);
                longT.current = window.setTimeout(() => setShowQuick(true), 550);
              }}
              onTouchEnd={() => { if (longT.current) window.clearTimeout(longT.current); }}
              onClick={() => { if (props.selected) props.onTapSelect(m); }}
              className={`relative px-3 pt-2 pb-1.5 shadow-sm text-[15px] leading-relaxed break-words cursor-pointer transition ${
                bigEmoji
                  ? 'bg-transparent shadow-none !px-1'
                  : mine
                    ? 'bg-teal-600 dark:bg-teal-700 text-white rounded-2xl rounded-br-md'
                    : 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-2xl rounded-bl-md'
              } ${props.selected ? 'ring-2 ring-amber-400' : ''}`}
            >
              {/* sender name in group */}
              {props.showSender && !mine && (
                <button onClick={() => props.onAvatarClick(m.sender_id)} className="block text-[13px] font-extrabold text-teal-600 dark:text-teal-400 truncate max-w-full text-left">
                  {props.sender?.name || 'Anggota'}
                </button>
              )}

              {/* forwarded */}
              {m.forwarded && (
                <span className={`flex items-center gap-1 text-[12px] italic mb-0.5 ${mine ? 'text-teal-100' : 'text-slate-400'}`}>
                  ➦ Diteruskan{m.forwarded_from ? ` dari ${m.forwarded_from}` : ''}
                </span>
              )}

              {/* quote */}
              {m.reply_to && (
                <QuotedBlock
                  mine={mine}
                  body={props.quoted ? quotePreview(props.quoted) : 'Memuat…'}
                  name={m.reply_to === m.id ? '' : props.quotedSenderName || ''}
                  onClick={() => props.onQuoteClick(m.reply_to!)}
                />
              )}

              {/* content */}
              <MsgContent m={m} mine={mine} onOpenMedia={() => props.onOpenMedia(m)} namesOf={props.namesOf} />

              {/* meta */}
              <span className={`flex items-center justify-end gap-1 mt-0.5 select-none ${bigEmoji ? 'bg-black/30 rounded-full px-2 py-0.5 w-fit ml-auto' : ''}`}>
                {m.edited && <span className={`text-[10px] italic ${mine && !bigEmoji ? 'text-teal-100' : 'text-slate-400'}`}>diedit</span>}
                <span className={`text-[11px] ${mine && !bigEmoji ? 'text-teal-100' : bigEmoji ? 'text-white' : 'text-slate-400'}`}>{fmtClock(m.created_at)}</span>
                {mine && props.readReceiptsOn !== false && <Tick status={props.receipt} size={16} />}
                {mine && props.readReceiptsOn === false && <span className="text-teal-100 text-[11px]">✓</span>}
              </span>
            </div>

            {/* reactions */}
            {grouped.length > 0 && (
              <span className={`absolute -bottom-3.5 ${mine ? 'left-1' : 'right-1'} flex gap-0.5 bg-white dark:bg-slate-800 rounded-full shadow border border-slate-200 dark:border-slate-700 px-1 py-0.5 z-10`}>
                {grouped.map(([emoji, arr]) => (
                  <button
                    key={emoji}
                    title={arr.map((r) => props.namesOf(r.user_id)).join(', ')}
                    onClick={() => props.onReact(m, emoji)}
                    className="flex items-center gap-0.5 text-[13px] hover:scale-110 transition px-0.5"
                  >
                    {emoji}{arr.length > 1 && <span className="text-[11px] font-bold text-slate-500 dark:text-slate-300">{arr.length}</span>}
                  </button>
                ))}
              </span>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

function quotePreview(m: Message): string {
  if (m.is_deleted) return 'Pesan telah dihapus';
  if (m.kind === 'text') return m.body.slice(0, 120);
  if (m.kind === 'image') return '📷 Foto' + (m.body ? ` • ${m.body.slice(0, 60)}` : '');
  if (m.kind === 'video') return '🎬 Video' + (m.body ? ` • ${m.body.slice(0, 60)}` : '');
  if (m.kind === 'voice') return '🎙️ Pesan suara';
  if (m.kind === 'audio') return '🎵 Audio';
  if (m.kind === 'document') return `📄 ${m.media_name || 'Dokumen'}`;
  if (m.kind === 'contact') return '👤 Kontak';
  if (m.kind === 'location') return '📍 Lokasi';
  if (m.kind === 'sticker') return '😀 Stiker';
  if (m.kind === 'gif') return '🎞️ GIF';
  return m.body.slice(0, 120);
}

function QuotedBlock({ mine, body, name, onClick }: { mine: boolean; body: string; name: string; onClick: () => void }) {
  return (
    <button
      onClick={(e) => { e.stopPropagation(); onClick(); }}
      className={`flex w-full gap-2 items-stretch rounded-lg overflow-hidden mb-1 text-left ${mine ? 'bg-black/20' : 'bg-slate-100 dark:bg-slate-700/60'}`}
    >
      <span className={`w-1 shrink-0 ${mine ? 'bg-teal-200' : 'bg-teal-500'}`} />
      <span className="flex-1 min-w-0 py-1 pr-2">
        {name && <span className={`block text-[12px] font-extrabold truncate ${mine ? 'text-teal-100' : 'text-teal-600 dark:text-teal-400'}`}>{name}</span>}
        <span className={`block text-[13px] truncate ${mine ? 'text-teal-50' : 'text-slate-500 dark:text-slate-300'}`}>
          <Quote size={11} className="inline mr-1 -mt-0.5" />{body}
        </span>
      </span>
    </button>
  );
}

function linkify(text: string, mine: boolean) {
  const parts = text.split(/(\s+)/);
  return parts.map((w, i) => {
    if (/^(https?:\/\/|www\.)\S+$/i.test(w)) {
      const href = w.startsWith('http') ? w : `https://${w}`;
      return <a key={i} href={href} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} className={`underline break-all ${mine ? 'text-teal-50' : 'text-teal-600 dark:text-teal-400'}`}>{w}</a>;
    }
    if (/^@[\w.-]+$/.test(w)) {
      return <span key={i} className={`font-bold ${mine ? 'text-lime-200' : 'text-teal-600 dark:text-teal-400'}`}>{w}</span>;
    }
    return <span key={i}>{w}</span>;
  });
}

function MsgContent({ m, mine, onOpenMedia, namesOf: _namesOf }: { m: Message; mine: boolean; onOpenMedia: () => void; namesOf: (u: string) => string }) {
  void _namesOf;
  if (m.kind === 'image') {
    return (
      <span className="block">
        <button onClick={(e) => { e.stopPropagation(); onOpenMedia(); }} className="block rounded-xl overflow-hidden -mx-1 -mt-1 mb-1 max-w-[300px]">
          <img src={m.media_url} alt="" loading="lazy" className="w-full max-h-[320px] object-cover bg-black/10" />
        </button>
        {m.body && <span className="block whitespace-pre-wrap">{linkify(m.body, mine)}</span>}
      </span>
    );
  }
  if (m.kind === 'video') {
    return (
      <span className="block">
        <button onClick={(e) => { e.stopPropagation(); onOpenMedia(); }} className="relative block rounded-xl overflow-hidden -mx-1 -mt-1 mb-1 max-w-[300px]">
          <video src={m.media_url} preload="metadata" className="w-full max-h-[320px] bg-black" />
          <span className="absolute inset-0 flex items-center justify-center">
            <span className="w-12 h-12 rounded-full bg-black/60 text-white flex items-center justify-center"><Play size={22} className="ml-0.5" /></span>
          </span>
          {m.duration > 0 && <span className="absolute bottom-1.5 right-1.5 text-[11px] font-bold text-white bg-black/60 px-1.5 py-0.5 rounded">{fmtDuration(m.duration)}</span>}
        </button>
        {m.body && <span className="block whitespace-pre-wrap">{linkify(m.body, mine)}</span>}
      </span>
    );
  }
  if (m.kind === 'gif') {
    return (
      <span className="block">
        <button onClick={(e) => { e.stopPropagation(); onOpenMedia(); }} className="block rounded-xl overflow-hidden -mx-1 -mt-1 mb-1 max-w-[260px]">
          <img src={m.media_url} alt={m.body || 'GIF'} loading="lazy" className="w-full max-h-[260px] object-cover bg-black/10" />
        </button>
        {m.body && <span className="block text-[13px] opacity-80">{m.body}</span>}
      </span>
    );
  }
  if (m.kind === 'sticker') {
    return m.media_mime === 'text' ? (
      <span className="block font-mono font-bold text-lg py-1 whitespace-pre-wrap">{m.body}</span>
    ) : (
      <span className="block text-[72px] leading-none py-1">{m.body}</span>
    );
  }
  if (m.kind === 'voice' || m.kind === 'audio') {
    return <VoicePlayer key={m.id} m={m} mine={mine} />;
  }
  if (m.kind === 'document') {
    return <DocCard m={m} mine={mine} />;
  }
  if (m.kind === 'contact') {
    const c = m.contact_data || {};
    return (
      <span className={`flex items-center gap-2.5 rounded-xl p-2.5 min-w-[200px] ${mine ? 'bg-black/15' : 'bg-slate-100 dark:bg-slate-700/60'}`}>
        <span className={`w-11 h-11 rounded-full flex items-center justify-center shrink-0 ${mine ? 'bg-white/25' : 'bg-teal-100 dark:bg-teal-900'}`}>
          <UserIcon size={22} className={mine ? 'text-white' : 'text-teal-600 dark:text-teal-300'} />
        </span>
        <span className="min-w-0">
          <span className="block font-bold truncate">{c.name || 'Kontak'}</span>
          <span className={`block text-[13px] ${mine ? 'text-teal-100' : 'text-slate-500 dark:text-slate-400'}`}>{c.phone || ''}</span>
          {c.phone && <a href={`tel:${c.phone}`} onClick={(e) => e.stopPropagation()} className={`text-[13px] font-bold underline ${mine ? 'text-white' : 'text-teal-600'}`}>Hubungi</a>}
        </span>
      </span>
    );
  }
  if (m.kind === 'location') {
    const l = m.location_data || {};
    const maps = l.lat !== undefined ? `https://www.google.com/maps?q=${l.lat},${l.lng}` : 'https://maps.google.com';
    return (
      <a href={maps} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} className={`flex items-center gap-2.5 rounded-xl p-2.5 min-w-[210px] ${mine ? 'bg-black/15' : 'bg-slate-100 dark:bg-slate-700/60'}`}>
        <span className={`w-11 h-11 rounded-full flex items-center justify-center shrink-0 ${mine ? 'bg-white/25' : 'bg-rose-100 dark:bg-rose-900/40'}`}>
          <MapPin size={22} className={mine ? 'text-white' : 'text-rose-500'} />
        </span>
        <span className="min-w-0">
          <span className="block font-bold truncate">{l.label || 'Lokasi dibagikan'}</span>
          <span className={`block text-[13px] underline ${mine ? 'text-teal-100' : 'text-teal-600 dark:text-teal-400'}`}>Buka di Google Maps</span>
        </span>
      </a>
    );
  }
  return <span className={`block whitespace-pre-wrap ${isOnlyEmoji(m.body) ? 'text-[44px] leading-tight' : ''}`}>{linkify(m.body, mine)}</span>;
}

function VoicePlayer({ m, mine }: { m: Message; mine: boolean }) {
  const audio = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);
  const [t, setT] = useState(0);
  const [dur, setDur] = useState(m.duration || 0);

  useEffect(() => {
    const a = audio.current;
    if (!a) return;
    const onTime = () => setT(a.currentTime);
    const onMeta = () => { if (a.duration && Number.isFinite(a.duration)) setDur(a.duration); };
    const onEnd = () => { setPlaying(false); setT(0); };
    a.addEventListener('timeupdate', onTime);
    a.addEventListener('loadedmetadata', onMeta);
    a.addEventListener('ended', onEnd);
    return () => {
      a.removeEventListener('timeupdate', onTime);
      a.removeEventListener('loadedmetadata', onMeta);
      a.removeEventListener('ended', onEnd);
    };
  }, []);

  const toggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    const a = audio.current;
    if (!a) return;
    if (playing) { a.pause(); setPlaying(false); }
    else {
      document.querySelectorAll('audio').forEach((x) => { if (x !== a) x.pause(); });
      void a.play(); setPlaying(true);
    }
  };

  const bars = useMemo(() => {
    const seed = m.id * 7919;
    return Array.from({ length: 26 }, (_, i) => {
      const v = Math.sin(seed + i * 1.7) * 0.5 + 0.5;
      return 0.3 + v * 0.7;
    });
  }, [m.id]);
  const progress = dur > 0 ? t / dur : 0;

  return (
    <span className="flex items-center gap-2 min-w-[210px] max-w-[280px]" onClick={(e) => e.stopPropagation()}>
      <audio ref={audio} src={m.media_url} preload="metadata" />
      <button onClick={toggle} className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 transition active:scale-95 ${mine ? 'bg-white/25 hover:bg-white/35' : 'bg-teal-600 hover:bg-teal-700 text-white'}`}>
        {playing ? <Pause size={19} /> : m.kind === 'voice' ? <Mic size={19} /> : <Play size={19} className="ml-0.5" />}
      </button>
      <span className="flex-1 min-w-0">
        <span className="flex items-end gap-[2px] h-7 cursor-pointer" onClick={(e) => {
          const a = audio.current;
          if (!a || !dur) return;
          const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
          const ratio = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
          a.currentTime = ratio * dur;
          setT(a.currentTime);
        }}>
          {bars.map((h, i) => (
            <span
              key={i}
              className={`flex-1 rounded-full ${i / bars.length <= progress ? (mine ? 'bg-white' : 'bg-teal-600') : (mine ? 'bg-white/40' : 'bg-slate-300 dark:bg-slate-600')}`}
              style={{ height: `${h * 100}%`, minWidth: 2 }}
            />
          ))}
        </span>
        <span className={`flex justify-between text-[11px] font-semibold mt-0.5 ${mine ? 'text-teal-100' : 'text-slate-400'}`}>
          <span>{fmtDuration(t)}</span><span>{fmtDuration(dur)}</span>
        </span>
      </span>
    </span>
  );
}

function DocCard({ m, mine }: { m: Message; mine: boolean }) {
  const [pct, setPct] = useState<number | null>(null);
  const dl = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      setPct(0);
      await downloadFile(m.media_url, m.media_name || 'dokumen', (p) => setPct(p));
      setPct(null);
    } catch {
      setPct(null);
    }
  };
  return (
    <span className={`flex items-center gap-2.5 rounded-xl p-2.5 min-w-[220px] max-w-[280px] ${mine ? 'bg-black/15' : 'bg-slate-100 dark:bg-slate-700/60'}`}>
      <span className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${mine ? 'bg-white/25' : 'bg-rose-100 dark:bg-rose-900/40'}`}>
        <FileText size={22} className={mine ? 'text-white' : 'text-rose-500'} />
      </span>
      <span className="flex-1 min-w-0">
        <span className="block font-bold truncate text-[14px]">{m.media_name || 'Dokumen'}</span>
        <span className={`block text-[12px] ${mine ? 'text-teal-100' : 'text-slate-500 dark:text-slate-400'}`}>
          {fmtBytes(m.media_size)}{m.media_mime ? ` • ${m.media_mime.split('/')[1] || m.media_mime}` : ''}
        </span>
        {pct !== null && (
          <span className="block h-1.5 rounded-full bg-black/20 mt-1 overflow-hidden">
            <span className="block h-full bg-white rounded-full" style={{ width: `${pct}%` }} />
          </span>
        )}
      </span>
      <button onClick={dl} className={`p-2 rounded-full shrink-0 transition active:scale-95 ${mine ? 'bg-white/25 hover:bg-white/35' : 'bg-teal-600 hover:bg-teal-700 text-white'}`} title="Unduh">
        <Download size={17} />
      </button>
    </span>
  );
}

/** Lightbox galeri media */
export function MediaViewer({ items, index, onClose, onNav }: {
  items: Message[];
  index: number;
  onClose: () => void;
  onNav: (i: number) => void;
}) {
  const m = items[index];
  const [pct, setPct] = useState<number | null>(null);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') onNav((index + 1) % items.length);
      if (e.key === 'ArrowLeft') onNav((index - 1 + items.length) % items.length);
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [index, items.length, onClose, onNav]);

  if (!m) return null;
  const dl = async () => {
    try {
      setPct(0);
      await downloadFile(m.media_url, m.media_name || `fastapp-${m.kind}-${m.id}`, (p) => setPct(p));
      setPct(null);
    } catch { setPct(null); }
  };

  return (
    <div className="fixed inset-0 z-[90] bg-black/95 flex flex-col fa-animate-fade-in" onClick={onClose}>
      <div className="flex items-center justify-between px-4 py-3 text-white" onClick={(e) => e.stopPropagation()}>
        <span className="text-sm font-bold">{index + 1} / {items.length} • {m.media_name || (m.kind === 'image' ? 'Foto' : m.kind === 'video' ? 'Video' : 'GIF')}</span>
        <span className="flex gap-1">
          {(m.kind === 'image' || m.kind === 'video') && (
            <button onClick={dl} className="p-2.5 rounded-full hover:bg-white/15" title="Unduh">
              <Download size={20} />
            </button>
          )}
          <button onClick={onClose} className="p-2.5 rounded-full hover:bg-white/15" title="Tutup">
            <X size={20} />
          </button>
        </span>
      </div>
      {pct !== null && (
        <div className="h-1 bg-white/20 mx-4 rounded-full overflow-hidden" onClick={(e) => e.stopPropagation()}>
          <div className="h-full bg-teal-400 rounded-full transition-all" style={{ width: `${pct}%` }} />
        </div>
      )}
      <div className="flex-1 flex items-center justify-center min-h-0 px-2 sm:px-14" onClick={(e) => e.stopPropagation()}>
        {items.length > 1 && (
          <button onClick={() => onNav((index - 1 + items.length) % items.length)} className="hidden sm:flex p-3 rounded-full bg-white/10 hover:bg-white/20 text-white mr-3" aria-label="Sebelumnya">
            <ChevronLeft size={24} />
          </button>
        )}
        <div className="max-w-full max-h-full flex items-center justify-center">
          {m.kind === 'video' ? (
            <video src={m.media_url} controls autoPlay className="max-w-full max-h-[78vh] rounded-xl" />
          ) : (
            <img src={m.media_url} alt="" className="max-w-full max-h-[78vh] object-contain rounded-xl" />
          )}
        </div>
        {items.length > 1 && (
          <button onClick={() => onNav((index + 1) % items.length)} className="hidden sm:flex p-3 rounded-full bg-white/10 hover:bg-white/20 text-white ml-3" aria-label="Berikutnya">
            <ChevronRight size={24} />
          </button>
        )}
      </div>
      {m.body && <p className="text-center text-white/80 text-sm px-6 pb-2" onClick={(e) => e.stopPropagation()}>{m.body}</p>}
      <p className="text-center text-white/50 text-xs pb-5" onClick={(e) => e.stopPropagation()}>
        {dayLabel(m.created_at)} • {fmtClock(m.created_at)}
      </p>
    </div>
  );
}

export { StickerIcon, Phone };
export type { Receipt };
