import { useEffect, useRef, useState } from 'react';
import {
  X, Camera, Pencil, Check, Phone, Mail, AtSign, Info, LogOut, Moon, Sun,
  Bell, BellOff, Volume2, ShieldCheck, Eye, EyeOff, UserX, ChevronRight,
  Trash2, Loader2, Lock, Smartphone, Users,
} from 'lucide-react';
import Avatar from './Avatar';
import Logo from './Logo';
import { useToast } from './Toast';
import { useAuth } from '../contexts/AuthContext';
import { apiGet, apiDelete, uploadFile, type UserProfile } from '../lib/api';

interface Props {
  onClose: () => void;
  dark: boolean;
  onToggleDark: () => void;
}

type Page = 'main' | 'profile' | 'privacy' | 'notif' | 'blocked' | 'about';

export default function Settings({ onClose, dark, onToggleDark }: Props) {
  const { profile, updateProfile, signOut } = useAuth();
  const toast = useToast();
  const [page, setPage] = useState<Page>('main');
  const [blocked, setBlocked] = useState<UserProfile[]>([]);
  const [loggingOut, setLoggingOut] = useState(false);

  useEffect(() => {
    if (page === 'blocked' && profile) {
      apiGet<{ rows: { blocked_id: string }[] }>(`/api/blocks?user_id=${profile.id}`)
        .then(async (r) => {
          const ids = r.rows.map((x) => x.blocked_id);
          if (!ids.length) { setBlocked([]); return; }
          const users = await apiGet<UserProfile[]>(`/api/users?ids=${ids.join(',')}`);
          setBlocked(users);
        })
        .catch(() => {});
    }
  }, [page, profile]);

  const unblock = async (id: string) => {
    if (!profile) return;
    try {
      await apiDelete('/api/blocks', { blocker_id: profile.id, blocked_id: id });
      setBlocked((b) => b.filter((u) => u.id !== id));
      toast('Blokir dibuka ✓', 'success');
    } catch { toast('Gagal membuka blokir', 'error'); }
  };

  const doLogout = async () => {
    if (!window.confirm('Keluar dari FastApp?')) return;
    setLoggingOut(true);
    try { await signOut(); } catch { toast('Gagal keluar', 'error'); setLoggingOut(false); }
  };

  const titles: Record<Page, string> = {
    main: 'Pengaturan', profile: 'Profil saya', privacy: 'Privasi & Keamanan',
    notif: 'Notifikasi', blocked: 'Kontak diblokir', about: 'Tentang FastApp',
  };

  return (
    <div className="fixed inset-0 z-[75] bg-black/60 flex justify-end" onClick={onClose}>
      <div className="w-full sm:max-w-md h-full bg-slate-50 dark:bg-slate-950 overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="sticky top-0 z-10 bg-slate-50/95 dark:bg-slate-950/95 backdrop-blur flex items-center gap-2 px-4 py-3 border-b border-slate-200 dark:border-slate-800">
          {page !== 'main' ? (
            <button onClick={() => setPage('main')} className="p-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 font-bold">‹ Kembali</button>
          ) : (
            <button onClick={onClose} className="p-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800"><X size={20} /></button>
          )}
          <p className="font-extrabold flex-1">{titles[page]}</p>
          <span className="w-9" />
        </div>

        <div className="p-3 pb-10 space-y-2.5">
          {page === 'main' && profile && (
            <>
              <button onClick={() => setPage('profile')} className="w-full bg-white dark:bg-slate-900 rounded-2xl p-4 flex items-center gap-3 shadow-sm border border-slate-200/60 dark:border-slate-800 text-left">
                <Avatar name={profile.name} src={profile.avatar_url} size={58} />
                <span className="flex-1 min-w-0">
                  <span className="font-extrabold block truncate text-[17px]">{profile.name}</span>
                  <span className="text-[13px] text-slate-500 truncate block">{profile.bio || 'Hai! Saya memakai FastApp ⚡'}</span>
                </span>
                <ChevronRight size={19} className="text-slate-300" />
              </button>

              <Card>
                <Item icon={<Users size={19} />} t="Profil saya" d="Foto, nama, username, bio" onClick={() => setPage('profile')} />
                <Item icon={<ShieldCheck size={19} />} t="Privasi & Keamanan" d="Terakhir dilihat, foto, centang biru" onClick={() => setPage('privacy')} />
                <Item icon={<Bell size={19} />} t="Notifikasi" d="Bunyi, getar, pratinjau" onClick={() => setPage('notif')} />
                <Item icon={<UserX size={19} />} t="Kontak diblokir" d="Kelola daftar blokir" onClick={() => setPage('blocked')} />
                <Item
                  icon={dark ? <Sun size={19} /> : <Moon size={19} />}
                  t="Mode gelap" d={dark ? 'Aktif' : 'Mati'}
                  onClick={onToggleDark} toggle={dark}
                />
                <Item icon={<Info size={19} />} t="Tentang FastApp" d="Versi & info aplikasi" onClick={() => setPage('about')} />
              </Card>

              <button
                onClick={() => void doLogout()}
                disabled={loggingOut}
                className="w-full bg-white dark:bg-slate-900 rounded-2xl p-4 flex items-center justify-center gap-2 text-rose-600 dark:text-rose-400 font-extrabold shadow-sm border border-slate-200/60 dark:border-slate-800 disabled:opacity-60"
              >
                {loggingOut ? <Loader2 size={19} className="animate-spin" /> : <LogOut size={19} />}
                {loggingOut ? 'Keluar…' : 'Keluar Akun'}
              </button>
              <p className="text-center text-xs text-slate-400">Masuk sebagai {profile.email}</p>
            </>
          )}

          {page === 'profile' && profile && <ProfileEditor />}

          {page === 'privacy' && profile && (
            <PrivacyPage
              profile={profile}
              onSave={async (patch) => {
                try {
                  await updateProfile(patch);
                  toast('Pengaturan privasi disimpan ✓', 'success');
                } catch { toast('Gagal menyimpan', 'error'); }
              }}
            />
          )}

          {page === 'notif' && profile && (
            <NotifPage
              profile={profile}
              onSave={async (ns) => {
                try {
                  await updateProfile({ notif_settings: ns });
                  toast('Pengaturan notifikasi disimpan ✓', 'success');
                } catch { toast('Gagal menyimpan', 'error'); }
              }}
            />
          )}

          {page === 'blocked' && (
            <Card>
              {blocked.length === 0 ? (
                <p className="text-sm text-slate-400 text-center py-6">Tidak ada kontak yang diblokir. 🎉</p>
              ) : blocked.map((u) => (
                <div key={u.id} className="flex items-center gap-3 py-2">
                  <Avatar name={u.name} src={u.avatar_url} size={44} />
                  <span className="flex-1 min-w-0">
                    <span className="font-bold block truncate">{u.name}</span>
                    <span className="text-xs text-slate-500 block truncate">@{u.username}</span>
                  </span>
                  <button onClick={() => void unblock(u.id)} className="px-3.5 py-1.5 rounded-full bg-teal-600 text-white text-[13px] font-bold">Buka</button>
                </div>
              ))}
            </Card>
          )}

          {page === 'about' && (
            <>
              <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 flex flex-col items-center text-center shadow-sm border border-slate-200/60 dark:border-slate-800">
                <Logo size={72} className="!rounded-[22px]" />
                <p className="font-extrabold text-xl mt-3">FastApp</p>
                <p className="text-sm text-slate-500">Versi 1.0.0 • Web App</p>
                <p className="text-[13px] text-slate-500 mt-3 leading-relaxed">
                  Aplikasi komunikasi modern yang cepat, ringan, dan aman. Chat pribadi, grup, status, serta panggilan suara & video — semua dalam satu aplikasi.
                </p>
              </div>
              <Card>
                <InfoRow k="Kecepatan" v="⚡ Kilat" />
                <InfoRow k="Keamanan" v="🔐 Kata sandi terenkripsi" />
                <InfoRow k="Sesi" v="Tetap login otomatis" />
                <InfoRow k="Platform" v="Web responsif (HP & desktop)" />
              </Card>
              <p className="text-center text-xs text-slate-400">© 2026 FastApp • Buatan Indonesia 🇮🇩</p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function ProfileEditor() {
  const { profile, updateProfile } = useAuth();
  const toast = useToast();
  const [name, setName] = useState(profile?.name || '');
  const [username, setUsername] = useState(profile?.username || '');
  const [phone, setPhone] = useState(profile?.phone || '');
  const [bio, setBio] = useState(profile?.bio || '');
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  if (!profile) return null;

  const save = async () => {
    if (name.trim().length < 2) { toast('Nama minimal 2 huruf', 'error'); return; }
    if (!/^[a-zA-Z0-9._]{3,24}$/.test(username.trim())) { toast('Username 3–24 karakter (huruf, angka, titik, garis bawah)', 'error'); return; }
    if (phone.trim() && !/^[+]?[\d\s().-]{9,16}$/.test(phone.trim())) { toast('Nomor telepon tidak valid', 'error'); return; }
    setBusy(true);
    try {
      await updateProfile({ name: name.trim(), username: username.trim().toLowerCase(), phone: phone.trim(), bio: bio.trim().slice(0, 160) });
      toast('Profil diperbarui ✓', 'success');
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Gagal menyimpan profil', 'error');
    } finally {
      setBusy(false);
    }
  };

  const changePhoto = async (f: File | undefined) => {
    if (!f) return;
    if (!f.type.startsWith('image/')) { toast('Pilih file gambar', 'error'); return; }
    if (f.size > 8 * 1024 * 1024) { toast('Ukuran foto maks. 8 MB', 'error'); return; }
    setUploading(true);
    try {
      const { url } = await uploadFile(f);
      await updateProfile({ avatar_url: url });
      toast('Foto profil diubah 📷', 'success');
    } catch { toast('Gagal mengunggah foto', 'error'); }
    finally { setUploading(false); }
  };

  const removePhoto = async () => {
    if (!window.confirm('Hapus foto profil?')) return;
    try {
      await updateProfile({ avatar_url: '' });
      toast('Foto profil dihapus', 'success');
    } catch { toast('Gagal menghapus foto', 'error'); }
  };

  return (
    <>
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 flex flex-col items-center shadow-sm border border-slate-200/60 dark:border-slate-800">
        <span className="relative">
          <Avatar name={name || profile.name} src={profile.avatar_url} size={104} />
          <button onClick={() => fileRef.current?.click()} className="absolute bottom-0 right-0 w-10 h-10 rounded-full bg-teal-600 text-white flex items-center justify-center shadow-lg" title="Ganti foto">
            {uploading ? <Loader2 size={18} className="animate-spin" /> : <Camera size={18} />}
          </button>
        </span>
        <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => { void changePhoto(e.target.files?.[0]); e.target.value = ''; }} />
        {profile.avatar_url && (
          <button onClick={() => void removePhoto()} className="mt-2 text-[13px] font-bold text-rose-500 flex items-center gap-1">
            <Trash2 size={13} /> Hapus foto
          </button>
        )}
        <p className="text-xs text-slate-400 mt-2 flex items-center gap-1"><Lock size={11} /> Foto maks. 8 MB • format gambar</p>
      </div>
      <Card>
        <PField icon={<Pencil size={17} />} label="Nama" value={name} onChange={setName} max={40} placeholder="Nama lengkap" />
        <PField icon={<AtSign size={17} />} label="Username" value={username} onChange={setUsername} max={24} placeholder="username_unik" />
        <PField icon={<Phone size={17} />} label="Nomor telepon" value={phone} onChange={setPhone} max={16} placeholder="0812…" />
        <label className="block py-2">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wide flex items-center gap-1.5"><Info size={13} /> Bio / Tentang</span>
          <textarea
            value={bio} onChange={(e) => setBio(e.target.value.slice(0, 160))} rows={2}
            placeholder="Ceritakan tentang dirimu…"
            className="mt-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-2xl px-4 py-3 text-[15px] outline-none focus:ring-2 focus:ring-teal-500 resize-none"
          />
          <span className="text-[11px] text-slate-400">{bio.length}/160</span>
        </label>
        <div className="flex items-center gap-2 py-2 text-sm">
          <Mail size={17} className="text-slate-400" />
          <span className="text-slate-500">{profile.email}</span>
          <span className="text-[11px] font-bold text-emerald-600 bg-emerald-100 dark:bg-emerald-900/50 px-2 py-0.5 rounded-full">Terverifikasi ✓</span>
        </div>
        <button onClick={() => void save()} disabled={busy} className="w-full mt-2 py-3 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white font-extrabold disabled:opacity-60 flex items-center justify-center gap-2">
          {busy ? <Loader2 size={17} className="animate-spin" /> : <Check size={17} />} Simpan Perubahan
        </button>
      </Card>
    </>
  );
}

const VIS_OPTS = [
  { v: 'everyone', t: 'Semua orang' },
  { v: 'contacts', t: 'Kontak saya' },
  { v: 'nobody', t: 'Tidak ada' },
] as const;

function PrivacyPage({ profile, onSave }: { profile: UserProfile; onSave: (p: Partial<UserProfile>) => Promise<void> }) {
  const [lastSeen, setLastSeen] = useState(profile.last_seen_visibility);
  const [avatar, setAvatar] = useState(profile.avatar_visibility);
  const [receipts, setReceipts] = useState(profile.read_receipts);
  const [busy, setBusy] = useState(false);

  const save = async () => {
    setBusy(true);
    await onSave({ last_seen_visibility: lastSeen, avatar_visibility: avatar, read_receipts: receipts });
    setBusy(false);
  };

  return (
    <>
      <Card>
        <VisRow icon={<Eye size={19} />} t="Terakhir dilihat & online" d="Siapa yang bisa melihat kapan Anda online" v={lastSeen} onChange={(v) => setLastSeen(v as typeof lastSeen)} />
        <VisRow icon={<Camera size={19} />} t="Foto profil" d="Siapa yang bisa melihat foto Anda" v={avatar} onChange={(v) => setAvatar(v as typeof avatar)} />
        <div className="flex items-center gap-3 py-3">
          <span className="text-slate-500 dark:text-slate-400">{receipts ? <Eye size={19} /> : <EyeOff size={19} />}</span>
          <span className="flex-1">
            <span className="block font-semibold text-sm">Tanda dibaca (centang biru)</span>
            <span className="block text-xs text-slate-400">Jika mati, Anda juga tidak bisa melihat tanda dibaca orang lain</span>
          </span>
          <Toggle on={receipts} onClick={() => setReceipts(!receipts)} />
        </div>
        <button onClick={() => void save()} disabled={busy} className="w-full mt-1 py-3 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white font-extrabold disabled:opacity-60 flex items-center justify-center gap-2">
          {busy && <Loader2 size={17} className="animate-spin" />} Simpan Privasi
        </button>
      </Card>
      <Card>
        <RowLabel t="Keamanan akun" />
        <div className="flex items-start gap-3 py-2 text-sm">
          <ShieldCheck size={19} className="text-emerald-500 shrink-0 mt-0.5" />
          <span className="text-slate-600 dark:text-slate-300">
            Kata sandi Anda tersimpan <b>terenkripsi</b> dan sesi login memakai <b>token aman</b> yang diperbarui otomatis. Jangan bagikan kode verifikasi ke siapa pun.
          </span>
        </div>
        <div className="flex items-start gap-3 py-2 text-sm">
          <Smartphone size={19} className="text-teal-500 shrink-0 mt-0.5" />
          <span className="text-slate-600 dark:text-slate-300">
            Anda tetap login di perangkat ini sampai sengaja keluar. Di perangkat umum, selalu tekan <b>Keluar Akun</b>.
          </span>
        </div>
      </Card>
    </>
  );
}

function NotifPage({ profile, onSave }: { profile: UserProfile; onSave: (ns: Record<string, boolean>) => Promise<void> }) {
  const toast = useToast();
  const [ns, setNs] = useState<Record<string, boolean>>({
    message: true, mention: true, call: true, sound: true, vibrate: true, preview: true,
    ...(profile.notif_settings || {}),
  });
  const [perm, setPerm] = useState<string>(typeof Notification !== 'undefined' ? Notification.permission : 'unsupported');

  const set = (k: string, v: boolean) => {
    const next = { ...ns, [k]: v };
    setNs(next);
    void onSave(next);
  };

  const askPerm = async () => {
    try {
      const r = await Notification.requestPermission();
      setPerm(r);
      if (r === 'granted') toast('Notifikasi browser diizinkan 🔔', 'success');
      else toast('Izin notifikasi ditolak', 'error');
    } catch { toast('Browser tidak mendukung notifikasi', 'error'); }
  };

  const askDevice = async (kind: 'camera' | 'mic') => {
    try {
      const s = await navigator.mediaDevices.getUserMedia(kind === 'camera' ? { video: true } : { audio: true });
      s.getTracks().forEach((t) => t.stop());
      toast(`Izin ${kind === 'camera' ? 'kamera' : 'mikrofon'} diberikan ✓`, 'success');
    } catch {
      toast(`Izin ${kind === 'camera' ? 'kamera' : 'mikrofon'} ditolak. Aktifkan di pengaturan browser.`, 'error');
    }
  };

  return (
    <>
      <Card>
        <RowLabel t="Izin perangkat" />
        <div className="flex items-center gap-3 py-2.5">
          <span className="text-slate-500">{perm === 'granted' ? <Bell size={19} /> : <BellOff size={19} />}</span>
          <span className="flex-1">
            <span className="block font-semibold text-sm">Notifikasi browser</span>
            <span className="block text-xs text-slate-400">Status: {perm === 'granted' ? 'diizinkan ✓' : perm === 'denied' ? 'ditolak' : 'belum diminta'}</span>
          </span>
          {perm !== 'granted' && (
            <button onClick={() => void askPerm()} className="px-3.5 py-1.5 rounded-full bg-teal-600 text-white text-[13px] font-bold">Izinkan</button>
          )}
        </div>
        <div className="flex items-center gap-3 py-2.5">
          <span className="text-slate-500"><Camera size={19} /></span>
          <span className="flex-1">
            <span className="block font-semibold text-sm">Kamera</span>
            <span className="block text-xs text-slate-400">Untuk video call & foto</span>
          </span>
          <button onClick={() => void askDevice('camera')} className="px-3.5 py-1.5 rounded-full bg-slate-200 dark:bg-slate-700 text-[13px] font-bold">Minta</button>
        </div>
        <div className="flex items-center gap-3 py-2.5">
          <span className="text-slate-500"><Volume2 size={19} /></span>
          <span className="flex-1">
            <span className="block font-semibold text-sm">Mikrofon</span>
            <span className="block text-xs text-slate-400">Untuk voice call & pesan suara</span>
          </span>
          <button onClick={() => void askDevice('mic')} className="px-3.5 py-1.5 rounded-full bg-slate-200 dark:bg-slate-700 text-[13px] font-bold">Minta</button>
        </div>
      </Card>
      <Card>
        <RowLabel t="Preferensi" />
        <NotifRow t="Pesan baru" d="Beri tahu setiap ada pesan masuk" on={!!ns.message} onClick={() => set('message', !ns.message)} />
        <NotifRow t="Mention di grup" d="Saat seseorang menyebut @username Anda" on={!!ns.mention} onClick={() => set('mention', !ns.mention)} />
        <NotifRow t="Panggilan masuk" d="Nada dering & banner panggilan" on={!!ns.call} onClick={() => set('call', !ns.call)} />
        <NotifRow t="Bunyi" d="Efek suara saat kirim & terima" on={!!ns.sound} onClick={() => set('sound', !ns.sound)} />
        <NotifRow t="Getar" d="Getaran saat pesan masuk (HP)" on={!!ns.vibrate} onClick={() => set('vibrate', !ns.vibrate)} />
        <NotifRow t="Pratinjau isi pesan" d="Tampilkan isi pesan di notifikasi" on={!!ns.preview} onClick={() => set('preview', !ns.preview)} />
      </Card>
    </>
  );
}

function Card({ children }: { children: React.ReactNode }) {
  return <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/60 dark:border-slate-800">{children}</div>;
}
function RowLabel({ t }: { t: string }) {
  return <p className="text-xs font-extrabold uppercase tracking-wider text-slate-400 mb-1">{t}</p>;
}
function InfoRow({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between py-1.5 text-sm border-b border-slate-100 dark:border-slate-800 last:border-0">
      <span className="text-slate-400">{k}</span><span className="font-semibold">{v}</span>
    </div>
  );
}
function Item({ icon, t, d, onClick, toggle }: { icon: React.ReactNode; t: string; d: string; onClick: () => void; toggle?: boolean }) {
  return (
    <button onClick={onClick} className="w-full flex items-center gap-3 py-2.5 text-left">
      <span className="p-2 rounded-2xl bg-teal-50 text-teal-600 dark:bg-teal-900/40 dark:text-teal-300">{icon}</span>
      <span className="flex-1"><span className="block font-bold text-[15px]">{t}</span><span className="block text-xs text-slate-400">{d}</span></span>
      {toggle === undefined ? <ChevronRight size={18} className="text-slate-300" /> : <Toggle on={toggle} onClick={onClick} />}
    </button>
  );
}
function PField({ icon, label, value, onChange, max, placeholder }: {
  icon: React.ReactNode; label: string; value: string; onChange: (v: string) => void; max: number; placeholder: string;
}) {
  return (
    <label className="block py-2">
      <span className="text-xs font-bold text-slate-400 uppercase tracking-wide flex items-center gap-1.5">{icon} {label}</span>
      <input
        value={value} onChange={(e) => onChange(e.target.value.slice(0, max))} placeholder={placeholder}
        className="mt-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-2xl px-4 py-3 text-[15px] outline-none focus:ring-2 focus:ring-teal-500"
      />
    </label>
  );
}
export function Toggle({ on, onClick }: { on: boolean; onClick: () => void }) {
  return (
    <button
      onClick={(e) => { e.stopPropagation(); onClick(); }}
      className={`w-12 h-7 rounded-full p-1 transition shrink-0 ${on ? 'bg-teal-600' : 'bg-slate-300 dark:bg-slate-700'}`}
      role="switch" aria-checked={on}
    >
      <span className={`block w-5 h-5 rounded-full bg-white shadow transition-transform ${on ? 'translate-x-5' : ''}`} />
    </button>
  );
}
function VisRow({ icon, t, d, v, onChange }: { icon: React.ReactNode; t: string; d: string; v: string; onChange: (v: string) => void }) {
  return (
    <div className="py-3 border-b border-slate-100 dark:border-slate-800 last:border-0">
      <span className="flex items-center gap-3">
        <span className="text-slate-500 dark:text-slate-400">{icon}</span>
        <span className="flex-1"><span className="block font-semibold text-sm">{t}</span><span className="block text-xs text-slate-400">{d}</span></span>
      </span>
      <span className="flex gap-1.5 mt-2 ml-9">
        {VIS_OPTS.map((o) => (
          <button
            key={o.v}
            onClick={() => onChange(o.v)}
            className={`flex-1 py-1.5 rounded-xl text-[12px] font-bold transition ${v === o.v ? 'bg-teal-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'}`}
          >
            {o.t}
          </button>
        ))}
      </span>
    </div>
  );
}
function NotifRow({ t, d, on, onClick }: { t: string; d: string; on: boolean; onClick: () => void }) {
  return (
    <div className="flex items-center gap-3 py-2.5 border-b border-slate-100 dark:border-slate-800 last:border-0">
      <span className="flex-1"><span className="block font-semibold text-sm">{t}</span><span className="block text-xs text-slate-400">{d}</span></span>
      <Toggle on={on} onClick={onClick} />
    </div>
  );
}
