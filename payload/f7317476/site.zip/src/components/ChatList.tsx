import { useMemo, useState } from 'react';
import { Search, MessageSquarePlus, Users, Archive, VolumeX, Pin, Camera, Plus } from 'lucide-react';
import Avatar from './Avatar';
import Tick from './Tick';
import Logo from './Logo';
import { fmtListTime, previewFor, colorFor, type Chat, type StatusItem } from '../lib/api';

interface Props {
  chats: Chat[];
  myId: string;
  activeId: number | null;
  onSelect: (id: number) => void;
  onNewChat: () => void;
  onNewGroup: () => void;
  onOpenSettings: () => void;
  myAvatar: string;
  myName: string;
  statuses: StatusItem[];
  onOpenStatuses: () => void;
  onAddStatus: () => void;
  search: string;
  onSearch: (s: string) => void;
  contextChat: (chat: Chat, x: number, y: number) => void;
}

export function chatTitle(c: Chat, myId: string): string {
  if (c.type === 'group') return c.name || 'Grup Tanpa Nama';
  const other = c.members.find((m) => m.user_id !== myId)?.user;
  return other?.name || c.name || 'Pengguna FastApp';
}

export function chatAvatar(c: Chat, myId: string): string {
  if (c.type === 'group') return c.avatar_url || '';
  const other = c.members.find((m) => m.user_id !== myId)?.user;
  return other?.avatar_url || '';
}

export function peerOf(c: Chat, myId: string) {
  return c.members.find((m) => m.user_id !== myId)?.user || null;
}

function tickFor(c: Chat, myId: string): 'sent' | 'delivered' | 'read' | null {
  const last = c.last_message;
  if (!last || last.sender_id !== myId) return null;
  if (last.is_deleted) return null;
  const others = c.members.filter((m) => m.user_id !== myId).map((m) => m.user_id);
  if (!others.length) return 'sent';
  const rc = c.last_receipts || [];
  const got = (uid: string) => rc.find((r) => r.user_id === uid)?.status;
  if (others.every((u) => got(u) === 'read')) return 'read';
  if (others.some((u) => got(u) === 'read' || got(u) === 'delivered')) return 'delivered';
  return 'sent';
}

export default function ChatList(p: Props) {
  const [tab, setTab] = useState<'all' | 'unread' | 'archived'>('all');

  const myStatuses = p.statuses.filter((s) => s.user_id === p.myId);
  const otherStatuses = p.statuses.filter((s) => s.user_id !== p.myId);

  const filtered = useMemo(() => {
    let rows = p.chats;
    if (tab === 'archived') rows = rows.filter((c) => c.my.archived);
    else {
      rows = rows.filter((c) => !c.my.archived);
      if (tab === 'unread') rows = rows.filter((c) => c.unread > 0);
    }
    const q = p.search.trim().toLowerCase();
    if (q) {
      rows = rows.filter((c) => {
        const t = chatTitle(c, p.myId).toLowerCase();
        const last = (c.last_message?.body || '').toLowerCase();
        const peer = peerOf(c, p.myId);
        return t.includes(q) || last.includes(q) || (peer?.username || '').toLowerCase().includes(q);
      });
    }
    return rows;
  }, [p.chats, p.search, p.myId, tab]);

  const archivedCount = p.chats.filter((c) => c.my.archived).length;

  return (
    <div className="h-full flex flex-col bg-white dark:bg-slate-900">
      {/* header */}
      <div className="flex items-center gap-3 px-4 pt-4 pb-3">
        <button onClick={p.onOpenSettings} className="flex items-center gap-2.5 flex-1 min-w-0 text-left group" title="Profil & Pengaturan">
          <Avatar name={p.myName} src={p.myAvatar} size={44} />
          <span className="min-w-0">
            <span className="flex items-center gap-1.5">
              <Logo size={20} className="!rounded-lg" />
              <span className="font-extrabold text-lg tracking-tight text-teal-700 dark:text-teal-300">FastApp</span>
            </span>
            <span className="block text-xs text-slate-500 dark:text-slate-400 truncate">{p.myName}</span>
          </span>
        </button>
        <button onClick={p.onNewChat} title="Chat baru" className="p-2.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition">
          <MessageSquarePlus size={21} />
        </button>
        <button onClick={p.onNewGroup} title="Grup baru" className="p-2.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition">
          <Users size={21} />
        </button>
      </div>

      {/* search */}
      <div className="px-4 pb-2">
        <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 rounded-2xl px-3.5 py-2.5">
          <Search size={18} className="text-slate-400 shrink-0" />
          <input
            value={p.search}
            onChange={(e) => p.onSearch(e.target.value)}
            placeholder="Cari chat atau kontak…"
            className="flex-1 bg-transparent outline-none text-[15px] placeholder:text-slate-400 min-w-0"
          />
        </div>
      </div>

      {/* status strip */}
      <div className="flex items-center gap-3 px-4 py-2 overflow-x-auto shrink-0">
        <button onClick={p.onAddStatus} className="flex flex-col items-center gap-1 shrink-0 group" title="Tambah status">
          <span className="relative">
            <Avatar name={p.myName} src={p.myAvatar} size={52} />
            <span className="absolute -bottom-0.5 -right-0.5 w-6 h-6 rounded-full bg-teal-600 text-white flex items-center justify-center border-2 border-white dark:border-slate-900">
              <Plus size={14} strokeWidth={3} />
            </span>
          </span>
          <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">Statusku</span>
        </button>
        {myStatuses.length > 0 && (
          <button onClick={p.onOpenStatuses} className="flex flex-col items-center gap-1 shrink-0" title="Status saya">
            <span className={`p-[2.5px] rounded-full bg-gradient-to-tr from-teal-500 to-emerald-400`}>
              <Avatar name={p.myName} src={p.myAvatar} size={47} className="border-2 border-white dark:border-slate-900" />
            </span>
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">Saya • {myStatuses.length}</span>
          </button>
        )}
        {[...new Map(otherStatuses.map((s) => [s.user_id, s])).values()].slice(0, 12).map((s) => (
          <button key={s.user_id} onClick={p.onOpenStatuses} className="flex flex-col items-center gap-1 shrink-0" title={s.user?.name}>
            <span className="p-[2.5px] rounded-full bg-gradient-to-tr from-teal-500 to-emerald-400">
              <Avatar name={s.user?.name || '?'} src={s.user?.avatar_url || ''} size={47} className="border-2 border-white dark:border-slate-900" />
            </span>
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 max-w-[56px] truncate">{(s.user?.name || '?').split(' ')[0]}</span>
          </button>
        ))}
      </div>

      {/* tabs */}
      <div className="flex items-center gap-2 px-4 py-2 shrink-0">
        {[
          { k: 'all', t: 'Semua' },
          { k: 'unread', t: `Belum dibaca${p.chats.some((c) => c.unread > 0 && !c.my.archived) ? ` (${p.chats.filter((c) => c.unread > 0 && !c.my.archived).length})` : ''}` },
          { k: 'archived', t: `Arsip${archivedCount ? ` (${archivedCount})` : ''}` },
        ].map((t) => (
          <button
            key={t.k}
            onClick={() => setTab(t.k as typeof tab)}
            className={`px-3.5 py-1.5 rounded-full text-[13px] font-bold transition ${tab === t.k ? 'bg-teal-600 text-white shadow' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'}`}
          >
            {t.t}
          </button>
        ))}
      </div>

      {/* list */}
      <div className="flex-1 overflow-y-auto px-2 pb-3">
        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center px-8 py-16 text-slate-400">
            {tab === 'archived' ? <Archive size={44} strokeWidth={1.5} /> : <Camera size={44} strokeWidth={1.5} />}
            <p className="font-bold mt-3 text-slate-500 dark:text-slate-400">
              {tab === 'archived' ? 'Arsip kosong' : p.search ? 'Tidak ditemukan' : 'Belum ada chat'}
            </p>
            <p className="text-sm mt-1">
              {tab === 'archived'
                ? 'Chat yang diarsipkan akan muncul di sini.'
                : p.search
                  ? `Tidak ada hasil untuk "${p.search}".`
                  : 'Ketuk ikon chat di atas untuk mulai ngobrol! 💬'}
            </p>
            {!p.search && tab === 'all' && (
              <button onClick={p.onNewChat} className="mt-4 px-5 py-2.5 rounded-full bg-teal-600 hover:bg-teal-700 text-white text-sm font-bold shadow-lg shadow-teal-600/25 transition">
                Mulai Chat Baru
              </button>
            )}
          </div>
        )}
        {filtered.map((c) => {
          const title = chatTitle(c, p.myId);
          const av = chatAvatar(c, p.myId);
          const tick = tickFor(c, p.myId);
          const last = c.last_message;
          const active = c.id === p.activeId;
          return (
            <button
              key={c.id}
              onClick={() => p.onSelect(c.id)}
              onContextMenu={(e) => { e.preventDefault(); p.contextChat(c, e.clientX, e.clientY); }}
              className={`w-full flex items-center gap-3 px-3 py-3 rounded-2xl text-left transition group ${active ? 'bg-teal-50 dark:bg-teal-950/40' : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'}`}
            >
              <span className="relative shrink-0">
                {c.type === 'group' ? (
                  <span className={`w-[52px] h-[52px] rounded-full bg-gradient-to-br ${colorFor('g' + c.id)} flex items-center justify-center text-white`}>
                    {c.avatar_url
                      ? <img src={c.avatar_url} alt="" className="w-full h-full rounded-full object-cover" />
                      : <Users size={24} />}
                  </span>
                ) : (
                  <Avatar name={title} src={av} size={52} />
                )}
              </span>
              <span className="flex-1 min-w-0">
                <span className="flex items-baseline gap-2">
                  <span className="font-bold truncate flex-1 text-[15px]">{title}</span>
                  {last && (
                    <span className={`text-[11px] shrink-0 font-semibold ${c.unread > 0 ? 'text-teal-600 dark:text-teal-400' : 'text-slate-400'}`}>
                      {fmtListTime(last.created_at)}
                    </span>
                  )}
                </span>
                <span className="flex items-center gap-1.5 mt-0.5">
                  {tick && <Tick status={tick} size={17} />}
                  {c.type === 'group' && last && last.sender_id === p.myId && (
                    <span className="text-[13px] text-slate-400 shrink-0">Anda:</span>
                  )}
                  {c.type === 'group' && last && last.sender_id !== p.myId && !last.is_deleted && (
                    <span className="text-[13px] text-slate-400 shrink-0 truncate max-w-[90px]">
                      {c.members.find((m) => m.user_id === last.sender_id)?.user?.name?.split(' ')[0] || ''}:
                    </span>
                  )}
                  <span className={`text-[13px] truncate flex-1 ${c.unread > 0 ? 'font-bold text-slate-800 dark:text-slate-100' : 'text-slate-500 dark:text-slate-400'}`}>
                    {previewFor(last)}
                  </span>
                  {c.my.muted && <VolumeX size={14} className="text-slate-400 shrink-0" />}
                  {c.my.pinned && <Pin size={13} className="text-slate-400 shrink-0 rotate-45" />}
                  {c.unread > 0 && (
                    <span className="min-w-[20px] h-5 px-1.5 rounded-full bg-teal-600 text-white text-[11px] font-extrabold flex items-center justify-center shrink-0">
                      {c.unread > 99 ? '99+' : c.unread}
                    </span>
                  )}
                </span>
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
