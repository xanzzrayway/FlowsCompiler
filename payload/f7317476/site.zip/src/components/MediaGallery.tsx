import { useEffect, useState } from 'react';
import { X, Download, FileText, Play, Loader2 } from 'lucide-react';
import { MediaViewer } from './MessageBubble';
import { apiGet, downloadFile, fmtListTime, fmtBytes, type Message } from '../lib/api';

interface Props {
  chatId: number;
  myId: string;
  tab: 'media' | 'docs';
  onClose: () => void;
}

export default function MediaGallery({ chatId, myId, onClose, tab }: Props) {
  const [t, setT] = useState(tab);
  const [msgs, setMsgs] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewer, setViewer] = useState<number | null>(null);
  const [dlId, setDlId] = useState<number | null>(null);

  useEffect(() => {
    setLoading(true);
    apiGet<{ messages: Message[] }>(`/api/messages?chat_id=${chatId}&limit=150`)
      .then((r) => setMsgs(r.messages.filter((m) => !(m.deleted_for || []).includes(myId) && !m.is_deleted)))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [chatId, myId]);

  const media = msgs.filter((m) => ['image', 'video', 'gif'].includes(m.kind) && m.media_url);
  const docs = msgs.filter((m) => ['document', 'audio', 'voice'].includes(m.kind));

  const dl = async (m: Message) => {
    try {
      setDlId(m.id);
      await downloadFile(m.media_url, m.media_name || `fastapp-${m.kind}-${m.id}`);
    } catch { /* abaikan */ }
    finally { setDlId(null); }
  };

  return (
    <div className="fixed inset-0 z-[76] bg-black/60 flex justify-end" onClick={onClose}>
      <div className="w-full sm:max-w-md h-full bg-white dark:bg-slate-950 flex flex-col" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-2 px-4 py-3 border-b border-slate-200 dark:border-slate-800">
          <button onClick={onClose} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800"><X size={20} /></button>
          <p className="font-extrabold flex-1">Galeri Chat</p>
        </div>
        <div className="flex gap-2 px-4 pt-3">
          <button onClick={() => setT('media')} className={`flex-1 py-2 rounded-2xl font-bold text-sm transition ${t === 'media' ? 'bg-teal-600 text-white' : 'bg-slate-100 dark:bg-slate-800'}`}>
            Foto & Video ({media.length})
          </button>
          <button onClick={() => setT('docs')} className={`flex-1 py-2 rounded-2xl font-bold text-sm transition ${t === 'docs' ? 'bg-teal-600 text-white' : 'bg-slate-100 dark:bg-slate-800'}`}>
            Dokumen ({docs.length})
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          {loading ? (
            <p className="text-center text-sm text-slate-400 py-10">Memuat galeri…</p>
          ) : t === 'media' ? (
            media.length === 0 ? (
              <Empty t="Belum ada foto atau video di chat ini." />
            ) : (
              <div className="grid grid-cols-3 gap-1.5">
                {media.map((m, i) => (
                  <button key={m.id} onClick={() => setViewer(i)} className="relative aspect-square rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 group">
                    {m.kind === 'video' ? (
                      <>
                        <video src={m.media_url} preload="metadata" className="w-full h-full object-cover" />
                        <span className="absolute inset-0 flex items-center justify-center">
                          <span className="w-9 h-9 rounded-full bg-black/60 text-white flex items-center justify-center"><Play size={17} className="ml-0.5" /></span>
                        </span>
                      </>
                    ) : (
                      <img src={m.media_url} alt="" loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition" />
                    )}
                  </button>
                ))}
              </div>
            )
          ) : docs.length === 0 ? (
            <Empty t="Belum ada dokumen atau audio di chat ini." />
          ) : (
            <div className="space-y-1">
              {docs.map((m) => (
                <div key={m.id} className="flex items-center gap-3 p-2.5 rounded-2xl hover:bg-slate-50 dark:hover:bg-slate-900">
                  <span className="w-11 h-11 rounded-xl bg-rose-100 dark:bg-rose-900/40 text-rose-500 flex items-center justify-center shrink-0">
                    <FileText size={21} />
                  </span>
                  <span className="flex-1 min-w-0">
                    <span className="font-bold text-sm block truncate">{m.media_name || (m.kind === 'voice' ? 'Pesan suara' : 'Audio')}</span>
                    <span className="text-xs text-slate-400">{fmtBytes(m.media_size)} • {fmtListTime(m.created_at)}</span>
                  </span>
                  <button onClick={() => void dl(m)} className="p-2.5 rounded-full bg-teal-600 text-white hover:bg-teal-700" title="Unduh">
                    {dlId === m.id ? <Loader2 size={17} className="animate-spin" /> : <Download size={17} />}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      {viewer !== null && <MediaViewer items={media} index={viewer} onClose={() => setViewer(null)} onNav={setViewer} />}
    </div>
  );
}

function Empty({ t }: { t: string }) {
  return (
    <div className="text-center py-14 text-slate-400">
      <p className="text-5xl mb-3">🖼️</p>
      <p className="text-sm font-semibold">{t}</p>
    </div>
  );
}
