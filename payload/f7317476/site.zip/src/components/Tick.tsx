import { Check, CheckCheck } from 'lucide-react';

interface Props {
  status: 'sent' | 'delivered' | 'read';
  size?: number;
}

/** Centang status pesan ala aplikasi chat. */
export default function Tick({ status, size = 16 }: Props) {
  if (status === 'read') return <CheckCheck size={size} className="text-sky-400 shrink-0" />;
  if (status === 'delivered') return <CheckCheck size={size} className="text-slate-400 shrink-0" />;
  return <Check size={size} className="text-slate-400 shrink-0" />;
}
