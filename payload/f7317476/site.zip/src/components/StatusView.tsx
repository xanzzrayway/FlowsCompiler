import { useEffect, useMemo, useRef, useState } from 'react';
import { X, Plus, Trash2, Eye, Image as ImageIcon, Type, Send, ChevronLeft, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Avatar from './Avatar';
import { useToast } from './Toast';
import { apiGet, apiPost, apiDelete, uploadFile, timeAgo, type StatusItem, type UserProfile } from '../lib/api';

interface Props {
  myId: string;
  statuses: StatusItem[];
  onChanged: () => void;
  initialUser?: string | null;
  onClose: () => void;
}

const BG_CHOICES = [
  'linear-gradient(135deg,#0d9488,#059669)',
  'linear-gradient(135deg,#7c3aed,#4f46e5)',
  'linear-gradient(135deg,#db2777,#9333ea)',
  'linear-gradient(135deg,#ea580c,#dc2626)',
  'linear-gradient(135deg,#0ea5e9,#6366f1)',
  'linear-gradient(135deg,#1f2937,#0f172a)',
  'linear-gradient(135deg,#65a30d,#15803d)',
];

export function StatusViewer({ myId, statuses, onChanged, initialUser, onClose }: Props) {
  const toast = useToast();
  const groups = useMemo(() => {
    const map = new Map<string, StatusItem[]>();
    for (const s of statuses) {
      const arr = map.get(s.user_id) || [];
      arr.push(s);
      map.set(s.user_id, arr);
    }
    return [...map.entries()].map(([uid, items]) => ({
      uid,
      user: items[0].user || null,
      items: items.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()),
      mine: uid === myId,
    })).sort((a, b) => (a.mine ? -1 : b.mine ? 1 : 0));
  }, [statuses, myId]);

  const [gi, setGi] = useState(() => {
    if (!initialUser) return 0;
    const i = groups.findIndex((g) => g.uid === initialUser);
    return i >= 0 ? i : 0;
  });
  const [si, setSi] = useState(0);
  const [progress, setProgress] = useState(0);
  const [paused, setPaused] = useState(false);
  const [showViews, setShowViews] = useState(false);
  const [views, setViews] = useState<{ viewer_id: string; user?: UserProfile | null; viewed_at: string }[]>([]);
  const timer = useRef<number | null>(null);

  const g = groups[gi];
  const item = g?.items[si];

  useEffect(() => {
    if (!item || paused) return;
    setProgress(0);
    const t0 = Date.now();
    const dur = item.kind === 'text' ? 5000 : 7000;
    timer.current = window.setInterval(() => {
      const p = (Date.now() - t0) / dur;
      if (p >= 1) {
        if (timer.current) window.clearInterval(timer.current);
        next();
      } else setProgress(p);
    }, 100);
    return () => { if (timer.current) window.clearInterval(timer.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gi, si, paused, item?.id]);

  useEffect(() => {
    if (!item) return;
    if (item.user_id !== myId) {
      apiPost('/api/status-views', { status_id: item.id, viewer_id: myId }).catch(() => {});
    } else {
      apiGet<(typeof views)>(`/api/status-views?status_id=${item.id}`).then(setViews).catch(() => {});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [item?.id]);

  const next = () => {
    setShowViews(false);
    if (!g) return;
    if (si + 1 < g.items.length) setSi(si + 1);
    else if (gi + 1 < groups.length) { setGi(gi + 1); setSi(0); }
    else onClose();
  };
  const prev = () => {
    setShowViews(false);
    if (si > 0) setSi(si - 1);
    else if (gi > 0) { setGi(gi - 1); setSi(groups[gi - 1].items.length - 1); }
  };

  const remove = async () => {
    if (!item || !window.confirm('Hapus status ini?')) return;
    try {
      await apiDelete('/api/statuses', { id: item.id });
      toast('Status dihapus', 'success');
      onChanged();
      next();
    } catch { toast('Gagal menghapus status', 'error'); }
  };

  if (!g || !item) {
    return (
      <div className="fixed inset-0 z-[85] bg-black/95 text-white flex flex-col items-center justify-center gap-3">
        <p className="font-bold">Belum ada status</p>
        <button onClick={onClose} className="px-5 py-2 rounded-full bg-teal-600 font-bold text-sm">Tutup</button>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[85] bg-black flex items-center justify-center" onClick={onClose}>
      <div
        className="relative w-full max-w-md h-full sm:h-[92vh] sm:rounded-3xl overflow-hidden flex flex-col"
        style={item.kind === 'text' ? { background: item.bg || BG_CHOICES[0] } : { background: '#000' }}
        onClick={(e) => e.stopPropagation()}
      >
        {item.kind !== 'text' && item.media_url && (
          item.media_url.match(/\.(mp4|webm|mov)(\?|$)/i) ? (
            <video src={item.media_url} autoPlay muted playsInline loop className="absolute inset-0 w-full h-full object-contain bg-black" />
          ) : (
            <img src={item.media_url} alt="" className="absolute inset-0 w-full h-full object-contain bg-black" />
          )
        )}
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/60 pointer-events-none" />

        {/* progress */}
        <div className="relative flex gap-1 px-3 pt-3">
          {g.items.map((_, i) => (
            <div key={i} className="flex-1 h-1 rounded-full bg-white/30 overflow-hidden">
              <div
                className="h-full bg-white rounded-full status-progress-fill"
                style={{ width: i < si ? '100%' : i === si ? `${progress * 100}%` : '0%' }}
              />
            </div>
          ))}
        </div>

        {/* header */}
        <div className="relative flex items-center gap-2.5 px-3 py-2.5 text-white">
          <button onClick={onClose} className="p-1.5 rounded-full hover:bg-white/15"><X size={20} /></button>
          <Avatar name={g.user?.name || '?'} src={g.user?.avatar_url || ''} size={38} />
          <span className="flex-1 min-w-0">
            <span className="block font-bold text-sm truncate">{g.mine ? 'Status saya' : g.user?.name}</span>
            <span className="block text-xs text-white/70">{timeAgo(item.created_at)}</span>
          </span>
          {g.mine && (
            <button onClick={() => void remove()} className="p-2 rounded-full hover:bg-white/15" title="Hapus"><Trash2 size={18} /></button>
          )}
        </div>

        {/* body */}
        <div className="relative flex-1 flex items-center justify-center px-6 overflow-hidden">
          {item.kind === 'text' ? (
            <p className="text-white text-2xl sm:text-3xl font-extrabold text-center leading-snug break-words drop-shadow-lg max-h-full overflow-y-auto">
              {item.body}
            </p>
          ) : item.body ? (
            <p className="absolute bottom-16 inset-x-4 text-white text-center font-semibold drop-shadow bg-black/40 rounded-2xl px-4 py-2.5">
              {item.body}
            </p>
          ) : null}
          {/* tap zones */}
          <button className="absolute left-0 top-0 bottom-0 w-1/3" onClick={prev} aria-label="Sebelumnya" />
          <button
            className="absolute right-0 top-0 bottom-0 w-1/3"
            onClick={next}
            onMouseDown={() => setPaused(true)}
            onMouseUp={() => setPaused(false)}
            onTouchStart={() => setPaused(true)}
            onTouchEnd={() => setPaused(false)}
            aria-label="Berikutnya"
          />
        </div>

        {/* footer */}
        <div className="relative px-4 pb-5 flex items-center justify-between text-white">
          <span className="flex gap-2">
            {g.mine ? (
              <button onClick={() => setShowViews(!showViews)} className="flex items-center gap-1.5 text-sm font-bold bg-white/15 hover:bg-white/25 px-3.5 py-2 rounded-full">
                <Eye size={16} /> {(item.views?.length || 0) + views.length > 0 ? `${views.length || item.views?.length || 0} dilihat` : 'Belum dilihat'}
              </button>
            ) : (
              <span className="text-xs text-white/70 font-semibold">Tahan layar untuk menjeda</span>
            )}
          </span>
          <span className="flex gap-1">
            <button onClick={prev} className="p-2 rounded-full bg-white/15 hover:bg-white/25"><ChevronLeft size={18} /></button>
            <button onClick={next} className="p-2 rounded-full bg-white/15 hover:bg-white/25"><ChevronRight size={18} /></button>
          </span>
        </div>

        {/* views sheet */}
        <AnimatePresence>
          {showViews && (
            <motion.div
              initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
              className="absolute inset-x-0 bottom-0 max-h-[55%] bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 rounded-t-3xl p-4 overflow-y-auto"
            >
              <p className="font-extrabold mb-3 text-sm">Dilihat oleh ({views.length})</p>
              {views.length === 0 && <p className="text-sm text-slate-400 text-center py-4">Belum ada yang melihat.</p>}
              {views.map((v) => (
                <div key={v.viewer_id} className="flex items-center gap-3 py-2">
                  <Avatar name={v.user?.name || '?'} src={v.user?.avatar_url || ''} size={38} />
                  <span className="flex-1 font-semibold text-sm truncate">{v.user?.name || 'Pengguna'}</span>
                  <span className="text-xs text-slate-400">{timeAgo(v.viewed_at)}</span>
                </div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

export function StatusComposer({ myId, onDone, onClose }: { myId: string; onDone: () => void; onClose: () => void }) {
  const toast = useToast();
  const [tab, setTab] = useState<'text' | 'media'>('text');
  const [text, setText] = useState('');
  const [bg, setBg] = useState(0);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState('');
  const [caption, setCaption] = useState('');
  const [busy, setBusy] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const pick = (f: File | undefined) => {
    if (!f) return;
    if (f.size > 25 * 1024 * 1024) { toast('File melebihi 25 MB', 'error'); return; }
    setFile(f);
    setPreview(URL.createObjectURL(f));
  };

  const submit = async () => {
    if (busy) return;
    if (tab === 'text' && !text.trim()) { toast('Tulis status dulu ya', 'error'); return; }
    if (tab === 'media' && !file) { toast('Pilih foto/video dulu', 'error'); return; }
    setBusy(true);
    try {
      if (tab === 'text') {
        await apiPost('/api/statuses', { user_id: myId, kind: 'text', body: text.trim(), bg: BG_CHOICES[bg % BG_CHOICES.length] });
      } else {
        const { url } = await uploadFile(file!);
        await apiPost('/api/statuses', { user_id: myId, kind: file!.type.startsWith('video/') ? 'video' : 'image', body: caption.trim(), media_url: url });
      }
      toast('Status dibagikan 🎉', 'success');
      onDone();
      onClose();
    } catch {
      toast('Gagal membagikan status', 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[85] bg-black/70 flex items-end sm:items-center justify-center sm:p-4" onClick={onClose}>
      <div className="w-full sm:max-w-md bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl overflow-hidden fa-animate-fade-up max-h-[92vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-200 dark:border-slate-800">
          <button onClick={onClose} className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800"><X size={20} /></button>
          <p className="font-extrabold flex-1">Status baru</p>
          <Plus size={18} className="text-teal-600" />
        </div>
        <div className="flex gap-2 px-5 pt-4">
          <button onClick={() => setTab('text')} className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-2xl font-bold text-sm transition ${tab === 'text' ? 'bg-teal-600 text-white' : 'bg-slate-100 dark:bg-slate-800'}`}>
            <Type size={17} /> Teks
          </button>
          <button onClick={() => setTab('media')} className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-2xl font-bold text-sm transition ${tab === 'media' ? 'bg-teal-600 text-white' : 'bg-slate-100 dark:bg-slate-800'}`}>
            <ImageIcon size={17} /> Foto/Video
          </button>
        </div>
        <div className="p-5 overflow-y-auto">
          {tab === 'text' ? (
            <>
              <div className="rounded-3xl p-6 min-h-[220px] flex items-center justify-center transition-all" style={{ background: BG_CHOICES[bg % BG_CHOICES.length] }}>
                <textarea
                  value={text}
                  onChange={(e) => setText(e.target.value.slice(0, 300))}
                  placeholder="Ketik status…"
                  rows={4}
                  className="w-full bg-transparent text-white text-xl font-extrabold text-center placeholder:text-white/60 outline-none resize-none"
                />
              </div>
              <div className="flex gap-2 mt-3 justify-center">
                {BG_CHOICES.map((b, i) => (
                  <button
                    key={i}
                    onClick={() => setBg(i)}
                    className={`w-9 h-9 rounded-full transition ${bg === i ? 'ring-2 ring-offset-2 ring-teal-500 dark:ring-offset-slate-900' : ''}`}
                    style={{ background: b }}
                    aria-label={`Warna ${i + 1}`}
                  />
                ))}
              </div>
            </>
          ) : (
            <>
              {!file ? (
                <button onClick={() => inputRef.current?.click()} className="w-full rounded-3xl border-2 border-dashed border-slate-300 dark:border-slate-700 min-h-[220px] flex flex-col items-center justify-center gap-2 text-slate-400 hover:border-teal-500 hover:text-teal-600 transition">
                  <ImageIcon size={40} />
                  <span className="font-bold text-sm">Ketuk untuk pilih foto/video</span>
                  <span className="text-xs">Maks. 25 MB</span>
                </button>
              ) : (
                <div className="rounded-3xl overflow-hidden bg-black">
                  {file.type.startsWith('video/') ? (
                    <video src={preview} controls className="w-full max-h-[300px]" />
                  ) : (
                    <img src={preview} alt="" className="w-full max-h-[300px] object-contain" />
                  )}
                </div>
              )}
              <input ref={inputRef} type="file" accept="image/*,video/*" className="hidden" onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ''; }} />
              {file && (
                <div className="flex gap-2 mt-3">
                  <input value={caption} onChange={(e) => setCaption(e.target.value)} placeholder="Tambahkan keterangan…" className="flex-1 bg-slate-100 dark:bg-slate-800 rounded-2xl px-4 py-2.5 text-sm outline-none" />
                  <button onClick={() => { setFile(null); setPreview(''); }} className="p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 text-rose-500"><Trash2 size={17} /></button>
                </div>
              )}
            </>
          )}
        </div>
        <div className="p-5 pt-0">
          <button
            onClick={() => void submit()}
            disabled={busy}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-teal-600 to-emerald-600 text-white font-extrabold shadow-lg disabled:opacity-60 flex items-center justify-center gap-2"
          >
            {busy ? 'Membagikan…' : <><Send size={18} /> Bagikan Status</>}
          </button>
          <p className="text-center text-xs text-slate-400 mt-2">Status hilang otomatis setelah 24 jam ⏳</p>
        </div>
      </div>
    </div>
  );
}
