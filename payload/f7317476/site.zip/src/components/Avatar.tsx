import { colorFor, initials } from '../lib/api';

interface Props {
  name?: string;
  src?: string;
  size?: number;
  className?: string;
  online?: boolean;
}

export default function Avatar({ name = '?', src = '', size = 44, className = '', online }: Props) {
  const label = initials(name);
  return (
    <span className={`relative inline-flex shrink-0 ${className}`} style={{ width: size, height: size }}>
      {src ? (
        <img
          src={src}
          alt={name}
          className="w-full h-full rounded-full object-cover bg-slate-200 dark:bg-slate-700"
          draggable={false}
          onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
        />
      ) : (
        <span
          className={`w-full h-full rounded-full bg-gradient-to-br ${colorFor(name + size)} text-white flex items-center justify-center font-bold select-none`}
          style={{ fontSize: Math.max(11, size * 0.36) }}
        >
          {label}
        </span>
      )}
      {online !== undefined && (
        <span
          className={`absolute bottom-0 right-0 rounded-full border-2 border-white dark:border-slate-900 ${online ? 'bg-emerald-500' : 'bg-slate-400'}`}
          style={{ width: Math.max(10, size * 0.26), height: Math.max(10, size * 0.26) }}
        />
      )}
    </span>
  );
}
