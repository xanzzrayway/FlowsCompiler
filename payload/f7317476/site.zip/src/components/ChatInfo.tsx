import { useEffect, useMemo, useRef, useState } from 'react';
import {
  X, Users, UserMinus, UserPlus, ShieldCheck, Pencil, Camera, Image as ImageIcon,
  FileText, Volume2, Ban, Flag, Phone, Video, Trash2, LogOut, VolumeX, Archive,
  Loader2, Check, ChevronRight,
} from 'lucide-react';
import Avatar from './Avatar';
import { useToast } from './Toast';
import { AddMembersModal } from './NewChat';
import { chatTitle, chatAvatar, peerOf } from './ChatList';
import {
  apiGet, apiPost, apiPut, apiDelete, uploadFile, canSee, timeAgo, fmtListTime,
  type Chat, type Message, type UserProfile, type Member,
} from '../lib/api';

interface Props {
  chat: Chat;
  myId: string;
  onClose: () => void;
  onChatPatched: (c: Chat) => void;
  onChatRemoved: () => void;
  onOpenProfile: (userId: string) => void;
  onStartCall: (type: 'voice' | 'video', peerId: string) => void;
  onOpenMediaTab: (tab: 'media' | 'docs') => void;
}

export default function ChatInfo(p: Props) {
  const toast = useToast();
  const { chat, myId } = p;
  const isGroup = chat.type === 'group';
  const peer = peerOf(chat, myId);
  const iAmAdmin = chat.my.role === 'admin';

  const [members, setMembers] = useState<Member[]>(chat.members);
  const [editingName, setEditingName] = useState(false);
  const [nameDraft, setNameDraft] = useState(chat.name);
  const [editingDesc, setEditingDesc] = useState(false);
  const [descDraft, setDescDraft] = useState(chat.description);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [mediaCount, setMediaCount] = useState({ media: 0, docs: 0 });
  const [confirmKick, setConfirmKick] = useState<Member | null>(null);
  const [showReport, setShowReport] = useState(false);
  const avatarRef = useRef<HTMLInputElement>(null);

  const refreshMembers = async () => {
    try {
      const ms = await apiGet<Member[]>(`/api/members?chat_id=${chat.id}`);
      setMembers(ms);
    } catch { /* abaikan */ }
  };

  useEffect(() => {
    void refreshMembers();
    apiGet<{ messages: Message[] }>(`/api/messages?chat_id=${chat.id}&limit=150`).then((r) => {
      const ms = r.messages.filter((m) => !(m.deleted_for || []).includes(myId) && !m.is_deleted);
      setMediaCount({
        media: ms.filter((m) => ['image', 'video', 'gif'].includes(m.kind)).length,
        docs: ms.filter((m) => ['document', 'audio', 'voice'].includes(m.kind)).length,
      });
    }).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chat.id]);

  const saveName = async () => {
    if (!nameDraft.trim()) { toast('Nama grup tidak boleh kosong', 'error'); return; }
    try {
      const updated = await apiPut<Chat>('/api/chats', { id: chat.id, name: nameDraft.trim() });
      p.onChatPatched({ ...chat, name: updated.name });
      setEditingName(false);
      toast('Nama grup diubah ✓', 'success');
    } catch { toast('Gagal mengubah nama', 'error'); }
  };

  const saveDesc = async () => {
    try {
      const updated = await apiPut<Chat>('/api/chats', { id: chat.id, description: descDraft.trim() });
      p.onChatPatched({ ...chat, description: updated.description });
      setEditingDesc(false);
      toast('Deskripsi grup diubah ✓', 'success');
    } catch { toast('Gagal mengubah deskripsi', 'error'); }
  };

  const changeAvatar = async (f: File | undefined) => {
    if (!f) return;
    if (!f.type.startsWith('image/')) { toast('Pilih file gambar', 'error'); return; }
    if (f.size > 8 * 1024 * 1024) { toast('Ukuran foto maks. 8 MB', 'error'); return; }
    setUploadingAvatar(true);
    try {
      const { url } = await uploadFile(f);
      const updated = await apiPut<Chat>('/api/chats', { id: chat.id, avatar_url: url });
      p.onChatPatched({ ...chat, avatar_url: updated.avatar_url });
      toast('Foto grup diubah 📷', 'success');
    } catch { toast('Gagal mengunggah foto', 'error'); }
    finally { setUploadingAvatar(false); }
  };

  const kick = async () => {
    if (!confirmKick) return;
    try {
      await apiDelete('/api/members', { chat_id: chat.id, user_id: confirmKick.user_id });
      await apiPost('/api/messages', {
        chat_id: chat.id, sender_id: myId, kind: 'system',
        body: `🚫 ${confirmKick.user?.name || 'Anggota'} dikeluarkan dari grup`,
      }).catch(() => null);
      setMembers((ms) => ms.filter((m) => m.user_id !== confirmKick.user_id));
      toast('Anggota dikeluarkan', 'success');
    } catch { toast('Gagal mengeluarkan anggota', 'error'); }
    setConfirmKick(null);
  };

  const toggleAdmin = async (m: Member) => {
    try {
      await apiPut('/api/members', { chat_id: chat.id, user_id: m.user_id, role: m.role === 'admin' ? 'member' : 'admin' });
      setMembers((ms) => ms.map((x) => (x.user_id === m.user_id ? { ...x, role: (m.role === 'admin' ? 'member' : 'admin') as 'admin' | 'member' } : x)));
      toast(m.role === 'admin' ? 'Status admin dicabut' : `${m.user?.name} kini admin grup 👑`, 'success');
    } catch { toast('Gagal mengubah peran', 'error'); }
  };

  const title = chatTitle(chat, myId);
  const avatar = chatAvatar(chat, myId);

  return (
    <div className="fixed inset-0 z-[75] bg-black/60 flex justify-end" onClick={p.onClose}>
      <div
        className="w-full sm:max-w-md h-full bg-slate-50 dark:bg-slate-950 overflow-y-auto fa-animate-fade-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* hero */}
        <div className="relative bg-gradient-to-br from-teal-600 via-teal-600 to-emerald-600 text-white pt-4 pb-8 px-5">
          <div className="flex items-center justify-between">
            <button onClick={p.onClose} className="p-2 rounded-full hover:bg-white/15"><X size={20} /></button>
            <span className="text-sm font-bold opacity-80">{isGroup ? 'Info Grup' : 'Info Kontak'}</span>
            <span className="w-9" />
          </div>
          <div className="flex flex-col items-center mt-2">
            <span className="relative">
              {isGroup ? (
                <span className="w-24 h-24 rounded-full bg-white/20 border-4 border-white/30 flex items-center justify-center overflow-hidden">
                  {chat.avatar_url ? <img src={chat.avatar_url} alt="" className="w-full h-full object-cover" /> : <Users size={42} />}
                </span>
              ) : (
                <Avatar name={title} src={avatar} size={96} className="border-4 border-white/30" />
              )}
              {isGroup && iAmAdmin && (
                <button
                  onClick={() => avatarRef.current?.click()}
                  className="absolute bottom-0 right-0 w-9 h-9 rounded-full bg-white text-teal-700 flex items-center justify-center shadow-lg"
                  title="Ganti foto grup"
                >
                  {uploadingAvatar ? <Loader2 size={17} className="animate-spin" /> : <Camera size={17} />}
                </button>
              )}
              <input ref={avatarRef} type="file" accept="image/*" className="hidden" onChange={(e) => { void changeAvatar(e.target.files?.[0]); e.target.value = ''; }} />
            </span>
            {isGroup && editingName ? (
              <span className="flex items-center gap-2 mt-3 w-full max-w-[260px]">
                <input
                  value={nameDraft} onChange={(e) => setNameDraft(e.target.value)} maxLength={60}
                  className="flex-1 bg-white/20 rounded-xl px-3 py-2 text-center font-extrabold outline-none placeholder:text-white/60"
                />
                <button onClick={() => void saveName()} className="p-2 rounded-full bg-white text-teal-700"><Check size={17} /></button>
              </span>
            ) : (
              <button
                onClick={() => { if (isGroup && iAmAdmin) { setNameDraft(chat.name); setEditingName(true); } }}
                className="mt-3 text-xl font-extrabold text-center flex items-center gap-1.5"
              >
                {title}
                {isGroup && iAmAdmin && <Pencil size={15} className="opacity-70" />}
              </button>
            )}
            <p className="text-teal-100 text-sm mt-0.5">
              {isGroup ? `${members.length} anggota` : `@${peer?.username || 'pengguna'}`}
            </p>
            {!isGroup && peer && (
              <p className="text-teal-100/90 text-[13px] mt-1 text-center px-6">
                {peer.bio || 'Hai! Saya memakai FastApp ⚡'}
              </p>
            )}
          </div>

          {/* quick actions */}
          {!isGroup && peer && (
            <div className="flex justify-center gap-6 mt-4">
              <QBtn icon={<Phone size={20} />} t="Telepon" onClick={() => p.onStartCall('voice', peer.id)} />
              <QBtn icon={<Video size={20} />} t="Video" onClick={() => p.onStartCall('video', peer.id)} />
              <QBtn icon={<Users size={20} />} t="Profil" onClick={() => p.onOpenProfile(peer.id)} />
            </div>
          )}
        </div>

        <div className="px-3 -mt-4 pb-8 space-y-2.5 relative">
          {/* desc grup */}
          {isGroup && (
            <Card>
              <RowLabel t="Deskripsi grup" />
              {editingDesc ? (
                <span className="flex gap-2 mt-1">
                  <textarea value={descDraft} onChange={(e) => setDescDraft(e.target.value)} rows={2} maxLength={200} className="flex-1 bg-slate-100 dark:bg-slate-800 rounded-xl px-3 py-2 text-sm outline-none resize-none" />
                  <button onClick={() => void saveDesc()} className="p-2 h-fit rounded-full bg-teal-600 text-white"><Check size={16} /></button>
                </span>
              ) : (
                <button
                  onClick={() => { if (iAmAdmin) { setDescDraft(chat.description); setEditingDesc(true); } }}
                  className="text-sm text-slate-600 dark:text-slate-300 mt-1 text-left w-full"
                >
                  {chat.description || (iAmAdmin ? <span className="italic text-slate-400">Tambahkan deskripsi grup…</span> : <span className="italic text-slate-400">Tidak ada deskripsi.</span>)}
                </button>
              )}
              <p className="text-[11px] text-slate-400 mt-2">Dibuat {timeAgo(chat.created_at)}</p>
            </Card>
          )}

          {/* kontak detail */}
          {!isGroup && peer && (
            <Card>
              <RowLabel t="Kontak" />
              <InfoLine k="Nomor telepon" v={peer.phone || '—'} />
              <InfoLine k="Email" v={peer.email || '—'} />
              <InfoLine k="Username" v={`@${peer.username}`} />
              <InfoLine
                k="Terakhir dilihat"
                v={canSee(myId, peer, 'last_seen', true) ? (peer.is_online ? 'Online 🟢' : timeAgo(peer.last_seen)) : 'Disembunyikan 🔒'}
              />
            </Card>
          )}

          {/* media */}
          <Card>
            <RowLabel t={`Media, tautan & dokumen`} />
            <button onClick={() => p.onOpenMediaTab('media')} className="w-full flex items-center gap-3 py-2.5 hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-xl px-1">
              <span className="p-2.5 rounded-2xl bg-violet-100 text-violet-600 dark:bg-violet-900/50 dark:text-violet-300"><ImageIcon size={19} /></span>
              <span className="flex-1 text-left font-semibold text-sm">Foto & Video <span className="text-slate-400 font-normal">({mediaCount.media})</span></span>
              <ChevronRight size={18} className="text-slate-400" />
            </button>
            <button onClick={() => p.onOpenMediaTab('docs')} className="w-full flex items-center gap-3 py-2.5 hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-xl px-1">
              <span className="p-2.5 rounded-2xl bg-amber-100 text-amber-600 dark:bg-amber-900/50 dark:text-amber-300"><FileText size={19} /></span>
              <span className="flex-1 text-left font-semibold text-sm">Dokumen & Audio <span className="text-slate-400 font-normal">({mediaCount.docs})</span></span>
              <ChevronRight size={18} className="text-slate-400" />
            </button>
          </Card>

          {/* members */}
          {isGroup && (
            <Card>
              <span className="flex items-center justify-between">
                <RowLabel t={`${members.length} anggota`} />
                {iAmAdmin && (
                  <button onClick={() => setShowAdd(true)} className="flex items-center gap-1 text-[13px] font-bold text-teal-600 dark:text-teal-400">
                    <UserPlus size={15} /> Tambah
                  </button>
                )}
              </span>
              <div className="mt-1 -mx-1">
                {members.map((m) => (
                  <MemberRow
                    key={m.user_id}
                    m={m}
                    myId={myId}
                    iAmAdmin={iAmAdmin}
                    onOpen={() => p.onOpenProfile(m.user_id)}
                    onToggleAdmin={() => void toggleAdmin(m)}
                    onKick={() => setConfirmKick(m)}
                  />
                ))}
              </div>
            </Card>
          )}

          {/* pengaturan chat */}
          <Card>
            <RowLabel t="Pengaturan" />
            <SettingRow
              icon={chat.my.muted ? <VolumeX size={19} /> : <Volume2 size={19} />}
              t="Bisukan notifikasi" d={chat.my.muted ? 'Aktif — Anda tidak akan dapat bunyi' : 'Mati'}
              onClick={async () => {
                try {
                  await apiPut('/api/members', { chat_id: chat.id, user_id: myId, muted: !chat.my.muted });
                  p.onChatPatched({ ...chat, my: { ...chat.my, muted: !chat.my.muted } });
                  toast(chat.my.muted ? 'Notifikasi dinyalakan' : 'Chat dibisukan 🔕', 'success');
                } catch { toast('Gagal', 'error'); }
              }}
            />
            <SettingRow
              icon={<Archive size={19} />} t={chat.my.archived ? 'Keluarkan dari arsip' : 'Arsipkan chat'}
              d={chat.my.archived ? 'Chat ada di arsip' : 'Sembunyikan dari daftar utama'}
              onClick={async () => {
                try {
                  await apiPut('/api/members', { chat_id: chat.id, user_id: myId, archived: !chat.my.archived });
                  p.onChatPatched({ ...chat, my: { ...chat.my, archived: !chat.my.archived } });
                  toast(chat.my.archived ? 'Dikeluarkan dari arsip' : 'Chat diarsipkan', 'success');
                } catch { toast('Gagal', 'error'); }
              }}
            />
          </Card>

          {/* danger */}
          <Card>
            {!isGroup && peer && (
              <>
                <BlockRow myId={myId} peer={peer} />
                <button onClick={() => setShowReport(true)} className="w-full flex items-center gap-3 py-2.5 px-1 text-amber-600 dark:text-amber-400 font-semibold text-sm">
                  <Flag size={19} /> Laporkan pengguna
                </button>
              </>
            )}
            <button
              onClick={async () => {
                if (!window.confirm(isGroup ? 'Bersihkan seluruh riwayat chat ini untuk Anda?' : 'Bersihkan riwayat percakapan ini untuk Anda?')) return;
                try {
                  await apiPut('/api/messages', { chat_id: chat.id, clear_chat_for: myId });
                  toast('Riwayat dibersihkan', 'success');
                } catch { toast('Gagal membersihkan', 'error'); }
              }}
              className="w-full flex items-center gap-3 py-2.5 px-1 text-slate-600 dark:text-slate-300 font-semibold text-sm"
            >
              <Trash2 size={19} /> Bersihkan riwayat chat
            </button>
            <button
              onClick={async () => {
                if (!window.confirm(isGroup ? 'Keluar dari grup ini?' : 'Hapus percakapan ini?')) return;
                try {
                  await apiDelete('/api/chats', { id: chat.id, user_id: myId });
                  toast(isGroup ? 'Anda keluar dari grup' : 'Percakapan dihapus', 'success');
                  p.onChatRemoved();
                } catch { toast('Gagal', 'error'); }
              }}
              className="w-full flex items-center gap-3 py-2.5 px-1 text-rose-600 dark:text-rose-400 font-semibold text-sm"
            >
              <LogOut size={19} /> {isGroup ? 'Keluar dari grup' : 'Hapus percakapan'}
            </button>
          </Card>
        </div>

        {showAdd && (
          <AddMembersModal
            chatId={chat.id}
            myId={myId}
            existingIds={members.map((m) => m.user_id)}
            onClose={() => setShowAdd(false)}
            onChanged={() => { void refreshMembers(); }}
          />
        )}

        {confirmKick && (
          <ConfirmBox
            title={`Keluarkan ${confirmKick.user?.name || 'anggota'}?`}
            desc="Mereka tidak akan bisa mengirim pesan sampai ditambahkan lagi."
            ok="Keluarkan"
            onCancel={() => setConfirmKick(null)}
            onOk={kick}
          />
        )}

        {showReport && peer && (
          <ReportModal myId={myId} peer={peer} onClose={() => setShowReport(false)} />
        )}
      </div>
    </div>
  );
}

function Card({ children }: { children: React.ReactNode }) {
  return <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200/60 dark:border-slate-800 p-4">{children}</div>;
}
function RowLabel({ t }: { t: string }) {
  return <p className="text-xs font-extrabold uppercase tracking-wider text-slate-400">{t}</p>;
}
function InfoLine({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between gap-3 py-1.5 text-sm border-b border-slate-100 dark:border-slate-800 last:border-0">
      <span className="text-slate-400">{k}</span>
      <span className="font-semibold text-right break-all">{v}</span>
    </div>
  );
}
function QBtn({ icon, t, onClick }: { icon: React.ReactNode; t: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-1.5">
      <span className="w-12 h-12 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition">{icon}</span>
      <span className="text-xs font-bold">{t}</span>
    </button>
  );
}
function SettingRow({ icon, t, d, onClick }: { icon: React.ReactNode; t: string; d: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="w-full flex items-center gap-3 py-2.5 px-1 text-left hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-xl">
      <span className="text-slate-500 dark:text-slate-400">{icon}</span>
      <span className="flex-1"><span className="block font-semibold text-sm">{t}</span><span className="block text-xs text-slate-400">{d}</span></span>
      <ChevronRight size={17} className="text-slate-300" />
    </button>
  );
}

function MemberRow({ m, myId, iAmAdmin, onOpen, onToggleAdmin, onKick }: {
  m: Member; myId: string; iAmAdmin: boolean;
  onOpen: () => void; onToggleAdmin: () => void; onKick: () => void;
}) {
  const [open, setOpen] = useState(false);
  const isMe = m.user_id === myId;
  return (
    <div className="relative">
      <button onClick={onOpen} className="w-full flex items-center gap-3 px-2 py-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-left">
        <Avatar name={m.user?.name || '?'} src={m.user?.avatar_url || ''} size={42} online={isMe ? undefined : m.user?.is_online} />
        <span className="flex-1 min-w-0">
          <span className="font-bold block truncate text-[15px]">
            {isMe ? 'Anda' : m.user?.name || 'Anggota'}
            {m.role === 'admin' && <span className="ml-2 text-[10px] font-extrabold text-amber-600 bg-amber-100 dark:bg-amber-900/50 px-1.5 py-0.5 rounded-md">👑 ADMIN</span>}
          </span>
          <span className="text-xs text-slate-500 truncate block">
            {m.user?.bio || `@${m.user?.username || ''}`} • gabung {fmtListTime(m.joined_at)}
          </span>
        </span>
        {iAmAdmin && !isMe && (
          <span onClick={(e) => { e.stopPropagation(); setOpen(!open); }} className="p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-400 font-extrabold px-2.5 cursor-pointer">⋮</span>
        )}
      </button>
      {open && (
        <>
          <span className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
          <span className="absolute right-2 top-full z-40 w-52 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-700 py-1.5 fa-animate-pop">
            <button onClick={() => { setOpen(false); onToggleAdmin(); }} className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm font-semibold hover:bg-slate-100 dark:hover:bg-slate-700">
              <ShieldCheck size={16} /> {m.role === 'admin' ? 'Cabut admin' : 'Jadikan admin'}
            </button>
            <button onClick={() => { setOpen(false); onKick(); }} className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40">
              <UserMinus size={16} /> Keluarkan
            </button>
          </span>
        </>
      )}
    </div>
  );
}

export function ConfirmBox({ title, desc, ok, onOk, onCancel }: {
  title: string; desc: string; ok: string; onOk: () => void; onCancel: () => void;
}) {
  return (
    <div className="fixed inset-0 z-[95] bg-black/60 flex items-center justify-center p-4" onClick={onCancel}>
      <div className="w-full max-w-xs bg-white dark:bg-slate-900 rounded-3xl p-5 fa-animate-pop" onClick={(e) => e.stopPropagation()}>
        <p className="font-extrabold">{title}</p>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">{desc}</p>
        <div className="flex gap-2 mt-4">
          <button onClick={onCancel} className="flex-1 py-2.5 rounded-2xl border border-slate-300 dark:border-slate-700 font-bold text-sm">Batal</button>
          <button onClick={onOk} className="flex-1 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-sm">{ok}</button>
        </div>
      </div>
    </div>
  );
}

function BlockRow({ myId, peer }: { myId: string; peer: UserProfile }) {
  const toast = useToast();
  const [byMe, setByMe] = useState<boolean | null>(null);
  useEffect(() => {
    apiGet<{ blocked: string[] }>(`/api/blocks?user_id=${myId}`)
      .then((r) => setByMe(r.blocked.includes(peer.id)))
      .catch(() => setByMe(false));
  }, [myId, peer.id]);
  const toggle = async () => {
    try {
      if (byMe) {
        await apiDelete('/api/blocks', { blocker_id: myId, blocked_id: peer.id });
        setByMe(false);
        toast('Blokir dibuka ✓', 'success');
      } else {
        await apiPost('/api/blocks', { blocker_id: myId, blocked_id: peer.id });
        setByMe(true);
        toast(`${peer.name} diblokir`, 'success');
      }
    } catch { toast('Gagal', 'error'); }
  };
  if (byMe === null) return null;
  return (
    <button onClick={() => void toggle()} className="w-full flex items-center gap-3 py-2.5 px-1 text-rose-600 dark:text-rose-400 font-semibold text-sm">
      <Ban size={19} /> {byMe ? 'Buka blokir pengguna ini' : 'Blokir pengguna ini'}
    </button>
  );
}

export function ReportModal({ myId, peer, onClose }: { myId: string; peer: UserProfile; onClose: () => void }) {
  const toast = useToast();
  const [reason, setReason] = useState('Spam');
  const [detail, setDetail] = useState('');
  const [busy, setBusy] = useState(false);
  const reasons = useMemo(() => ['Spam', 'Penipuan / scam', 'Ujaran kebencian', 'Konten tidak pantas', 'Akun palsu', 'Lainnya'], []);
  const submit = async () => {
    setBusy(true);
    try {
      await apiPost('/api/reports', { reporter_id: myId, reported_id: peer.id, reason, detail: detail.trim() });
      toast('Laporan terkirim. Terima kasih! 🙏', 'success');
      onClose();
    } catch { toast('Gagal mengirim laporan', 'error'); }
    finally { setBusy(false); }
  };
  return (
    <div className="fixed inset-0 z-[95] bg-black/60 flex items-end sm:items-center justify-center sm:p-4" onClick={onClose}>
      <div className="w-full sm:max-w-sm bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl p-5 fa-animate-fade-up" onClick={(e) => e.stopPropagation()}>
        <p className="font-extrabold flex items-center gap-2"><Flag size={18} className="text-amber-500" /> Laporkan {peer.name}</p>
        <p className="text-[13px] text-slate-500 mt-1">Laporan bersifat anonim dan ditinjau tim FastApp.</p>
        <div className="flex flex-wrap gap-2 mt-3">
          {reasons.map((r) => (
            <button
              key={r}
              onClick={() => setReason(r)}
              className={`px-3 py-1.5 rounded-full text-[13px] font-bold transition ${reason === r ? 'bg-amber-500 text-white' : 'bg-slate-100 dark:bg-slate-800'}`}
            >
              {r}
            </button>
          ))}
        </div>
        <textarea
          value={detail} onChange={(e) => setDetail(e.target.value.slice(0, 300))}
          placeholder="Ceritakan detailnya (opsional)…"
          rows={3}
          className="mt-3 w-full bg-slate-100 dark:bg-slate-800 rounded-2xl px-4 py-3 text-sm outline-none resize-none"
        />
        <div className="flex gap-2 mt-3">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-2xl border border-slate-300 dark:border-slate-700 font-bold text-sm">Batal</button>
          <button onClick={() => void submit()} disabled={busy} className="flex-1 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-sm disabled:opacity-60">
            {busy ? 'Mengirim…' : 'Kirim Laporan'}
          </button>
        </div>
      </div>
    </div>
  );
}
