import { useEffect, useState, useRef } from 'react';
import { X, Smile, Image as ImageIcon, Sticker, Film } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const EMOJI_GROUPS: { name: string; emojis: string[] }[] = [
  { name: 'Sering', emojis: ['😂', '❤️', '👍', '🙏', '😊', '🔥', '🎉', '😍', '🤣', '😭', '👏', '💪', '😎', '🥳', '😅', '🤔'] },
  { name: 'Wajah', emojis: ['😀', '😁', '😄', '😆', '😉', '😋', '😜', '🤪', '😝', '🤑', '🤗', '🤭', '🤫', '🤐', '😐', '😑', '😒', '🙄', '😬', '😮', '😯', '😲', '😳', '🥺', '😢', '😤', '😡', '🤯', '🥴', '🤢', '🤮', '🤧', '😷', '🤒', '🤕', '😴', '💤'] },
  { name: 'Gestur', emojis: ['👋', '🤚', '✋', '🖖', '👌', '🤌', '✌️', '🤞', '🤟', '🤘', '👍', '👎', '✊', '👊', '🤛', '🤜', '👏', '🙌', '👐', '🤲', '🤝', '☝️', '👆', '👇', '👈', '👉', '💅', '✍️', '💪', '🦾'] },
  { name: 'Hati', emojis: ['❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔', '❣️', '💕', '💞', '💓', '💗', '💖', '💘', '💝', '💟', '♥️'] },
  { name: 'Hewan', emojis: ['🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯', '🦁', '🐮', '🐷', '🐸', '🐵', '🙈', '🙉', '🙊', '🐒', '🐔', '🐧', '🐦', '🐤', '🦆', '🦅', '🦉', '🐝', '🦋', '🐌', '🐞', '🐢', '🐍', '🦎', '🐙', '🦑', '🐠', '🐟', '🐬', '🐳', '🦈'] },
  { name: 'Makanan', emojis: ['🍎', '🍐', '🍊', '🍋', '🍌', '🍉', '🍇', '🍓', '🍒', '🍑', '🥭', '🍍', '🥥', '🥝', '🍅', '🥑', '🍆', '🥔', '🥕', '🌽', '🍞', '🥐', '🥖', '🧀', '🍔', '🍟', '🍕', '🌭', '🥪', '🌮', '🍜', '🍲', '🍛', '🍣', '🍱', '🍩', '🍪', '🎂', '🍰', '🧁', '🍦', '🍨', '☕', '🧋', '🥤', '🍺'] },
  { name: 'Aktivitas', emojis: ['⚽', '🏀', '🏈', '⚾', '🎾', '🏐', '🏓', '🏸', '🥊', '🎮', '🎲', '🎯', '🎪', '🎨', '🎭', '🎤', '🎧', '🎼', '🎹', '🥁', '🎸', '🎺', '🚗', '🚕', '🚌', '🚎', '🚑', '🚒', '✈️', '🚀', '⛵', '🚤', '⚓', '🏖️', '🏝️', '🎡', '🎢', '⛺', '🌋'] },
  { name: 'Simbol', emojis: ['✅', '❌', '⭐', '🌟', '✨', '💥', '💯', '💢', '💫', '⚡', '☀️', '🌙', '☁️', '⛅', '🌈', '❄️', '🎈', '🎁', '🏆', '🥇', '🏅', '💰', '💎', '🔔', '🔕', '📌', '📍', '🚩', '🎀', '💡', '🔑', '🔒', '🔓', '❗', '❓', '💬', '👁️', '🕐', '📅'] },
];

const STICKER_SETS: { name: string; items: string[] }[] = [
  { name: 'Ekspresi', items: ['(¬‿¬)', '(◕‿◕)', '(╯°□°）╯', '(づ｡◕‿‿◕｡)づ', '(ﾉ◕ヮ◕)ﾉ', '( ͡° ͜ʖ ͡°)', '¯\\_(ツ)_/¯', '(╥﹏╥)', '(ง •̀_•́)ง', '(´• ω •`)ﾉ', '(¬_¬)', '(☞ﾟヮﾟ)☞', '(ʘ‿ʘ)', '(◕‿◕✿)', '(⌐■_■)', '( ͡~ ͜ʖ ͡°)'] },
  { name: 'Lucu', items: ['😹', '🙈', '🤡', '👻', '💩', '🎃', '🤖', '👽', '🐸', '🦄', '🐵', '🐷', '🐥', '🦖', '🐲', '🍕'] },
];

const GIFS: { label: string; url: string }[] = [
  { label: 'Setuju', url: 'https://media.giphy.com/media/111ebonMs90YLu/giphy.gif' },
  { label: 'Tertawa', url: 'https://media.giphy.com/media/3o7btPCcdNniyf0ArS/giphy.gif' },
  { label: 'Tepuk tangan', url: 'https://media.giphy.com/media/eM2jQcznZPEA/giphy.gif' },
  { label: 'Jempol', url: 'https://media.giphy.com/media/3o6ZtpxSZbQRRnwCKQ/giphy.gif' },
  { label: 'Hore', url: 'https://media.giphy.com/media/5GoVLqeAOo6PK/giphy.gif' },
  { label: 'Love', url: 'https://media.giphy.com/media/l0HlvtIPzPdt2usKs/giphy.gif' },
  { label: 'Sedih', url: 'https://media.giphy.com/media/1zSz5mvfsHNKG/giphy.gif' },
  { label: 'Marah', url: 'https://media.giphy.com/media/12A3U741SwTdGg/giphy.gif' },
  { label: 'Kaget', url: 'https://media.giphy.com/media/ shock /giphy.gif'.replace(' shock ', '6pUBffnKhIrgI') },
  { label: 'Ngantuk', url: 'https://media.giphy.com/media/l3nWhJ6FWOzB0wW3K/giphy.gif' },
  { label: 'Dansa', url: 'https://media.giphy.com/media/3oKIPnAiaMCws8nOsE/giphy.gif' },
  { label: 'Mikir', url: 'https://media.giphy.com/media/3o7btNa0RUYa5E7iGY/giphy.gif' },
];

interface Props {
  open: boolean;
  onClose: () => void;
  onEmoji: (e: string) => void;
  onSticker: (s: string, isText: boolean) => void;
  onGif: (url: string, label: string) => void;
  anchor?: 'left' | 'right';
}

export default function EmojiPicker({ open, onClose, onEmoji, onSticker, onGif, anchor = 'left' }: Props) {
  const [tab, setTab] = useState<'emoji' | 'sticker' | 'gif'>('emoji');
  const [group, setGroup] = useState(0);
  const [stickerSet, setStickerSet] = useState(0);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    };
    const t = window.setTimeout(() => document.addEventListener('mousedown', h), 50);
    return () => { window.clearTimeout(t); document.removeEventListener('mousedown', h); };
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 10, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 10, scale: 0.98 }}
          transition={{ duration: 0.16 }}
          className={`absolute bottom-full mb-2 z-40 w-[330px] max-w-[calc(100vw-2rem)] h-[340px] flex flex-col rounded-2xl shadow-2xl border overflow-hidden bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 ${anchor === 'left' ? 'left-0' : 'right-0'}`}
        >
          <div className="flex items-center gap-1 px-2 pt-2">
            {[
              { k: 'emoji', icon: <Smile size={18} />, t: 'Emoji' },
              { k: 'sticker', icon: <Sticker size={18} />, t: 'Stiker' },
              { k: 'gif', icon: <Film size={18} />, t: 'GIF' },
            ].map((t) => (
              <button
                key={t.k}
                onClick={() => setTab(t.k as typeof tab)}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-sm font-bold transition ${tab === t.k ? 'bg-teal-100 dark:bg-teal-900/50 text-teal-700 dark:text-teal-300' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'}`}
              >
                {t.icon} {t.t}
              </button>
            ))}
            <button onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800" aria-label="Tutup">
              <X size={17} />
            </button>
          </div>

          {tab === 'emoji' && (
            <>
              <div className="flex gap-1 px-2 py-1.5 overflow-x-auto border-b border-slate-100 dark:border-slate-800">
                {EMOJI_GROUPS.map((g, i) => (
                  <button
                    key={g.name}
                    onClick={() => setGroup(i)}
                    className={`px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap transition ${group === i ? 'bg-teal-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'}`}
                  >
                    {g.name}
                  </button>
                ))}
              </div>
              <div className="flex-1 overflow-y-auto p-2 grid grid-cols-8 gap-0.5">
                {EMOJI_GROUPS[group].emojis.map((e, i) => (
                  <button key={i} onClick={() => onEmoji(e)} className="text-[26px] leading-9 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition active:scale-110">
                    {e}
                  </button>
                ))}
              </div>
            </>
          )}

          {tab === 'sticker' && (
            <>
              <div className="flex gap-1 px-2 py-1.5 border-b border-slate-100 dark:border-slate-800">
                {STICKER_SETS.map((s, i) => (
                  <button
                    key={s.name}
                    onClick={() => setStickerSet(i)}
                    className={`px-3 py-1 rounded-full text-xs font-bold transition ${stickerSet === i ? 'bg-teal-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'}`}
                  >
                    {s.name}
                  </button>
                ))}
              </div>
              <div className="flex-1 overflow-y-auto p-2 grid grid-cols-2 gap-1.5">
                {STICKER_SETS[stickerSet].items.map((s, i) => (
                  <button
                    key={i}
                    onClick={() => onSticker(s, stickerSet === 0)}
                    className="rounded-xl bg-gradient-to-br from-teal-50 to-emerald-50 dark:from-slate-800 dark:to-slate-800 border border-teal-100 dark:border-slate-700 p-3 hover:scale-[1.03] transition active:scale-95 min-h-[64px] flex items-center justify-center"
                  >
                    <span className={stickerSet === 0 ? 'text-sm font-mono font-bold text-teal-800 dark:text-teal-200' : 'text-4xl'}>{s}</span>
                  </button>
                ))}
              </div>
            </>
          )}

          {tab === 'gif' && (
            <div className="flex-1 overflow-y-auto p-2 grid grid-cols-2 gap-1.5">
              {GIFS.map((g) => (
                <button
                  key={g.url}
                  onClick={() => onGif(g.url, g.label)}
                  className="relative rounded-xl overflow-hidden group border border-slate-200 dark:border-slate-700"
                >
                  <img src={g.url} alt={g.label} loading="lazy" className="w-full h-24 object-cover bg-slate-100 dark:bg-slate-800" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                  <span className="absolute inset-x-0 bottom-0 text-[11px] font-bold text-white bg-gradient-to-t from-black/70 to-transparent px-2 pt-4 pb-1 text-left flex items-center gap-1">
                    <ImageIcon size={11} /> {g.label}
                  </span>
                </button>
              ))}
            </div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
