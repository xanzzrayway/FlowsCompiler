import { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft, Phone, Video, Search, MoreVertical, Smile, Plus, Mic, Send, X,
  Image as ImageIcon, FileText, User as UserIcon, MapPin, Camera, Square,
  Pin, Trash2, Pencil, Reply, Forward, Copy, CheckCheck, Info, VolumeX,
  Archive, LogOut, Users, ShieldAlert, Ban, ChevronDown, Play, Pause, Loader2,
} from 'lucide-react';
import supabase from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from './Toast';
import Avatar from './Avatar';
import Tick from './Tick';
import MessageBubble, { MediaViewer } from './MessageBubble';
import EmojiPicker from './EmojiPicker';
import { chatTitle, chatAvatar, peerOf } from './ChatList';
import { broadcastTyping, useTypingChannel } from '../hooks/useTyping';
import {
  apiGet, apiPost, apiPut, apiDelete, uploadFile, canSee, timeAgo, previewFor,
  mentionNames, fmtClock, playSend, playReceive, ensureAudio, notifyBrowser, sameDay,
  type Chat, type Message, type Reaction, type Receipt, type UserProfile,
} from '../lib/api';

interface Props {
  chat: Chat;
  onBack: () => void;
  onChatPatched: (c: Chat) => void;
  onOpenInfo: () => void;
  onStartCall: (type: 'voice' | 'video', peerId: string) => void;
  onOpenProfile: (userId: string) => void;
  refreshSignal: number;
}

type MenuState = { x: number; y: number; msg: Message } | null;

export default function ChatWindow(p: Props) {
  const { profile } = useAuth();
  const toast = useToast();
  const myId = profile?.id || '';
  const chat = p.chat;

  const [messages, setMessages] = useState<Message[]>([]);
  const [quoted, setQuoted] = useState<Record<number, Message>>({});
  const [reactions, setReactions] = useState<Reaction[]>([]);
  const [receipts, setReceipts] = useState<Receipt[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [text, setText] = useState('');
  const [menu, setMenu] = useState<MenuState>(null);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [replyTo, setReplyTo] = useState<Message | null>(null);
  const [editing, setEditing] = useState<Message | null>(null);
  const [showEmoji, setShowEmoji] = useState(false);
  const [showAttach, setShowAttach] = useState(false);
  const [searchMode, setSearchMode] = useState(false);
  const [searchQ, setSearchQ] = useState('');
  const [searchHits, setSearchHits] = useState<Message[]>([]);
  const [hitIdx, setHitIdx] = useState(0);
  const [flashId, setFlashId] = useState<number | null>(null);
  const [typingUsers, setTypingUsers] = useState<Set<string>>(new Set());
  const [viewerIdx, setViewerIdx] = useState<number | null>(null);
  const [forwardIds, setForwardIds] = useState<number[] | null>(null);
  const [chatsForForward, setChatsForForward] = useState<Chat[]>([]);
  const [recording, setRecording] = useState(false);
  const [recSec, setRecSec] = useState(0);
  const [uploadPct, setUploadPct] = useState<number | null>(null);
  const [previewFiles, setPreviewFiles] = useState<{ file: File; url: string; caption: string }[] | null>(null);
  const [peerPresence, setPeerPresence] = useState<{ online: boolean; last: string } | null>(null);
  const [infoMsg, setInfoMsg] = useState<Message | null>(null);
  const [headerMenu, setHeaderMenu] = useState(false);
  const [blocked, setBlocked] = useState<{ byMe: boolean; byPeer: boolean }>({ byMe: false, byPeer: false });

  const scrollRef = useRef<HTMLDivElement>(null);
  const stickBottom = useRef(true);
  const typingTimer = useRef<number | null>(null);
  const typingOff = useRef<number | null>(null);
  const mediaRef = useRef<HTMLInputElement>(null);
  const docRef = useRef<HTMLInputElement>(null);
  const mediaRecorder = useRef<MediaRecorder | null>(null);
  const recChunks = useRef<Blob[]>([]);
  const recTimer = useRef<number | null>(null);
  const peer = peerOf(chat, myId);
  const isGroup = chat.type === 'group';

  const namesOf = (uid: string) => {
    if (uid === myId) return 'Anda';
    return chat.members.find((m) => m.user_id === uid)?.user?.name || peer?.name || 'Pengguna';
  };

  // ---------------- load messages ----------------
  const fetchMessages = async (before?: number) => {
    try {
      if (before) setLoadingMore(true);
      else setLoading(true);
      const res = await apiGet<{ messages: Message[]; quoted: Record<number, Message> }>(
        `/api/messages?chat_id=${chat.id}&limit=60${before ? `&before_id=${before}` : ''}`,
      );
      const vis = res.messages.filter((m) => !(m.deleted_for || []).includes(myId));
      if (before) {
        setMessages((prev) => [...vis, ...prev]);
        if (vis.length < 60) setHasMore(false);
      } else {
        setMessages(vis);
        setQuoted(res.quoted || {});
        setHasMore(vis.length >= 60);
        stickBottom.current = true;
      }
      const [rc, rx] = await Promise.all([
        apiGet<Receipt[]>(`/api/receipts?message_ids=${res.messages.map((m) => m.id).join(',') || '0'}`),
        apiGet<Reaction[]>(`/api/reactions?chat_id=${chat.id}`),
      ]);
      setReceipts((prev) => {
        const map = new Map(prev.map((r) => [r.id, r]));
        for (const r of rc) map.set(r.id, r);
        return [...map.values()];
      });
      setReactions(rx);
    } catch (e) {
      console.error(e);
      if (!before) toast('Gagal memuat pesan', 'error');
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  };

  useEffect(() => {
    setMessages([]); setQuoted({}); setReactions([]); setReceipts([]);
    setReplyTo(null); setEditing(null); setSelected(new Set()); setSearchMode(false);
    setSearchQ(''); setSearchHits([]); setHasMore(true); stickBottom.current = true;
    void fetchMessages();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chat.id]);

  // ---------------- realtime: messages ----------------
  useEffect(() => {
    const ch = supabase.channel(`chat-${chat.id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `chat_id=eq.${chat.id}` }, (pl) => {
        const m = pl.new as Message;
        if ((m.deleted_for || []).includes(myId)) return;
        setMessages((prev) => (prev.some((x) => x.id === m.id) ? prev : [...prev, m]));
        if (m.reply_to && !quoted[m.reply_to]) {
          void apiGet<{ messages: Message[]; quoted: Record<number, Message> }>(`/api/messages?chat_id=${chat.id}&limit=60`).then((r) => {
            setQuoted((prev) => ({ ...prev, ...(r.quoted || {}) }));
          }).catch(() => {});
        }
        if (m.sender_id !== myId) {
          if (!chat.my.muted) { playReceive(); }
          void apiPost('/api/receipts', { message_id: m.id, user_id: myId, status: 'delivered' });
          // tandai dibaca jika chat sedang terbuka
          window.setTimeout(() => void markReadRef.current([m.id]), 600);
        } else {
          playSend();
        }
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages', filter: `chat_id=eq.${chat.id}` }, (pl) => {
        const m = pl.new as Message;
        setMessages((prev) => prev.map((x) => (x.id === m.id ? m : x)));
      })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'messages' }, (pl) => {
        const old = pl.old as { id?: number };
        if (old?.id) setMessages((prev) => prev.filter((x) => x.id !== old.id));
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'reactions' }, () => {
        apiGet<Reaction[]>(`/api/reactions?chat_id=${chat.id}`).then(setReactions).catch(() => {});
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'message_receipts' }, (pl) => {
        const row = (pl.new || pl.old) as Receipt;
        if (!row?.message_id) return;
        setMessages((prev) => {
          if (!prev.some((m) => m.id === row.message_id)) return prev;
          return prev;
        });
        setReceipts((prev) => {
          const map = new Map(prev.map((r) => [`${r.message_id}:${r.user_id}`, r]));
          if (pl.eventType === 'DELETE') map.delete(`${row.message_id}:${row.user_id}`);
          else map.set(`${row.message_id}:${row.user_id}`, row as Receipt);
          return [...map.values()];
        });
      })
      .subscribe();
    return () => { void supabase.removeChannel(ch); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chat.id, myId]);

  // fallback polling tiap 6 detik (jaga-jaga realtime mati)
  useEffect(() => {
    const t = window.setInterval(async () => {
      try {
        const res = await apiGet<{ messages: Message[]; quoted: Record<number, Message> }>(`/api/messages?chat_id=${chat.id}&limit=30`);
        const vis = res.messages.filter((m) => !(m.deleted_for || []).includes(myId));
        setMessages((prev) => {
          const ids = new Set(prev.map((m) => m.id));
          const fresh = vis.filter((m) => !ids.has(m.id));
          if (!fresh.length) return prev;
          const map = new Map(prev.map((m) => [m.id, m]));
          for (const m of vis) map.set(m.id, m);
          return [...map.values()].sort((a, b) => a.id - b.id);
        });
        setQuoted((prev) => ({ ...prev, ...(res.quoted || {}) }));
      } catch { /* abaikan */ }
    }, 6000);
    return () => window.clearInterval(t);
  }, [chat.id, myId]);

  // ---------------- typing ----------------
  useTypingChannel(chat.id, myId, (uid, typing) => {
    setTypingUsers((prev) => {
      const n = new Set(prev);
      if (typing) n.add(uid); else n.delete(uid);
      return n;
    });
  });

  const onType = (v: string) => {
    setText(v);
    ensureAudio();
    void broadcastTyping(chat.id, myId, true);
    if (typingOff.current) window.clearTimeout(typingOff.current);
    typingOff.current = window.setTimeout(() => void broadcastTyping(chat.id, myId, false), 2500);
  };

  // ---------------- presence peer ----------------
  const refreshPeer = async () => {
    if (isGroup || !peer) return;
    try {
      const u = await apiGet<UserProfile | null>(`/api/users?id=${peer.id}`);
      if (u) setPeerPresence({ online: u.is_online, last: u.last_seen });
    } catch { /* abaikan */ }
  };
  useEffect(() => {
    void refreshPeer();
    const t = window.setInterval(refreshPeer, 15000);
    return () => window.clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chat.id, peer?.id]);

  // ---------------- block status ----------------
  const refreshBlocks = async () => {
    if (isGroup || !peer) { setBlocked({ byMe: false, byPeer: false }); return; }
    try {
      const r = await apiGet<{ blocked: string[]; blockedBy: string[] }>(`/api/blocks?user_id=${myId}`);
      setBlocked({ byMe: r.blocked.includes(peer.id), byPeer: r.blockedBy.includes(peer.id) });
    } catch { /* abaikan */ }
  };
  useEffect(() => { void refreshBlocks(); /* eslint-disable-next-line */ }, [chat.id, p.refreshSignal]);

  // ---------------- mark read ----------------
  const markRead = async (specific?: number[]) => {
    try {
      if (specific?.length) {
        await Promise.all(specific.map((mid) => apiPost('/api/receipts', { message_id: mid, user_id: myId, status: 'read' }).catch(() => null)));
        await apiPut('/api/members', { chat_id: chat.id, user_id: myId, last_read_at: new Date().toISOString() }).catch(() => null);
      } else {
        await apiPut('/api/receipts', { chat_id: chat.id, user_id: myId, status: 'read' });
        await apiPut('/api/members', { chat_id: chat.id, user_id: myId, last_read_at: new Date().toISOString() });
      }
    } catch { /* abaikan */ }
  };
  const markReadRef = useRef(markRead);
  markReadRef.current = markRead;
  useEffect(() => {
    if (!messages.length) return;
    const unread = messages.filter((m) => m.sender_id !== myId && !m.is_deleted);
    if (unread.length) {
      const t = window.setTimeout(() => void markRead(), 800);
      return () => window.clearTimeout(t);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messages.length, chat.id]);

  // ---------------- auto scroll ----------------
  useEffect(() => {
    const el = scrollRef.current;
    if (el && stickBottom.current) el.scrollTop = el.scrollHeight;
  }, [messages, typingUsers]);

  const onScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    stickBottom.current = el.scrollHeight - el.scrollTop - el.clientHeight < 120;
    if (el.scrollTop < 80 && hasMore && !loadingMore && messages.length) {
      const first = messages[0]?.id;
      if (first) {
        const prevH = el.scrollHeight;
        void fetchMessages(first).then(() => {
          requestAnimationFrame(() => {
            const now = scrollRef.current;
            if (now) now.scrollTop = now.scrollHeight - prevH;
          });
        });
      }
    }
  };

  // ---------------- send ----------------
  const notifyOthers = async (m: Message, title: string, body: string) => {
    if (isGroup && profile?.notif_settings) { /* preferensi bunyi ditangani di App */ }
    const others = chat.members.map((x) => x.user_id).filter((u) => u !== myId);
    const mentions = mentionNames(m.body || '');
    for (const uid of others) {
      const member = chat.members.find((x) => x.user_id === uid);
      const uname = (member?.user?.username || '').toLowerCase();
      const mentioned = mentions.includes(uname);
      try {
        await apiPost('/api/notifications', {
          user_id: uid,
          title,
          body: body.slice(0, 120),
          chat_id: chat.id,
          kind: mentioned ? 'mention' : 'message',
        });
      } catch { /* abaikan */ }
    }
  };

  const sendMessage = async (payload: Partial<Message> & { kind: string }) => {
    try {
      const created = await apiPost<Message>('/api/messages', {
        chat_id: chat.id,
        sender_id: myId,
        reply_to: replyTo?.id || null,
        ...payload,
      });
      setMessages((prev) => (prev.some((x) => x.id === created.id) ? prev : [...prev, created]));
      if (replyTo) setQuoted((q) => ({ ...q, [replyTo.id]: replyTo }));
      setReplyTo(null);
      stickBottom.current = true;
      const senderName = profile?.name || 'Seseorang';
      const title = isGroup ? `${senderName} di ${chat.name}` : senderName;
      void notifyOthers(created, title, previewFor(created));
      if (!chat.my.muted) playSend();
      return created;
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Gagal mengirim pesan', 'error');
      return null;
    }
  };

  const sendText = async () => {
    const v = text.trim();
    if (editing) {
      if (!v) return;
      try {
        const updated = await apiPut<Message>('/api/messages', { id: editing.id, body: v });
        setMessages((prev) => prev.map((m) => (m.id === updated.id ? updated : m)));
        setEditing(null); setText('');
        toast('Pesan diubah', 'success');
      } catch { toast('Gagal mengubah pesan', 'error'); }
      return;
    }
    if (!v) return;
    setText('');
    void broadcastTyping(chat.id, myId, false);
    await sendMessage({ kind: 'text', body: v });
  };

  // ---------------- reactions ----------------
  const react = async (m: Message, emoji: string) => {
    try {
      await apiPost('/api/reactions', { message_id: m.id, user_id: myId, emoji });
      const rx = await apiGet<Reaction[]>(`/api/reactions?chat_id=${chat.id}`);
      setReactions(rx);
    } catch { toast('Gagal memberi reaksi', 'error'); }
  };

  // ---------------- context menu actions ----------------
  const closeMenu = () => setMenu(null);

  const doReply = () => { if (menu) setReplyTo(menu.msg); closeMenu(); };
  const doEdit = () => {
    if (!menu) return;
    setEditing(menu.msg);
    setText(menu.msg.body);
    closeMenu();
  };
  const doCopy = async () => {
    if (!menu) return;
    try {
      await navigator.clipboard.writeText(menu.msg.body || previewFor(menu.msg));
      toast('Pesan disalin', 'success');
    } catch { toast('Gagal menyalin', 'error'); }
    closeMenu();
  };
  const doPin = async () => {
    if (!menu) return;
    try {
      const updated = await apiPut<Message>('/api/messages', { id: menu.msg.id, is_pinned: !menu.msg.is_pinned });
      setMessages((prev) => prev.map((m) => (m.id === updated.id ? updated : m)));
      toast(updated.is_pinned ? 'Pesan disematkan 📌' : 'Sematan dilepas', 'success');
    } catch { toast('Gagal menyematkan', 'error'); }
    closeMenu();
  };
  const doDeleteMe = async (ids: number[]) => {
    try {
      await Promise.all(ids.map(async (id) => {
        const m = messages.find((x) => x.id === id);
        if (!m) return;
        await apiPut('/api/messages', { id, deleted_for: [...(m.deleted_for || []), myId] });
      }));
      setMessages((prev) => prev.filter((m) => !ids.includes(m.id)));
      toast('Pesan dihapus untuk saya', 'success');
    } catch { toast('Gagal menghapus', 'error'); }
    closeMenu();
    setSelected(new Set());
  };
  const doDeleteAll = async (ids: number[]) => {
    try {
      await Promise.all(ids.map((id) => apiPut('/api/messages', { id, is_deleted: true })));
      setMessages((prev) => prev.map((m) => (ids.includes(m.id) ? { ...m, is_deleted: true } : m)));
      toast('Pesan dihapus untuk semua orang', 'success');
    } catch { toast('Gagal menghapus', 'error'); }
    closeMenu();
    setSelected(new Set());
  };

  const openForward = async (ids: number[]) => {
    try {
      const all = await apiGet<Chat[]>(`/api/chats?user_id=${myId}`);
      setChatsForForward(all);
      setForwardIds(ids);
    } catch { toast('Gagal memuat daftar chat', 'error'); }
    closeMenu();
  };

  const execForward = async (targetId: number) => {
    if (!forwardIds?.length) return;
    try {
      const targets = messages.filter((m) => forwardIds.includes(m.id));
      for (const m of targets) {
        await apiPost('/api/messages', {
          chat_id: targetId,
          sender_id: myId,
          kind: m.kind,
          body: m.body,
          media_url: m.media_url,
          media_name: m.media_name,
          media_size: m.media_size,
          media_mime: m.media_mime,
          duration: m.duration,
          contact_data: m.contact_data,
          location_data: m.location_data,
          forwarded: true,
          forwarded_from: namesOf(m.sender_id),
        });
      }
      toast(`Diteruskan ke ${targets.length} pesan ✓`, 'success');
      if (targetId === chat.id) void fetchMessages();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Gagal meneruskan', 'error');
    }
    setForwardIds(null);
    setSelected(new Set());
  };

  // ---------------- composer helpers ----------------
  const insertEmoji = (e: string) => setText((t) => t + e);

  const sendSticker = (s: string, isText: boolean) => {
    setShowEmoji(false);
    void sendMessage({ kind: 'sticker', body: s, media_mime: isText ? 'text' : 'emoji' });
  };
  const sendGif = (url: string, label: string) => {
    setShowEmoji(false);
    void sendMessage({ kind: 'gif', body: label, media_url: url, media_mime: 'image/gif' });
  };

  const onFilesPicked = (files: FileList | null, kind: 'media' | 'doc') => {
    if (!files?.length) return;
    const arr = [...files].slice(0, 6);
    for (const f of arr) {
      if (f.size > 25 * 1024 * 1024) {
        toast(`"${f.name}" melebihi 25 MB, dilewati`, 'error');
      }
    }
    const ok = arr.filter((f) => f.size <= 25 * 1024 * 1024);
    if (!ok.length) return;
    if (kind === 'doc') {
      void (async () => {
        for (const f of ok) {
          try {
            setUploadPct(0);
            const { url } = await uploadFile(f, (pct) => setUploadPct(pct));
            await sendMessage({ kind: 'document', media_url: url, media_name: f.name, media_size: f.size, media_mime: f.type });
          } catch { toast(`Gagal mengunggah ${f.name}`, 'error'); }
        }
        setUploadPct(null);
      })();
      return;
    }
    setPreviewFiles(ok.map((file) => ({ file, url: URL.createObjectURL(file), caption: '' })));
    setShowAttach(false);
  };

  const sendPreview = async () => {
    if (!previewFiles?.length) return;
    const batch = [...previewFiles];
    setPreviewFiles(null);
    for (const item of batch) {
      const f = item.file;
      try {
        setUploadPct(0);
        const { url } = await uploadFile(f, (pct) => setUploadPct(pct));
        const kind = f.type.startsWith('image/') ? 'image' : f.type.startsWith('video/') ? 'video' : f.type.startsWith('audio/') ? 'audio' : 'document';
        await sendMessage({ kind, body: item.caption, media_url: url, media_name: f.name, media_size: f.size, media_mime: f.type });
      } catch { toast(`Gagal mengunggah ${f.name}`, 'error'); }
    }
    setUploadPct(null);
  };

  const sendContact = () => {
    setShowAttach(false);
    const name = window.prompt('Nama kontak:');
    if (!name) return;
    const phone = window.prompt('Nomor telepon:') || '';
    void sendMessage({ kind: 'contact', contact_data: { name, phone } });
  };

  const sendLocation = () => {
    setShowAttach(false);
    if (!navigator.geolocation) { toast('Perangkat tidak mendukung lokasi', 'error'); return; }
    toast('Mengambil lokasi…', 'info');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        void sendMessage({
          kind: 'location',
          location_data: { lat: pos.coords.latitude, lng: pos.coords.longitude, label: `Lokasi saya (${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)})` },
        });
      },
      () => toast('Izin lokasi ditolak. Aktifkan izin lokasi di browser.', 'error'),
      { timeout: 12000 },
    );
  };

  // ---------------- voice recording ----------------
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mime = MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : undefined;
      const mr = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
      recChunks.current = [];
      mr.ondataavailable = (e) => { if (e.data.size) recChunks.current.push(e.data); };
      mr.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
      };
      mediaRecorder.current = mr;
      mr.start();
      setRecording(true);
      setRecSec(0);
      recTimer.current = window.setInterval(() => setRecSec((s) => s + 1), 1000);
    } catch {
      toast('Izin mikrofon ditolak. Aktifkan izin mikrofon di browser.', 'error');
    }
  };

  const stopRecording = async (send: boolean) => {
    if (recTimer.current) window.clearInterval(recTimer.current);
    const mr = mediaRecorder.current;
    setRecording(false);
    if (!mr) return;
    await new Promise<void>((resolve) => {
      mr.onstop = () => {
        mr.stream.getTracks().forEach((t) => t.stop());
        resolve();
      };
      try { mr.stop(); } catch { resolve(); }
    });
    mediaRecorder.current = null;
    if (!send) return;
    const blob = new Blob(recChunks.current, { type: mr.mimeType || 'audio/webm' });
    if (!blob.size) { toast('Rekaman kosong', 'error'); return; }
    const file = new File([blob], `voice-${Date.now()}.webm`, { type: blob.type });
    try {
      setUploadPct(0);
      const { url } = await uploadFile(file, (pct) => setUploadPct(pct));
      await sendMessage({ kind: 'voice', media_url: url, media_name: file.name, media_size: file.size, media_mime: file.type, duration: recSec });
    } catch { toast('Gagal mengirim pesan suara', 'error'); }
    finally { setUploadPct(null); setRecSec(0); }
  };

  // ---------------- search in chat ----------------
  const runSearch = async (q: string) => {
    setSearchQ(q);
    if (q.trim().length < 2) { setSearchHits([]); return; }
    try {
      const res = await apiGet<{ messages: Message[] }>(`/api/messages?chat_id=${chat.id}&q=${encodeURIComponent(q.trim())}`);
      const vis = res.messages.filter((m) => !(m.deleted_for || []).includes(myId));
      setSearchHits(vis);
      setHitIdx(0);
    } catch { /* abaikan */ }
  };

  const jumpTo = (id: number) => {
    const el = document.getElementById(`msg-${id}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setFlashId(id);
      window.setTimeout(() => setFlashId(null), 1700);
    } else {
      toast('Pesan lama — muat lebih banyak dulu (scroll ke atas)', 'info');
    }
  };

  // ---------------- header actions ----------------
  const toggleMute = async () => {
    try {
      await apiPut('/api/members', { chat_id: chat.id, user_id: myId, muted: !chat.my.muted });
      p.onChatPatched({ ...chat, my: { ...chat.my, muted: !chat.my.muted } });
      toast(chat.my.muted ? 'Notifikasi dinyalakan' : 'Chat dibisukan 🔕', 'success');
    } catch { toast('Gagal mengubah bisu', 'error'); }
    setHeaderMenu(false);
  };
  const toggleArchive = async () => {
    try {
      await apiPut('/api/members', { chat_id: chat.id, user_id: myId, archived: !chat.my.archived });
      p.onChatPatched({ ...chat, my: { ...chat.my, archived: !chat.my.archived } });
      toast(chat.my.archived ? 'Chat dikeluarkan dari arsip' : 'Chat diarsipkan', 'success');
    } catch { toast('Gagal mengarsipkan', 'error'); }
    setHeaderMenu(false);
  };
  const clearChat = async () => {
    if (!window.confirm('Hapus semua pesan di chat ini untuk Anda?')) return;
    try {
      await apiPut('/api/messages', { chat_id: chat.id, clear_chat_for: myId });
      setMessages([]);
      toast('Riwayat chat dibersihkan', 'success');
    } catch { toast('Gagal membersihkan', 'error'); }
    setHeaderMenu(false);
  };
  const leaveChat = async () => {
    if (!window.confirm(isGroup ? 'Keluar dari grup ini?' : 'Hapus percakapan ini?')) return;
    try {
      await apiDelete('/api/chats', { id: chat.id, user_id: myId });
      toast(isGroup ? 'Anda keluar dari grup' : 'Percakapan dihapus', 'success');
      p.onBack();
    } catch { toast('Gagal', 'error'); }
  };

  // ---------------- derived ----------------
  const title = chatTitle(chat, myId);
  const avatar = chatAvatar(chat, myId);
  const shareChat = true;
  const canSeeLast = peer ? canSee(myId, peer, 'last_seen', shareChat) : false;

  const typingNames = [...typingUsers].map(namesOf).join(', ');
  const subtitle = typingNames
    ? `${typingNames} mengetik…`
    : isGroup
      ? `${chat.members.length} anggota`
      : blocked.byMe
        ? 'Anda memblokir kontak ini'
        : blocked.byPeer
          ? 'Tidak tersedia'
          : peerPresence?.online
            ? 'Online'
            : canSeeLast && peerPresence
              ? `Terakhir dilihat ${timeAgo(peerPresence.last)}`
              : peer?.bio || 'Hai! Saya memakai FastApp ⚡';

  const mediaItems = useMemo(() => messages.filter((m) => ['image', 'video', 'gif'].includes(m.kind) && m.media_url && !m.is_deleted), [messages]);
  const pinned = messages.filter((m) => m.is_pinned && !m.is_deleted);

  const receiptFor = (m: Message): 'sent' | 'delivered' | 'read' => {
    const others = chat.members.filter((x) => x.user_id !== myId).map((x) => x.user_id);
    if (!others.length) return 'sent';
    const rows = receipts.filter((r) => r.message_id === m.id);
    const got = (uid: string) => rows.find((r) => r.user_id === uid)?.status;
    if (others.every((u) => got(u) === 'read')) return 'read';
    if (others.some((u) => got(u) === 'read' || got(u) === 'delivered')) return 'delivered';
    return 'sent';
  };

  const readReceiptsOn = profile?.read_receipts !== false;

  return (
    <div className="h-full flex flex-col bg-transparent">
      {/* ===== header ===== */}
      <div className="flex items-center gap-1.5 sm:gap-2 px-2 sm:px-4 py-2 bg-white/95 dark:bg-slate-900/95 backdrop-blur border-b border-slate-200 dark:border-slate-800 z-20">
        <button onClick={p.onBack} className="lg:hidden p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800" aria-label="Kembali">
          <ArrowLeft size={21} />
        </button>
        <button onClick={p.onOpenInfo} className="flex items-center gap-2.5 flex-1 min-w-0 text-left p-1 rounded-xl">
          {isGroup ? (
            <span className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-500 to-emerald-600 flex items-center justify-center text-white shrink-0 overflow-hidden">
              {chat.avatar_url ? <img src={chat.avatar_url} alt="" className="w-full h-full object-cover" /> : <Users size={20} />}
            </span>
          ) : (
            <Avatar name={title} src={avatar} size={40} online={blocked.byMe || blocked.byPeer ? undefined : peerPresence?.online} />
          )}
          <span className="min-w-0 flex-1">
            <span className="font-bold truncate block text-[15px]">{title}</span>
            <span className={`text-xs truncate flex items-center gap-1 ${typingNames ? 'text-teal-600 dark:text-teal-400 font-semibold' : 'text-slate-500 dark:text-slate-400'}`}>
              {typingNames && <span className="text-teal-600 dark:text-teal-400"><span className="typing-dot" /><span className="typing-dot" /><span className="typing-dot" /></span>}
              <span className="truncate">{subtitle}</span>
            </span>
          </span>
        </button>
        {!isGroup && peer && (
          <>
            <button onClick={() => p.onStartCall('voice', peer.id)} className="p-2.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300" title="Panggilan suara">
              <Phone size={20} />
            </button>
            <button onClick={() => p.onStartCall('video', peer.id)} className="p-2.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300" title="Panggilan video">
              <Video size={20} />
            </button>
          </>
        )}
        <button onClick={() => setSearchMode(!searchMode)} className="p-2.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300" title="Cari dalam chat">
          <Search size={20} />
        </button>
        <span className="relative">
          <button onClick={() => setHeaderMenu(!headerMenu)} className="p-2.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300" title="Lainnya">
            <MoreVertical size={20} />
          </button>
          {headerMenu && (
            <>
              <span className="fixed inset-0 z-30" onClick={() => setHeaderMenu(false)} />
              <span className="absolute right-0 top-full mt-1 z-40 w-56 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-700 py-1.5 fa-animate-pop">
                <HItem icon={<Info size={17} />} t={isGroup ? 'Info grup' : 'Info kontak'} onClick={() => { setHeaderMenu(false); p.onOpenInfo(); }} />
                <HItem icon={<VolumeX size={17} />} t={chat.my.muted ? 'Nyalakan notifikasi' : 'Bisukan notifikasi'} onClick={toggleMute} />
                <HItem icon={<Archive size={17} />} t={chat.my.archived ? 'Keluarkan dari arsip' : 'Arsipkan chat'} onClick={toggleArchive} />
                <HItem icon={<Trash2 size={17} />} t="Bersihkan chat" onClick={clearChat} />
                <span className="block h-px bg-slate-100 dark:bg-slate-700 my-1" />
                <HItem icon={<LogOut size={17} />} t={isGroup ? 'Keluar dari grup' : 'Hapus percakapan'} danger onClick={leaveChat} />
              </span>
            </>
          )}
        </span>
      </div>

      {/* search bar */}
      {searchMode && (
        <div className="px-3 py-2 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2 fa-animate-fade-in z-10">
          <Search size={17} className="text-slate-400 shrink-0" />
          <input
            autoFocus
            value={searchQ}
            onChange={(e) => void runSearch(e.target.value)}
            placeholder="Cari pesan…"
            className="flex-1 bg-transparent outline-none text-sm min-w-0"
          />
          {searchHits.length > 0 && (
            <span className="flex items-center gap-1 text-xs font-bold text-slate-500 shrink-0">
              <button onClick={() => { const i = (hitIdx - 1 + searchHits.length) % searchHits.length; setHitIdx(i); jumpTo(searchHits[i].id); }} className="px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800">▲</button>
              {hitIdx + 1}/{searchHits.length}
              <button onClick={() => { const i = (hitIdx + 1) % searchHits.length; setHitIdx(i); jumpTo(searchHits[i].id); }} className="px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800">▼</button>
            </span>
          )}
          <button onClick={() => { setSearchMode(false); setSearchQ(''); setSearchHits([]); }} className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
            <X size={17} />
          </button>
        </div>
      )}

      {/* pinned banner */}
      {pinned.length > 0 && !searchMode && (
        <button
          onClick={() => jumpTo(pinned[pinned.length - 1].id)}
          className="mx-3 sm:mx-6 mt-2 flex items-center gap-2 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 rounded-xl px-3 py-2 text-left"
        >
          <Pin size={15} className="text-amber-500 shrink-0 rotate-45" />
          <span className="text-[13px] text-amber-900 dark:text-amber-200 truncate flex-1">
            <b>Disematkan{pinned.length > 1 ? ` (${pinned.length})` : ''}:</b> {previewFor(pinned[pinned.length - 1])}
          </span>
          <ChevronDown size={15} className="text-amber-500 shrink-0" />
        </button>
      )}

      {/* selection bar */}
      {selected.size > 0 && (
        <div className="flex items-center gap-1 px-3 py-1.5 bg-slate-800 text-white text-sm font-bold fa-animate-fade-in z-10">
          <button onClick={() => setSelected(new Set())} className="p-1.5 rounded-full hover:bg-white/15"><X size={18} /></button>
          <span className="flex-1">{selected.size} dipilih</span>
          <button onClick={() => openForward([...selected])} className="p-2 rounded-full hover:bg-white/15" title="Teruskan"><Forward size={18} /></button>
          <button onClick={() => {
            const all = [...selected].map((id) => messages.find((m) => m.id === id)?.body || '').join('\n');
            void navigator.clipboard.writeText(all).then(() => toast('Disalin', 'success'));
          }} className="p-2 rounded-full hover:bg-white/15" title="Salin"><Copy size={18} /></button>
          <button onClick={() => doDeleteMe([...selected])} className="p-2 rounded-full hover:bg-white/15" title="Hapus untuk saya"><Trash2 size={18} /></button>
          {[...selected].every((id) => messages.find((m) => m.id === id)?.sender_id === myId) && (
            <button onClick={() => doDeleteAll([...selected])} className="p-2 rounded-full hover:bg-white/15" title="Hapus untuk semua"><Ban size={18} /></button>
          )}
        </div>
      )}

      {/* ===== messages ===== */}
      <div ref={scrollRef} onScroll={onScroll} className="flex-1 overflow-y-auto py-3 space-y-[3px]">
        {loading ? (
          <div className="px-6 py-4 space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className={`flex ${i % 2 ? 'justify-start' : 'justify-end'}`}>
                <div className={`skeleton h-12 rounded-2xl ${i % 2 ? 'w-56' : 'w-44'}`} />
              </div>
            ))}
          </div>
        ) : messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center px-8">
            <div className="w-24 h-24 rounded-full bg-teal-100 dark:bg-teal-900/40 flex items-center justify-center mb-4">
              <span className="text-5xl">👋</span>
            </div>
            <p className="font-extrabold text-lg">Belum ada pesan</p>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-[280px]">
              Sapa {isGroup ? 'anggota grup' : title.split(' ')[0]} dan mulai percakapan seru! 💬
            </p>
          </div>
        ) : (
          <>
            {loadingMore && <p className="text-center text-xs text-slate-400 py-1">Memuat pesan lama…</p>}
            {messages.map((m, i) => {
              const prev = messages[i - 1];
              const newDay = !prev || !sameDay(prev.created_at, m.created_at);
              const continued = !!prev && prev.sender_id === m.sender_id && sameDay(prev.created_at, m.created_at) && (new Date(m.created_at).getTime() - new Date(prev.created_at).getTime()) < 5 * 60000;
              return (
                <MessageBubble
                  key={m.id}
                  msg={m}
                  mine={m.sender_id === myId}
                  sender={chat.members.find((x) => x.user_id === m.sender_id)?.user}
                  showSender={isGroup && !continued && m.sender_id !== myId && !m.is_deleted && m.kind !== 'system'}
                  isGroup={isGroup}
                  quoted={m.reply_to ? quoted[m.reply_to] || messages.find((x) => x.id === m.reply_to) || null : null}
                  quotedSenderName={m.reply_to ? namesOf((quoted[m.reply_to] || messages.find((x) => x.id === m.reply_to))?.sender_id || '') : ''}
                  reactions={reactions.filter((r) => r.message_id === m.id)}
                  receipt={receiptFor(m)}
                  readReceiptsOn={readReceiptsOn}
                  continued={continued}
                  newDay={newDay}
                  selected={selected.has(m.id)}
                  highlight={flashId === m.id}
                  onContext={(e, msg) => {
                    e.preventDefault();
                    if (selected.size) { toggleSelect(msg.id); return; }
                    setMenu({ x: Math.min(e.clientX, window.innerWidth - 230), y: Math.min(e.clientY, window.innerHeight - 320), msg });
                  }}
                  onOpenMedia={(msg) => {
                    const idx = mediaItems.findIndex((x) => x.id === msg.id);
                    if (idx >= 0) setViewerIdx(idx);
                  }}
                  onQuoteClick={jumpTo}
                  onReact={react}
                  onTapSelect={(msg) => toggleSelect(msg.id)}
                  onAvatarClick={(uid) => p.onOpenProfile(uid)}
                  namesOf={namesOf}
                />
              );
            })}
            {typingUsers.size > 0 && (
              <div className="flex justify-start px-3 sm:px-6">
                <div className="px-4 py-2.5 rounded-2xl rounded-bl-md bg-white dark:bg-slate-800 shadow-sm text-slate-500 flex items-center gap-1">
                  <span className="typing-dot" /><span className="typing-dot" /><span className="typing-dot" />
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* upload progress */}
      {uploadPct !== null && (
        <div className="px-4 py-2 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2 text-xs font-bold text-teal-600 dark:text-teal-400">
            <Loader2 size={14} className="animate-spin" /> Mengunggah… {uploadPct}%
          </div>
          <div className="h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full mt-1 overflow-hidden">
            <div className="h-full bg-teal-500 rounded-full transition-all" style={{ width: `${uploadPct}%` }} />
          </div>
        </div>
      )}

      {/* ===== composer ===== */}
      {blocked.byMe || blocked.byPeer ? (
        <div className="px-4 py-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 text-center">
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-2">
            {blocked.byMe ? 'Anda memblokir kontak ini. Buka blokir untuk mengirim pesan.' : 'Anda tidak dapat mengirim pesan ke kontak ini.'}
          </p>
          {blocked.byMe && peer && (
            <button
              onClick={async () => {
                try {
                  await apiDelete('/api/blocks', { blocker_id: myId, blocked_id: peer.id });
                  setBlocked({ byMe: false, byPeer: false });
                  toast('Blokir dibuka ✓', 'success');
                } catch { toast('Gagal membuka blokir', 'error'); }
              }}
              className="px-5 py-2 rounded-full bg-teal-600 hover:bg-teal-700 text-white text-sm font-bold"
            >
              Buka Blokir
            </button>
          )}
        </div>
      ) : recording ? (
        <div className="flex items-center gap-2 px-3 py-2.5 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
          <button onClick={() => void stopRecording(false)} className="p-2.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-rose-500" title="Batalkan">
            <Trash2 size={20} />
          </button>
          <span className="flex items-center gap-2 flex-1 bg-rose-50 dark:bg-rose-950/30 rounded-full px-4 py-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
            <span className="text-sm font-bold text-rose-600 dark:text-rose-400 tabular-nums">
              {Math.floor(recSec / 60)}:{String(recSec % 60).padStart(2, '0')}
            </span>
            <span className="flex gap-[3px] items-end h-5 text-rose-400 ml-1">
              {[0.5, 0.9, 0.4, 1, 0.6, 0.8, 0.45].map((d, i) => (
                <span key={i} className="eq-bar" style={{ height: '100%', animationDelay: `${i * 0.12}s`, animationDuration: `${0.6 + d * 0.5}s` }} />
              ))}
            </span>
          </span>
          <button onClick={() => void stopRecording(false)} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 text-sm font-bold px-3">Batal</button>
          <button onClick={() => void stopRecording(true)} className="p-3 rounded-full bg-teal-600 hover:bg-teal-700 text-white shadow-lg" title="Kirim">
            <Send size={19} />
          </button>
        </div>
      ) : (
        <div className="px-2 sm:px-3 pb-2.5 pt-1.5 bg-transparent relative">
          {/* reply / edit preview */}
          {(replyTo || editing) && (
            <div className="mx-1 mb-1.5 flex items-center gap-2 bg-white dark:bg-slate-800 rounded-2xl px-3 py-2 shadow border border-slate-200 dark:border-slate-700 fa-animate-fade-in">
              <span className={`w-1 self-stretch rounded-full ${editing ? 'bg-amber-400' : 'bg-teal-500'}`} />
              <span className="flex-1 min-w-0">
                <span className="block text-[12px] font-extrabold text-teal-600 dark:text-teal-400">
                  {editing ? <><Pencil size={11} className="inline mr-1" />Edit pesan</> : <><Reply size={11} className="inline mr-1" />Balas {namesOf(replyTo!.sender_id)}</>}
                </span>
                <span className="block text-[13px] text-slate-500 dark:text-slate-400 truncate">{previewFor(replyTo || editing)}</span>
              </span>
              <button onClick={() => { setReplyTo(null); setEditing(null); if (editing) setText(''); }} className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700">
                <X size={17} />
              </button>
            </div>
          )}

          <div className="flex items-end gap-1.5">
            <div className="flex-1 flex items-end gap-0.5 bg-white dark:bg-slate-800 rounded-3xl shadow border border-slate-200/70 dark:border-slate-700 px-1.5 py-1.5 relative">
              <EmojiPicker
                open={showEmoji}
                onClose={() => setShowEmoji(false)}
                onEmoji={insertEmoji}
                onSticker={sendSticker}
                onGif={sendGif}
              />
              <button onClick={() => { setShowEmoji(!showEmoji); setShowAttach(false); }} className={`p-2 rounded-full transition ${showEmoji ? 'text-teal-600 bg-teal-50 dark:bg-teal-950' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'}`} title="Emoji, stiker & GIF">
                <Smile size={23} />
              </button>
              <span className="relative">
                <button onClick={() => { setShowAttach(!showAttach); setShowEmoji(false); }} className={`p-2 rounded-full transition ${showAttach ? 'rotate-45 text-teal-600 bg-teal-50 dark:bg-teal-950' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'}`} title="Lampirkan">
                  <Plus size={23} />
                </button>
                {showAttach && (
                  <>
                    <span className="fixed inset-0 z-30" onClick={() => setShowAttach(false)} />
                    <span className="absolute bottom-full mb-2 left-0 z-40 w-52 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-700 py-1.5 fa-animate-pop">
                      <AItem icon={<Camera size={18} />} bg="bg-violet-100 text-violet-600 dark:bg-violet-900/50 dark:text-violet-300" t="Foto / Video" onClick={() => mediaRef.current?.click()} />
                      <AItem icon={<FileText size={18} />} bg="bg-rose-100 text-rose-600 dark:bg-rose-900/50 dark:text-rose-300" t="Dokumen" onClick={() => docRef.current?.click()} />
                      <AItem icon={<UserIcon size={18} />} bg="bg-sky-100 text-sky-600 dark:bg-sky-900/50 dark:text-sky-300" t="Kontak" onClick={sendContact} />
                      <AItem icon={<MapPin size={18} />} bg="bg-emerald-100 text-emerald-600 dark:bg-emerald-900/50 dark:text-emerald-300" t="Lokasi" onClick={sendLocation} />
                    </span>
                  </>
                )}
              </span>
              <textarea
                value={text}
                onChange={(e) => onType(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void sendText(); }
                }}
                placeholder={editing ? 'Ubah pesan…' : 'Ketik pesan…'}
                rows={1}
                className="fa-autosize flex-1 bg-transparent outline-none text-[15px] px-1 py-2 resize-none placeholder:text-slate-400 min-w-0"
              />
              <input ref={mediaRef} type="file" accept="image/*,video/*,audio/*" multiple className="hidden" onChange={(e) => { onFilesPicked(e.target.files, 'media'); e.target.value = ''; }} />
              <input ref={docRef} type="file" multiple className="hidden" onChange={(e) => { onFilesPicked(e.target.files, 'doc'); e.target.value = ''; }} />
            </div>
            {text.trim() || editing ? (
              <button onClick={() => void sendText()} className="p-3.5 rounded-full bg-teal-600 hover:bg-teal-700 text-white shadow-lg shadow-teal-600/30 transition active:scale-95" title={editing ? 'Simpan' : 'Kirim'}>
                {editing ? <CheckCheck size={21} /> : <Send size={20} />}
              </button>
            ) : (
              <button onClick={() => void startRecording()} className="p-3.5 rounded-full bg-teal-600 hover:bg-teal-700 text-white shadow-lg shadow-teal-600/30 transition active:scale-95" title="Pesan suara">
                <Mic size={21} />
              </button>
            )}
          </div>
        </div>
      )}

      {/* ===== context menu ===== */}
      {menu && (
        <>
          <span className="fixed inset-0 z-40" onClick={closeMenu} />
          <CtxMenu
            x={menu.x} y={menu.y} msg={menu.msg} mine={menu.msg.sender_id === myId}
            onReply={doReply} onEdit={doEdit} onCopy={doCopy} onPin={doPin}
            onForward={() => openForward([menu.msg.id])}
            onSelect={() => { toggleSelect(menu.msg.id); closeMenu(); }}
            onDeleteMe={() => doDeleteMe([menu.msg.id])}
            onDeleteAll={() => doDeleteAll([menu.msg.id])}
            onInfo={() => { setInfoMsg(menu.msg); closeMenu(); }}
            onReact={(e) => { react(menu.msg, e); closeMenu(); }}
          />
        </>
      )}

      {/* ===== media preview before send ===== */}
      {previewFiles && (
        <div className="fixed inset-0 z-[80] bg-black/90 flex flex-col fa-animate-fade-in">
          <div className="flex items-center justify-between px-4 py-3 text-white">
            <button onClick={() => setPreviewFiles(null)} className="p-2 rounded-full hover:bg-white/15"><X size={22} /></button>
            <span className="text-sm font-bold">{previewFiles.length} file dipilih</span>
            <span className="w-10" />
          </div>
          <div className="flex-1 overflow-y-auto px-4 py-2 space-y-4">
            {previewFiles.map((pf, i) => (
              <div key={i} className="max-w-lg mx-auto bg-white/10 rounded-2xl overflow-hidden">
                {pf.file.type.startsWith('image/') && <img src={pf.url} alt="" className="w-full max-h-[46vh] object-contain bg-black" />}
                {pf.file.type.startsWith('video/') && <video src={pf.url} controls className="w-full max-h-[46vh] bg-black" />}
                {pf.file.type.startsWith('audio/') && (
                  <div className="p-6 flex items-center gap-2 text-white">
                    <Play size={20} /> <audio src={pf.url} controls className="flex-1" />
                  </div>
                )}
                {!pf.file.type.startsWith('image/') && !pf.file.type.startsWith('video/') && !pf.file.type.startsWith('audio/') && (
                  <div className="p-6 text-white font-bold">{pf.file.name}</div>
                )}
                <div className="flex items-center gap-2 p-2">
                  <input
                    value={pf.caption}
                    onChange={(e) => setPreviewFiles((prev) => prev!.map((x, j) => (j === i ? { ...x, caption: e.target.value } : x)))}
                    placeholder="Tambahkan keterangan…"
                    className="flex-1 bg-white/10 text-white placeholder:text-white/50 rounded-xl px-3 py-2 text-sm outline-none"
                  />
                  <button onClick={() => setPreviewFiles((prev) => (prev!.length === 1 ? null : prev!.filter((_, j) => j !== i)))} className="p-2 rounded-full bg-white/10 text-white hover:bg-white/20">
                    <Trash2 size={17} />
                  </button>
                </div>
              </div>
            ))}
          </div>
          <div className="p-4 flex justify-end max-w-lg w-full mx-auto">
            <button onClick={() => void sendPreview()} className="p-4 rounded-full bg-teal-500 hover:bg-teal-400 text-white shadow-xl">
              <Send size={22} />
            </button>
          </div>
        </div>
      )}

      {/* ===== forward picker ===== */}
      {forwardIds && (
        <div className="fixed inset-0 z-[80] bg-black/60 flex items-end sm:items-center justify-center p-0 sm:p-4" onClick={() => setForwardIds(null)}>
          <div className="w-full sm:max-w-md bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl max-h-[80vh] flex flex-col fa-animate-fade-up" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-200 dark:border-slate-800">
              <button onClick={() => setForwardIds(null)} className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800"><X size={20} /></button>
              <div>
                <p className="font-extrabold">Teruskan ke…</p>
                <p className="text-xs text-slate-500">{forwardIds.length} pesan dipilih</p>
              </div>
            </div>
            <div className="overflow-y-auto p-2">
              {chatsForForward.map((c) => (
                <button
                  key={c.id}
                  onClick={() => void execForward(c.id)}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 text-left"
                >
                  <Avatar name={chatTitle(c, myId)} src={chatAvatar(c, myId)} size={44} />
                  <span className="flex-1 min-w-0">
                    <span className="font-bold block truncate text-[15px]">{chatTitle(c, myId)}</span>
                    <span className="text-xs text-slate-500 truncate block">{c.type === 'group' ? `Grup • ${c.members.length} anggota` : 'Chat pribadi'}</span>
                  </span>
                  <Forward size={18} className="text-teal-600" />
                </button>
              ))}
              {chatsForForward.length === 0 && <p className="text-center text-sm text-slate-400 py-8">Tidak ada chat lain.</p>}
            </div>
          </div>
        </div>
      )}

      {/* ===== message info ===== */}
      {infoMsg && (
        <MsgInfoModal
          msg={infoMsg}
          chat={chat}
          myId={myId}
          namesOf={namesOf}
          onClose={() => setInfoMsg(null)}
        />
      )}

      {/* ===== media viewer ===== */}
      {viewerIdx !== null && mediaItems.length > 0 && (
        <MediaViewer items={mediaItems} index={viewerIdx} onClose={() => setViewerIdx(null)} onNav={setViewerIdx} />
      )}
    </div>
  );

  function toggleSelect(id: number) {
    setSelected((prev) => {
      const n = new Set(prev);
      if (n.has(id)) n.delete(id); else n.add(id);
      return n;
    });
  }
}

function HItem({ icon, t, onClick, danger }: { icon: React.ReactNode; t: string; onClick: () => void; danger?: boolean }) {
  return (
    <button onClick={onClick} className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm font-semibold transition ${danger ? 'text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40' : 'hover:bg-slate-100 dark:hover:bg-slate-700/60'}`}>
      {icon} {t}
    </button>
  );
}

function AItem({ icon, bg, t, onClick }: { icon: React.ReactNode; bg: string; t: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="w-full flex items-center gap-3 px-4 py-2.5 text-sm font-semibold hover:bg-slate-100 dark:hover:bg-slate-700/60">
      <span className={`p-2 rounded-full ${bg}`}>{icon}</span> {t}
    </button>
  );
}

function CtxMenu(props: {
  x: number; y: number; msg: Message; mine: boolean;
  onReply: () => void; onEdit: () => void; onCopy: () => void; onPin: () => void;
  onForward: () => void; onSelect: () => void; onDeleteMe: () => void; onDeleteAll: () => void;
  onInfo: () => void; onReact: (e: string) => void;
}) {
  const { msg } = props;
  if (msg.is_deleted || msg.kind === 'system') return null;
  const canEdit = props.mine && msg.kind === 'text' && (Date.now() - new Date(msg.created_at).getTime()) < 15 * 60000;
  return (
    <div
      className="fixed z-50 w-56 bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 py-1.5 fa-animate-pop"
      style={{ left: props.x, top: props.y }}
      onClick={(e) => e.stopPropagation()}
    >
      <div className="flex justify-around px-2 pb-1.5 border-b border-slate-100 dark:border-slate-700 mb-1">
        {['❤️', '👍', '😂', '😮', '😢', '🙏'].map((e) => (
          <button key={e} onClick={() => props.onReact(e)} className="text-xl hover:scale-125 transition">{e}</button>
        ))}
      </div>
      <HItem icon={<Reply size={17} />} t="Balas" onClick={props.onReply} />
      <HItem icon={<Forward size={17} />} t="Teruskan" onClick={props.onForward} />
      <HItem icon={<Copy size={17} />} t="Salin" onClick={props.onCopy} />
      {canEdit && <HItem icon={<Pencil size={17} />} t="Ubah" onClick={props.onEdit} />}
      <HItem icon={<Pin size={17} />} t={msg.is_pinned ? 'Lepas sematan' : 'Sematkan'} onClick={props.onPin} />
      <HItem icon={<CheckCheck size={17} />} t="Pilih" onClick={props.onSelect} />
      {props.mine && <HItem icon={<Info size={17} />} t="Info pesan" onClick={props.onInfo} />}
      <span className="block h-px bg-slate-100 dark:bg-slate-700 my-1" />
      <HItem icon={<Trash2 size={17} />} t="Hapus untuk saya" danger onClick={props.onDeleteMe} />
      {props.mine && <HItem icon={<Ban size={17} />} t="Hapus untuk semua" danger onClick={props.onDeleteAll} />}
    </div>
  );
}

function MsgInfoModal({ msg, chat, myId, namesOf, onClose }: {
  msg: Message; chat: Chat; myId: string; namesOf: (u: string) => string; onClose: () => void;
}) {
  const [rows, setRows] = useState<Receipt[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    apiGet<Receipt[]>(`/api/receipts?message_ids=${msg.id}`)
      .then(setRows)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [msg.id]);
  const others = chat.members.filter((m) => m.user_id !== myId);
  return (
    <div className="fixed inset-0 z-[80] bg-black/60 flex items-end sm:items-center justify-center sm:p-4" onClick={onClose}>
      <div className="w-full sm:max-w-sm bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl p-5 fa-animate-fade-up" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <p className="font-extrabold">Info pesan</p>
          <button onClick={onClose} className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800"><X size={18} /></button>
        </div>
        <div className="bg-teal-50 dark:bg-slate-800 rounded-2xl p-3 text-sm mb-4 max-h-28 overflow-y-auto">
          {previewFor(msg)}
          <span className="block text-[11px] text-slate-400 mt-1">{fmtClock(msg.created_at)} • {msg.kind}</span>
        </div>
        {loading ? (
          <p className="text-sm text-slate-400 text-center py-4">Memuat…</p>
        ) : (
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {others.map((m) => {
              const r = rows.find((x) => x.user_id === m.user_id);
              return (
                <div key={m.user_id} className="flex items-center gap-3">
                  <Avatar name={namesOf(m.user_id)} src={m.user?.avatar_url || ''} size={38} />
                  <span className="flex-1 font-semibold text-sm truncate">{namesOf(m.user_id)}</span>
                  {r ? (
                    <span className="flex items-center gap-1.5 text-xs text-slate-500">
                      {r.status === 'read' ? 'Dibaca' : r.status === 'delivered' ? 'Diterima' : 'Terkirim'} • {fmtClock(r.updated_at)}
                      <Tick status={r.status} size={17} />
                    </span>
                  ) : (
                    <span className="flex items-center gap-1.5 text-xs text-slate-400">Terkirim <Tick status="sent" size={17} /></span>
                  )}
                </div>
              );
            })}
            {others.length === 0 && <p className="text-sm text-slate-400 text-center">Hanya Anda di chat ini.</p>}
          </div>
        )}
      </div>
    </div>
  );
}

export { ShieldAlert, Square, Pause };
