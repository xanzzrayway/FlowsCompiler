import { createContext, useContext, useState, useCallback } from 'react';
import type { ReactNode } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

interface Toast { id: number; text: string; kind: 'success' | 'error' | 'info'; }

const Ctx = createContext<(text: string, kind?: Toast['kind']) => void>(() => {});

export const useToast = () => useContext(Ctx);

let seq = 1;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);

  const push = useCallback((text: string, kind: Toast['kind'] = 'info') => {
    const id = seq++;
    setItems((p) => [...p.slice(-3), { id, text, kind }]);
    window.setTimeout(() => setItems((p) => p.filter((t) => t.id !== id)), 3400);
  }, []);

  return (
    <Ctx.Provider value={push}>
      {children}
      <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[120] flex flex-col items-center gap-2 pointer-events-none px-4 w-full max-w-md">
        <AnimatePresence>
          {items.map((t) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: -14, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.96 }}
              className={`pointer-events-auto flex items-center gap-2.5 pl-3 pr-2 py-2 rounded-2xl shadow-xl border text-sm font-medium backdrop-blur-xl ${
                t.kind === 'success'
                  ? 'bg-emerald-600/95 border-emerald-500 text-white'
                  : t.kind === 'error'
                    ? 'bg-rose-600/95 border-rose-500 text-white'
                    : 'bg-slate-800/95 border-slate-700 text-white'
              }`}
            >
              {t.kind === 'success' ? <CheckCircle2 size={18} /> : t.kind === 'error' ? <AlertCircle size={18} /> : <Info size={18} />}
              <span className="flex-1">{t.text}</span>
              <button
                onClick={() => setItems((p) => p.filter((x) => x.id !== t.id))}
                className="p-1 rounded-lg hover:bg-white/20"
                aria-label="Tutup"
              >
                <X size={15} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </Ctx.Provider>
  );
}
