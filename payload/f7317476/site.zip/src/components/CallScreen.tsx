import { useEffect, useRef, useState } from 'react';
import { PhoneOff, Mic, MicOff, Video, VideoOff, Volume2, User as UserIcon, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import supabase from '../lib/supabase';
import Avatar from './Avatar';
import { apiGet, apiPost, apiPut, fmtDuration, startRing, type CallRow, type Signal, type UserProfile } from '../lib/api';

interface Props {
  call: CallRow;
  me: UserProfile;
  peer: UserProfile | null;
  role: 'caller' | 'callee';
  onEnd: () => void;
}

const ICE = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:global.stun.twilio.com:3478' }] };

/** Layar panggilan WebRTC 1-on-1 dengan signaling via Supabase. */
export default function CallScreen({ call, me, peer, role, onEnd }: Props) {
  const [status, setStatus] = useState<'ringing' | 'ongoing' | 'ended'>(call.status === 'ongoing' ? 'ongoing' : 'ringing');
  const [muted, setMuted] = useState(false);
  const [camOff, setCamOff] = useState(false);
  const [speaker] = useState(true);
  const [sec, setSec] = useState(0);
  const [err, setErr] = useState('');
  const [remoteOn, setRemoteOn] = useState(false);
  const pc = useRef<RTCPeerConnection | null>(null);
  const localStream = useRef<MediaStream | null>(null);
  const localVideo = useRef<HTMLVideoElement>(null);
  const remoteVideo = useRef<HTMLVideoElement>(null);
  const remoteAudio = useRef<HTMLAudioElement>(null);
  const seenSignals = useRef(0);
  const stopRing = useRef<(() => void) | null>(null);
  const ended = useRef(false);
  const isVideo = call.call_type === 'video';

  const peerId = role === 'caller' ? call.callee_id : call.caller_id;

  // ------- cleanup -------
  const cleanup = () => {
    try { stopRing.current?.(); } catch { /* noop */ }
    stopRing.current = null;
    try { pc.current?.close(); } catch { /* noop */ }
    pc.current = null;
    try { localStream.current?.getTracks().forEach((t) => t.stop()); } catch { /* noop */ }
    localStream.current = null;
  };

  const finish = async (finalStatus: string) => {
    if (ended.current) return;
    ended.current = true;
    cleanup();
    try { await apiPut('/api/calls', { id: call.id, status: finalStatus }); } catch { /* abaikan */ }
    try { await fetch(`/api/signals?call_id=${call.id}`, { method: 'DELETE' }); } catch { /* abaikan */ }
    setStatus('ended');
    onEnd();
  };

  // ------- peer connection -------
  const ensurePC = async () => {
    if (pc.current) return pc.current;
    const c = new RTCPeerConnection(ICE);
    pc.current = c;

    // media lokal
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: isVideo });
      localStream.current = stream;
      stream.getTracks().forEach((t) => c.addTrack(t, stream));
      if (localVideo.current && isVideo) {
        localVideo.current.srcObject = stream;
      }
    } catch (e) {
      console.error('getUserMedia:', e);
      setErr('Tidak dapat mengakses kamera/mikrofon. Periksa izin perangkat lalu coba lagi.');
      throw e;
    }

    c.ontrack = (ev) => {
      setRemoteOn(true);
      const [stream] = ev.streams;
      if (isVideo && remoteVideo.current) remoteVideo.current.srcObject = stream;
      if (remoteAudio.current) {
        remoteAudio.current.srcObject = stream;
        void remoteAudio.current.play().catch(() => {});
      }
    };
    c.onicecandidate = (ev) => {
      if (ev.candidate) {
        void apiPost('/api/signals', {
          call_id: call.id, from_id: me.id, to_id: peerId, kind: 'ice', payload: ev.candidate.toJSON(),
        }).catch(() => {});
      }
    };
    c.onconnectionstatechange = () => {
      if (['disconnected', 'failed', 'closed'].includes(c.connectionState)) {
        setRemoteOn(false);
      }
    };
    return c;
  };

  const sendSignal = (kind: string, payload: Record<string, unknown>) =>
    apiPost('/api/signals', { call_id: call.id, from_id: me.id, to_id: peerId, kind, payload });

  // ------- caller: buat offer -------
  const startCaller = async () => {
    try {
      const c = await ensurePC();
      const offer = await c.createOffer();
      await c.setLocalDescription(offer);
      await sendSignal('offer', { sdp: offer.sdp, type: offer.type });
    } catch {
      setErr('Gagal memulai panggilan. Periksa izin kamera/mikrofon.');
    }
  };

  // ------- callee: jawab -------
  const accept = async () => {
    try { stopRing.current?.(); } catch { /* noop */ }
    stopRing.current = null;
    try {
      await ensurePC();
      await apiPut('/api/calls', { id: call.id, status: 'ongoing' });
      setStatus('ongoing');
    } catch {
      setErr('Gagal menjawab. Periksa izin kamera/mikrofon.');
    }
  };

  // ------- dengarkan sinyal (realtime + polling) -------
  useEffect(() => {
    let timer: number;
    const handle = async (s: Signal) => {
      if (s.from_id === me.id) return;
      try {
        const c = pc.current || (role === 'callee' && s.kind === 'offer' ? await ensurePC() : pc.current);
        if (!c) return;
        if (s.kind === 'offer' && role === 'callee') {
          const p = s.payload as { sdp?: string; type?: RTCSdpType };
          if (!p.sdp) return;
          await c.setRemoteDescription(new RTCSessionDescription({ sdp: p.sdp, type: p.type || 'offer' }));
          // jawaban dibuat setelah user menekan terima — simpan penanda
          c.onnegotiationneeded = null;
          (c as unknown as { _needAnswer?: boolean })._needAnswer = true;
          if (status === 'ongoing') {
            const answer = await c.createAnswer();
            await c.setLocalDescription(answer);
            await sendSignal('answer', { sdp: answer.sdp, type: answer.type });
          }
        } else if (s.kind === 'answer' && role === 'caller') {
          const p = s.payload as { sdp?: string; type?: RTCSdpType };
          if (!p.sdp) return;
          if (!c.currentRemoteDescription) {
            await c.setRemoteDescription(new RTCSessionDescription({ sdp: p.sdp, type: p.type || 'answer' }));
            setStatus('ongoing');
          }
        } else if (s.kind === 'ice') {
          try { await c.addIceCandidate(new RTCIceCandidate(s.payload as RTCIceCandidateInit)); } catch { /* abaikan */ }
        } else if (s.kind === 'hangup') {
          void finish('ended');
        } else if (s.kind === 'reject') {
          void finish(role === 'caller' ? 'rejected' : 'ended');
        }
      } catch (e) {
        console.error('signal handle:', e);
      }
    };

    // saat callee menekan terima setelah offer datang
    const answerIfNeeded = async () => {
      const c = pc.current as unknown as { _needAnswer?: boolean } | null;
      if (role === 'callee' && status === 'ongoing' && c?._needAnswer && pc.current?.remoteDescription && !pc.current?.localDescription) {
        try {
          const answer = await pc.current.createAnswer();
          await pc.current.setLocalDescription(answer);
          await sendSignal('answer', { sdp: answer.sdp, type: answer.type });
          c._needAnswer = false;
        } catch (e) { console.error('answer:', e); }
      }
    };
    void answerIfNeeded();

    const poll = async () => {
      try {
        const rows = await apiGet<Signal[]>(`/api/signals?call_id=${call.id}&after_id=${seenSignals.current}`);
        for (const s of rows) {
          seenSignals.current = Math.max(seenSignals.current, s.id);
          await handle(s);
        }
        // cek status panggilan dari sisi lawan
        const cur = await apiGet<CallRow | null>(`/api/calls?id=${call.id}`);
        if (!cur || ['ended', 'rejected', 'missed', 'cancelled'].includes(cur.status)) {
          if (!ended.current) { cleanup(); setStatus('ended'); onEnd(); }
          return;
        }
        if (cur.status === 'ongoing' && role === 'caller') setStatus('ongoing');
      } catch { /* abaikan */ }
    };

    const ch = supabase.channel(`call-${call.id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'call_signals', filter: `call_id=eq.${call.id}` }, (pl) => {
        const s = pl.new as Signal;
        if (s.id > seenSignals.current) {
          seenSignals.current = s.id;
          void handle(s);
        }
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'calls', filter: `id=eq.${call.id}` }, (pl) => {
        const c = pl.new as CallRow;
        if (['ended', 'rejected', 'missed', 'cancelled'].includes(c.status)) {
          if (!ended.current) { cleanup(); setStatus('ended'); onEnd(); }
        } else if (c.status === 'ongoing') {
          setStatus('ongoing');
          void answerIfNeeded();
        }
      })
      .subscribe();

    timer = window.setInterval(poll, 1500);
    void poll();
    return () => {
      window.clearInterval(timer);
      void supabase.removeChannel(ch);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [call.id, status]);

  // ------- init -------
  useEffect(() => {
    if (role === 'caller') {
      stopRing.current = startRing();
      // hentikan nada setelah 45 detik / tak dijawab
      const t = window.setTimeout(() => {
        if (!ended.current && status === 'ringing') {
          void (async () => {
            try { await sendSignal('hangup', {}); } catch { /* noop */ }
            await finish('missed');
          })();
        }
      }, 45000);
      void startCaller();
      return () => window.clearTimeout(t);
    } else if (status === 'ringing') {
      stopRing.current = startRing();
    }
    return () => { try { stopRing.current?.(); } catch { /* noop */ } };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ------- timer -------
  useEffect(() => {
    if (status !== 'ongoing') return;
    try { stopRing.current?.(); } catch { /* noop */ }
    stopRing.current = null;
    const t = window.setInterval(() => setSec((s) => s + 1), 1000);
    return () => window.clearInterval(t);
  }, [status]);

  useEffect(() => () => cleanup(), []); // eslint-disable-line react-hooks/exhaustive-deps

  const toggleMute = () => {
    const on = !muted;
    setMuted(on);
    localStream.current?.getAudioTracks().forEach((t) => { t.enabled = !on; });
  };
  const toggleCam = () => {
    const off = !camOff;
    setCamOff(off);
    localStream.current?.getVideoTracks().forEach((t) => { t.enabled = !off; });
  };

  const reject = async () => {
    try { await sendSignal('reject', {}); } catch { /* noop */ }
    await finish(role === 'callee' ? 'rejected' : 'cancelled');
  };
  const hangup = async () => {
    try { await sendSignal('hangup', {}); } catch { /* noop */ }
    await finish('ended');
  };

  const endOrReject = () => {
    if (status === 'ringing') void reject();
    else void hangup();
  };

  const label = status === 'ongoing' ? fmtDuration(sec) : status === 'ringing' ? (role === 'caller' ? 'Berdering…' : 'Panggilan masuk…') : 'Berakhir';

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 z-[100] bg-gradient-to-b from-slate-900 via-slate-900 to-teal-950 text-white flex flex-col overflow-hidden">
      {/* remote video */}
      {isVideo && (
        <video ref={remoteVideo} autoPlay playsInline className={`absolute inset-0 w-full h-full object-cover ${remoteOn ? '' : 'hidden'}`} />
      )}
      {isVideo && !remoteOn && <div className="absolute inset-0 bg-gradient-to-b from-slate-900 to-teal-950" />}
      {isVideo && remoteOn && <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/40 pointer-events-none" />}
      <audio ref={remoteAudio} autoPlay playsInline className="hidden" />

      {/* local preview */}
      {isVideo && (
        <div className="absolute top-4 right-4 w-28 h-40 sm:w-36 sm:h-52 rounded-2xl overflow-hidden border-2 border-white/30 shadow-2xl bg-slate-800 z-10">
          {camOff ? (
            <div className="w-full h-full flex items-center justify-center"><VideoOff size={26} className="text-slate-500" /></div>
          ) : (
            <video ref={localVideo} autoPlay playsInline muted className="w-full h-full object-cover mirror" style={{ transform: 'scaleX(-1)' }} />
          )}
        </div>
      )}

      <div className="relative flex-1 flex flex-col items-center justify-center gap-3 px-6 text-center">
        {(!isVideo || !remoteOn) && (
          <>
            <motion.div
              animate={status === 'ringing' ? { scale: [1, 1.06, 1] } : {}}
              transition={{ repeat: status === 'ringing' ? Infinity : 0, duration: 1.4 }}
              className={status === 'ringing' ? 'ring-pulse rounded-full' : ''}
            >
              <Avatar name={peer?.name || '?'} src={peer?.avatar_url || ''} size={110} className="border-4 border-white/25 shadow-2xl" />
            </motion.div>
            <h2 className="text-2xl font-extrabold mt-2">{peer?.name || 'Pengguna FastApp'}</h2>
            <p className="text-teal-200 font-semibold flex items-center gap-2">
              {status === 'ongoing' ? <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> : null}
              {label}
            </p>
            <p className="text-white/60 text-sm flex items-center gap-1.5">
              {isVideo ? <Video size={15} /> : <Volume2 size={15} />}
              FastApp {isVideo ? 'Video' : 'Suara'} • {role === 'caller' ? 'Panggilan keluar' : 'Panggilan masuk'}
            </p>
          </>
        )}
        {isVideo && remoteOn && (
          <div className="absolute top-4 left-4 bg-black/50 backdrop-blur px-3 py-1.5 rounded-full text-sm font-bold">
            {peer?.name} • {fmtDuration(sec)}
          </div>
        )}
        {err && (
          <div className="max-w-sm bg-rose-600/90 rounded-2xl px-4 py-3 text-sm font-semibold">{err}</div>
        )}
        {status === 'ongoing' && !remoteOn && !err && (
          <p className="text-white/60 text-sm flex items-center gap-2"><Loader2 size={15} className="animate-spin" /> Menghubungkan media…</p>
        )}
      </div>

      {/* controls */}
      <div className="relative pb-10 pt-4 px-6">
        {role === 'callee' && status === 'ringing' ? (
          <div className="flex items-center justify-center gap-10">
            <span className="flex flex-col items-center gap-2">
              <button onClick={() => void reject()} className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-500 flex items-center justify-center shadow-xl active:scale-95 transition" aria-label="Tolak">
                <PhoneOff size={28} />
              </button>
              <span className="text-xs font-bold text-white/70">Tolak</span>
            </span>
            <span className="flex flex-col items-center gap-2">
              <button onClick={() => void accept()} className="w-16 h-16 rounded-full bg-emerald-500 hover:bg-emerald-400 flex items-center justify-center shadow-xl active:scale-95 transition ring-pulse" aria-label="Terima">
                {isVideo ? <Video size={28} /> : <UserIcon size={28} />}
              </button>
              <span className="text-xs font-bold text-white/70">Terima</span>
            </span>
          </div>
        ) : (
          <div className="flex items-center justify-center gap-5">
            <CtlBtn onClick={toggleMute} active={!muted} label={muted ? 'Nyalakan mic' : 'Bisukan'}>
              {muted ? <MicOff size={22} /> : <Mic size={22} />}
            </CtlBtn>
            {isVideo && (
              <CtlBtn onClick={toggleCam} active={!camOff} label={camOff ? 'Nyalakan kamera' : 'Matikan kamera'}>
                {camOff ? <VideoOff size={22} /> : <Video size={22} />}
              </CtlBtn>
            )}
            <button onClick={endOrReject} className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-500 flex items-center justify-center shadow-xl active:scale-95 transition" aria-label="Akhiri">
              <PhoneOff size={28} />
            </button>
            <CtlBtn onClick={() => {}} active={speaker} label="Speaker">
              <Volume2 size={22} />
            </CtlBtn>
            {isVideo ? <span className="w-[52px]" /> : null}
          </div>
        )}
        {status === 'ongoing' && <p className="text-center text-white/60 text-sm font-bold mt-4 tabular-nums">{fmtDuration(sec)}</p>}
      </div>
    </motion.div>
  );
}

function CtlBtn({ children, onClick, active, label }: { children: React.ReactNode; onClick: () => void; active: boolean; label: string }) {
  return (
    <span className="flex flex-col items-center gap-1.5">
      <button
        onClick={onClick}
        title={label}
        className={`w-[52px] h-[52px] rounded-full flex items-center justify-center shadow-lg active:scale-95 transition ${active ? 'bg-white/15 hover:bg-white/25' : 'bg-white text-slate-900'}`}
      >
        {children}
      </button>
      <span className="text-[10px] font-bold text-white/60 w-16 text-center">{label}</span>
    </span>
  );
}

/** Kartu panggilan masuk (saat user sedang di aplikasi) */
export function IncomingBanner({ peer, callType, onAccept, onReject }: {
  peer: UserProfile | null; callType: 'voice' | 'video'; onAccept: () => void; onReject: () => void;
}) {
  useEffect(() => {
    const stop = startRing();
    return () => stop();
  }, []);
  return (
    <motion.div
      initial={{ y: -90, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed top-3 left-1/2 -translate-x-1/2 z-[95] w-[calc(100%-1.5rem)] max-w-md bg-slate-900 text-white rounded-3xl shadow-2xl border border-white/10 p-4 flex items-center gap-3"
    >
      <span className="ring-pulse rounded-full shrink-0">
        <Avatar name={peer?.name || '?'} src={peer?.avatar_url || ''} size={52} />
      </span>
      <span className="flex-1 min-w-0">
        <span className="block font-extrabold truncate">{peer?.name || 'Penelepon'}</span>
        <span className="text-xs text-teal-300 font-semibold">Panggilan {callType === 'video' ? 'video' : 'suara'} masuk…</span>
      </span>
      <button onClick={onReject} className="w-12 h-12 rounded-full bg-rose-600 hover:bg-rose-500 flex items-center justify-center shrink-0" aria-label="Tolak">
        <PhoneOff size={22} />
      </button>
      <button onClick={onAccept} className="w-12 h-12 rounded-full bg-emerald-500 hover:bg-emerald-400 flex items-center justify-center shrink-0" aria-label="Terima">
        {callType === 'video' ? <Video size={22} /> : <Mic size={22} />}
      </button>
    </motion.div>
  );
}

export { Loader2 };
