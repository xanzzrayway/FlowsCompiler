import { useEffect, useState } from 'react';
import { X, Search, Users, Check, Loader2, UserPlus, Phone } from 'lucide-react';
import Avatar from './Avatar';
import { useToast } from './Toast';
import { apiGet, apiPost, type UserProfile } from '../lib/api';

interface Props {
  myId: string;
  onClose: () => void;
  onChatCreated: (chatId: number) => void;
}

/** Cari pengguna & mulai chat 1-on-1 */
export function NewChatModal({ myId, onClose, onChatCreated }: Props) {
  const toast = useToast();
  const [q, setQ] = useState('');
  const [rows, setRows] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);

  useEffect(() => {
    const t = window.setTimeout(async () => {
      setLoading(true);
      try {
        const data = await apiGet<UserProfile[]>(q.trim() ? `/api/users?q=${encodeURIComponent(q.trim())}` : '/api/users');
        setRows(data.filter((u) => u.id !== myId).slice(0, 30));
      } catch {
        toast('Gagal memuat pengguna', 'error');
      } finally {
        setLoading(false);
      }
    }, q.trim() ? 350 : 0);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  const start = async (u: UserProfile) => {
    setBusyId(u.id);
    try {
      const chat = await apiPost<{ id: number; existed?: boolean }>('/api/chats', {
        type: 'direct', created_by: myId, member_ids: [myId, u.id],
      });
      toast(chat.existed ? `Membuka chat dengan ${u.name}` : `Chat dengan ${u.name} dibuat ✨`, 'success');
      onChatCreated(chat.id);
      onClose();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Gagal membuat chat', 'error');
    } finally {
      setBusyId(null);
    }
  };

  return (
    <Sheet title="Chat baru" sub="Cari teman lalu mulai ngobrol" onClose={onClose}>
      <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 rounded-2xl px-3.5 py-2.5 mb-3">
        <Search size={18} className="text-slate-400 shrink-0" />
        <input
          autoFocus
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Cari nama, username, email, nomor…"
          className="flex-1 bg-transparent outline-none text-[15px] min-w-0 placeholder:text-slate-400"
        />
      </div>
      <div className="overflow-y-auto -mx-2 px-2 pb-2 min-h-[200px]">
        {loading ? (
          <div className="py-10 text-center text-slate-400 text-sm flex items-center justify-center gap-2">
            <Loader2 size={17} className="animate-spin" /> Mencari…
          </div>
        ) : rows.length === 0 ? (
          <div className="py-10 text-center">
            <p className="font-bold">Tidak ada hasil</p>
            <p className="text-sm text-slate-400 mt-1">
              {q ? `Tidak ada pengguna cocok "${q}".` : 'Belum ada pengguna lain. Ajak temanmu daftar FastApp! 🎉'}
            </p>
          </div>
        ) : (
          rows.map((u) => (
            <button
              key={u.id}
              onClick={() => void start(u)}
              disabled={busyId === u.id}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 text-left transition disabled:opacity-60"
            >
              <Avatar name={u.name} src={u.avatar_url} size={46} online={u.is_online} />
              <span className="flex-1 min-w-0">
                <span className="font-bold block truncate">{u.name}</span>
                <span className="text-[13px] text-slate-500 dark:text-slate-400 truncate block">
                  @{u.username}{u.phone ? ` • ${u.phone}` : ''}{u.is_online ? ' • Online' : ''}
                </span>
                {u.bio && <span className="text-xs text-slate-400 truncate block">{u.bio}</span>}
              </span>
              {busyId === u.id ? <Loader2 size={19} className="animate-spin text-teal-600" /> : <UserPlus size={19} className="text-teal-600" />}
            </button>
          ))
        )}
      </div>
    </Sheet>
  );
}

export function NewGroupModal({ myId, onClose, onChatCreated }: Props) {
  const toast = useToast();
  const [step, setStep] = useState(1);
  const [q, setQ] = useState('');
  const [rows, setRows] = useState<UserProfile[]>([]);
  const [picked, setPicked] = useState<UserProfile[]>([]);
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const t = window.setTimeout(async () => {
      try {
        const data = await apiGet<UserProfile[]>(q.trim() ? `/api/users?q=${encodeURIComponent(q.trim())}` : '/api/users');
        setRows(data.filter((u) => u.id !== myId).slice(0, 40));
      } catch { /* abaikan */ }
    }, q.trim() ? 350 : 0);
    return () => window.clearTimeout(t);
  }, [q, myId]);

  const toggle = (u: UserProfile) => {
    setPicked((p) => (p.some((x) => x.id === u.id) ? p.filter((x) => x.id !== u.id) : [...p, u]));
  };

  const create = async () => {
    if (!name.trim()) { toast('Beri nama grup dulu ya', 'error'); return; }
    if (!picked.length) { toast('Pilih minimal 1 anggota', 'error'); return; }
    setBusy(true);
    try {
      const chat = await apiPost<{ id: number }>('/api/chats', {
        type: 'group',
        created_by: myId,
        member_ids: [myId, ...picked.map((x) => x.id)],
        name: name.trim(),
        description: desc.trim(),
      });
      await apiPost('/api/messages', {
        chat_id: chat.id, sender_id: myId, kind: 'system',
        body: `🎉 Grup "${name.trim()}" dibuat`,
      }).catch(() => null);
      toast(`Grup "${name.trim()}" dibuat! 🎉`, 'success');
      onChatCreated(chat.id);
      onClose();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Gagal membuat grup', 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={step === 1 ? 'Grup baru' : 'Detail grup'} sub={step === 1 ? 'Pilih anggota grup' : `${picked.length} anggota dipilih`} onClose={onClose}>
      {step === 1 ? (
        <>
          {picked.length > 0 && (
            <div className="flex gap-2 overflow-x-auto pb-2 mb-1">
              {picked.map((u) => (
                <button key={u.id} onClick={() => toggle(u)} className="flex flex-col items-center gap-0.5 shrink-0 group" title="Hapus">
                  <span className="relative">
                    <Avatar name={u.name} src={u.avatar_url} size={46} />
                    <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-rose-500 text-white flex items-center justify-center"><X size={12} /></span>
                  </span>
                  <span className="text-[10px] font-bold max-w-[52px] truncate">{u.name.split(' ')[0]}</span>
                </button>
              ))}
            </div>
          )}
          <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 rounded-2xl px-3.5 py-2.5 mb-3">
            <Search size={18} className="text-slate-400 shrink-0" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari anggota…" className="flex-1 bg-transparent outline-none text-[15px] min-w-0 placeholder:text-slate-400" />
          </div>
          <div className="overflow-y-auto -mx-2 px-2 pb-2 max-h-[38vh]">
            {rows.map((u) => {
              const on = picked.some((x) => x.id === u.id);
              return (
                <button key={u.id} onClick={() => toggle(u)} className="w-full flex items-center gap-3 px-3 py-2 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 text-left">
                  <Avatar name={u.name} src={u.avatar_url} size={42} />
                  <span className="flex-1 min-w-0">
                    <span className="font-bold block truncate text-[15px]">{u.name}</span>
                    <span className="text-xs text-slate-500 truncate block">@{u.username}</span>
                  </span>
                  <span className={`w-6 h-6 rounded-full flex items-center justify-center transition ${on ? 'bg-teal-600 text-white' : 'border-2 border-slate-300 dark:border-slate-600'}`}>
                    {on && <Check size={15} strokeWidth={3} />}
                  </span>
                </button>
              );
            })}
            {rows.length === 0 && <p className="text-center text-sm text-slate-400 py-8">Tidak ada pengguna ditemukan.</p>}
          </div>
          <button
            onClick={() => (picked.length ? setStep(2) : toast('Pilih minimal 1 anggota dulu', 'error'))}
            className="w-full mt-3 py-3 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white font-extrabold transition"
          >
            Lanjut ({picked.length})
          </button>
        </>
      ) : (
        <>
          <div className="flex items-center gap-4 mb-4">
            <span className="w-16 h-16 rounded-full bg-gradient-to-br from-teal-500 to-emerald-600 flex items-center justify-center text-white shrink-0">
              <Users size={28} />
            </span>
            <div className="text-sm text-slate-500 dark:text-slate-400">
              Foto grup bisa diganti nanti lewat <b>Info grup</b>.
            </div>
          </div>
          <label className="block mb-3">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">Nama grup *</span>
            <input
              value={name} onChange={(e) => setName(e.target.value.slice(0, 60))}
              placeholder="cth: Keluarga Cemara 🌳"
              className="mt-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-2xl px-4 py-3 text-[15px] outline-none focus:ring-2 focus:ring-teal-500"
            />
          </label>
          <label className="block mb-4">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">Deskripsi (opsional)</span>
            <textarea
              value={desc} onChange={(e) => setDesc(e.target.value.slice(0, 200))}
              placeholder="Tentang grup ini…"
              rows={2}
              className="mt-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-2xl px-4 py-3 text-[15px] outline-none focus:ring-2 focus:ring-teal-500 resize-none"
            />
          </label>
          <div className="flex gap-2">
            <button onClick={() => setStep(1)} className="flex-1 py-3 rounded-2xl border border-slate-300 dark:border-slate-700 font-bold">Kembali</button>
            <button onClick={() => void create()} disabled={busy} className="flex-[2] py-3 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white font-extrabold disabled:opacity-60 flex items-center justify-center gap-2">
              {busy && <Loader2 size={17} className="animate-spin" />} Buat Grup 🎉
            </button>
          </div>
        </>
      )}
    </Sheet>
  );
}

export function AddMembersModal({ chatId, myId, existingIds, onClose, onChanged }: {
  chatId: number; myId: string; existingIds: string[]; onClose: () => void; onChanged: () => void;
}) {
  const toast = useToast();
  const [q, setQ] = useState('');
  const [rows, setRows] = useState<UserProfile[]>([]);
  const [picked, setPicked] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const t = window.setTimeout(async () => {
      try {
        const data = await apiGet<UserProfile[]>(q.trim() ? `/api/users?q=${encodeURIComponent(q.trim())}` : '/api/users');
        setRows(data.filter((u) => u.id !== myId && !existingIds.includes(u.id)).slice(0, 40));
      } catch { /* abaikan */ }
    }, q.trim() ? 350 : 0);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  const toggle = (id: string) => {
    setPicked((p) => { const n = new Set(p); if (n.has(id)) n.delete(id); else n.add(id); return n; });
  };

  const add = async () => {
    if (!picked.size) { toast('Pilih anggota dulu', 'error'); return; }
    setBusy(true);
    try {
      for (const uid of picked) {
        await apiPost('/api/members', { chat_id: chatId, user_id: uid, role: 'member' });
      }
      toast(`${picked.size} anggota ditambahkan ✓`, 'success');
      onChanged();
      onClose();
    } catch { toast('Gagal menambahkan anggota', 'error'); }
    finally { setBusy(false); }
  };

  return (
    <Sheet title="Tambah anggota" sub="Pilih pengguna untuk dimasukkan ke grup" onClose={onClose}>
      <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 rounded-2xl px-3.5 py-2.5 mb-3">
        <Search size={18} className="text-slate-400 shrink-0" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari pengguna…" className="flex-1 bg-transparent outline-none text-[15px] min-w-0 placeholder:text-slate-400" />
      </div>
      <div className="overflow-y-auto -mx-2 px-2 pb-2 max-h-[40vh]">
        {rows.map((u) => {
          const on = picked.has(u.id);
          return (
            <button key={u.id} onClick={() => toggle(u.id)} className="w-full flex items-center gap-3 px-3 py-2 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 text-left">
              <Avatar name={u.name} src={u.avatar_url} size={42} />
              <span className="flex-1 min-w-0">
                <span className="font-bold block truncate text-[15px]">{u.name}</span>
                <span className="text-xs text-slate-500 truncate flex items-center gap-1">@{u.username}{u.phone ? <><Phone size={10} /> {u.phone}</> : ''}</span>
              </span>
              <span className={`w-6 h-6 rounded-full flex items-center justify-center transition ${on ? 'bg-teal-600 text-white' : 'border-2 border-slate-300 dark:border-slate-600'}`}>
                {on && <Check size={15} strokeWidth={3} />}
              </span>
            </button>
          );
        })}
        {rows.length === 0 && <p className="text-center text-sm text-slate-400 py-8">Semua pengguna sudah jadi anggota / tidak ditemukan.</p>}
      </div>
      <button onClick={() => void add()} disabled={busy} className="w-full mt-3 py-3 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white font-extrabold disabled:opacity-60 flex items-center justify-center gap-2">
        {busy && <Loader2 size={17} className="animate-spin" />} Tambahkan ({picked.size})
      </button>
    </Sheet>
  );
}

function Sheet({ title, sub, onClose, children }: { title: string; sub: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-[80] bg-black/60 flex items-end sm:items-center justify-center sm:p-4" onClick={onClose}>
      <div className="w-full sm:max-w-md bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl max-h-[85vh] flex flex-col fa-animate-fade-up" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-200 dark:border-slate-800">
          <button onClick={onClose} className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800"><X size={20} /></button>
          <div>
            <p className="font-extrabold">{title}</p>
            <p className="text-xs text-slate-500">{sub}</p>
          </div>
        </div>
        <div className="p-4 overflow-hidden flex flex-col">{children}</div>
      </div>
    </div>
  );
}
