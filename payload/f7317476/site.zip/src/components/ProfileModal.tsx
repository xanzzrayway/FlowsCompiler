import { useEffect, useState } from 'react';
import { X, Phone, Video, MessageCircle, Ban, Flag, AtSign, Info, Clock } from 'lucide-react';
import Avatar from './Avatar';
import { ReportModal } from './ChatInfo';
import { useToast } from './Toast';
import { apiGet, apiPost, apiDelete, canSee, timeAgo, type UserProfile } from '../lib/api';

interface Props {
  userId: string;
  myId: string;
  onClose: () => void;
  onChat: (userId: string) => void;
  onCall: (type: 'voice' | 'video', userId: string) => void;
}

export default function ProfileModal({ userId, myId, onClose, onChat, onCall }: Props) {
  const toast = useToast();
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [blocked, setBlocked] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const isMe = userId === myId;

  useEffect(() => {
    apiGet<UserProfile | null>(`/api/users?id=${userId}`)
      .then(setUser)
      .catch(() => toast('Gagal memuat profil', 'error'))
      .finally(() => setLoading(false));
    if (!isMe) {
      apiGet<{ blocked: string[] }>(`/api/blocks?user_id=${myId}`)
        .then((r) => setBlocked(r.blocked.includes(userId)))
        .catch(() => {});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  const toggleBlock = async () => {
    try {
      if (blocked) {
        await apiDelete('/api/blocks', { blocker_id: myId, blocked_id: userId });
        setBlocked(false);
        toast('Blokir dibuka ✓', 'success');
      } else {
        if (!window.confirm(`Blokir ${user?.name}? Anda tidak akan menerima pesan/panggilan dari mereka.`)) return;
        await apiPost('/api/blocks', { blocker_id: myId, blocked_id: userId });
        setBlocked(true);
        toast('Pengguna diblokir', 'success');
      }
    } catch { toast('Gagal', 'error'); }
  };

  const showAvatar = user ? canSee(myId, user, 'avatar', true) : false;
  const showLast = user ? canSee(myId, user, 'last_seen', true) : false;

  return (
    <div className="fixed inset-0 z-[78] bg-black/60 flex items-end sm:items-center justify-center sm:p-4" onClick={onClose}>
      <div className="w-full sm:max-w-sm bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl overflow-hidden fa-animate-fade-up" onClick={(e) => e.stopPropagation()}>
        {loading || !user ? (
          <div className="p-10 text-center text-slate-400 text-sm">Memuat profil…</div>
        ) : (
          <>
            <div className="relative bg-gradient-to-br from-teal-600 to-emerald-600 pt-4 pb-16 px-5">
              <div className="flex justify-between items-center">
                <span className="text-white/80 text-sm font-bold">Profil</span>
                <button onClick={onClose} className="p-2 rounded-full bg-white/15 hover:bg-white/25 text-white"><X size={18} /></button>
              </div>
            </div>
            <div className="px-5 pb-5 -mt-12">
              <Avatar name={user.name} src={showAvatar ? user.avatar_url : ''} size={96} online={isMe ? undefined : user.is_online} className="border-4 border-white dark:border-slate-900 shadow-lg" />
              <h2 className="text-xl font-extrabold mt-2">{user.name}</h2>
              <p className="text-sm text-slate-500 flex items-center gap-1"><AtSign size={13} />{user.username}</p>
              <p className="text-sm text-slate-600 dark:text-slate-300 mt-2 flex items-start gap-1.5">
                <Info size={14} className="mt-0.5 shrink-0 text-slate-400" />
                {user.bio || 'Hai! Saya memakai FastApp ⚡'}
              </p>
              <p className="text-[13px] text-slate-400 mt-2 flex items-center gap-1.5">
                <Clock size={13} />
                {user.is_online ? 'Online 🟢' : showLast ? `Terakhir dilihat ${timeAgo(user.last_seen)}` : 'Terakhir dilihat disembunyikan 🔒'}
              </p>

              {!isMe && (
                <>
                  <div className="grid grid-cols-3 gap-2 mt-4">
                    <button onClick={() => { onChat(userId); onClose(); }} className="flex flex-col items-center gap-1 py-3 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs transition">
                      <MessageCircle size={20} /> Chat
                    </button>
                    <button onClick={() => { onCall('voice', userId); onClose(); }} className="flex flex-col items-center gap-1 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 font-bold text-xs transition">
                      <Phone size={20} className="text-teal-600" /> Telepon
                    </button>
                    <button onClick={() => { onCall('video', userId); onClose(); }} className="flex flex-col items-center gap-1 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 font-bold text-xs transition">
                      <Video size={20} className="text-teal-600" /> Video
                    </button>
                  </div>
                  <div className="flex gap-2 mt-2">
                    <button onClick={() => void toggleBlock()} className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-2xl font-bold text-[13px] transition ${blocked ? 'bg-teal-100 text-teal-700 dark:bg-teal-900/40 dark:text-teal-300' : 'bg-rose-50 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400'}`}>
                      <Ban size={15} /> {blocked ? 'Buka Blokir' : 'Blokir'}
                    </button>
                    <button onClick={() => setShowReport(true)} className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-2xl bg-amber-50 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400 font-bold text-[13px] transition">
                      <Flag size={15} /> Laporkan
                    </button>
                  </div>
                </>
              )}
            </div>
          </>
        )}
        {showReport && user && <ReportModal myId={myId} peer={user} onClose={() => setShowReport(false)} />}
      </div>
    </div>
  );
}
