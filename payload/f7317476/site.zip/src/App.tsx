import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ToastProvider } from './components/Toast';
import { handleGoogleRedirect } from './lib/googleAuth';
import AuthPage, { SplashScreen } from './pages/AuthPage';
import AppShell from './components/AppShell';

handleGoogleRedirect();

function Root() {
  const { authUser, loading } = useAuth();

  if (loading) return <SplashScreen />;
  if (!authUser) return <AuthPage />;
  return <AppShell />;
}

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <Root />
      </AuthProvider>
    </ToastProvider>
  );
}
