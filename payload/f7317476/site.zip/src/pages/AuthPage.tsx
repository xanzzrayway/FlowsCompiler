import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Lock, User as UserIcon, Phone, Eye, EyeOff, Loader2, Zap, MessageCircle, Users, PhoneCall, ShieldCheck, ChevronLeft } from 'lucide-react';
import supabase from '../lib/supabase';
import { signInWithGoogle } from '../lib/googleAuth';
import { apiGet, type UserProfile } from '../lib/api';
import Logo from '../components/Logo';
import { useToast } from '../components/Toast';

type Mode = 'login' | 'register' | 'forgot' | 'verify' | 'recovery';

const looksLikePhone = (v: string) => /^[+]?[\d\s().-]{9,16}$/.test(v.trim());

function prettyAuthError(msg: string): string {
  const m = (msg || '').toLowerCase();
  if (m.includes('invalid login credentials') || m.includes('invalid-login')) return 'Email/nomor atau kata sandi salah. Periksa kembali lalu coba lagi.';
  if (m.includes('email not confirmed') || m.includes('not confirmed')) return 'Email belum diverifikasi. Buka kotak masuk email Anda lalu klik tautan verifikasi.';
  if (m.includes('user already registered') || m.includes('already registered')) return 'Akun dengan email ini sudah terdaftar. Silakan masuk.';
  if (m.includes('password')) {
    if (m.includes('6')) return 'Kata sandi minimal 6 karakter.';
    if (m.includes('weak') || m.includes('short')) return 'Kata sandi terlalu lemah. Gunakan minimal 6 karakter.';
  }
  if (m.includes('invalid email')) return 'Format email tidak valid.';
  if (m.includes('rate limit') || m.includes('too many')) return 'Terlalu banyak percobaan. Tunggu sebentar lalu coba lagi.';
  if (m.includes('network') || m.includes('fetch')) return 'Tidak dapat terhubung. Periksa koneksi internet Anda.';
  return msg || 'Terjadi kesalahan. Silakan coba lagi.';
}

export default function AuthPage() {
  const toast = useToast();
  const [mode, setMode] = useState<Mode>(() => {
    const p = new URLSearchParams(window.location.search);
    return p.get('mode') === 'recovery' ? 'recovery' : 'login';
  });
  const [identifier, setIdentifier] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [info, setInfo] = useState('');
  const [pendingEmail, setPendingEmail] = useState('');

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((ev) => {
      if (ev === 'PASSWORD_RECOVERY') setMode('recovery');
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const switchMode = (m: Mode) => {
    setMode(m); setErr(''); setInfo('');
  };

  /** Login dengan email ATAU nomor telepon + password */
  const doLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(''); setInfo('');
    const id = identifier.trim();
    if (!id) return setErr('Masukkan email atau nomor telepon Anda.');
    if (!password) return setErr('Masukkan kata sandi Anda.');
    setBusy(true);
    try {
      let loginEmail = id;
      if (looksLikePhone(id) && !id.includes('@')) {
        // cari email akun dari nomor telepon
        const rows = await apiGet<UserProfile[]>(`/api/users?q=${encodeURIComponent(id)}`);
        const match = rows.find((r) => (r.phone || '').replace(/\D/g, '').endsWith(id.replace(/\D/g, '').slice(-9)));
        if (!match) {
          setErr('Nomor telepon tidak terdaftar. Daftar dulu yuk, gratis!');
          setBusy(false);
          return;
        }
        loginEmail = match.email;
      }
      const { data, error } = await supabase.auth.signInWithPassword({ email: loginEmail, password });
      if (error) throw error;
      if (!data.session) {
        setPendingEmail(loginEmail);
        switchMode('verify');
        return;
      }
      toast('Selamat datang kembali di FastApp ⚡', 'success');
    } catch (e2) {
      setErr(prettyAuthError(e2 instanceof Error ? e2.message : ''));
    } finally {
      setBusy(false);
    }
  };

  /** Registrasi dengan email + nomor telepon opsional */
  const doRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(''); setInfo('');
    const nm = name.trim();
    const em = email.trim();
    const ph = phone.trim();
    if (nm.length < 2) return setErr('Masukkan nama lengkap Anda (min. 2 huruf).');
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) return setErr('Masukkan alamat email yang valid.');
    if (ph && !looksLikePhone(ph)) return setErr('Nomor telepon tidak valid. Contoh: 08123456789.');
    if (password.length < 6) return setErr('Kata sandi minimal 6 karakter.');
    if (password !== confirm) return setErr('Konfirmasi kata sandi tidak cocok.');
    setBusy(true);
    try {
      const { data, error } = await supabase.auth.signUp({
        email: em,
        password,
        options: {
          data: { full_name: nm, phone: ph },
          emailRedirectTo: window.location.origin,
        },
      });
      if (error) throw error;
      if (!data.session) {
        setPendingEmail(em);
        switchMode('verify');
        toast('Pendaftaran berhasil! Cek email untuk verifikasi.', 'success');
        return;
      }
      toast('Akun berhasil dibuat. Selamat datang! 🎉', 'success');
    } catch (e2) {
      setErr(prettyAuthError(e2 instanceof Error ? e2.message : ''));
    } finally {
      setBusy(false);
    }
  };

  const doForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(''); setInfo('');
    const em = email.trim() || identifier.trim();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) return setErr('Masukkan alamat email yang valid untuk reset kata sandi.');
    setBusy(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(em, {
        redirectTo: `${window.location.origin}/?mode=recovery`,
      });
      if (error) throw error;
      setInfo('Tautan reset kata sandi telah dikirim ke email Anda. Buka email lalu ikuti instruksinya.');
    } catch (e2) {
      setErr(prettyAuthError(e2 instanceof Error ? e2.message : ''));
    } finally {
      setBusy(false);
    }
  };

  const doRecovery = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(''); setInfo('');
    if (password.length < 6) return setErr('Kata sandi baru minimal 6 karakter.');
    if (password !== confirm) return setErr('Konfirmasi kata sandi tidak cocok.');
    setBusy(true);
    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;
      setInfo('Kata sandi berhasil diubah. Anda akan masuk otomatis…');
      window.setTimeout(() => { window.location.href = '/'; }, 1200);
    } catch (e2) {
      setErr(prettyAuthError(e2 instanceof Error ? e2.message : ''));
    } finally {
      setBusy(false);
    }
  };

  const resendVerify = async () => {
    if (!pendingEmail) return;
    setBusy(true); setErr(''); setInfo('');
    try {
      const { error } = await supabase.auth.resend({ type: 'signup', email: pendingEmail });
      if (error) throw error;
      setInfo('Email verifikasi dikirim ulang. Periksa kotak masuk & folder spam Anda.');
    } catch (e2) {
      setErr(prettyAuthError(e2 instanceof Error ? e2.message : ''));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-full flex bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      {/* Panel kiri — branding */}
      <div className="hidden lg:flex lg:w-[46%] relative overflow-hidden bg-gradient-to-br from-teal-700 via-teal-600 to-emerald-600 text-white flex-col justify-between p-12">
        <div className="absolute inset-0 opacity-[0.14]" style={{ backgroundImage: 'radial-gradient(#fff 1.4px, transparent 1.4px)', backgroundSize: '26px 26px' }} />
        <div className="absolute -right-24 -top-24 w-96 h-96 rounded-full bg-white/10 blur-2xl" />
        <div className="absolute -left-16 bottom-10 w-72 h-72 rounded-full bg-emerald-300/20 blur-2xl" />
        <div className="relative flex items-center gap-3">
          <Logo size={46} />
          <div>
            <div className="text-2xl font-extrabold tracking-tight">FastApp</div>
            <div className="text-teal-100 text-sm">Chat super cepat, kapan pun</div>
          </div>
        </div>
        <div className="relative space-y-7">
          <h1 className="text-4xl xl:text-5xl font-extrabold leading-tight">
            Ngobrol makin seru,<br />makin <span className="text-lime-300">ngebut.</span>
          </h1>
          <div className="space-y-4 text-teal-50">
            {[
              { icon: <Zap size={20} />, t: 'Kilat & ringan', d: 'Pesan terkirim dalam sekejap, hemat kuota.' },
              { icon: <Users size={20} />, t: 'Chat pribadi & grup', d: 'Ngobrol 1 lawan 1 atau bareng komunitas.' },
              { icon: <PhoneCall size={20} />, t: 'Voice & video call', d: 'Telepon suara dan video langsung dari chat.' },
              { icon: <ShieldCheck size={20} />, t: 'Aman terkendali', d: 'Privasi, blokir, dan laporan dalam genggaman.' },
            ].map((f, i) => (
              <motion.div key={i} initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.15 + i * 0.12 }} className="flex gap-3 items-start">
                <span className="p-2.5 rounded-xl bg-white/15 backdrop-blur shrink-0">{f.icon}</span>
                <span><span className="font-bold block">{f.t}</span><span className="text-sm text-teal-100">{f.d}</span></span>
              </motion.div>
            ))}
          </div>
        </div>
        <div className="relative text-sm text-teal-100">© 2026 FastApp • Buatan Indonesia 🇮🇩</div>
      </div>

      {/* Panel kanan — form */}
      <div className="flex-1 flex items-center justify-center p-5 sm:p-10">
        <motion.div
          key={mode}
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          <div className="lg:hidden flex items-center gap-3 mb-8 justify-center">
            <Logo size={48} />
            <div>
              <div className="text-2xl font-extrabold tracking-tight text-teal-700 dark:text-teal-300">FastApp</div>
              <div className="text-xs text-slate-500 dark:text-slate-400">Chat super cepat ⚡</div>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-xl shadow-slate-200/60 dark:shadow-black/40 border border-slate-200/70 dark:border-slate-800 p-6 sm:p-8">
            {mode !== 'verify' && (
              <div className="mb-6">
                <h2 className="text-2xl font-extrabold">
                  {mode === 'login' && 'Selamat datang kembali 👋'}
                  {mode === 'register' && 'Buat akun baru ✨'}
                  {mode === 'forgot' && 'Lupa kata sandi? 🔑'}
                  {mode === 'recovery' && 'Atur kata sandi baru 🔐'}
                </h2>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                  {mode === 'login' && 'Masuk untuk lanjut ngobrol dengan temanmu.'}
                  {mode === 'register' && 'Daftar gratis, langsung bisa chat sepuasnya.'}
                  {mode === 'forgot' && 'Kami akan kirim tautan reset ke email Anda.'}
                  {mode === 'recovery' && 'Masukkan kata sandi baru untuk akun Anda.'}
                </p>
              </div>
            )}

            {err && (
              <div className="mb-4 text-sm bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 rounded-xl px-4 py-3 fa-animate-fade-in">
                {err}
              </div>
            )}
            {info && (
              <div className="mb-4 text-sm bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 rounded-xl px-4 py-3 fa-animate-fade-in">
                {info}
              </div>
            )}

            {mode === 'login' && (
              <form onSubmit={doLogin} className="space-y-4">
                <Field icon={<UserIcon size={18} />} label="Email atau Nomor Telepon">
                  <input
                    value={identifier} onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="nama@email.com / 0812…" autoComplete="username"
                    className="w-full bg-transparent outline-none placeholder:text-slate-400"
                  />
                </Field>
                <Field icon={<Lock size={18} />} label="Kata Sandi" action={
                  <button type="button" onClick={() => setShowPw(!showPw)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300" aria-label="Tampilkan sandi">
                    {showPw ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                }>
                  <input
                    type={showPw ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••" autoComplete="current-password"
                    className="w-full bg-transparent outline-none placeholder:text-slate-400"
                  />
                </Field>
                <div className="flex justify-end">
                  <button type="button" onClick={() => switchMode('forgot')} className="text-sm font-semibold text-teal-600 dark:text-teal-400 hover:underline">
                    Lupa kata sandi?
                  </button>
                </div>
                <Submit busy={busy} label="Masuk" />
                <Divider />
                <GoogleBtn onClick={() => signInWithGoogle('FastApp')} />
                <Swap q="Belum punya akun?" a="Daftar gratis" onClick={() => switchMode('register')} />
              </form>
            )}

            {mode === 'register' && (
              <form onSubmit={doRegister} className="space-y-4">
                <Field icon={<UserIcon size={18} />} label="Nama Lengkap">
                  <input value={name} onChange={(e) => setName(e.target.value)} placeholder="cth: Budi Santoso" autoComplete="name" className="w-full bg-transparent outline-none placeholder:text-slate-400" />
                </Field>
                <Field icon={<Mail size={18} />} label="Email">
                  <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="nama@email.com" autoComplete="email" className="w-full bg-transparent outline-none placeholder:text-slate-400" />
                </Field>
                <Field icon={<Phone size={18} />} label="Nomor Telepon (opsional)">
                  <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="cth: 08123456789" autoComplete="tel" className="w-full bg-transparent outline-none placeholder:text-slate-400" />
                </Field>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Field icon={<Lock size={18} />} label="Kata Sandi">
                    <input type={showPw ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Min. 6 karakter" autoComplete="new-password" className="w-full bg-transparent outline-none placeholder:text-slate-400" />
                  </Field>
                  <Field icon={<Lock size={18} />} label="Konfirmasi">
                    <input type={showPw ? 'text' : 'password'} value={confirm} onChange={(e) => setConfirm(e.target.value)} placeholder="Ulangi sandi" autoComplete="new-password" className="w-full bg-transparent outline-none placeholder:text-slate-400" />
                  </Field>
                </div>
                <label className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400 cursor-pointer">
                  <input type="checkbox" checked={showPw} onChange={(e) => setShowPw(e.target.checked)} className="accent-teal-600 w-4 h-4" />
                  Tampilkan kata sandi
                </label>
                <Submit busy={busy} label="Daftar Sekarang" />
                <Divider />
                <GoogleBtn onClick={() => signInWithGoogle('FastApp')} />
                <Swap q="Sudah punya akun?" a="Masuk" onClick={() => switchMode('login')} />
              </form>
            )}

            {mode === 'forgot' && (
              <form onSubmit={doForgot} className="space-y-4">
                <Field icon={<Mail size={18} />} label="Email Terdaftar">
                  <input value={email || identifier} onChange={(e) => { setEmail(e.target.value); }} placeholder="nama@email.com" autoComplete="email" className="w-full bg-transparent outline-none placeholder:text-slate-400" />
                </Field>
                <Submit busy={busy} label="Kirim Tautan Reset" />
                <BackBtn onClick={() => switchMode('login')} label="Kembali masuk" />
              </form>
            )}

            {mode === 'recovery' && (
              <form onSubmit={doRecovery} className="space-y-4">
                <Field icon={<Lock size={18} />} label="Kata Sandi Baru">
                  <input type={showPw ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Min. 6 karakter" autoComplete="new-password" className="w-full bg-transparent outline-none placeholder:text-slate-400" />
                </Field>
                <Field icon={<Lock size={18} />} label="Konfirmasi Sandi Baru">
                  <input type={showPw ? 'text' : 'password'} value={confirm} onChange={(e) => setConfirm(e.target.value)} placeholder="Ulangi sandi baru" autoComplete="new-password" className="w-full bg-transparent outline-none placeholder:text-slate-400" />
                </Field>
                <Submit busy={busy} label="Simpan Kata Sandi" />
              </form>
            )}

            {mode === 'verify' && (
              <div className="text-center py-4">
                <div className="mx-auto w-20 h-20 rounded-full bg-teal-100 dark:bg-teal-900/40 flex items-center justify-center mb-5">
                  <Mail size={36} className="text-teal-600 dark:text-teal-400" />
                </div>
                <h2 className="text-xl font-extrabold mb-2">Verifikasi email Anda 📧</h2>
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-1">
                  Kami mengirim tautan verifikasi ke:
                </p>
                <p className="font-bold text-teal-700 dark:text-teal-300 mb-4 break-all">{pendingEmail || email}</p>
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">
                  Klik tautan di email tersebut, lalu kembali dan masuk. Cek juga folder spam ya!
                </p>
                <div className="space-y-3">
                  <button
                    onClick={() => switchMode('login')}
                    className="w-full py-3 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white font-bold transition"
                  >
                    Saya Sudah Verifikasi — Masuk
                  </button>
                  <button
                    onClick={resendVerify} disabled={busy}
                    className="w-full py-3 rounded-2xl border border-slate-300 dark:border-slate-700 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 transition disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {busy && <Loader2 size={17} className="animate-spin" />}
                    Kirim Ulang Email
                  </button>
                </div>
              </div>
            )}
          </div>

          <p className="text-center text-xs text-slate-400 mt-5 flex items-center justify-center gap-1.5">
            <ShieldCheck size={13} /> Kata sandi terenkripsi & sesi Anda terlindungi.
          </p>
        </motion.div>
      </div>
    </div>
  );
}

function Field({ icon, label, children, action }: { icon: React.ReactNode; label: string; children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide">{label}</span>
      <span className="mt-1.5 flex items-center gap-2.5 bg-slate-100 dark:bg-slate-800 border border-transparent focus-within:border-teal-500 focus-within:bg-white dark:focus-within:bg-slate-900 rounded-2xl px-4 py-3 transition">
        <span className="text-slate-400">{icon}</span>
        <span className="flex-1 flex text-[15px]">{children}</span>
        {action}
      </span>
    </label>
  );
}

function Submit({ busy, label }: { busy: boolean; label: string }) {
  return (
    <button
      type="submit" disabled={busy}
      className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white font-extrabold shadow-lg shadow-teal-600/25 transition disabled:opacity-60 flex items-center justify-center gap-2"
    >
      {busy && <Loader2 size={18} className="animate-spin" />}
      {busy ? 'Memproses…' : label}
    </button>
  );
}

function Divider() {
  return (
    <div className="flex items-center gap-3 text-xs text-slate-400 font-semibold">
      <span className="flex-1 h-px bg-slate-200 dark:bg-slate-800" /> ATAU <span className="flex-1 h-px bg-slate-200 dark:bg-slate-800" />
    </div>
  );
}

function GoogleBtn({ onClick }: { onClick: () => void }) {
  return (
    <button
      type="button" onClick={onClick}
      className="w-full py-3 rounded-2xl border border-slate-300 dark:border-slate-700 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 transition flex items-center justify-center gap-2.5"
    >
      <svg width="19" height="19" viewBox="0 0 24 24">
        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.27-4.74 3.27-8.1Z" />
        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A11 11 0 0 0 12 23Z" />
        <path fill="#FBBC05" d="M5.84 14.1a6.6 6.6 0 0 1 0-4.2V7.06H2.18a11 11 0 0 0 0 9.88l3.66-2.84Z" />
        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15A11 11 0 0 0 2.18 7.06l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38Z" />
      </svg>
      Lanjutkan dengan Google
    </button>
  );
}

function Swap({ q, a, onClick }: { q: string; a: string; onClick: () => void }) {
  return (
    <p className="text-center text-sm text-slate-500 dark:text-slate-400">
      {q}{' '}
      <button type="button" onClick={onClick} className="font-bold text-teal-600 dark:text-teal-400 hover:underline">
        {a}
      </button>
    </p>
  );
}

function BackBtn({ onClick, label }: { onClick: () => void; label: string }) {
  return (
    <button type="button" onClick={onClick} className="w-full flex items-center justify-center gap-1 text-sm font-bold text-slate-500 dark:text-slate-400 hover:text-teal-600 py-1">
      <ChevronLeft size={16} /> {label}
    </button>
  );
}

export function SplashScreen() {
  return (
    <div className="h-full flex flex-col items-center justify-center bg-gradient-to-br from-teal-700 via-teal-600 to-emerald-600 text-white gap-4">
      <motion.div initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: 'spring', stiffness: 200, damping: 14 }}>
        <Logo size={84} className="!rounded-[26px] !shadow-2xl" />
      </motion.div>
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="text-center">
        <div className="text-3xl font-extrabold tracking-tight">FastApp</div>
        <div className="text-teal-100 text-sm mt-1 flex items-center gap-1.5 justify-center">
          <MessageCircle size={14} /> Menghubungkan…
        </div>
      </motion.div>
      <div className="w-40 h-1.5 rounded-full bg-white/20 overflow-hidden">
        <motion.div className="h-full bg-white rounded-full" initial={{ x: '-100%' }} animate={{ x: '220%' }} transition={{ repeat: Infinity, duration: 1.1, ease: 'easeInOut' }} style={{ width: '45%' }} />
      </div>
    </div>
  );
}
