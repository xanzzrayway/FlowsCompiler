import { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import supabase from '../lib/supabase';
import { apiPost, apiGet, type UserProfile } from '../lib/api';

interface AuthCtx {
  authUser: User | null;
  session: Session | null;
  profile: UserProfile | null;
  loading: boolean;
  refreshProfile: () => Promise<void>;
  updateProfile: (patch: Partial<UserProfile>) => Promise<UserProfile | null>;
  signOut: () => Promise<void>;
}

const Ctx = createContext<AuthCtx>({
  authUser: null, session: null, profile: null, loading: true,
  refreshProfile: async () => {}, updateProfile: async () => null, signOut: async () => {},
});

export const useAuth = () => useContext(Ctx);

function usernameFrom(email: string): string {
  const base = (email.split('@')[0] || 'pengguna').toLowerCase().replace(/[^a-z0-9._]/g, '').slice(0, 20) || 'pengguna';
  return base + Math.floor(Math.random() * 900 + 100);
}

async function ensureProfile(user: User): Promise<UserProfile | null> {
  try {
    const existing = await apiGet<UserProfile | null>(`/api/users?id=${user.id}`);
    if (existing) return existing;
  } catch { /* lanjut buat baru */ }
  const email = user.email || '';
  const meta = (user.user_metadata || {}) as Record<string, string>;
  const name = meta.full_name || meta.name || (email ? email.split('@')[0] : 'Pengguna FastApp');
  try {
    const created = await apiPost<UserProfile>('/api/users', {
      id: user.id,
      email,
      phone: meta.phone || '',
      name,
      username: meta.username || usernameFrom(email || user.id),
      avatar_url: meta.avatar_url || meta.picture || '',
      bio: 'Hai! Saya memakai FastApp ⚡',
    });
    return created;
  } catch (e) {
    console.error('ensureProfile gagal:', e);
    return null;
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const booted = useRef(false);

  const loadFor = async (user: User | null) => {
    if (!user) {
      setProfile(null);
      return;
    }
    const p = await ensureProfile(user);
    setProfile(p);
  };

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const { data } = await supabase.auth.getSession();
        if (!alive) return;
        setSession(data.session ?? null);
        setAuthUser(data.session?.user ?? null);
        await loadFor(data.session?.user ?? null);
      } catch (e) {
        console.error('getSession:', e);
      } finally {
        if (alive) { setLoading(false); booted.current = true; }
      }
    })();
    const { data: sub } = supabase.auth.onAuthStateChange(async (_ev, sess) => {
      if (!alive) return;
      setSession(sess ?? null);
      setAuthUser(sess?.user ?? null);
      if (booted.current) await loadFor(sess?.user ?? null);
    });
    return () => { alive = false; sub.subscription.unsubscribe(); };
  }, []);

  const value = useMemo<AuthCtx>(() => ({
    authUser, session, profile, loading,
    refreshProfile: async () => {
      if (!authUser) return;
      try {
        const p = await apiGet<UserProfile | null>(`/api/users?id=${authUser.id}`);
        if (p) setProfile(p);
      } catch (e) { console.error('refreshProfile:', e); }
    },
    updateProfile: async (patch) => {
      if (!authUser) return null;
      try {
        const res = await fetch('/api/users', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: authUser.id, ...patch }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data?.error || 'Gagal menyimpan profil');
        setProfile(data as UserProfile);
        return data as UserProfile;
      } catch (e) {
        console.error('updateProfile:', e);
        throw e;
      }
    },
    signOut: async () => {
      try {
        if (authUser) {
          await fetch('/api/users', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: authUser.id, is_online: false, last_seen: new Date().toISOString() }),
          });
        }
      } catch { /* abaikan */ }
      await supabase.auth.signOut();
      setAuthUser(null);
      setSession(null);
      setProfile(null);
    },
  }), [authUser, session, profile, loading]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
