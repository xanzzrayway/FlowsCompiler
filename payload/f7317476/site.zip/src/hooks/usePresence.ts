import { useEffect, useRef } from 'react';

/** Heartbeat online + set offline saat tab ditutup. */
export function usePresence(myId: string | null) {
  const idRef = useRef(myId);
  idRef.current = myId;

  useEffect(() => {
    if (!myId) return;
    let alive = true;
    const beat = async (online: boolean) => {
      try {
        await fetch('/api/users', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: myId, is_online: online, last_seen: new Date().toISOString() }),
        });
      } catch { /* abaikan */ }
    };
    beat(true);
    const t = window.setInterval(() => { if (alive) void beat(true); }, 25000);
    const onHide = () => { if (document.visibilityState === 'hidden') void beat(false); };
    const onShow = () => { if (document.visibilityState === 'visible') void beat(true); };
    const onUnload = () => {
      try {
        const blob = new Blob([JSON.stringify({ id: idRef.current, is_online: false, last_seen: new Date().toISOString() })], { type: 'application/json' });
        navigator.sendBeacon('/api/users', blob);
      } catch { /* abaikan */ }
    };
    document.addEventListener('visibilitychange', onHide);
    document.addEventListener('visibilitychange', onShow);
    window.addEventListener('pagehide', onUnload);
    window.addEventListener('beforeunload', onUnload);
    return () => {
      alive = false;
      window.clearInterval(t);
      document.removeEventListener('visibilitychange', onHide);
      document.removeEventListener('visibilitychange', onShow);
      window.removeEventListener('pagehide', onUnload);
      window.removeEventListener('beforeunload', onUnload);
    };
  }, [myId]);
}
