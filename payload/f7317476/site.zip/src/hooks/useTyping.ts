import { useEffect, useRef } from 'react';
import type { RealtimeChannel } from '@supabase/supabase-js';
import supabase from '../lib/supabase';

/** Kirim & terima typing indicator via Supabase Broadcast (tanpa tabel). */

const channels = new Map<number, RealtimeChannel>();
const refCount = new Map<number, number>();

function getChannel(chatId: number): RealtimeChannel {
  let ch = channels.get(chatId);
  if (!ch) {
    ch = supabase.channel(`typing-${chatId}`, { config: { broadcast: { self: false } } });
    void ch.subscribe();
    channels.set(chatId, ch);
  }
  return ch;
}

export function useTypingChannel(chatId: number | null, myId: string, onTyping: (userId: string, typing: boolean) => void) {
  const cb = useRef(onTyping);
  cb.current = onTyping;

  useEffect(() => {
    if (!chatId) return;
    refCount.set(chatId, (refCount.get(chatId) || 0) + 1);
    const ch = getChannel(chatId);
    const sub = ch.on('broadcast', { event: 'typing' }, (msg) => {
      const p = msg.payload as { user_id?: string; typing?: boolean };
      if (p?.user_id && p.user_id !== myId) cb.current(p.user_id, !!p.typing);
    });
    void sub.subscribe();
    return () => {
      const n = (refCount.get(chatId) || 1) - 1;
      if (n <= 0) {
        refCount.delete(chatId);
        const c = channels.get(chatId);
        if (c) {
          channels.delete(chatId);
          void supabase.removeChannel(c);
        }
      } else {
        refCount.set(chatId, n);
      }
    };
  }, [chatId, myId]);
}

export async function broadcastTyping(chatId: number, userId: string, typing: boolean) {
  try {
    const ch = getChannel(chatId);
    await ch.send({ type: 'broadcast', event: 'typing', payload: { user_id: userId, typing } });
  } catch { /* abaikan */ }
}
