import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { call_id, after_id } = req.query;
      if (!call_id) return res.status(400).json({ error: 'call_id wajib diisi' });
      const { data, error } = await supabase.from('call_signals').select('*').eq('call_id', call_id).gt('id', Number(after_id) || 0).order('id', { ascending: true }).limit(100);
      if (error) throw error;
      return res.status(200).json(data || []);
    }
    if (req.method === 'POST') {
      const body = req.body || {};
      const { call_id, from_id, to_id, kind, payload } = body;
      if (!call_id || !from_id || !kind) return res.status(400).json({ error: 'call_id, from_id, kind wajib diisi' });
      const { data, error } = await supabase.from('call_signals').insert({ call_id, from_id, to_id: to_id || null, kind, payload: payload || {} }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'DELETE') {
      const p = { ...(req.query || {}), ...(req.body || {}) };
      if (!p.call_id) return res.status(400).json({ error: 'call_id wajib diisi' });
      const { error } = await supabase.from('call_signals').delete().eq('call_id', p.call_id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('signals api:', err);
    return res.status(500).json({ error: err.message });
  }
}
