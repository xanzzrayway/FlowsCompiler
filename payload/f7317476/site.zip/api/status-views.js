import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { status_id } = req.query;
      if (!status_id) return res.status(400).json({ error: 'status_id wajib diisi' });
      const { data, error } = await supabase.from('status_views').select('*').eq('status_id', status_id).order('viewed_at', { ascending: true });
      if (error) throw error;
      const uids = [...new Set((data || []).map((v) => v.viewer_id))];
      let users = [];
      if (uids.length) {
        const u = await supabase.from('users').select('*').in('id', uids);
        users = u.data || [];
      }
      const umap = Object.fromEntries(users.map((u) => [u.id, u]));
      return res.status(200).json((data || []).map((v) => ({ ...v, user: umap[v.viewer_id] || null })));
    }
    if (req.method === 'POST') {
      const body = req.body || {};
      const { status_id, viewer_id } = body;
      if (!status_id || !viewer_id) return res.status(400).json({ error: 'status_id dan viewer_id wajib diisi' });
      const ex = await supabase.from('status_views').select('*').eq('status_id', status_id).eq('viewer_id', viewer_id).maybeSingle();
      if (ex.data) return res.status(200).json(ex.data);
      const { data, error } = await supabase.from('status_views').insert({ status_id, viewer_id }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('status-views api:', err);
    return res.status(500).json({ error: err.message });
  }
}
