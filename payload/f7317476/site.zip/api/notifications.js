import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { user_id } = req.query;
      if (!user_id) return res.status(400).json({ error: 'user_id wajib diisi' });
      const { data, error } = await supabase.from('notifications').select('*').eq('user_id', user_id).order('created_at', { ascending: false }).limit(30);
      if (error) throw error;
      return res.status(200).json(data || []);
    }
    if (req.method === 'POST') {
      const body = req.body || {};
      const { user_id, title, body: text, chat_id, kind } = body;
      if (!user_id) return res.status(400).json({ error: 'user_id wajib diisi' });
      const { data, error } = await supabase.from('notifications').insert({ user_id, title: title || '', body: text || '', chat_id: chat_id || null, kind: kind || 'message' }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const body = req.body || {};
      const { id, user_id, all } = body;
      if (all && user_id) {
        const { error } = await supabase.from('notifications').update({ is_read: true }).eq('user_id', user_id);
        if (error) throw error;
        return res.status(200).json({ ok: true });
      }
      if (!id) return res.status(400).json({ error: 'id wajib diisi' });
      const { error } = await supabase.from('notifications').update({ is_read: true }).eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    if (req.method === 'DELETE') {
      const p = { ...(req.query || {}), ...(req.body || {}) };
      if (!p.user_id) return res.status(400).json({ error: 'user_id wajib diisi' });
      const { error } = await supabase.from('notifications').delete().eq('user_id', p.user_id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('notifications api:', err);
    return res.status(500).json({ error: err.message });
  }
}
