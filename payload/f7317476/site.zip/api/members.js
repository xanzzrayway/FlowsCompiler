import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { chat_id } = req.query;
      if (!chat_id) return res.status(400).json({ error: 'chat_id wajib diisi' });
      const { data, error } = await supabase.from('chat_members').select('*').eq('chat_id', chat_id).order('joined_at', { ascending: true });
      if (error) throw error;
      const uids = [...new Set((data || []).map((m) => m.user_id))];
      let users = [];
      if (uids.length) {
        const u = await supabase.from('users').select('*').in('id', uids);
        users = u.data || [];
      }
      const umap = Object.fromEntries(users.map((u) => [u.id, u]));
      return res.status(200).json((data || []).map((m) => ({ ...m, user: umap[m.user_id] || null })));
    }
    if (req.method === 'POST') {
      const body = req.body || {};
      const { chat_id, user_id, role } = body;
      if (!chat_id || !user_id) return res.status(400).json({ error: 'chat_id dan user_id wajib diisi' });
      const ex = await supabase.from('chat_members').select('*').eq('chat_id', chat_id).eq('user_id', user_id).maybeSingle();
      if (ex.data) return res.status(200).json(ex.data);
      const { data, error } = await supabase.from('chat_members').insert({ chat_id, user_id, role: role || 'member' }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const body = req.body || {};
      const { chat_id, user_id } = body;
      if (!chat_id || !user_id) return res.status(400).json({ error: 'chat_id dan user_id wajib diisi' });
      const patch = {};
      if (body.role !== undefined) patch.role = body.role;
      if (body.muted !== undefined) patch.muted = body.muted;
      if (body.archived !== undefined) patch.archived = body.archived;
      if (body.pinned !== undefined) patch.pinned = body.pinned;
      if (body.last_read_at !== undefined) patch.last_read_at = body.last_read_at;
      const { data, error } = await supabase.from('chat_members').update(patch).eq('chat_id', chat_id).eq('user_id', user_id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const p = { ...(req.query || {}), ...(req.body || {}) };
      const { chat_id, user_id } = p;
      if (!chat_id || !user_id) return res.status(400).json({ error: 'chat_id dan user_id wajib diisi' });
      const { error } = await supabase.from('chat_members').delete().eq('chat_id', chat_id).eq('user_id', user_id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('members api:', err);
    return res.status(500).json({ error: err.message });
  }
}
