import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const now = new Date().toISOString();
      const { data, error } = await supabase.from('statuses').select('*').gt('expires_at', now).order('created_at', { ascending: false }).limit(200);
      if (error) throw error;
      const rows = data || [];
      if (!rows.length) return res.status(200).json([]);
      const uids = [...new Set(rows.map((s) => s.user_id))];
      const sids = rows.map((s) => s.id);
      const uRes = await supabase.from('users').select('*').in('id', uids);
      const vRes = await supabase.from('status_views').select('*').in('status_id', sids);
      const umap = Object.fromEntries((uRes.data || []).map((u) => [u.id, u]));
      const vBy = {};
      for (const v of vRes.data || []) {
        if (!vBy[v.status_id]) vBy[v.status_id] = [];
        vBy[v.status_id].push(v);
      }
      return res.status(200).json(rows.map((s) => ({ ...s, user: umap[s.user_id] || null, views: vBy[s.id] || [] })));
    }
    if (req.method === 'POST') {
      const body = req.body || {};
      const { user_id, kind, body: text, media_url, bg } = body;
      if (!user_id) return res.status(400).json({ error: 'user_id wajib diisi' });
      const expires_at = new Date(Date.now() + 24 * 3600 * 1000).toISOString();
      const { data, error } = await supabase.from('statuses').insert({ user_id, kind: kind || 'text', body: text || '', media_url: media_url || '', bg: bg || '' }).select().single();
      if (error) throw error;
      await supabase.from('statuses').update({ expires_at }).eq('id', data.id);
      data.expires_at = expires_at;
      return res.status(201).json(data);
    }
    if (req.method === 'DELETE') {
      const p = { ...(req.query || {}), ...(req.body || {}) };
      if (!p.id) return res.status(400).json({ error: 'id wajib diisi' });
      await supabase.from('status_views').delete().eq('status_id', p.id);
      const { error } = await supabase.from('statuses').delete().eq('id', p.id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('statuses api:', err);
    return res.status(500).json({ error: err.message });
  }
}
