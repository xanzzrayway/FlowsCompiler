import supabase from './db-client.js';

const RANK = { sent: 0, delivered: 1, read: 2 };

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { message_ids } = req.query;
      const ids = message_ids ? String(message_ids).split(',').map(Number).filter(Boolean) : [];
      if (!ids.length) return res.status(200).json([]);
      const { data, error } = await supabase.from('message_receipts').select('*').in('message_id', ids);
      if (error) throw error;
      return res.status(200).json(data || []);
    }
    if (req.method === 'POST') {
      const body = req.body || {};
      const { message_id, user_id, status } = body;
      const st = status || 'delivered';
      if (!message_id || !user_id) return res.status(400).json({ error: 'message_id dan user_id wajib diisi' });
      const ex = await supabase.from('message_receipts').select('*').eq('message_id', message_id).eq('user_id', user_id).maybeSingle();
      if (ex.data) {
        if ((RANK[ex.data.status] ?? 0) >= (RANK[st] ?? 0)) return res.status(200).json(ex.data);
        const { data, error } = await supabase.from('message_receipts').update({ status: st, updated_at: new Date().toISOString() }).eq('id', ex.data.id).select().single();
        if (error) throw error;
        return res.status(200).json(data);
      }
      const { data, error } = await supabase.from('message_receipts').insert({ message_id, user_id, status: st }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const body = req.body || {};
      const { chat_id, user_id, status } = body;
      const st = status || 'read';
      if (!chat_id || !user_id) return res.status(400).json({ error: 'chat_id dan user_id wajib diisi' });
      const msgs = await supabase.from('messages').select('id,sender_id').eq('chat_id', chat_id).order('id', { ascending: false }).limit(500);
      const targets = (msgs.data || []).filter((m) => m.sender_id !== user_id).map((m) => m.id);
      if (!targets.length) return res.status(200).json({ ok: true, count: 0 });
      const existing = await supabase.from('message_receipts').select('*').in('message_id', targets).eq('user_id', user_id);
      const exMap = Object.fromEntries((existing.data || []).map((r) => [r.message_id, r]));
      const needRank = RANK[st] ?? 0;
      const toUp = [];
      const toIns = [];
      for (const mid of targets) {
        const ex = exMap[mid];
        if (!ex) toIns.push({ message_id: mid, user_id, status: st });
        else if ((RANK[ex.status] ?? 0) < needRank) toUp.push(ex.id);
      }
      if (toUp.length) await supabase.from('message_receipts').update({ status: st, updated_at: new Date().toISOString() }).in('id', toUp);
      if (toIns.length) await supabase.from('message_receipts').insert(toIns);
      return res.status(200).json({ ok: true, count: toUp.length + toIns.length });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('receipts api:', err);
    return res.status(500).json({ error: err.message });
  }
}
