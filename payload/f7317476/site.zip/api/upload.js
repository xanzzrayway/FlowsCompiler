import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'POST') {
      const body = req.body || {};
      const fileName = body.fileName || 'file';
      const safe = String(fileName).replace(/[^a-zA-Z0-9._-]+/g, '_').slice(0, 80) || 'file';
      const path = 'chat/' + Date.now() + '-' + Math.random().toString(36).slice(2, 8) + '-' + safe;
      const { data, error } = await supabase.storage.from('fastapp-media').createSignedUploadUrl(path);
      if (error) throw error;
      const pub = supabase.storage.from('fastapp-media').getPublicUrl(path);
      return res.status(200).json({ uploadUrl: data.signedUrl, publicUrl: pub.data.publicUrl, path });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('upload api:', err);
    return res.status(500).json({ error: err.message });
  }
}
