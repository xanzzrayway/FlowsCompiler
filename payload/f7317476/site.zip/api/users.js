import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { id, ids, q } = req.query;
      if (id) {
        const { data, error } = await supabase.from('users').select('*').eq('id', id).maybeSingle();
        if (error) throw error;
        return res.status(200).json(data || null);
      }
      if (ids) {
        const arr = String(ids).split(',').filter(Boolean);
        if (!arr.length) return res.status(200).json([]);
        const { data, error } = await supabase.from('users').select('*').in('id', arr);
        if (error) throw error;
        return res.status(200).json(data || []);
      }
      if (q) {
        const s = String(q).slice(0, 60);
        const { data, error } = await supabase.from('users').select('*').or('name.ilike.%' + s + '%,username.ilike.%' + s + '%,email.ilike.%' + s + '%,phone.ilike.%' + s + '%').limit(20);
        if (error) throw error;
        return res.status(200).json(data || []);
      }
      const { data, error } = await supabase.from('users').select('*').order('created_at', { ascending: false }).limit(50);
      if (error) throw error;
      return res.status(200).json(data || []);
    }
    if (req.method === 'POST') {
      const body = req.body || {};
      if (!body.id) return res.status(400).json({ error: 'id wajib diisi' });
      const { data, error } = await supabase.from('users').upsert(body, { onConflict: 'id' }).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'PUT') {
      const body = req.body || {};
      const { id } = body;
      if (!id) return res.status(400).json({ error: 'id wajib diisi' });
      const fields = { ...body };
      delete fields.id;
      delete fields.created_at;
      const { data, error } = await supabase.from('users').update(fields).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('users api:', err);
    return res.status(500).json({ error: err.message });
  }
}
