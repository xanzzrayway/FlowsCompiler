import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { id, user_id, history } = req.query;
      if (id) {
        const { data, error } = await supabase.from('calls').select('*').eq('id', id).maybeSingle();
        if (error) throw error;
        return res.status(200).json(data || null);
      }
      if (!user_id) return res.status(400).json({ error: 'user_id wajib diisi' });
      if (history) {
        const { data, error } = await supabase.from('calls').select('*').or('caller_id.eq.' + user_id + ',callee_id.eq.' + user_id).order('created_at', { ascending: false }).limit(30);
        if (error) throw error;
        return res.status(200).json(data || []);
      }
      const { data, error } = await supabase.from('calls').select('*').or('caller_id.eq.' + user_id + ',callee_id.eq.' + user_id).in('status', ['ringing', 'ongoing']).order('created_at', { ascending: false }).limit(5);
      if (error) throw error;
      return res.status(200).json(data || []);
    }
    if (req.method === 'POST') {
      const body = req.body || {};
      const { chat_id, caller_id, callee_id, call_type } = body;
      if (!caller_id || !callee_id) return res.status(400).json({ error: 'caller_id dan callee_id wajib diisi' });
      const bl = await supabase.from('blocks').select('id').or('and(blocker_id.eq.' + caller_id + ',blocked_id.eq.' + callee_id + '),and(blocker_id.eq.' + callee_id + ',blocked_id.eq.' + caller_id + ')').limit(1);
      if (bl.data && bl.data.length) return res.status(403).json({ error: 'Panggilan tidak dapat dilakukan karena pemblokiran.' });
      const busy = await supabase.from('calls').select('id').or('caller_id.eq.' + callee_id + ',callee_id.eq.' + callee_id).in('status', ['ringing', 'ongoing']).limit(1);
      if (busy.data && busy.data.length) return res.status(409).json({ error: 'Pengguna sedang dalam panggilan lain.' });
      const { data, error } = await supabase.from('calls').insert({ chat_id: chat_id || null, caller_id, callee_id, call_type: call_type || 'voice', status: 'ringing' }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const body = req.body || {};
      const { id, status, ended_at } = body;
      if (!id) return res.status(400).json({ error: 'id wajib diisi' });
      const patch = {};
      if (status) patch.status = status;
      if (ended_at || (status && ['ended', 'rejected', 'missed', 'cancelled'].includes(status))) patch.ended_at = ended_at || new Date().toISOString();
      const { data, error } = await supabase.from('calls').update(patch).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('calls api:', err);
    return res.status(500).json({ error: err.message });
  }
}
