import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { user_id } = req.query;
      if (!user_id) return res.status(400).json({ error: 'user_id wajib diisi' });
      const a = await supabase.from('blocks').select('*').eq('blocker_id', user_id);
      const b = await supabase.from('blocks').select('*').eq('blocked_id', user_id);
      return res.status(200).json({ blocked: ((a.data || []).map((r) => r.blocked_id)), blockedBy: ((b.data || []).map((r) => r.blocker_id)), rows: a.data || [] });
    }
    if (req.method === 'POST') {
      const body = req.body || {};
      const { blocker_id, blocked_id } = body;
      if (!blocker_id || !blocked_id) return res.status(400).json({ error: 'blocker_id dan blocked_id wajib diisi' });
      if (blocker_id === blocked_id) return res.status(400).json({ error: 'Tidak dapat memblokir diri sendiri' });
      const ex = await supabase.from('blocks').select('*').eq('blocker_id', blocker_id).eq('blocked_id', blocked_id).maybeSingle();
      if (ex.data) return res.status(200).json(ex.data);
      const { data, error } = await supabase.from('blocks').insert({ blocker_id, blocked_id }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'DELETE') {
      const p = { ...(req.query || {}), ...(req.body || {}) };
      if (!p.blocker_id || !p.blocked_id) return res.status(400).json({ error: 'blocker_id dan blocked_id wajib diisi' });
      const { error } = await supabase.from('blocks').delete().eq('blocker_id', p.blocker_id).eq('blocked_id', p.blocked_id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('blocks api:', err);
    return res.status(500).json({ error: err.message });
  }
}
