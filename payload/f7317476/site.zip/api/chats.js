import supabase from './db-client.js';

async function enrichChats(chatRows, meId) {
  if (!chatRows.length) return [];
  const chatIds = chatRows.map((c) => c.id);
  const memRes = await supabase.from('chat_members').select('*').in('chat_id', chatIds);
  const msgRes = await supabase.from('messages').select('*').in('chat_id', chatIds).eq('is_deleted', false).order('id', { ascending: false }).limit(600);
  const allMembers = memRes.data || [];
  const allMsgs = msgRes.data || [];
  const userIds = [...new Set(allMembers.map((m) => m.user_id))];
  let users = [];
  if (userIds.length) {
    const u = await supabase.from('users').select('*').in('id', userIds);
    users = u.data || [];
  }
  const userMap = Object.fromEntries(users.map((u) => [u.id, u]));
  const byChat = {};
  for (const m of allMsgs) {
    if (!byChat[m.chat_id]) byChat[m.chat_id] = [];
    byChat[m.chat_id].push(m);
  }
  const lastByChat = {};
  const lastIds = [];
  for (const cid of chatIds) {
    const arr = (byChat[cid] || []).filter((m) => !((m.deleted_for || []).includes(meId)));
    lastByChat[cid] = arr[0] || null;
    if (arr[0]) lastIds.push(arr[0].id);
  }
  let rcByMsg = {};
  if (lastIds.length) {
    const r = await supabase.from('message_receipts').select('*').in('message_id', lastIds);
    for (const x of r.data || []) {
      if (!rcByMsg[x.message_id]) rcByMsg[x.message_id] = [];
      rcByMsg[x.message_id].push(x);
    }
  }
  return chatRows
    .map((c) => {
      const mems = allMembers.filter((m) => m.chat_id === c.id).map((m) => ({ ...m, user: userMap[m.user_id] || null }));
      const me = allMembers.find((m) => m.chat_id === c.id && m.user_id === meId) || {};
      const arr = byChat[c.id] || [];
      const lastRead = me.last_read_at ? new Date(me.last_read_at).getTime() : 0;
      const unread = arr.filter((m) => m.sender_id !== meId && new Date(m.created_at).getTime() > lastRead && !((m.deleted_for || []).includes(meId))).length;
      const last = lastByChat[c.id];
      return {
        ...c,
        members: mems,
        my: { muted: !!me.muted, archived: !!me.archived, pinned: !!me.pinned, role: me.role || 'member', last_read_at: me.last_read_at },
        last_message: last,
        last_receipts: last ? rcByMsg[last.id] || [] : [],
        unread,
      };
    })
    .sort((a, b) => Number(b.my.pinned) - Number(a.my.pinned) || (new Date(b.updated_at || b.created_at).getTime() - new Date(a.updated_at || a.created_at).getTime()));
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { user_id, id } = req.query;
      if (id) {
        const { data: chat, error } = await supabase.from('chats').select('*').eq('id', id).single();
        if (error) throw error;
        const out = await enrichChats([chat], user_id || '');
        return res.status(200).json(out[0] || chat);
      }
      if (!user_id) return res.status(400).json({ error: 'user_id wajib diisi' });
      const { data: myMembers, error: mErr } = await supabase.from('chat_members').select('*').eq('user_id', user_id);
      if (mErr) throw mErr;
      if (!myMembers || !myMembers.length) return res.status(200).json([]);
      const chatIds = [...new Set(myMembers.map((m) => m.chat_id))];
      const { data: chats, error } = await supabase.from('chats').select('*').in('id', chatIds);
      if (error) throw error;
      const out = await enrichChats(chats || [], user_id);
      return res.status(200).json(out);
    }
    if (req.method === 'POST') {
      const body = req.body || {};
      const type = body.type || 'direct';
      const created_by = body.created_by;
      const member_ids = body.member_ids || [];
      const name = body.name || '';
      const avatar_url = body.avatar_url || '';
      const description = body.description || '';
      if (!member_ids.length) return res.status(400).json({ error: 'member_ids wajib diisi' });
      if (type === 'direct' && member_ids.length === 2) {
        const m1 = await supabase.from('chat_members').select('chat_id').eq('user_id', member_ids[0]);
        const ids1 = (m1.data || []).map((r) => r.chat_id);
        if (ids1.length) {
          const m2 = await supabase.from('chat_members').select('chat_id').eq('user_id', member_ids[1]).in('chat_id', ids1);
          for (const r of m2.data || []) {
            const ch = await supabase.from('chats').select('*').eq('id', r.chat_id).maybeSingle();
            if (ch.data && ch.data.type === 'direct') return res.status(200).json({ ...ch.data, existed: true });
          }
        }
      }
      const { data: chat, error } = await supabase.from('chats').insert({ type, name, avatar_url, description, created_by }).select().single();
      if (error) throw error;
      const rows = [...new Set(member_ids)].map((uid) => ({
        chat_id: chat.id,
        user_id: uid,
        role: type === 'group' && uid === created_by ? 'admin' : 'member',
      }));
      const { error: mErr } = await supabase.from('chat_members').insert(rows);
      if (mErr) throw mErr;
      return res.status(201).json(chat);
    }
    if (req.method === 'PUT') {
      const body = req.body || {};
      const { id } = body;
      if (!id) return res.status(400).json({ error: 'id wajib diisi' });
      const patch = {};
      if (body.name !== undefined) patch.name = body.name;
      if (body.avatar_url !== undefined) patch.avatar_url = body.avatar_url;
      if (body.description !== undefined) patch.description = body.description;
      const { data, error } = await supabase.from('chats').update(patch).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const p = { ...(req.query || {}), ...(req.body || {}) };
      const { id, user_id } = p;
      if (!id || !user_id) return res.status(400).json({ error: 'id dan user_id wajib diisi' });
      const leaving = await supabase.from('chat_members').select('*').eq('chat_id', id).eq('user_id', user_id).maybeSingle();
      await supabase.from('chat_members').delete().eq('chat_id', id).eq('user_id', user_id);
      const rest = await supabase.from('chat_members').select('*').eq('chat_id', id);
      const restRows = rest.data || [];
      if (!restRows.length) {
        const msgs = await supabase.from('messages').select('id').eq('chat_id', id);
        const mids = (msgs.data || []).map((m) => m.id);
        if (mids.length) {
          await supabase.from('message_receipts').delete().in('message_id', mids);
          await supabase.from('reactions').delete().in('message_id', mids);
          await supabase.from('messages').delete().in('id', mids);
        }
        await supabase.from('calls').update({ chat_id: null }).eq('chat_id', id);
        await supabase.from('chats').delete().eq('id', id);
        return res.status(200).json({ ok: true, removed_chat: true });
      }
      if (leaving.data && leaving.data.role === 'admin' && !restRows.some((m) => m.role === 'admin')) {
        const next = [...restRows].sort((a, b) => new Date(a.joined_at).getTime() - new Date(b.joined_at).getTime())[0];
        await supabase.from('chat_members').update({ role: 'admin' }).eq('id', next.id);
      }
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('chats api:', err);
    return res.status(500).json({ error: err.message });
  }
}
