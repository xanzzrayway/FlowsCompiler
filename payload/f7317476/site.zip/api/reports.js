import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { reporter_id } = req.query;
      let q = supabase.from('reports').select('*').order('created_at', { ascending: false }).limit(50);
      if (reporter_id) q = q.eq('reporter_id', reporter_id);
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json(data || []);
    }
    if (req.method === 'POST') {
      const body = req.body || {};
      const { reporter_id, reported_id, reason, detail } = body;
      if (!reporter_id || !reported_id) return res.status(400).json({ error: 'reporter_id dan reported_id wajib diisi' });
      const { data, error } = await supabase.from('reports').insert({ reporter_id, reported_id, reason: reason || '', detail: detail || '' }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('reports api:', err);
    return res.status(500).json({ error: err.message });
  }
}
