import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { chat_id, limit, before_id, q } = req.query;
      if (!chat_id) return res.status(400).json({ error: 'chat_id wajib diisi' });
      let rows = [];
      if (q) {
        const s = String(q).slice(0, 80);
        const { data, error } = await supabase.from('messages').select('*').eq('chat_id', chat_id).ilike('body', '%' + s + '%').order('id', { ascending: false }).limit(50);
        if (error) throw error;
        rows = (data || []).reverse();
      } else {
        let query = supabase.from('messages').select('*').eq('chat_id', chat_id).order('id', { ascending: false }).limit(Math.min(Number(limit) || 60, 150));
        if (before_id) query = query.lt('id', Number(before_id));
        const { data, error } = await query;
        if (error) throw error;
        rows = (data || []).reverse();
      }
      const rids = [...new Set(rows.filter((m) => m.reply_to).map((m) => m.reply_to))];
      const quoted = {};
      if (rids.length) {
        const qs = await supabase.from('messages').select('*').in('id', rids);
        for (const m of qs.data || []) quoted[m.id] = m;
      }
      return res.status(200).json({ messages: rows, quoted });
    }
    if (req.method === 'POST') {
      const b = req.body || {};
      if (!b.chat_id || !b.sender_id) return res.status(400).json({ error: 'chat_id dan sender_id wajib diisi' });
      const chatRes = await supabase.from('chats').select('*').eq('id', b.chat_id).maybeSingle();
      if (!chatRes.data) return res.status(404).json({ error: 'Chat tidak ditemukan' });
      if (chatRes.data.type === 'direct') {
        const mems = await supabase.from('chat_members').select('user_id').eq('chat_id', b.chat_id);
        const other = (mems.data || []).map((m) => m.user_id).find((u) => u !== b.sender_id);
        if (other) {
          const bl = await supabase.from('blocks').select('id').or('and(blocker_id.eq.' + b.sender_id + ',blocked_id.eq.' + other + '),and(blocker_id.eq.' + other + ',blocked_id.eq.' + b.sender_id + ')').limit(1);
          if (bl.data && bl.data.length) return res.status(403).json({ error: 'Pesan tidak dapat dikirim karena pemblokiran. Buka blokir terlebih dahulu.' });
        }
      }
      const row = {
        chat_id: b.chat_id,
        sender_id: b.sender_id,
        kind: b.kind || 'text',
        body: b.body || '',
        media_url: b.media_url || '',
        media_name: b.media_name || '',
        media_size: b.media_size || 0,
        media_mime: b.media_mime || '',
        duration: b.duration || 0,
        contact_data: b.contact_data || null,
        location_data: b.location_data || null,
        reply_to: b.reply_to || null,
        forwarded: !!b.forwarded,
        forwarded_from: b.forwarded_from || '',
      };
      const { data, error } = await supabase.from('messages').insert(row).select().single();
      if (error) throw error;
      await supabase.from('chats').update({ updated_at: new Date().toISOString() }).eq('id', b.chat_id);
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const b = req.body || {};
      if (b.clear_chat_for && b.chat_id) {
        const all = await supabase.from('messages').select('id,deleted_for').eq('chat_id', b.chat_id).limit(2000);
        const rows = all.data || [];
        const targets = rows.filter((m) => !((m.deleted_for || []).includes(b.clear_chat_for)));
        for (let i = 0; i < targets.length; i += 40) {
          await Promise.all(targets.slice(i, i + 40).map((m) => supabase.from('messages').update({ deleted_for: [...(m.deleted_for || []), b.clear_chat_for] }).eq('id', m.id)));
        }
        return res.status(200).json({ ok: true, cleared: targets.length });
      }
      const { id } = b;
      if (!id) return res.status(400).json({ error: 'id wajib diisi' });
      const patch = {};
      if (b.body !== undefined) { patch.body = b.body; patch.edited = true; patch.edited_at = new Date().toISOString(); }
      if (b.is_pinned !== undefined) patch.is_pinned = b.is_pinned;
      if (b.is_deleted !== undefined) patch.is_deleted = b.is_deleted;
      if (b.deleted_for !== undefined) patch.deleted_for = b.deleted_for;
      const { data, error } = await supabase.from('messages').update(patch).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const p = { ...(req.query || {}), ...(req.body || {}) };
      if (!p.id) return res.status(400).json({ error: 'id wajib diisi' });
      await supabase.from('message_receipts').delete().eq('message_id', p.id);
      await supabase.from('reactions').delete().eq('message_id', p.id);
      const { error } = await supabase.from('messages').delete().eq('id', p.id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('messages api:', err);
    return res.status(500).json({ error: err.message });
  }
}
