import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { message_id, message_ids, chat_id } = req.query;
      if (chat_id) {
        const msgs = await supabase.from('messages').select('id').eq('chat_id', chat_id).order('id', { ascending: false }).limit(400);
        const mids = (msgs.data || []).map((m) => m.id);
        if (!mids.length) return res.status(200).json([]);
        const { data, error } = await supabase.from('reactions').select('*').in('message_id', mids).order('id', { ascending: true });
        if (error) throw error;
        return res.status(200).json(data || []);
      }
      let ids = [];
      if (message_ids) ids = String(message_ids).split(',').map(Number).filter(Boolean);
      else if (message_id) ids = [Number(message_id)];
      if (!ids.length) return res.status(200).json([]);
      const { data, error } = await supabase.from('reactions').select('*').in('message_id', ids).order('id', { ascending: true });
      if (error) throw error;
      return res.status(200).json(data || []);
    }
    if (req.method === 'POST') {
      const body = req.body || {};
      const { message_id, user_id, emoji } = body;
      if (!message_id || !user_id || !emoji) return res.status(400).json({ error: 'message_id, user_id, emoji wajib diisi' });
      const ex = await supabase.from('reactions').select('*').eq('message_id', message_id).eq('user_id', user_id).maybeSingle();
      if (ex.data) {
        if (ex.data.emoji === emoji) {
          await supabase.from('reactions').delete().eq('id', ex.data.id);
          return res.status(200).json({ removed: true });
        }
        const { data, error } = await supabase.from('reactions').update({ emoji }).eq('id', ex.data.id).select().single();
        if (error) throw error;
        return res.status(200).json(data);
      }
      const { data, error } = await supabase.from('reactions').insert({ message_id, user_id, emoji }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'DELETE') {
      const p = { ...(req.query || {}), ...(req.body || {}) };
      if (!p.message_id || !p.user_id) return res.status(400).json({ error: 'message_id dan user_id wajib diisi' });
      const { error } = await supabase.from('reactions').delete().eq('message_id', p.message_id).eq('user_id', p.user_id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('reactions api:', err);
    return res.status(500).json({ error: err.message });
  }
}
